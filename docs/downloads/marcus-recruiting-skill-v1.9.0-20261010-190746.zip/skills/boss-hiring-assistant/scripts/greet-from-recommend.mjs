#!/usr/bin/env node
/**
 * greet-from-recommend.mjs — 推荐页「一人一事务」打招呼闭环
 *
 * 对名单里的每位候选人依次执行：
 *   关面板 → 按姓名唯一绑定卡片 → 打 ASCII 标记 → 滚到视口 →
 *   /clickAtFrame 点姓名开面板 → 打标记 → /clickAtFrame 点打招呼 →
 *   三处成功确认 → remove() 关面板 → 随机间隔
 *
 * 用法：
 *   node greet-from-recommend.mjs <targetId> --names-file=names.txt [--max=5] [--dry]
 *
 * 硬规则遵守：
 *   - 中文只从 UTF-8 文件进（Windows argv 传中文会坏）
 *   - iframe 内点击走 /clickAtFrame（`::iframe::` 前缀已废弃）
 *   - 标记值一律 ASCII
 *   - 相邻打招呼随机间隔 2000~5000ms；每 2~3 人额外 5~10s 轻校验
 *   - 单轮上限默认 5（approval-policy.yaml max_batch_greet）
 *   - 检测到 verify / 安全验证 页立即停止整轮
 *
 * 输出：每行  name|RESULT|detail
 *   RESULT ∈ SUCCESS | SUCCESS_UNCONFIRMED | NOT_FOUND | NO_PANEL | NO_BTN | FAILED | SKIPPED | DRY
 *   SUCCESS_UNCONFIRMED（D2）：卡片被虚拟滚动回收、取不到按钮文案时，
 *   用「标记已清 + 面板按钮消失 + 面板已关/成功类 toast」作备用判据通过；
 *   已计入发送数（不重复补发），但需人工复核，汇报时单独列出。
 * 退出码：0=全部处理完 2=触发风控中止 3=达到单轮上限
 */

import fs from 'node:fs';

const BASE = process.env.WEB_ACCESS_BASE || 'http://localhost:3456';
const TARGET = process.argv[2];
const fileArg = process.argv.find((a) => a.startsWith('--names-file='));
const maxArg = process.argv.find((a) => a.startsWith('--max='));
const MAX = maxArg ? parseInt(maxArg.split('=')[1], 10) : 5;
const DRY = process.argv.includes('--dry');
const FRAME = 'iframe[src*=recommend]';

if (!TARGET || !fileArg) {
  console.error('用法: node greet-from-recommend.mjs <targetId> --names-file=names.txt [--max=5] [--dry]');
  process.exit(1);
}
const NAMES = fs
  .readFileSync(fileArg.split('=').slice(1).join('='), 'utf8')
  .split(/\r?\n/)
  .map((s) => s.trim())
  .filter(Boolean);

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ts = () => new Date().toTimeString().slice(0, 8);

async function ev(js) {
  const res = await fetch(`${BASE}/eval?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: js,
  });
  const j = await res.json();
  if (j.error) throw new Error(j.error);
  return j.value;
}

/** iframe 内真实鼠标点击 */
async function clickAtFrame(selector) {
  const res = await fetch(`${BASE}/clickAtFrame?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ frame: FRAME, selector }),
  });
  const j = await res.json().catch(() => ({}));
  if (res.ok && j.clicked) return j;

  // 兼容仍未提供 /clickAtFrame、但已提供 /clickAt 的 proxy：
  // 先在顶层页面创建一个 pointer-events:none 的定位锚点，再让 /clickAt
  // 通过 CDP Input.dispatchMouseEvent 点击锚点坐标。真实命中的是锚点下方
  // iframe 内的目标元素，仍属于浏览器级可信点击，绝不退回 element.click()。
  if (res.status !== 404 && j.error !== String.fromCharCode(26410, 30693, 31471, 28857)) {
    throw new Error('clickAtFrame 失败: ' + JSON.stringify(j).slice(0, 160));
  }
  const pos = JSON.parse(await ev(`var f=document.querySelector(${JSON.stringify(FRAME)});
var d=f&&f.contentDocument,e=d&&d.querySelector(${JSON.stringify(selector)});
if(!e){JSON.stringify({ok:false,error:'selector not found'});}else{
e.scrollIntoView({block:'center'});
var er=e.getBoundingClientRect(),fr=f.getBoundingClientRect();
var x=fr.left+er.left+er.width/2,y=fr.top+er.top+er.height/2;
var a=document.getElementById('__wb_click_anchor');
if(!a){a=document.createElement('div');a.id='__wb_click_anchor';document.documentElement.appendChild(a);}
a.style.cssText='position:fixed;pointer-events:none;z-index:2147483647;width:2px;height:2px;left:'+(x-1)+'px;top:'+(y-1)+'px';
JSON.stringify({ok:true,x:x,y:y});}`));
  if (!pos.ok) throw new Error('clickAtFrame 坐标定位失败: ' + pos.error);
  const click = await fetch(`${BASE}/clickAt?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: '#__wb_click_anchor',
  });
  const out = await click.json().catch(() => ({}));
  await ev(`var a=document.getElementById('__wb_click_anchor');if(a)a.remove();'ok'`);
  if (!click.ok || !out.clicked) throw new Error('clickAt 兼容点击失败: ' + JSON.stringify(out).slice(0, 160));
  return {...out, fallback: 'trusted-coordinate-click'};
}

/** 风控探针 */
async function riskCheck() {
  const v = await ev(`JSON.stringify({u:location.href,v:location.href.indexOf('verify')>=0,
    t:document.body.innerText.indexOf(String.fromCharCode(23433,20840,39564,35777))>=0})`);
  const o = JSON.parse(v);
  return o.v || o.t;
}

const CLOSE_ALL = `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.querySelectorAll('.dialog-wrap').forEach(function(w){w.remove()});'ok'`;

/** 按姓名唯一绑定卡片并打标记；返回 {ok, matched, name} */
const locate = (name) => `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var cs=d.querySelectorAll('.candidate-card-wrap');
cs.forEach(function(c){c.removeAttribute('data-wb-open')});
var key=${JSON.stringify(name)}, hit=null, n=0;
cs.forEach(function(c){var e=c.querySelector('.name');
  if(e&&e.innerText.trim()===key){n++;hit=c;}});
if(n!==1){JSON.stringify({ok:false,matched:n});}else{
  hit.setAttribute('data-wb-open','s');
  var r=hit.getBoundingClientRect();
  d.documentElement.scrollTop=d.documentElement.scrollTop+r.top-200;
  JSON.stringify({ok:true,matched:n,name:hit.querySelector('.name').innerText.trim()});}`;

const READ_PANEL = `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var p=d.querySelector('.lib-standard-resume,.dialog-lib-resume');
p?p.innerText.replace(/\\s+/g,' ').slice(0,600):'NO_PANEL'`;

/**
 * 「同事沟通进度」探测。
 * **仅作信息参考**（2026-09-19 用户规定：同事是否沟通过不影响打招呼）。
 * 探测结果只写进日志与汇总，**不改变发送决策**。
 * 在页面内判定并只回传布尔值：该区块位于面板末尾，用 slice 截断会漏判。
 */
const HAS_COLLEAGUE_CONTACT = `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var p=d.querySelector('.resume-right-side,.lib-standard-resume,.dialog-lib-resume');
var K=String.fromCharCode(21516,20107,27807,36890);
JSON.stringify({dup: p? p.innerText.replace(/\\s+/g,'').indexOf(K)>=0 : false})`;

/** 打打招呼按钮标记，返回按钮文案 */
const MARK_GREET = `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var b=d.querySelector('.btn-sure-v2.btn-greet');
if(!b){JSON.stringify({ok:false});}else{
  b.setAttribute('data-workbuddy-greet-target','g1');
  JSON.stringify({ok:true,txt:b.innerText.trim(),n:d.querySelectorAll('[data-workbuddy-greet-target]').length});}`;

/** 三处成功确认（中文用 charCode，避免传参编码问题）
 *  D2（2026-09-19）：额外回报备用判据 —— toast 提示文案、面板是否已消失、卡片是否仍在 DOM。
 *  卡片可能被虚拟滚动回收，此时 cardBtn 会是 'CARD_GONE'，不能据此硬判失败。
 */
const verify = (name) => `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var left=d.querySelectorAll('[data-workbuddy-greet-target]').length;
var panelBtn=d.querySelector('.btn-sure-v2.btn-greet')?1:0;
var card=null;
d.querySelectorAll('.candidate-card-wrap').forEach(function(c){var e=c.querySelector('.name');
  if(e&&e.innerText.trim()===${JSON.stringify(name)})card=c;});
var JX=String.fromCharCode(32487,32493);
var txt=card?((card.querySelector('button')||{}).innerText||'').trim():'CARD_GONE';
var toast='';
d.querySelectorAll('[class*=toast],[class*=Toast],[class*=message],[class*=Message]').forEach(function(e){
  var t=(e.innerText||'').trim();
  if(t && t.length && t.length<60 && e.getBoundingClientRect().width>0) toast=t;});
JSON.stringify({markerLeft:left,panelBtn:panelBtn,cardBtn:txt,cardOk:txt.indexOf(JX)>=0,
  cardGone:txt==='CARD_GONE',toast:toast,panelGone:d.querySelectorAll('.dialog-wrap').length===0});`;

/** D2 备用判据：面板已关 + 标记已清 + 有成功类 toast */
const toastLooksSuccess = (t) => /成功|已发送|已打招呼|已沟通|已联系/.test(t || '');

(async () => {
  const results = [];
  let done = 0;

  for (const name of NAMES) {
    if (done >= MAX) {
      console.log(`[${ts()}] 已达单轮上限 ${MAX} 人，停止本轮`);
      results.push(`${name}|SKIPPED|单轮上限`);
      break;
    }
    if (await riskCheck()) {
      console.log(`[${ts()}] ⛔ 检测到安全验证页，立即停止本轮`);
      results.push(`${name}|SKIPPED|风控验证`);
      process.exitCode = 2;
      break;
    }

    try {
      await ev(CLOSE_ALL);

      const m = JSON.parse(await ev(locate(name)));
      if (!m.ok) {
        console.log(`${name}|NOT_FOUND|同名或不在DOM(matched=${m.matched})`);
        results.push(`${name}|NOT_FOUND|matched=${m.matched}`);
        continue;
      }

      await sleep(rand(300, 700));
      await clickAtFrame('.candidate-card-wrap[data-wb-open="s"] .name');
      await sleep(rand(1200, 2200));

      let panel = await ev(READ_PANEL);
      if (panel === 'NO_PANEL') {
        await sleep(rand(800, 1400));
        await clickAtFrame('.candidate-card-wrap[data-wb-open="s"] .name');
        await sleep(rand(1200, 2000));
        panel = await ev(READ_PANEL);
        if (panel === 'NO_PANEL') {
          console.log(`${name}|NO_PANEL|面板未打开`);
          results.push(`${name}|NO_PANEL|`);
          await ev(CLOSE_ALL);
          continue;
        }
      }

      let g = JSON.parse(await ev(MARK_GREET));
      // 详情文字常先于底部操作区完成挂载；文字可读不代表“打招呼”按钮已就绪。
      // 首次未找到时再等待一次，避免把正常的异步加载误判为“已联系过”。
      if (!g.ok) {
        await sleep(rand(2200, 3200));
        g = JSON.parse(await ev(MARK_GREET));
      }
      if (!g.ok) {
        console.log(`${name}|NO_BTN|面板内无打招呼按钮(可能已联系过)`);
        results.push(`${name}|NO_BTN|`);
        await ev(CLOSE_ALL);
        continue;
      }

      // 同事沟通进度：仅作信息参考，不改变发送决策（2026-09-19 用户规定）
      const dup = JSON.parse(await ev(HAS_COLLEAGUE_CONTACT)).dup;
      if (dup) {
        console.log(`${name}|INFO|面板显示同事已有沟通记录（按用户规定不影响打招呼，继续发送）`);
      }

      if (DRY) {
        console.log(`${name}|DRY|按钮「${g.txt}」可点，未实际发送`);
        results.push(`${name}|DRY|`);
        await ev(CLOSE_ALL);
        continue;
      }

      await sleep(rand(400, 900));
      await clickAtFrame('[data-workbuddy-greet-target="g1"]');
      await sleep(rand(2000, 3200));

      const v = JSON.parse(await ev(verify(name)));
      const ok = v.markerLeft === 0 && v.panelBtn === 0 && v.cardOk;
      // D2 备用判据：卡片被虚拟滚动回收（取不到卡片按钮文案）时，
      // 退化为「标记已清 + 面板内打招呼按钮已消失 + 面板已关（或出现成功类 toast）」。
      // 判不出就记 success_unconfirmed：待复核，不硬判失败、也不重复补发。
      const backupOk =
        v.cardGone && v.markerLeft === 0 && v.panelBtn === 0 && (v.panelGone || toastLooksSuccess(v.toast));

      if (ok) {
        done++;
        console.log(`[${ts()}] ${name}|SUCCESS|(第${done}人) 卡片按钮=「${v.cardBtn}」`);
        results.push(`${name}|SUCCESS|`);
      } else if (backupOk) {
        done++; // 计入已发，避免下一轮重复补发
        console.log(
          `[${ts()}] ${name}|SUCCESS_UNCONFIRMED|(第${done}人) 卡片已滚出DOM，备用判据通过` +
            `${v.toast ? ` toast=「${v.toast}」` : ''} → 待复核，不重复补发`
        );
        results.push(`${name}|SUCCESS_UNCONFIRMED|cardGone panelGone=${v.panelGone} toast=${v.toast}`);
      } else {
        console.log(
          `${name}|FAILED|marker=${v.markerLeft} panelBtn=${v.panelBtn} cardBtn=${v.cardBtn}` +
            ` cardGone=${v.cardGone} toast=${v.toast}`
        );
        results.push(`${name}|FAILED|${JSON.stringify(v)}`);
      }

      await ev(CLOSE_ALL);
      await sleep(rand(2000, 5000)); // 随机间隔（风控硬规则）

      // 每 2 人额外做一次轻校验停顿（5~10s）
      if (done > 0 && done % 2 === 0) {
        const extra = rand(5000, 10000);
        console.log(`[${ts()}] 轻校验停顿 ${(extra / 1000).toFixed(1)}s`);
        await sleep(extra);
      }
    } catch (e) {
      console.log(`${name}|FAILED|${e.message}`);
      results.push(`${name}|FAILED|${e.message}`);
      try { await ev(CLOSE_ALL); } catch {}
    }
  }

  console.log(`--- 汇总：本轮成功 ${done} 人 ---`);
  fs.writeFileSync(
    'C:/Users/Administrator/AppData/Local/Temp/bossx/greet-results.txt',
    results.join('\n'),
    'utf8'
  );
  if (done >= MAX) process.exitCode = 3;
})();
