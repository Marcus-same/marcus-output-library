#!/usr/bin/env node
/**
 * batch-read-resume.mjs — 批量打开候选人详情并读取简历要点
 *
 * 用途：对推荐页指定索引的候选人，逐个「滚动到视口 → 点姓名开面板 → 读经历概览 → 关面板」，
 *       全程使用随机间隔，输出紧凑的 索引|姓名|简历要点 结构，供主流程做 policy 判定。
 *
 * 用法：
 *   node batch-read-resume.mjs <targetId> <name1,name2,...> [--chars=500]
 *   node batch-read-resume.mjs <targetId> <idx1,idx2,...>  [--chars=500]
 *   node batch-read-resume.mjs <targetId> --names-file=names.txt [--chars=500]
 *
 * 说明：优先用**姓名**定位（索引会因列表自动轮换而失效）。
 *       参数全为数字时才按索引模式处理。
 *
 * 【Windows 硬规则】中文姓名**不要**走命令行参数：
 *   Windows 下 bash/argv 编码不可靠，中文会被破坏 → 姓名匹配必然失败
 *   （表现为 NOT_FOUND_IN_DOM）。必须用 --names-file=<UTF-8 文件> 传名单。
 *
 * 【切 tab 默认关闭】找不到姓名时默认**不**切 tab：
 *   切 tab 会重置 iframe 列表，把已滚动加载的候选池全部冲掉。
 *   只有显式加 --allow-tab-switch 才启用「轮换 tab 重试」。
 *
 * 输出：每行一条  key|name|resumeText
 * 退出码：0 正常，1 参数/连接错误
 */

const BASE = process.env.WEB_ACCESS_BASE || 'http://localhost:3456';
const TARGET = process.argv[2];
const fileArg = process.argv.find((a) => a.startsWith('--names-file='));
const ALLOW_TAB_SWITCH = process.argv.includes('--allow-tab-switch');
const JSON_OUTPUT = process.argv.includes('--json');
let RAW;
if (fileArg) {
  const fs = await import('node:fs');
  const p = fileArg.split('=').slice(1).join('=');
  if (!fs.existsSync(p)) {
    console.error(`名单文件不存在: ${p}`);
    process.exit(1);
  }
  RAW = fs.readFileSync(p, 'utf8').split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  console.error(`[names-file] 已载入 ${RAW.length} 人：${p}`);
} else {
  RAW = (process.argv[3] || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}
const BY_INDEX = RAW.length > 0 && RAW.every((s) => /^\d+$/.test(s));
const KEYS = BY_INDEX ? RAW.map((s) => parseInt(s, 10)) : RAW;
const charsArg = process.argv.find((a) => a.startsWith('--chars='));
const CHARS = charsArg ? parseInt(charsArg.split('=')[1], 10) : 500;
if (!Number.isSafeInteger(CHARS) || CHARS < 0) {
  console.error('--chars 必须是非负整数；0 表示完整右侧文字');
  process.exit(1);
}

if (!TARGET || !KEYS.length) {
  console.error('用法: node batch-read-resume.mjs <targetId> <name1,name2,...|idx1,idx2,...> [--chars=500]');
  process.exit(1);
}

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function ev(js) {
  const res = await fetch(`${BASE}/eval?target=${TARGET}`, {
    signal: AbortSignal.timeout(15000),
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: js,
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error);
  return json.value;
}

/**
 * 兼容层：web-access proxy 新版本（2026-09 起）已移除 /clickAt 的 `::iframe::` 前缀支持，
 * 改为独立的 POST /clickAtFrame + JSON body {frame, selector}。
 * 这里保留 `::iframe::` 调用写法，内部自动翻译，调用点无需改动。
 * 若 proxy 不支持 /clickAtFrame，自动回退旧的 `::iframe::` 前缀写法。
 */
const IFRAME_SEL = 'iframe[src*=recommend]';
async function clickAt(selector) {
  if (typeof selector === 'string' && selector.startsWith('::iframe::')) {
    const inner = selector.slice('::iframe::'.length);
    try {
      const r = await fetch(`${BASE}/clickAtFrame?target=${TARGET}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ frame: IFRAME_SEL, selector: inner }),
      });
      const j = await r.json();
      if (r.ok && j && j.clicked) return j;
      if (j && j.error === String.fromCharCode(26410,30693,31471,28857)) {
        const raw = await ev(`var f=document.querySelector('${IFRAME_SEL}');
var d=f&&f.contentDocument;var e=d&&d.querySelector(${JSON.stringify(inner)});
if(!e){JSON.stringify({clicked:false,error:'selector not found'});}else{
var rect=e.getBoundingClientRect(),cs=d.defaultView.getComputedStyle(e);
if(rect.width<=0||rect.height<=0||cs.display==='none'||cs.visibility==='hidden'){
JSON.stringify({clicked:false,error:'selector not visible'});
}else{e.click();JSON.stringify({clicked:true,fallback:'dom-control-click'});}}`);
        return JSON.parse(raw);
      }
      if (r.status === 404) throw new Error('__fallback__');
      return j;
    } catch (e) {
      if (e.message !== '__fallback__') throw e;
    }
  }
  const res = await fetch(`${BASE}/clickAt?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: selector,
  });
  return res.json();
}

const CLOSE_ALL = `var d=document.querySelector('iframe').contentDocument;
d.querySelectorAll('.dialog-wrap').forEach(function(w){w.remove()});'ok'`;

/**
 * 读详情面板文本。
 * 2026-09-19 实测：面板为左右两栏，左侧 .resume-center-side 装的是 WASM 渲染在
 * canvas 上的完整简历（无文本节点、不可滚动，读不出字），**右侧 .resume-right-side
 * 才是唯一可读文本**（经历概览 + 教育背景 + 同事沟通进度）。
 * 因此优先读右侧；右侧缺失时才退回读整个面板（兼容 BOSS 改版）。
 */
const READ_PANEL = (chars) => `var d=document.querySelector('iframe').contentDocument;
var r=d.querySelector('.resume-right-side');
var p=r || d.querySelector('.lib-standard-resume,.dialog-lib-resume');
p ? p.innerText.replace(/\\s+/g,' ') : 'NO_PANEL'`;

const TAB_REC = String.fromCharCode(25512, 33616); // 推荐
const TAB_LATEST = String.fromCharCode(26368, 26032); // 最新
let tabFlip = 0;

/** 切换标签：目标候选人不在当前批次时，靠轮换把它找回来 */
async function switchTab() {
  const label = tabFlip++ % 2 === 0 ? TAB_REC : TAB_LATEST;
  const json = JSON.stringify(label);
  await ev(`var d=document.querySelector('iframe').contentDocument;
d.querySelectorAll('.tab-item').forEach(function(e){e.removeAttribute('data-lobster-tab')});
var tgt=null;
d.querySelectorAll('.tab-item').forEach(function(e){ if(e.innerText.trim()===${json}) tgt=e; });
if(tgt) tgt.setAttribute('data-lobster-tab','go');
JSON.stringify({marked:!!tgt})`);
  await sleep(rand(400, 900));
  await clickAt('::iframe::[data-lobster-tab="go"]');
  await sleep(rand(2500, 4000));
}

const locateAndMark = (key) => {
  const locator = BY_INDEX
    ? `var hit=cs[${key}];`
    : `var hits=Array.from(cs).filter(function(c){var n=c.querySelector('.name');return n&&n.innerText.trim()===${JSON.stringify(key)};});var hit=hits.length===1?hits[0]:null;`;
  return `var d=document.querySelector('iframe').contentDocument;
var cs=d.querySelectorAll('.candidate-card-wrap');
cs.forEach(function(c){c.removeAttribute('data-lobster-open')});
${locator}
if(!hit) { JSON.stringify({ok:false,reason:typeof hits!=='undefined'&&hits.length>1?'AMBIGUOUS_NAME':'NOT_FOUND_IN_DOM'}); } else {
  hit.setAttribute('data-lobster-open','s');
  var r=hit.getBoundingClientRect();
  d.documentElement.scrollTop=d.documentElement.scrollTop+r.top-200;
  JSON.stringify({ok:true,name:(hit.querySelector('.name')||{}).innerText||''});
}`;
};

(async () => {
  for (const key of KEYS) {
    try {
      await ev(CLOSE_ALL);
      let m = JSON.parse(await ev(locateAndMark(key)));

      // 姓名模式：不在当前批次时，仅在显式允许时才轮换标签重试（最多 6 次）
      // 切 tab 会重置 iframe 列表 → 已加载的候选池会被冲掉，因此默认关闭
      if (!m.ok && m.reason !== 'AMBIGUOUS_NAME' && !BY_INDEX && ALLOW_TAB_SWITCH) {
        for (let r = 0; r < 6 && !m.ok; r++) {
          await switchTab();
          m = JSON.parse(await ev(locateAndMark(key)));
        }
      }

      if (!m.ok) {
        console.log(JSON_OUTPUT ? JSON.stringify({key,error:m.reason || 'NOT_FOUND_IN_DOM'}) : `${key}|${m.reason || 'NOT_FOUND_IN_DOM'}|`);
        continue;
      }

      await sleep(rand(300, 700));
      await clickAt('::iframe::.candidate-card-wrap[data-lobster-open="s"] .name');
      await sleep(rand(1200, 2200));

      let text = await ev(READ_PANEL(CHARS));
      // 面板若未打开，补试一次
      if (text === 'NO_PANEL') {
        await sleep(rand(800, 1500));
        await clickAt('::iframe::.candidate-card-wrap[data-lobster-open="s"] .name');
        await sleep(rand(1200, 2000));
        text = await ev(READ_PANEL(CHARS));
      }

      // 2026-09-19 修复：右区「经历概览」是**异步渲染**的 —— 实测打开后 1s 时 innerText 长度为 0，
      // 约 3s 后才出现内容。旧版只读一次，会把这类候选人误读成"只有操作区"的空面板。
      // 判据：文本里必须出现「经历概览」（charCode 20844,21382,27010,35272 需从页面取，
      // 这里改用长度 + 是否含 ASCII 时间戳 & 是否含页内中文标记的更稳做法：
      // 直接轮询「右区长度是否稳定且 > 80」）。
      if (text !== 'NO_PANEL' && text.length < 80) {
        for (let t = 0; t < 6; t++) {
          await sleep(rand(900, 1400));
          const again = await ev(READ_PANEL(CHARS));
          if (again !== 'NO_PANEL' && again.length > text.length) text = again;
          if (text.length >= 80) break;
        }
      }

      const fullLength = text === 'NO_PANEL' ? 0 : text.length;
      const truncated = CHARS > 0 && fullLength > CHARS;
      const excerpt = truncated ? text.slice(0, CHARS) : text;
      if (JSON_OUTPUT) {
        console.log(JSON.stringify({key,name:m.name,text:excerpt,fullLength,truncated,loaded:fullLength>=80}));
      } else {
        console.log(`${key}|${m.name}|${excerpt}`);
        console.error(JSON.stringify({key,fullLength,truncated,loaded:fullLength>=80}));
      }
      await ev(CLOSE_ALL);
      await sleep(rand(800, 1600));
    } catch (e) {
      console.log(JSON_OUTPUT ? JSON.stringify({key,error:e.message}) : `${key}|ERROR|${e.message}`);
    }
  }
  process.exit(0);
})();
