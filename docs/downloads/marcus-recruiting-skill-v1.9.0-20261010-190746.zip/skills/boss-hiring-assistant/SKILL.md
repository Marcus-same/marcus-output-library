---
name: boss-hiring-assistant
description: 面向 BOSS 直聘招聘流程的中文 skill。在本招聘工作区中主要由 recruit-daily 调用，负责推荐池扩池、卡片初筛、右侧文字复筛和入选候选人的在线简历截图深判；站内沟通和约面仍由工作区原流程控制。
---

# Boss Hiring Assistant

## Marcus recruiting skill 集成边界（本工作区最高优先级）

当本 skill 由 `skills/recruit-daily/SKILL.md` 调用时，只执行 BOSS 推荐池的
`recommended_feed` 寻访与筛选，并先完整读取
`../recruit-daily/references/boss-recommend-integration.md`。该集成文档在本场景中优先于本 skill
后续关于画像存储、自动打招呼、聊天和约面的说明。

- 招聘标准只取工作区 `CONTEXT.md` 与 `01-jd/_internal/<role>.md`；不要读取或采用本 skill
  自带的 `company-policy.yaml`、`approval-policy.yaml`、`data/profile.json` 或历史候选人数据。
- 在推荐池筛选阶段，只做扩池、卡片初筛、在线简历深筛和结果回传，不自行发送招呼、发消息、
  约面或点击平台“不合适”。当 `recruit-daily` 已保存本轮明确授权与逐名发送名单后，可由
  `recruit-daily` 再次调用本 skill 的推荐页发送方案执行真实点击和成功确认；本 skill 不负责
  决定授权是否成立，也不得扩大名单。
- 用户已明确要求：卡片初筛入选者先读取右侧文字，只有复筛后仍具潜力者才进一步截图深判。
  该授权只覆盖这些候选人的深筛截图，不覆盖全池截图、OCR 扫描或其他页面截图。
- 台账、去重、日报和关键词迭代仍由 `recruit-daily` 负责，本 skill 不另建事实源。
- 回传结果直接使用 `recruit-daily` 台账状态：`初筛通过 / 待确认 / 初筛不合适 / 已排除`，
  不再输出“强匹配／待人工确认／不匹配”等第二套同义分类。在线简历截图路径回传给
  `recruit-daily`，由其写入台账的 `简历路径` 列。
- 当 `CONTEXT.md` 能唯一确定一个本轮目标岗位且当前 BOSS 岗位不同，允许在复用的现有 BOSS tab
  内自动切岗；只有目标有歧义时才询问。切岗后必须核对可见岗位名与 `jobId`。对工作区事实源中
  已确认且能无歧义映射的筛选条件，按集成文档自动设置并校验；不得读取或回写本 skill 自带的
  `data/profile.json`，不得自行放宽条件或应用来源不明的历史筛选。

## 工作区执行入口

本工作区内直接调用本 skill 也必须先读 `../recruit-daily/references/boss-recommend-integration.md`，不进入独立安装版的聊天、画像存储或约面流程。

- 浏览器绑定与单标签恢复：读取 `references/browser-routing.md`，工作区规则优先。
- 推荐池卡片读取：读取 `references/boss-recommend-read-recipe.md`；选择器变化时暂停，不扩大自动操作。
- 筛选面板：`scripts/apply-profile-filters.mjs --profile-file=<工作区 runtime/boss-profile.json> --no-writeback`。
- 详情文字：`scripts/batch-read-resume.mjs <targetId> --names-file=<UTF-8文件> --json`；截断时 `--chars=0`。
- 滚动扩池：`scripts/human-scroll.mjs`，按集成文档的逐批筛选与停止条件执行。
- 深判截图仍由执行时按需调用，不对全池截图。
- 发送授权、名单和动作记录由 `recruit-daily` 管理；授权通过后的推荐页实际点击由本 skill 按
  `references/boss-greet-recipe.md` 和 `scripts/greet-from-recommend.mjs` 执行。其他站内消息按需读
  `references/boss-send-recipe.md`，仍不得绕过 `recruit-daily` 的授权闸门。
- `round-scan.mjs` 与 `round-execute.mjs` 为旧 Java 专用脚本，不适用于本工作区岗位，禁止在日常入口调用。
- 历史独立版文件保留但不参与此入口，包括企微约面、旧画像、公司 policy 与历史 data。
- 风控、登录异常、额度耗尽时保存进度并暂停；断线恢复按 `../recruit-daily/references/recovery-and-identity.md` 执行。
