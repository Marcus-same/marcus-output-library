# 逐人保存、身份核验与断点恢复

保留 `dedup-ledger.csv` 的现有表头与历史数据，不自动迁移或合并旧行。

## 身份

优先从页面已提供的信息取得 platform、candidateId、jobId；没有岗位 ID 时使用 CONTEXT 规范岗位名。不得猜测或把卡片序号当稳定 ID。平台没有稳定 ID 时使用本轮临时编号，并以姓名、公司、经历、教育核对；无法唯一绑定则待确认，禁止对外动作。

台账备注保存平台 ID，动作记录保存对应 ledgerNumber。姓名相同且 ID 不同是不同人；旧记录与新 ID 的关联必须有背景证据，保留原序号。

## 一人一事务

1. 卡片判断后立即保存 `screened` 动作及证据摘要；更新对应台账行。
2. 右侧文字与截图复筛后保存 `reviewed` 动作、台账状态及证据相对路径。
3. 用户授权的发送动作，点击前先保存 `greet_pending`；authorization 保存本轮明确授权的范围和数量，不能由脚本代为授权。
4. 页面明确成功并核验身份后保存 `greet_confirmed`，沿用同一 actionId；失败明确未发送保存 `greet_failed`；超时、断线或成功证据不足保存 `greet_unknown`。
5. 更新台账为已打招呼仅限 confirmed。pending/unknown 在备注写结果待核查，不覆盖初筛评级。

通过 `scripts/action-log.mjs --workspace=<绝对工作区> --event-file=<UTF-8 JSON>` 保存事件。事件必须包含 actionId（每次业务动作唯一）、runId、platform、candidateId、role、stage，可附 jobId、ledgerNumber、status、evidencePaths、authorization。每名候选人判断动作和打招呼动作使用不同 actionId；同一发送的 pending/confirmed/unknown 使用同一 actionId。

## 恢复

重新绑定现有 BOSS tab 后读取动作记录与台账。pending/unknown 先检查同一候选人的当前按钮或会话成功证据；不根据网络恢复推定发送成功。无法核实则等待用户，不重发。confirmed 不再发送。恢复未完成的读取与核验，不重复完成动作。授权只在原本明确的范围内有效，不因恢复而扩大。

`action-log.mjs --workspace=<绝对工作区> --summary-date=YYYY-MM-DD` 输出当日各动作最终阶段计数及待核查发送数。数据为个人招聘工作记录，不进入公开包。

动作记录使用短时独占锁与同步写入；写入失败时停止发送。锁遗留时核查是否有其他任务仍运行，不自动删除。CSV 更新先备份，写入临时文件、回读验证后替换，禁止在多会话中同时修改同一台账。
