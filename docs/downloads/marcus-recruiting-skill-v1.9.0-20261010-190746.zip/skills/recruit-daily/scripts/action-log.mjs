import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const args = Object.fromEntries(process.argv.slice(2).map(a => {
  const i = a.indexOf('='); return [a.slice(2, i), a.slice(i + 1)];
}));
if (!args.workspace || (!args['event-file'] && !args['summary-date'])) {
  throw new Error('Required: --workspace=<path> and --event-file=<path> or --summary-date=YYYY-MM-DD');
}
const runtime = path.join(path.resolve(args.workspace), 'runtime');
const log = path.join(runtime, 'recruit-actions.jsonl');
const read = () => fs.existsSync(log) ? fs.readFileSync(log, 'utf8').split(/\r?\n/).filter(Boolean).map(JSON.parse) : [];
const dateOf = time => new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit'
}).format(new Date(time));
const stages = new Set(['screened','reviewed','greet_pending','greet_confirmed','greet_failed','greet_unknown']);
if (args['event-file']) {
  const event = JSON.parse(fs.readFileSync(args['event-file'], 'utf8').replace(/^\uFEFF/, ''));
  for (const k of ['actionId','runId','platform','candidateId','role','stage']) {
    if (typeof event[k] !== 'string' || !event[k].trim()) throw new Error(`Missing ${k}`);
  }
  if (!stages.has(event.stage)) throw new Error('Invalid stage');
  if (event.stage === 'greet_pending' && !event.authorization) throw new Error('Explicit authorization required');
  fs.mkdirSync(runtime, {recursive:true});
  const lock = `${log}.lock`;
  const fd = fs.openSync(lock, 'wx');
  try {
    const prior = read().filter(e => e.actionId === event.actionId);
    if (prior.some(e => e.platform !== event.platform || e.candidateId !== event.candidateId || e.role !== event.role || (e.jobId || '') !== (event.jobId || ''))) {
      throw new Error('actionId identity mismatch');
    }
    const last = prior.at(-1);
    if (last?.stage === event.stage) {
      console.log(JSON.stringify({saved:false,reason:'duplicate-stage',actionId:event.actionId}));
    } else {
      if (last?.stage === 'greet_confirmed') throw new Error('Confirmed send cannot be reopened');
      if (event.stage.startsWith('greet_') && event.stage !== 'greet_pending' && !prior.some(e => e.stage === 'greet_pending')) throw new Error('Send requires prior pending record');
      if (event.stage === 'greet_pending' && last) throw new Error('Existing action cannot be resent');
      const record = {...event,eventId:crypto.randomUUID(),timestamp:new Date().toISOString()};
      const out = fs.openSync(log, 'a');
      try { fs.writeSync(out, JSON.stringify(record)+'\n'); fs.fsyncSync(out); } finally {fs.closeSync(out);}
      console.log(JSON.stringify({saved:true,eventId:record.eventId}));
    }
  } finally {fs.closeSync(fd); fs.unlinkSync(lock);}
} else {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(args['summary-date'])) throw new Error('Invalid summary date');
  const events = read();
  const latest = new Map();
  for (const e of events) latest.set(e.actionId,e);
  const counts = {};
  for (const e of latest.values()) if (dateOf(e.timestamp) === args['summary-date']) counts[e.stage]=(counts[e.stage] || 0)+1;
  const unresolved = [...latest.values()].filter(e => ['greet_pending','greet_unknown'].includes(e.stage));
  console.log(JSON.stringify({date:args['summary-date'],counts,unresolved},null,2));
}
