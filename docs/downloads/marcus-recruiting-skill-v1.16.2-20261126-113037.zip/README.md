# 1126（M）— Marcus 招聘 Skill 包

打包日期：2026-11-26

## 内容

- `skills/marcus-recruiting-skill/`：总入口，负责路由到 init / grill / daily
- `skills/recruit-init/`：初始化工作区
- `skills/recruit-grill/`：逐岗梳理真实要求
- `skills/recruit-daily/`：每日招聘流水线（含脚本与 references）
- `skills/web-access/`：受控浏览器依赖
- `_shared/templates/`：台账、候选人池、面试档案、JD 模板
- `skills/SHA256SUMS`：按本包当前文件重新生成的校验清单

## 不含

- 候选人台账、简历、截图、runtime 日志、浏览器会话等个人工作区数据
- 工作区的 `CONTEXT.md` / `AGENTS.md`（岗位标准与公司信息属于使用者私有）
- 本地筛选脚本（如 `runtime/screen2.mjs`、本地流水线脚本）

## 说明

- 解压后把 `skills/` 与 `_shared/` 放回工作区根目录即可使用。
- 本包为 2026-11-26 当天修改后的版本；修复记录见 `CHANGELOG-20261126.md`。
- 使用前仍需按各 SKILL.md 的要求配置工作区与浏览器授权。
