#!/usr/bin/env node
// 读取推荐池可见卡片：稳定ID(data-geekid) + 姓名 + 全文。只读。
// 用法：node read-cards.mjs <targetId> [--json-out=<file>]
import fs from 'node:fs';
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';

const TARGET = process.argv[2];
if (!TARGET) throw new Error('Usage: read-cards.mjs TARGET [--json-out=FILE]');
const outArg = (process.argv.find((a) => a.startsWith('--json-out=')) || '').split('=').slice(1).join('=');
assertBrowserAllowed(import.meta.url, { target: TARGET });
const client = createBrowserClient(import.meta.url, { target: TARGET });

const cards = JSON.parse(await client.ev(`(()=>{
  const d=document.querySelector('iframe[src*=recommend]').contentDocument;
  if(d.querySelector('.dialog-wrap.active'))throw Error('Detail panel open; close it first');
  const cs=[...d.querySelectorAll('.candidate-card-wrap')].filter(e=>e.getClientRects().length);
  return JSON.stringify(cs.map((c,i)=>{
    const inner=c.querySelector('.card-inner'), name=c.querySelector('.name');
    return {i, geekId:inner?inner.getAttribute('data-geekid'):null,
      name:name?name.innerText.trim():null,
      text:(c.innerText||'').replace(/\\s*\\n+\\s*/g,' | ')};
  }));
})()`));

if (outArg) fs.writeFileSync(outArg, JSON.stringify(cards, null, 1), 'utf8');
console.log(JSON.stringify({ count: cards.length, cards }, null, 1));
