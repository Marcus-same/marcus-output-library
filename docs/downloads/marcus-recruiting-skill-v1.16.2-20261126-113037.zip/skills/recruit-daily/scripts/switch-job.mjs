#!/usr/bin/env node
// 在已绑定的 BOSS 推荐页内切换发布岗位（真实点击下拉，不导航、不刷新）。
//
// 用法：node switch-job.mjs <targetId> <目标jobId>
// 退出码：0 已切换或本来就一致 | 2 找不到下拉/选项 | 3 切换后读不到目标岗位
//
// ⚠️ 顺序纪律（2026-11-24 实测踩坑，务必保留）：
//   页面 iframe 的 jobid 一变，常驻会话的绑定立刻过期。而常驻会话的所有页面路由
//   （/eval、/screenshot、/clickAtFrame）在求值前都会执行 assertPageState(…, activeJob)，
//   于是「读一下页面当前是哪个岗位」会被 PAGE_CHECK: JOB_MISMATCH 挡掉 —— 死结。
//   唯一能「校验页面 + 失败回滚」的通道是 /rebind。所以：
//     · 先 rebind 试探：成功说明页面已经是目标岗位，只需同步绑定；
//     · 点完下拉选项后必须**先 rebind 再读**，不能先读。
//
// ⚠️ 不要用「点开下拉再点回 label」来枚举岗位：BOSS 会把那两次点击当成一次选中，
//   直接把页面切到列表里的某个岗位（2026-11-24 实测把页面切到了「财务运营专员」）。
//   枚举只读 DOM 里已存在的 .job-item 节点，绝不点击。
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';

const [TARGET, JOB] = process.argv.slice(2);
if (!TARGET || !JOB) throw new Error('Usage: switch-job.mjs TARGET JOBID');
assertBrowserAllowed(import.meta.url, { target: TARGET });

const client = createBrowserClient(import.meta.url, { target: TARGET });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const readJob = () => client.ev(`(()=>{const f=document.querySelector('iframe[src*=recommend]');const d=f.contentDocument;
const l=d.querySelector('.job-selecter-wrap .ui-dropmenu-label');
return JSON.stringify({jobid:new URL(f.contentWindow.location.href).searchParams.get('jobid'),
label:l?l.innerText.trim().replace(/\\s+/g,' '):null});})()`).then(JSON.parse);

/** rebind 既改绑定又校验页面，失败自动回滚；用它做「页面是不是这个岗位」的判定。 */
async function tryRebind(job) {
  try { return { ok: true, res: await client.rebind(job) }; }
  catch (e) { return { ok: false, err: e.message }; }
}

// 第 0 步：先 rebind 试探。
// 成功 ⇒ 页面本来就是目标岗位（只是会话绑定过期/不一致），无需点任何东西。
const sync = await tryRebind(JOB);
if (sync.ok) {
  const st = await readJob();
  console.log(JSON.stringify({ status: 'already', before: st, rebound: sync.res }, null, 2));
  process.exit(0);
}

// 第 1 步：只读确认下拉里存在该岗位（节点未展开时也在 DOM 中，不点击）
const opened = JSON.parse(await client.ev(`(()=>{const d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.querySelectorAll('[data-wb-job]').forEach(e=>e.removeAttribute('data-wb-job'));
const items=[...d.querySelectorAll('.job-selecter-wrap .job-item')];
const hit=items.find(e=>e.getAttribute('value')===${JSON.stringify(JOB)});
if(!hit)return JSON.stringify({ok:false,why:'no_such_job',have:items.map(e=>e.getAttribute('value'))});
const l=d.querySelector('.job-selecter-wrap .ui-dropmenu-label');
if(!l)return JSON.stringify({ok:false,why:'no_label'});
l.setAttribute('data-wb-job','label');hit.setAttribute('data-wb-job','item');
return JSON.stringify({ok:true,text:(hit.innerText||'').trim().replace(/\\s+/g,' ')});})()`));
if (!opened.ok) { console.error('切换失败: ' + opened.why); process.exit(2); }

// 第 2 步：打开下拉 → 真的点选项（绝不点回 label）
await client.clickAtFrame('[data-wb-job="label"]');
await sleep(1000);
await client.clickAtFrame('[data-wb-job="item"]');
await sleep(2600);

// 第 3 步：点完立刻 rebind（此刻页面已变，不能先读），再回读做二次确认
const bound = await tryRebind(JOB);
if (!bound.ok) { console.error('切换后 rebind 失败: ' + bound.err); process.exit(3); }
const after = await readJob();
const ok = after.jobid === JOB;
console.log(JSON.stringify({ status: ok ? 'switched' : 'verify_failed', target: opened.text, rebound: bound.res, after }, null, 2));
process.exit(ok ? 0 : 3);
