import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { decodePng, encodePng, stitchVertical, stitchFiles } from './png-stitch.mjs';

// 造一张渐变图，行颜色只由 y 决定，便于校验拼接后行序正确
function makeImage(width, height, bpp = 4, yOffset = 0) {
  const data = Buffer.alloc(width * bpp * height);
  for (let y = 0; y < height; y++) {
    const v = (y + yOffset) & 0xff;
    for (let x = 0; x < width; x++) {
      const o = (y * width + x) * bpp;
      data[o] = v; data[o + 1] = 255 - v; data[o + 2] = x & 0xff;
      if (bpp === 4) data[o + 3] = 255;
    }
  }
  return { width, height, bpp, data };
}

const rowPixel = (img, y) => Array.from(img.data.subarray(y * img.width * img.bpp, y * img.width * img.bpp + img.bpp));

test('encode then decode round-trips pixels exactly (RGBA)', () => {
  const src = makeImage(17, 9);
  const back = decodePng(encodePng(src));
  assert.equal(back.width, 17);
  assert.equal(back.height, 9);
  assert.equal(back.bpp, 4);
  assert.ok(back.data.equals(src.data), '像素必须逐字节一致');
});

test('round-trips RGB (colorType 2)', () => {
  const src = makeImage(8, 5, 3);
  const back = decodePng(encodePng(src));
  assert.equal(back.bpp, 3);
  assert.ok(back.data.equals(src.data));
});

test('stitch stacks rows in order with no overlap', () => {
  const a = makeImage(4, 3), b = makeImage(4, 2, 4, 3);
  const out = stitchVertical([a, b], { overlap: 0 });
  assert.equal(out.height, 5);
  assert.deepEqual(rowPixel(out, 0), rowPixel(a, 0));
  assert.deepEqual(rowPixel(out, 2), rowPixel(a, 2));
  assert.deepEqual(rowPixel(out, 3), rowPixel(b, 0)); // b 的第 0 行原本是 y=3
  assert.deepEqual(rowPixel(out, 4), rowPixel(b, 1));
});

test('overlap trims duplicated rows from every tile but the first', () => {
  const a = makeImage(4, 4), b = makeImage(4, 4, 4, 4);
  const out = stitchVertical([a, b], { overlap: 2 });
  assert.equal(out.height, 6); // 4 + (4-2)
  assert.deepEqual(rowPixel(out, 3), rowPixel(a, 3));
  assert.deepEqual(rowPixel(out, 4), rowPixel(b, 2), '后一张前两行被裁掉');
});

test('rejects mismatched widths instead of producing a corrupted image', () => {
  assert.throws(() => stitchVertical([makeImage(4, 2), makeImage(5, 2)]), /width mismatch/);
});

test('rejects non-PNG input', () => {
  assert.throws(() => decodePng(Buffer.from('not a png at all')), /not a PNG/);
});

test('stitchFiles reads real files and writes a decodable result', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'png-stitch-'));
  const p1 = path.join(dir, 'a.png'), p2 = path.join(dir, 'b.png');
  fs.writeFileSync(p1, encodePng(makeImage(3, 2)));
  fs.writeFileSync(p2, encodePng(makeImage(3, 2)));
  const out = stitchFiles([p1, p2], { overlap: 0 });
  assert.equal(out.height, 4);
  const back = decodePng(encodePng(out));
  assert.ok(back.data.equals(out.data));
});
