import fs from 'node:fs';
import path from 'node:path';
import {createHash, randomUUID} from 'node:crypto';
import {appendEvent,readEvents,isSend,samePersonJob} from './action-store.mjs';
import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';

export const shanghaiDate = (now = new Date()) => new Intl.DateTimeFormat('en-CA', {timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
const required = (value, name) => {if(typeof value !== 'string' || !value.trim()) throw new Error(`Missing ${name}`);};
export function validatePlan(plan, target, send, now = new Date()) {
  for (const k of ['targetId','jobId','role']) required(plan[k], k);
  if(plan.targetId !== target) throw new Error('Target mismatch');
  if(!Array.isArray(plan.candidates) || !plan.candidates.length || plan.candidates.length > 5) throw new Error('Batch must contain 1..5 candidates');
  const ids = new Set();
  for(const c of plan.candidates) {
    required(c.candidateId,'candidateId'); required(c.name,'name');
    if(ids.has(c.candidateId)) throw new Error('Duplicate candidate'); ids.add(c.candidateId);
  }
  if(send) {
    const a=plan.authorization;
    if(a?.confirmed !== true || a?.date !== shanghaiDate(now) || a?.jobId !== plan.jobId || a?.targetId !== target) throw new Error('Current dated user authorization required');
    required(a.evidence,'authorization.evidence');
    if(!Array.isArray(a.candidateIds) || plan.candidates.some(c=>!a.candidateIds.includes(c.candidateId))) throw new Error('Candidate outside authorization');
    if(a.funnel) {
      if(a.funnel.bypassed!==true) throw new Error('authorization.funnel.bypassed must be true when funnel is present');
      required(a.funnel.reason,'authorization.funnel.reason');
      required(a.funnel.userQuote,'authorization.funnel.userQuote');
    }
  }
}
export function assertIdentity(snapshot, plan, candidate) {
  if(!snapshot || snapshot.risk || snapshot.jobId !== plan.jobId || snapshot.candidateId !== candidate.candidateId || snapshot.name !== candidate.name || snapshot.unique !== true) throw new Error('Identity/job/risk verification failed');
}

// 三级漏斗的第二层凭证：卡片过筛后必须读过右侧经历（batch-read-resume 写 reviewed）。
// 没有这条记录就拒绝发送，避免「卡片正则直接接打招呼」——这是 2026-11-25 的实际事故。
// 逃生口只允许写在 plan.authorization.funnel 里（原因 + 用户原话），并落进动作日志。
export function funnelMode(plan, candidate, events) {
  const bypass = plan.authorization?.funnel;
  const reviewed = events.some(e => e.stage === 'reviewed' && samePersonJob(e, {platform:'boss', jobId:plan.jobId, role:plan.role, candidateId:candidate.candidateId}));
  if (reviewed) return {mode:'reviewed', detail:''};
  if (bypass?.bypassed === true) return {mode:'bypassed', detail:`funnel=bypassed: ${bypass.reason} (userQuote: ${bypass.userQuote})`};
  throw new Error('FUNNEL_UNREVIEWED: 该候选人没有第二层（右侧经历）复筛记录；先用 batch-read-resume.mjs 读取，或在 authorization.funnel 里显式豁免（需 reason 与 userQuote）');
}
export async function runSafe({workspace, plan, target, send=false, adapter, pause=ms=>new Promise(r=>setTimeout(r,ms)), now=()=>new Date()}) {
  const {root}=assertBrowserAllowed(import.meta.url,{workspace,target});
  return runTransaction({workspace:root,plan,target,send,adapter,pause,now});
}
// Pure transaction engine for isolated fake adapters. Production entrypoints use runSafe.
export async function runTransaction({workspace, plan, target, send=false, adapter, pause=ms=>new Promise(r=>setTimeout(r,ms)), now=()=>new Date()}) {
  validatePlan(plan,target,send,now());
  const runtime=path.join(path.resolve(workspace),'runtime'); fs.mkdirSync(runtime,{recursive:true});
  const lock=path.join(runtime,'greet-run.lock'); let fd;
  try { fd=fs.openSync(lock,'wx'); }
  catch(error) {
    if(error.code!=='EEXIST') throw error;
    let age=null;
    try { age=Date.now()-fs.statSync(lock).mtimeMs; } catch {}
    throw Error(`GREET_LOCK_HELD (EEXIST): ${lock} 已存在${age!==null?`（约 ${Math.round(age/1000)} 秒前）`:''}。可能是仍有发送在跑，也可能是中断遗留；先运行 node skills/recruit-daily/scripts/greet-lock-status.mjs 核实动作日志，确认没有发送进程后再人工删除锁。不会自动重试，也不会自动删锁。`);
  }
  const results=[];
  const runId=randomUUID();
  function events(){return readEvents(workspace);}
  function record(candidate,stage,detail='') {
    const event={eventId:randomUUID(),actionId:createHash('sha256').update(JSON.stringify(['boss',plan.jobId,candidate.candidateId])).digest('hex'),runId,platform:'boss',jobId:plan.jobId,role:plan.role,candidateId:candidate.candidateId,stage,timestamp:now().toISOString(),authorization:plan.authorization?.evidence,detail};
    return appendEvent(workspace,event,now());
  }
  try {
    for(const candidate of plan.candidates) {
      validatePlan(plan,target,send,now());
      if(send && events().some(e=>isSend(e)&&samePersonJob(e,{platform:'boss',jobId:plan.jobId,role:plan.role,candidateId:candidate.candidateId}))) throw new Error('Prior send exists; manual reconciliation required');
      // 漏斗闸门：必须在打开详情之前判定，不产生任何页面动作。
      const funnel = send ? funnelMode(plan,candidate,events()) : null;
      let pending=false;
      try {
        assertIdentity(await adapter.open(candidate),plan,candidate);
        assertIdentity(await adapter.inspect(candidate),plan,candidate);
        if(!send){results.push({candidateId:candidate.candidateId,status:'DRY'});continue;}
        validatePlan(plan,target,true,now());
        if(record(candidate,'greet_pending',funnel?.detail||'').saved!==true)throw Error('Pending intent already exists; stop without sending');
        pending=true;
        // Recheck after durable intent and immediately before the irreversible request.
        assertIdentity(await adapter.inspect(candidate),plan,candidate);
        await adapter.send(candidate);
        await pause(2500);
        if(await adapter.confirm(candidate) !== true) throw new Error('Send result unknown');
        record(candidate,'greet_confirmed');pending=false;
        results.push({candidateId:candidate.candidateId,status:'SUCCESS'});
        await pause(2000+Math.floor(Math.random()*3000));
      } catch(error) {
        if(pending) record(candidate,'greet_unknown',error.message);
        results.push({candidateId:candidate.candidateId,status:pending?'UNKNOWN':'BLOCKED',detail:error.message});
        throw error; // Never continue a batch after ambiguity or an identity failure.
      } finally {await adapter.close?.();}
    }
    return results;
  } finally {
    try {fs.writeFileSync(path.join(runtime,`greet-results-${runId}.json`),JSON.stringify(results,null,2),'utf8');}
    finally {fs.closeSync(fd);fs.unlinkSync(lock);}
  }
}
