import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { writeSums, verifyBundle, listFiles } from './verify-bundle.mjs';

function fixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'verify-bundle-'));
  fs.mkdirSync(path.join(root, 'recruit-daily', 'scripts'), { recursive: true });
  fs.writeFileSync(path.join(root, 'README.md'), 'hello');
  fs.writeFileSync(path.join(root, 'recruit-daily', 'scripts', 'a.mjs'), 'export const a=1;\n');
  return root;
}

test('write then verify passes on untouched bundle', () => {
  const root = fixture();
  const w = writeSums(root);
  assert.equal(w.files, 2);
  assert.ok(fs.existsSync(path.join(root, 'SHA256SUMS')));
  const r = verifyBundle(root);
  assert.equal(r.ok, true);
  assert.deepEqual(r.mismatch, []);
  assert.deepEqual(r.missing, []);
  assert.deepEqual(r.extra, []);
});

test('tampered file is reported as mismatch, not silently accepted', () => {
  const root = fixture();
  writeSums(root);
  fs.writeFileSync(path.join(root, 'recruit-daily', 'scripts', 'a.mjs'), 'export const a=2;\n');
  const r = verifyBundle(root);
  assert.equal(r.ok, false);
  assert.deepEqual(r.mismatch, ['recruit-daily/scripts/a.mjs']);
});

test('deleted file is reported as missing', () => {
  const root = fixture();
  writeSums(root);
  fs.unlinkSync(path.join(root, 'README.md'));
  const r = verifyBundle(root);
  assert.equal(r.ok, false);
  assert.deepEqual(r.missing, ['README.md']);
});

test('file added after checksum generation is surfaced as unregistered', () => {
  const root = fixture();
  writeSums(root);
  fs.writeFileSync(path.join(root, 'recruit-daily', 'scripts', 'b.mjs'), 'export const b=1;\n');
  const r = verifyBundle(root);
  assert.equal(r.ok, true, 'ok 只反映声明的文件是否一致');
  assert.deepEqual(r.extra, ['recruit-daily/scripts/b.mjs']);
});

test('skips node_modules, .claude and lock/log artefacts', () => {
  const root = fixture();
  fs.mkdirSync(path.join(root, 'node_modules'), { recursive: true });
  fs.writeFileSync(path.join(root, 'node_modules', 'x.js'), 'x');
  fs.mkdirSync(path.join(root, '.claude'), { recursive: true });
  fs.writeFileSync(path.join(root, '.claude', 'y.md'), 'y');
  fs.writeFileSync(path.join(root, 'z.lock'), '');
  const files = listFiles(root);
  assert.ok(!files.some((f) => f.includes('node_modules')));
  assert.ok(!files.some((f) => f.startsWith('.claude')));
  assert.ok(!files.includes('z.lock'));
});

test('missing SHA256SUMS fails loudly instead of passing', () => {
  const root = fixture();
  assert.throws(() => verifyBundle(root), /SHA256SUMS missing/);
});
