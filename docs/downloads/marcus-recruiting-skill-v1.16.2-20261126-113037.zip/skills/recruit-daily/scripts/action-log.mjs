import fs from 'node:fs';
import {workspaceFor} from '../../recruit-init/scripts/workspace-policy.mjs';
import {appendEvent,readEvents} from './action-store.mjs';
const args=Object.fromEntries(process.argv.slice(2).map(a=>{const i=a.indexOf('=');if(!a.startsWith('--')||i<3)throw Error('Use --key=value');return [a.slice(2,i),a.slice(i+1)];}));
if(!args.workspace||(!args['event-file']&&!args['summary-date']))throw Error('Required: --workspace=PATH and --event-file=PATH or --summary-date=YYYY-MM-DD');
const root=workspaceFor(import.meta.url,args.workspace);
if(args['event-file'])console.log(JSON.stringify(appendEvent(root,JSON.parse(fs.readFileSync(args['event-file'],'utf8').replace(/^\uFEFF/,'')))));
else {
  if(!/^\d{4}-\d{2}-\d{2}$/.test(args['summary-date']))throw Error('Invalid summary date');
  const dateOf=time=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(time));
  const latest=new Map();for(const e of readEvents(root))latest.set(e.actionId,e);
  const counts={};for(const e of latest.values())if(dateOf(e.timestamp)===args['summary-date'])counts[e.stage]=(counts[e.stage]||0)+1;
  console.log(JSON.stringify({date:args['summary-date'],counts,unresolved:[...latest.values()].filter(e=>['greet_pending','greet_unknown'].includes(e.stage))},null,2));
}
