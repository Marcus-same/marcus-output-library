import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {workspaceFor,readPolicy,accessToken} from '../../recruit-init/scripts/workspace-policy.mjs';
import {archiveStaleSession,sessionBase} from './session-recovery.mjs';

// No connection creation: use only the exact running session identity.
export async function existingSession({maintenance=false,target,job,rootOverride,fetchImpl=fetch}={}){
 const started=Date.now();
 const root=rootOverride||workspaceFor(import.meta.url);const policy=readPolicy(root,{maintenance});
 const file=path.join(root,'runtime/browser-session.json');
 if(!fs.existsSync(file))throw Error('SESSION_MISSING: no running session descriptor; explicit start required');
 const descriptor=JSON.parse(fs.readFileSync(file,'utf8'));
 const base=sessionBase(descriptor);
 if(!maintenance&&descriptor.targetId!==policy.targetId)throw Error('Session target changed');
 if(target&&descriptor.targetId!==target)throw Error('SESSION_TARGET_MISMATCH: no connection attempted');
 if(job&&descriptor.jobId!==job)throw Error('SESSION_JOB_MISMATCH: no connection attempted');
 const headers={'X-Recruiting-Token':accessToken(root)};
 const url=new URL('/health',base);if(maintenance)url.searchParams.set('maintenance','stop');
 let response;
 const healthStarted=Date.now();
 try{response=await fetchImpl(url,{headers,redirect:'error',signal:AbortSignal.timeout(3000)});}
 catch(e){throw Error('SESSION_UNREACHABLE: '+(e.cause?.code||e.code||e.name)+'; no automatic restart');}
 if(!response.ok)throw Error('Existing session unavailable; no automatic restart');
 const health=await response.json();
 if(health.instanceId!==descriptor.instanceId||health.targetId!==descriptor.targetId||health.jobId!==descriptor.jobId)throw Error('Session identity mismatch');
 return {root,descriptor,headers,health,timing:{metadataMs:healthStarted-started,healthMs:Date.now()-healthStarted,totalMs:Date.now()-started}};
}
async function main(){
 const [command,...args]=process.argv.slice(2);
 if(command==='resume'){
  const options=Object.fromEntries(args.map(a=>{const m=a.match(/^--(target|job)=(.+)$/);if(!m)throw Error('Use resume --target=ID --job=ID');return [m[1],m[2]];}));
  if(!options.target||!options.job)throw Error('Explicit target and job required for resume');
  const session=await existingSession(options);
  if(!session.health.connected)throw Error('Chrome disconnected; no automatic restart');
  const result={status:'reused',instanceId:session.descriptor.instanceId,targetId:session.descriptor.targetId,jobId:session.descriptor.jobId,connectionAttempts:session.health.connectionAttempts,timing:session.timing,pageVerified:false};
  fs.appendFileSync(path.join(session.root,'runtime','browser-startup-timings.jsonl'),JSON.stringify({timestamp:new Date().toISOString(),mode:'reuse',...result})+'\n');
  console.log(JSON.stringify(result));return;
 }
 if(command==='archive-stale'){
  const root=workspaceFor(import.meta.url);readPolicy(root,{maintenance:true});
  console.log(JSON.stringify(await archiveStaleSession(root,{token:accessToken(root)})));return;
 }
 const session=await existingSession({maintenance:command==='stop'});
 if(command==='status'){console.log(JSON.stringify(session.health));return;}
 if(command==='stop'){
  const res=await fetch(new URL('/shutdown',session.descriptor.base),{method:'POST',headers:{...session.headers,'Content-Type':'application/json'},body:JSON.stringify({instanceId:session.descriptor.instanceId}),redirect:'error',signal:AbortSignal.timeout(3000)});
  if(!res.ok)throw Error('Session stop rejected');console.log(await res.text());return;
 }
 if(command!=='run'||!args.length)throw Error('Use status, stop or run SCRIPT [ARGS]');
 if(!session.health.connected)throw Error('Chrome disconnected; explicit restart required');
 const script=fs.realpathSync(path.resolve(session.root,args[0]));
 const allowed=path.join(session.root,'skills','recruit-daily','scripts')+path.sep;
 if(!script.startsWith(allowed)||!script.endsWith('.mjs'))throw Error('Only recruiting scripts in this workspace may run');
 const code=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,[script,...args.slice(1)],{cwd:session.root,env:{...process.env,WEB_ACCESS_BASE:session.descriptor.base},stdio:'inherit',windowsHide:true});child.on('error',reject);child.on('exit',resolve);});
 if(code!==0)throw Error('Recruiting task exited '+code);
}
if(process.argv[1]&&fs.realpathSync(process.argv[1])===fs.realpathSync(fileURLToPath(import.meta.url)))main().catch(e=>{console.error(e.message);process.exitCode=1;});
