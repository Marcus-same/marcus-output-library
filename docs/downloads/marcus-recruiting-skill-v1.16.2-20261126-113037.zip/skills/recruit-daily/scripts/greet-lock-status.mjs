#!/usr/bin/env node
// 只读诊断：greet-run.lock 是否存在、最近一次发送是否停在 pending。
// 用法：node skills/recruit-daily/scripts/greet-lock-status.mjs
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {readEvents,isSend} from './action-store.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const lock = path.join(root, 'runtime', 'greet-run.lock');
let lockInfo = { exists: false, path: lock };
try {
  const st = fs.statSync(lock);
  lockInfo = { exists: true, path: lock, mtime: st.mtime.toISOString(), ageMs: Date.now() - st.mtimeMs };
} catch {}

const events = readEvents(root).filter(isSend);
const byAction = {};
for (const e of events) (byAction[e.actionId] = byAction[e.actionId] || []).push(e);
const unresolved = [];
for (const [actionId, evs] of Object.entries(byAction)) {
  const last = evs.at(-1);
  if (last.stage === 'greet_pending') {
    unresolved.push({ actionId, candidateId: last.candidateId, role: last.role, jobId: last.jobId, pendingAt: last.timestamp });
  }
}
const lastEvent = events.at(-1) || null;
console.log(JSON.stringify({
  lock: lockInfo,
  unresolved,
  lastSend: lastEvent ? { stage: lastEvent.stage, candidateId: lastEvent.candidateId, timestamp: lastEvent.timestamp } : null,
  guidance: lockInfo.exists
    ? [
        '1) 确认没有仍在执行的 greet-from-recommend / 流水线进程；',
        '2) 核对 unresolved 中每个 pending 是否有对应的 greet_confirmed/unknown；无法回读卡片时不要重发；',
        '3) 确认后才人工删除 runtime/greet-run.lock；本工具不会自动删锁，也不会重发。',
      ]
    : ['当前没有遗留的 greet-run.lock。'],
}, null, 2));
