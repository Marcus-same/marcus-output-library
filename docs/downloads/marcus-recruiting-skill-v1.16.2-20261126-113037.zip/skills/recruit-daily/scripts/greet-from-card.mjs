#!/usr/bin/env node
// 推荐页「卡片直发」打招呼：复用 greet-safe 的事务引擎（计划校验/当日授权/动作日志/去重/锁/结果落盘），
// 身份锚点用卡片上的平台原生稳定 ID（data-geekid），岗位用推荐 iframe 实际 URL 的 jobid 核验。
// 用法：node greet-from-card.mjs <targetId> --plan-file=PLAN.json [--send|--dry] [--workspace=DIR]
import fs from 'node:fs';
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';
assertBrowserAllowed(import.meta.url, { target: process.argv[2] });
import { runSafe, validatePlan, assertIdentity } from './greet-safe.mjs';
import { pacingWait } from './pacing.mjs';
import { assertNotReadOnly } from './page-risk.mjs';

async function main() {
  const args = process.argv.slice(2), target = args.shift();
  const options = Object.fromEntries(args.filter((a) => a.includes('=')).map((a) => { const i = a.indexOf('='); return [a.slice(2, i), a.slice(i + 1)]; }));
  if (!target || !options['plan-file'] || args.some((a) => !/^--(plan-file=.+|workspace=.+|send|dry)$/.test(a)) || (args.includes('--send') && args.includes('--dry'))) throw new Error('Usage: node greet-from-card.mjs TARGET --plan-file=approved.json [--workspace=DIR] [--send|--dry]');
  const { root: workspace } = assertBrowserAllowed(import.meta.url, { workspace: options.workspace, target });
  const plan = JSON.parse(fs.readFileSync(options['plan-file'], 'utf8').replace(/^\uFEFF/, ''));
  const send = args.includes('--send');
  validatePlan(plan, target, send);
  if (send) assertNotReadOnly(workspace);

  const b = plan.binding;
  if (!b?.frame || b.job?.source !== 'frame-url') throw new Error('job binding must be frame-url');
  if (!b.card?.greetSelector) throw new Error('binding.card.greetSelector required');
  for (const c of plan.candidates) {
    if (!c.card?.selector || !c.card?.attribute || !c.card?.nameSelector) throw new Error('Missing candidate card bindings');
  }

  const client = createBrowserClient(import.meta.url, { target, workspace, frame: b.frame });
  const ev = client.ev;
  const click = client.clickAtFrame;
  const jobParam = b.job.parameter || 'jobid';
  const greetSelector = b.card.greetSelector;
  // BOSS 卡片结构：身份在 .card-inner（平台原生 data-geekid），打招呼按钮是其外层 .candidate-card-wrap 的同级控件
  const wrapSelector = b.card.wrapSelector || '.candidate-card-wrap';

  const probe = (c) => ev(`(()=>{const b=${JSON.stringify({ frame: b.frame })},cd=${JSON.stringify(c.card)},gs=${JSON.stringify(greetSelector)},ws=${JSON.stringify(wrapSelector)};
const fs=[...document.querySelectorAll(b.frame)];if(fs.length!==1)throw Error('Ambiguous frame');
const f=fs[0],d=f.contentDocument;if(!d)throw Error('Frame unavailable');
const vis=e=>!!e.getClientRects().length;
let jobId=null;try{jobId=new URL(f.contentWindow.location.href).searchParams.get(${JSON.stringify(jobParam)});}catch(e){}
const items=[...d.querySelectorAll(cd.selector)].filter(vis);
const item=items.length===1?items[0]:null;
const names=item?[...item.querySelectorAll(cd.nameSelector)].filter(vis):[];
const wrap=item?item.closest(ws):null;
const greets=wrap?[...wrap.querySelectorAll(gs)].filter(vis):[];
const g=greets.length===1?greets[0]:null;
return {jobId,candidateId:item?item.getAttribute(cd.attribute):null,name:names.length===1?names[0].innerText.trim():null,
unique:items.length===1&&names.length===1,
greetReady:!!g&&g.innerText.trim()==='\\u6253\\u62db\\u547c'&&!g.disabled,
greetCount:greets.length,
done:wrap?[...wrap.querySelectorAll('button')].some(e=>e.innerText.trim()==='\\u7ee7\\u7eed\\u6c9f\\u901a'):false,
risk:location.hostname!=='www.zhipin.com'||/\\u5b89\\u5168\\u9a8c\\u8bc1|\\u9a8c\\u8bc1\\u7801/.test(d.body.innerText)};})()`);

  const adapter = {
    async open(c) {
      await client.closePanel({ panel: '.dialog-wrap', closeSelector: '.close-btn' });
      return probe(c);
    },
    async inspect(c) {
      const s = await probe(c);
      if (s.risk) throw new Error('Risk/verify page detected');
      if (!s.greetReady) throw new Error(`Greet button not ready (count=${s.greetCount})`);
      return s;
    },
    async send(c) {
      if (send) await pacingWait('greet', workspace);
      // 用真实控件定位标记（仅用于点击目标，不参与身份判定）
      await ev(`(()=>{const d=document.querySelector(${JSON.stringify(b.frame)}).contentDocument;
const vis=e=>!!e.getClientRects().length;
d.querySelectorAll('[data-wb-greet]').forEach(e=>e.removeAttribute('data-wb-greet'));
const inner=[...d.querySelectorAll(${JSON.stringify(c.card.selector)})].filter(vis);
if(inner.length!==1)throw Error('Ambiguous card');
const wrap=inner[0].closest(${JSON.stringify(wrapSelector)});
if(!wrap)throw Error('Card wrap missing');
const g=[...wrap.querySelectorAll(${JSON.stringify(greetSelector)})].filter(vis);
if(g.length!==1||g[0].innerText.trim()!=='\\u6253\\u62db\\u547c'||g[0].disabled)throw Error('Greet control not ready');
g[0].setAttribute('data-wb-greet','1');return 'marked';})()`);
      await click('[data-wb-greet="1"]');
    },
    async confirm(c) {
      const s = await probe(c);
      assertIdentity(s, plan, c);
      return s.done === true;
    },
    async close() { /* 卡片直发不打开详情面板，无需关闭 */ },
  };

  console.log(JSON.stringify(await runSafe({ workspace, plan, target, send, adapter }), null, 2));
}
main().catch((e) => { console.error(e.message); process.exitCode = 1; });
