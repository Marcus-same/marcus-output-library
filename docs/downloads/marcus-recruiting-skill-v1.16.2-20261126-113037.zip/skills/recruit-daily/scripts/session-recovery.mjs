import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';

export function sessionBase(descriptor) {
 const base=new URL(descriptor.base);
 if(base.protocol!=='http:'||base.hostname!=='127.0.0.1'||!base.port||base.pathname!=='/'||base.username||base.password||base.search||base.hash)throw Error('Invalid session endpoint');
 return base;
}

// Explicit maintenance only. Never connects to Chrome, kills a process, or starts a service.
export async function archiveStaleSession(root,{token,fetchImpl=fetch,probePid=pid=>process.kill(pid,0)}={}) {
 const runtime=path.join(root,'runtime'),guard=path.join(runtime,'browser-session-recovery.lock');
 const fd=fs.openSync(guard,'wx');
 try{
  const descriptorFile=path.join(runtime,'browser-session.json'),lockFile=path.join(runtime,'browser-session.lock');
  const files=[descriptorFile,lockFile].filter(f=>fs.existsSync(f));
  if(!files.length)return {status:'nothing_to_archive'};
  const originals=files.map(file=>({file,raw:fs.readFileSync(file,'utf8')}));
  const descriptor=originals.find(x=>x.file===descriptorFile);
  const lock=originals.find(x=>x.file===lockFile);
  const parse=entry=>{try{return JSON.parse(entry.raw);}catch{throw Error('Unverifiable session metadata; preserve files');}};
  const desc=descriptor?parse(descriptor):null,owner=lock?parse(lock):null;
  for(const record of [desc,owner].filter(Boolean))if(!Number.isSafeInteger(record.pid)||record.pid<=0)throw Error('Unverifiable owner PID; preserve files');
  if(desc){
   const base=sessionBase(desc);
   try{
    await fetchImpl(new URL('/health?maintenance=stop',base),{headers:{'X-Recruiting-Token':token},redirect:'error',signal:AbortSignal.timeout(3000)});
    throw Error('Service responded; archive refused');
   }catch(e){if(e.cause?.code!=='ECONNREFUSED'&&e.code!=='ECONNREFUSED')throw Error('Cannot prove service stopped: '+e.message);}
  }
  for(const pid of new Set([desc?.pid,owner?.pid].filter(x=>x!==undefined))){
   if(!Number.isSafeInteger(pid)||pid<=0)throw Error('Invalid owner PID');
   try{probePid(pid);throw Error('Owner process still exists; archive refused');}
   catch(e){if(e.code!=='ESRCH')throw e;}
  }
  if(!desc?.pid&&!owner?.pid)throw Error('Missing owner PID; preserve files');
  for(const item of originals)if(fs.readFileSync(item.file,'utf8')!==item.raw)throw Error('Session metadata changed; archive refused');
  const suffix='.stale-'+randomUUID();
  for(const item of originals)fs.renameSync(item.file,item.file+suffix);
  return {status:'archived',files:originals.map(x=>path.basename(x.file)+suffix),browserConnected:false};
 }finally{fs.closeSync(fd);fs.unlinkSync(guard);}
}
