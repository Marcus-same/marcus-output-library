import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {planConnection,connectSession,connectionsToday} from './connect.mjs';

function fixture(t,{descriptor=true,lock=false,policyOverride}={}){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'recruit-connect-'));
 t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 fs.mkdirSync(path.join(root,'runtime'));
 const policy={version:1,browserAutomation:'existing-tab',allowNewTabs:false,allowBrowserLaunch:false,targetId:'T',...(policyOverride||{})};
 fs.writeFileSync(path.join(root,'.recruiting-policy.json'),JSON.stringify(policy));
 fs.writeFileSync(path.join(root,'runtime/proxy-access-token'),'a'.repeat(64));
 if(descriptor)fs.writeFileSync(path.join(root,'runtime/browser-session.json'),JSON.stringify({instanceId:'I',pid:4242,targetId:'T',jobId:'J',base:'http://127.0.0.1:12345'}));
 if(lock)fs.writeFileSync(path.join(root,'runtime/browser-session.lock'),JSON.stringify({pid:4242,targetId:'T',jobId:'J'}));
 return {root,policy};
}
const healthy=async()=>({ok:true,json:async()=>({status:'ok',instanceId:'I',targetId:'T',jobId:'J',connected:true,connectionAttempts:1})});
const dead=async()=>{throw Object.assign(Error('refused'),{code:'ECONNREFUSED'});};

test('healthy resident session is reused without touching Chrome or starting a connection',async t=>{
 const f=fixture(t);let started=0,archived=0,stopped=0;
 const plan=await planConnection({root:f.root,target:'T',job:'J',fetchImpl:healthy,archive:async()=>{archived++;return {status:'archived'};},stop:async()=>{stopped++;}});
 assert.equal(plan.action,'reuse');assert.equal(plan.lane,'healthy');
 assert.deepEqual([started,archived,stopped],[0,0,0]);
});

test('unreachable service is archived exactly once and only then a connection is started',async t=>{
 const f=fixture(t);const calls=[];
 const plan=await planConnection({root:f.root,target:'T',job:'J',fetchImpl:dead,archive:async()=>{calls.push('archive');return {status:'archived'};},stop:async()=>{calls.push('stop');}});
 assert.equal(plan.action,'start');assert.equal(plan.lane,'unreachable');
 assert.deepEqual(calls,['archive']);
});

test('service alive but Chrome disconnected is stopped, archived once, then restarted',async t=>{
 const f=fixture(t);const calls=[];
 const plan=await planConnection({root:f.root,target:'T',job:'J',fetchImpl:async()=>({ok:true,json:async()=>({instanceId:'I',targetId:'T',jobId:'J',connected:false,connectionAttempts:1})}),archive:async()=>{calls.push('archive');return {status:'archived'};},stop:async()=>{calls.push('stop');}});
 assert.equal(plan.action,'start');assert.equal(plan.lane,'disconnected');
 assert.deepEqual(calls,['stop','archive']);
});

test('descriptor with different job is never reused',async t=>{
 const f=fixture(t);const calls=[];
 const plan=await planConnection({root:f.root,target:'T',job:'OTHER',fetchImpl:healthy,archive:async()=>{calls.push('archive');return {status:'archived'};},stop:async()=>{calls.push('stop');}});
 assert.equal(plan.action,'start');assert.equal(plan.lane,'identity_mismatch');
 assert.deepEqual(calls,['stop','archive']);
});

test('no descriptor starts one connection; stale lock without descriptor refuses',async t=>{
 const clean=fixture(t,{descriptor:false});
 const plan=await planConnection({root:clean.root,job:'J',fetchImpl:healthy,archive:async()=>({status:'archived'}),stop:async()=>{}});
 assert.equal(plan.action,'start');assert.equal(plan.lane,'no_session');assert.equal(plan.cleaned.length,0);
 const locked=fixture(t,{descriptor:false,lock:true});
 await assert.rejects(planConnection({root:locked.root,job:'J',fetchImpl:healthy,archive:async()=>({status:'archived'}),stop:async()=>{}}),/Stale session lock/);
});

test('explicit job required and paused policy stops before any work',async t=>{
 const f=fixture(t);
 await assert.rejects(planConnection({root:f.root,job:'',fetchImpl:healthy,archive:async()=>({}),stop:async()=>{}}),/Explicit job required/);
 const paused=fixture(t,{policyOverride:{browserAutomation:'paused'}});
 await assert.rejects(planConnection({root:paused.root,job:'J',fetchImpl:healthy,archive:async()=>({}),stop:async()=>{}}),/BROWSER_PAUSED/);
});

test('connectSession starts with the bound target and never starts on reuse',async t=>{
 const f=fixture(t);const started=[];
 const reuse=await connectSession({root:f.root,job:'J',endpoint:'ws://127.0.0.1:9222/devtools/browser/x',fetchImpl:healthy,archive:async()=>({status:'archived'}),stop:async()=>{},start:async o=>{started.push(o);return {instanceId:'N',base:'http://127.0.0.1:1',timing:{totalMs:1}};}});
 assert.equal(reuse.status,'reused');assert.equal(started.length,0);
 const fresh=fixture(t,{descriptor:false});
 const out=await connectSession({root:fresh.root,job:'J',endpoint:'ws://127.0.0.1:9222/devtools/browser/x',fetchImpl:healthy,archive:async()=>({status:'archived'}),stop:async()=>{},start:async o=>{started.push(o);return {instanceId:'N',base:'http://127.0.0.1:1',timing:{totalMs:1}};}});
 assert.equal(out.status,'started');assert.equal(started.length,1);assert.equal(started[0].target,'T');assert.equal(started[0].job,'J');
});

test('connectionsToday counts only today successful/failed connect records',async t=>{
 const f=fixture(t);
 const today=new Date().toISOString();
 const yesterday=new Date(Date.now()-86400000).toISOString();
 const lines=[
  {timestamp:today,mode:'connect',status:'ready'},
  {timestamp:today,mode:'connect',status:'failed'},
  {timestamp:today,mode:'reuse',status:'reused'},
  {timestamp:yesterday,mode:'connect',status:'ready'},
 ];
 fs.writeFileSync(path.join(f.root,'runtime/browser-startup-timings.jsonl'),lines.map(l=>JSON.stringify(l)).join('\n')+'\n');
 assert.equal(connectionsToday(f.root),2);
});
