#!/usr/bin/env node
// 推荐池「刷新」：滚到底 → 核验 .btn-refresh 唯一可见 → 真实点击 → 回读新批次状态。
// 仅换一批推荐，不切换入口。用法：session-control.mjs run skills/recruit-daily/scripts/refresh-pool.mjs TARGET
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';

const TARGET = process.argv[2];
if (!TARGET) throw new Error('Usage: refresh-pool.mjs TARGET');
assertBrowserAllowed(import.meta.url, { target: TARGET });
const client = createBrowserClient(import.meta.url, { target: TARGET });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const FRAME = "document.querySelector('iframe[src*=recommend]').contentDocument";

const state = async () => JSON.parse(await client.ev(`(()=>{const d=${FRAME};return JSON.stringify({cards:d.querySelectorAll('.candidate-card-wrap').length,scrollTop:Math.round(d.documentElement.scrollTop),h:d.documentElement.scrollHeight,refresh:[...d.querySelectorAll('.btn-refresh')].filter(e=>e.getClientRects().length).length,noData:!!d.querySelector('.no-data-refresh')});})()`));

let before = await state();
for (let i = 0; i < 60 && !before.noData; i++) {
  await client.ev(`(()=>{const d=${FRAME};d.documentElement.scrollTop=Math.min(d.documentElement.scrollTop+800,d.documentElement.scrollHeight);return true;})()`);
  await sleep(700);
  before = await state();
}
console.log('BEFORE ' + JSON.stringify(before));
if (before.refresh !== 1) { console.log('NO_REFRESH_BUTTON'); process.exit(0); }
await client.clickAtFrame('.btn-refresh');
const t0 = Date.now();
let after = before;
while (Date.now() - t0 < 30000) {
  await sleep(1500);
  after = await state();
  if (after.scrollTop === 0 && after.cards !== before.cards && !after.noData) break;
}
console.log('AFTER ' + JSON.stringify({ ...after, waitMs: Date.now() - t0 }));
