import {assertIdentity,validatePlan} from './greet-safe.mjs';
// No I/O here; production passes the bound browser adapter, tests pass fakes.
//
// minText：正文最少字符数。详情面板有时只渲染出「经历概览」骨架（实测 53 字），
// 这时 snapshot.loaded 仍为 true（textSelector 有内容），若照单全收就会拿几十个字
// 判断候选人。低于 minText 视为「正文未加载」，按失败处理而不是当成读到。
//
// continueOnFailure（2026-11-26 补）：单人「正文未加载/骨架」不应让整批停止。
// 身份/风险/关闭失败仍是致命错误，必须停批；只有可重试的读取失败才继续下一位，
// 由调用方记「待确认」。
export async function readCandidates({plan,target,adapter,chars=500,onResult=()=>{},minText=0,continueOnFailure=false}) {
  validatePlan(plan,target,false);
  if(!Number.isSafeInteger(chars)||chars<0)throw Error('Invalid chars');
  if(!Number.isSafeInteger(minText)||minText<0)throw Error('Invalid minText');
  const results=[];
  for(const candidate of plan.candidates) {
    let result=null,opened=false;
    try{
      const initial=await adapter.open(candidate);opened=true;
      assertIdentity(initial,plan,candidate);
      const snapshot=await adapter.read(candidate);
      assertIdentity(snapshot,plan,candidate);
      if(snapshot.loaded!==true || typeof snapshot.text!=='string' || !snapshot.text.trim())throw Error('Resume not loaded; stop batch');
      const bodyLength=snapshot.text.trim().length;
      if(bodyLength<minText)throw Error(`Resume body not rendered (${bodyLength}<${minText} chars); refusing to judge on an outline skeleton`);
      const fullLength=snapshot.text.length;
      result={candidateId:candidate.candidateId,jobId:plan.jobId,name:candidate.name,text:chars?snapshot.text.slice(0,chars):snapshot.text,fullLength,truncated:chars>0&&fullLength>chars,loaded:true};
    }catch(error){
      const fatal=/Identity|risk|Ambiguous|Frame unavailable|Details panel|did not close/i.test(String(error.message||error));
      if(!continueOnFailure||fatal)throw error;
      result={candidateId:candidate.candidateId,jobId:plan.jobId,name:candidate.name,ok:false,error:String(error.message||error)};
    }finally{if(opened)await adapter.close();}
    results.push(result);await onResult(result);
  }
  return results;
}
