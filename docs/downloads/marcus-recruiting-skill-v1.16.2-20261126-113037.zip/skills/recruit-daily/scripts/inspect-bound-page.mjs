import {existingSession} from './session-control.mjs';
import {createBrowserClient} from './browser-client.mjs';
import {inspectPage} from './page-state.mjs';
import {pageRisk} from './page-risk.mjs';

// Diagnose through the existing owner. Never creates a Chrome connection.
const session=await existingSession();
if(!session.health.connected)throw Error('SESSION_DISCONNECTED: explicit recovery required');
process.env.WEB_ACCESS_BASE=session.descriptor.base;
const client=createBrowserClient(import.meta.url,{target:session.descriptor.targetId});
console.log(JSON.stringify(await client.ev(`(${inspectPage.toString()})('iframe[src*=recommend]',${pageRisk.toString()})`)));
