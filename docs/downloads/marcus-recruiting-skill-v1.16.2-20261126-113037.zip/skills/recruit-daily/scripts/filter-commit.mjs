export function assertFilterApplied({panelOpen,failed,info,expected,checked,jobId,expectedJobId}) {
  if(panelOpen!==false || failed!==0 || info?.found!==true || !Number.isSafeInteger(expected) || expected<0 || info.count!==expected || checked?.bad!==0 || !expectedJobId || jobId!==expectedJobId) {
    throw new Error('筛选提交未确认：面板、失败项、岗位或条件不一致；不得记录成功');
  }
}
