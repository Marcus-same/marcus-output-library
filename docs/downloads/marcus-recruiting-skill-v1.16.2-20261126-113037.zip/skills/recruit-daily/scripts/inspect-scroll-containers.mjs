#!/usr/bin/env node
import {createBrowserClient} from './browser-client.mjs';
import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';
const target=process.argv[2];
if(!target) throw Error('Usage: inspect-scroll-containers TARGET');
const {root}=assertBrowserAllowed(import.meta.url,{target});
const client=createBrowserClient(import.meta.url,{target,workspace:root,frame:'iframe[src*=recommend]'});
const result=await client.ev(`(()=>{const f=document.querySelector('iframe[src*=recommend]');if(!f)throw Error('Frame missing');const d=f.contentDocument;if(d.querySelector('.dialog-wrap.active'))throw Error('Detail open');const out=[];for(const e of d.querySelectorAll('*')){const s=d.defaultView.getComputedStyle(e);if(e.scrollHeight>e.clientHeight+20&&/(auto|scroll)/.test(s.overflowY)&&e.getClientRects().length)out.push({tag:e.tagName,cls:String(e.className||'').slice(0,120),id:e.id||'',top:e.scrollTop,height:e.scrollHeight,view:e.clientHeight,overflow:s.overflowY});}return out.slice(0,30);})()`);
console.log(JSON.stringify(result,null,2));
