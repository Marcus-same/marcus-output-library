import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {randomUUID} from 'node:crypto';
import {candidateSnapshot} from './candidate-snapshot.mjs';
import {assertIdentity} from './greet-safe.mjs';
import {readCandidates} from './read-safe.mjs';
import {checkProxyRequest} from '../../web-access/scripts/proxy-security.mjs';
import {inspectPage,assertPageState} from './page-state.mjs';

function fixture(){
 const doc={defaultView:{getComputedStyle:()=>({display:'block',visibility:'visible'})}};
 const node=(attrs={})=>({ownerDocument:doc,getClientRects:()=>[{}],getAttribute:k=>attrs[k]||null,querySelectorAll:()=>[]});
 const record={id:'native-A',name:'Same Name'},source=node();source.__vue__={$props:{resume:record}};
 const body=node();body.innerText='Verified resume';
 const panel=node();panel.querySelectorAll=s=>s==='source'?[source]:s==='text'?[body]:[];
 const frame=node();frame.contentDocument=doc;frame.contentWindow={location:{href:'https://www.zhipin.com/web/frame/recommend/?jobid=job-A'}};
 doc.querySelectorAll=s=>s==='panel'?[panel]:[];
 const document={querySelectorAll:s=>s==='frame'?[frame]:[]};
 const binding={frame:'frame',job:{source:'frame-url'},panel:{selector:'panel',textSelector:'text',identitySource:{type:'vue-record',selector:'source',recordPath:['$props','resume'],idPath:['id'],namePath:['name']}}};
 const snapshot=()=>vm.runInNewContext(`(${candidateSnapshot.toString()})(binding,{},true,true)`,{document,binding,URL});
 return {record,source,panel,frame,binding,snapshot};
}
test('native component ID and name are read from the same record, without modifying DOM',()=>{
 const f=fixture(),s=f.snapshot();assert.equal(s.candidateId,'native-A');assert.equal(s.name,'Same Name');assert.equal(s.jobId,'job-A');assert.equal(s.loaded,true);
 assert.equal(f.panel.getAttribute('data-geekid'),null);
 const plan={jobId:'job-A'},candidate={candidateId:'native-A',name:'Same Name'};
 assert.doesNotThrow(()=>assertIdentity(s,plan,candidate));
 f.record.id='native-B';assert.throws(()=>assertIdentity(f.snapshot(),plan,candidate),/Identity/);
});
test('missing, duplicate, conflicting or unsafe native identity fails closed',()=>{
 const a=fixture();delete a.record.id;assert.equal(a.snapshot().loaded,false);
 const b=fixture();b.panel.querySelectorAll=()=>[b.source,b.source];assert.equal(b.snapshot().unique,false);
 const c=fixture();c.binding.panel.identitySource.recordPath=['$props','__proto__'];assert.throws(()=>c.snapshot(),/Invalid identity path/);
 const d=fixture();d.binding.panel.attribute='data-geekid';d.panel.getAttribute=()=> 'other-ID';assert.equal(d.snapshot().unique,false);
 const e=fixture();e.frame.contentWindow.location.href='https://www.zhipin.com/web/frame/recommend/?jobid=other';assert.equal(e.snapshot().jobId,'other');
 const f=fixture();f.binding.panel.identitySource.jobIdPath=['jobId'];f.record.jobId='wrong';assert.equal(f.snapshot().unique,false);
 const g=fixture();g.binding.panel.identitySource.jobIdPath=['jobId'];g.record.jobId='job-A';assert.equal(g.snapshot().unique,true);
});
test('identity failure closes current panel and stops before another candidate',async()=>{
 let opened=0,closed=0;
 const plan={targetId:'T',jobId:'J',role:'R',candidates:[{candidateId:'A',name:'N'},{candidateId:'B',name:'N'}]};
 await assert.rejects(readCandidates({plan,target:'T',adapter:{open:async()=>{opened++;return {unique:true,jobId:'J',candidateId:'wrong',name:'N'};},close:async()=>{closed++;}}}),/Identity/);
 assert.equal(opened,1);assert.equal(closed,1);
});
test('continueOnFailure: skeleton read is recorded, next candidate still reads',async()=>{
 const plan={targetId:'T',jobId:'J',role:'R',candidates:[{candidateId:'A',name:'NA'},{candidateId:'B',name:'NB'}]};
 const snap=(c,text)=>({unique:true,risk:false,jobId:'J',candidateId:c.candidateId,name:c.name,text,loaded:true});
 let opened=0;
 const adapter={open:async c=>{opened++;return snap(c,'');},read:async c=>snap(c,'x'.repeat(c.candidateId==='A'?50:200)),close:async()=>{}};
 const results=await readCandidates({plan,target:'T',adapter,minText:120,continueOnFailure:true});
 assert.equal(opened,2);
 assert.equal(results.length,2);
 assert.equal(results[0].ok,false);
 assert.equal(results[1].loaded,true);
 assert.equal(results[1].text.length,200);
});
test('continueOnFailure still stops on identity mismatch',async()=>{
 const plan={targetId:'T',jobId:'J',role:'R',candidates:[{candidateId:'A',name:'NA'},{candidateId:'B',name:'NB'}]};
 let opened=0;
 const adapter={open:async()=>{opened++;return {unique:true,risk:false,jobId:'J',candidateId:'wrong',name:'NA'};},read:async()=>({}),close:async()=>{}};
 await assert.rejects(readCandidates({plan,target:'T',adapter,continueOnFailure:true}),/Identity/);
 assert.equal(opened,1);
});
test('persistent session reuses one connection across requests, never auto-reconnects, rejects another owner',async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'bound-session-test-'));fs.mkdirSync(path.join(root,'runtime'));
 const policy={version:1,browserAutomation:'existing-tab',allowNewTabs:false,allowBrowserLaunch:false,targetId:'T'};
 const token='a'.repeat(64);let connections=0,closes=0;
 const fake={connected:true,state:'connected',get attemptCount(){return connections;},connect:async()=>{connections++;},close(){closes++;this.connected=false;},async send(method){
  if(method==='Target.getTargetInfo')return {result:{targetInfo:{url:'https://www.zhipin.com/web/chat/recommend'}}};
  if(method==='Target.attachToTarget')return {result:{sessionId:'S'}};
  return {result:{result:{value:{host:'www.zhipin.com',jobId:'J',risk:false,code:'OK'}}}};
 }};
 const source=fs.readFileSync(new URL('./bound-session.mjs',import.meta.url),'utf8').replace(/^import .*;\r?$/gm,'').replace('export async function','async function').replaceAll('import.meta.url',JSON.stringify(import.meta.url));
 const sandbox={http,fs,path,randomUUID,WebSocket,URL,setTimeout,clearTimeout,setImmediate,process:{argv:[],pid:123},assertBrowserAllowed:()=>({root}),readPolicy:()=>policy,accessToken:()=>token,checkProxyRequest,pageRisk:()=>false,inspectPage,assertPageState,frameHitPoint:()=>{},createCdpConnection:()=>fake};
 const start=vm.runInNewContext(source.slice(0,source.indexOf('if(process.argv[1]'))+'\nstartBoundSession',sandbox);
 const service=await start({target:'T',job:'J',endpoint:'ws://127.0.0.1:9222/devtools/browser/abc-123',connection:fake});
 assert.ok(service.timing.totalMs>=0);
 const startup=JSON.parse(fs.readFileSync(path.join(root,'runtime/browser-startup-timings.jsonl'),'utf8').trim());
 assert.equal(startup.mode,'connect');assert.equal(startup.connectionAttempts,1);
 for(const phase of ['localPreflightMs','chromeHandshakeMs','targetLookupMs','targetAttachMs','pageAndJobCheckMs','localServiceMs'])assert.ok(startup.timing[phase]>=0);
 assert.equal(fs.existsSync(path.join(root,'runtime/browser-session.lock')),true);
 const headers={'X-Recruiting-Token':token};
 try{
  for(let i=0;i<2;i++)assert.equal((await fetch(service.base+'/eval?target=T',{method:'POST',headers,body:'read'})).status,200);
  assert.equal(connections,1);
  await assert.rejects(start({target:'T',job:'J',endpoint:'ws://127.0.0.1:9222/devtools/browser',connection:fake}),/Existing session descriptor/);
  assert.equal(connections,1);
  fake.connected=false;
  assert.equal((await fetch(service.base+'/eval?target=T',{method:'POST',headers,body:'read'})).status,400);
  assert.equal(connections,1);
  assert.equal((await fetch(service.base+'/eval?target=wrong',{method:'POST',headers,body:'read'})).status,403);
  assert.equal((await fetch(service.base+'/eval?target=T',{method:'POST',headers:{...headers,Origin:'https://example.com'},body:'read'})).status,403);
  policy.browserAutomation='paused';
  assert.equal((await fetch(service.base+'/eval?target=T',{method:'POST',headers,body:'read'})).status,503);
 }finally{await service.stop();}
 assert.equal(closes,1);assert.equal(fs.existsSync(service.descriptor),false);
 assert.equal(fs.existsSync(path.join(root,'runtime/browser-session.lock')),false);
});
