import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
import {createCdpConnection} from '../../web-access/scripts/cdp-connection.mjs';
import {resolveWebSocket} from '../../web-access/scripts/ws-compat.mjs';
import {checkProxyRequest} from '../../web-access/scripts/proxy-security.mjs';
import {frameHitPoint} from '../../web-access/scripts/browser-dom.mjs';
import {assertBrowserAllowed,readPolicy,accessToken} from '../../recruit-init/scripts/workspace-policy.mjs';
import {pageRisk} from './page-risk.mjs';
import {inspectPage,assertPageState} from './page-state.mjs';

// One explicit start owns one connection. Requests never connect/reconnect.
export async function startBoundSession({target,job,endpoint,connection,rootOverride,connectTimeoutMs=45000}) {
 const started=Date.now(),timing={};let phase='localPreflight',phaseStarted=started;
 const nextPhase=name=>{timing[phase+'Ms']=Date.now()-phaseStarted;phase=name;phaseStarted=Date.now();};
 const {root}=assertBrowserAllowed(import.meta.url,{target,workspace:rootOverride});
 if(typeof job!=='string'||!job.trim())throw Error('Explicit job required');
 const url=new URL(endpoint);
 if(url.protocol!=='ws:'||url.hostname!=='127.0.0.1'||!/^\/devtools\/browser(?:\/[A-Za-z0-9-]+)?$/.test(url.pathname)||url.search||url.hash||url.username||url.password)throw Error('Explicit local Chrome endpoint required');
 const descriptor=path.join(root,'runtime','browser-session.json');
 if(fs.existsSync(descriptor))throw Error('Existing session descriptor: inspect/reuse or explicitly stop; do not start a second connection');
 const lock=path.join(root,'runtime','browser-session.lock');
 if(fs.existsSync(path.join(root,'runtime','browser-session-recovery.lock')))throw Error('Session recovery in progress');
 const lockFd=fs.openSync(lock,'wx');
 fs.writeFileSync(lockFd,JSON.stringify({pid:process.pid,targetId:target,jobId:job}));
 const c=connection||createCdpConnection({WebSocketImpl:resolveWebSocket().WebSocket,discoverUrl:async()=>endpoint,commandTimeoutMs:10000});
 const instanceId=randomUUID();let session,server,port,busy=false,stopped=false;
 // 当前绑定的岗位。可在不重启连接的前提下用 /rebind 热切换 —— 每新建一条浏览器级 CDP 连接
 // 都可能触发 Chrome 144+ 的「允许远程调试」确认，所以能复用就绝不断开重连。
 let activeJob=job;
// 顶层文档元素的命中坐标（沟通会话行等不在推荐 iframe 内的控件）。
// 与 frameHitPoint 同规则：可见元素必须唯一、必须在视口内、点前做 elementFromPoint 遮挡校验。
function topHitPoint(selector,text) {
  const visible=(e)=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&s.pointerEvents!=='none';};
  let hits=[...document.querySelectorAll(selector)].filter(visible);
  if(text!=null)hits=hits.filter(e=>e.innerText.trim()===text);
  if(hits.length!==1)throw Error('Ambiguous or disabled control: '+selector+(text?'['+text+']':'')+' → '+hits.length);
  const el=hits[0];
  if(el.disabled)throw Error('Disabled control');
  el.scrollIntoView({block:'center'});
  const r=el.getBoundingClientRect();
  const x=r.left+r.width/2,y=r.top+r.height/2;
  if(x<0||y<0||x>=innerWidth||y>=innerHeight)throw Error('Control outside viewport');
  const inside=document.elementFromPoint(x,y);
  if(!inside||!(inside===el||el.contains(inside)||inside.contains(el)))throw Error('Control is obscured');
  return {x:Math.round(x),y:Math.round(y)};
}
 async function evaluate(expression){const r=await c.send('Runtime.evaluate',{expression,returnByValue:true},session);if(r.error||r.result?.exceptionDetails)throw Error(JSON.stringify(r.error||r.result.exceptionDetails));return r.result.result.value;}
 async function ensurePage(){
  assertBrowserAllowed(import.meta.url,{target});
  if(!c.connected)throw Error('Connection lost; explicit restart required, no automatic reconnect');
  const value=await evaluate(`(${inspectPage.toString()})('iframe[src*=recommend]',${pageRisk.toString()})`);
  assertPageState(value,activeJob);
 }
 async function stop(){
  if(stopped)return;stopped=true;
  // 清理顺序与容错：先摘 lock 再摘描述文件。
  // 反过来的话，中途被打断会留下「进程活着 / 描述文件没了 / lock 还在」的半死状态——
  // 2026-10-25 真实发生过一次：SIGTERM 打断 stop()，残留 lock 卡住下次启动，只能人工杀进程。
  try{
   try{c.close();}catch{}
   if(server?.listening)await new Promise(r=>server.close(r));
  }finally{
   try{fs.closeSync(lockFd);}catch{}
   try{fs.unlinkSync(lock);}catch{}
   try{if(fs.existsSync(descriptor)&&JSON.parse(fs.readFileSync(descriptor,'utf8')).instanceId===instanceId)fs.unlinkSync(descriptor);}catch{}
  }
 }
 try{
  nextPhase('chromeHandshake');
  if(fs.existsSync(path.join(root,'runtime','browser-session-recovery.lock')))throw Error('Session recovery in progress');
  let timer;
  try{await Promise.race([c.connect(),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Chrome permission/connect timeout; no retry')),connectTimeoutMs);})]);}finally{clearTimeout(timer);}
  nextPhase('targetLookup');
  const info=await c.send('Target.getTargetInfo',{targetId:target});
  if(info.error||!/^https:\/\/www\.zhipin\.com\//.test(info.result?.targetInfo?.url||''))throw Error('Bound tab unavailable');
  nextPhase('targetAttach');
  const attached=await c.send('Target.attachToTarget',{targetId:target,flatten:true});
  if(attached.error)throw Error(JSON.stringify(attached.error));session=attached.result.sessionId;
  nextPhase('pageAndJobCheck');
  await ensurePage();
  // 未验证的缓解措施：窗口转后台时 CSS 过渡可能不触发，导致 Vue 弹窗关闭动画停滞。
  // 依据仅为本机一次观察，未做对照验证；connection-recovery.md 明确「无证据不得把错误都归咎焦点」。
  try{await c.send('Emulation.setFocusEmulationEnabled',{enabled:true},session);}catch{}
  nextPhase('localService');
  server=http.createServer(async(req,res)=>{
   let ownsBusy=false;
   try{
    const guard=checkProxyRequest(req,{port,token:accessToken(root),policy:readPolicy(root,{maintenance:true})});
    if(guard.status!==200){res.writeHead(guard.status);res.end(JSON.stringify({error:guard.error}));return;}
    const route=new URL(req.url,'http://127.0.0.1').pathname;
    if(route==='/health'){
     res.end(JSON.stringify({status:'ok',instanceId,targetId:target,jobId:activeJob,connected:c.connected,connectionState:c.state,connectionAttempts:c.attemptCount,busy}));return;
    }
    if(!['/eval','/clickAtFrame','/clickTop','/screenshot','/rebind','/shutdown'].includes(route))throw Error('Endpoint disabled');
    if(busy){res.writeHead(409);res.end(JSON.stringify({error:'Session busy'}));return;}busy=true;ownsBusy=true;
    let body='';for await(const chunk of req){body+=chunk;if(body.length>200000)throw Error('Payload too large');}
    if(route==='/shutdown'){
     if(JSON.parse(body).instanceId!==instanceId)throw Error('Instance mismatch');
     res.end(JSON.stringify({stopped:true,instanceId}));setImmediate(()=>stop().catch(console.error));return;
    }
    if(route==='/rebind'){
     // 热切换岗位：改绑定并用当前页面立刻核验，失败则回滚。避免为换岗重启连接（每次重连都可能触发 Chrome 授权弹窗）。
     const next=JSON.parse(body||'{}').job;
     if(typeof next!=='string'||!next.trim())throw Error('Explicit job required');
     const prev=activeJob;activeJob=next;
     try{await ensurePage();}catch(e){activeJob=prev;throw Error('Rebind rejected: '+e.message);}
     try{const d=JSON.parse(fs.readFileSync(descriptor,'utf8'));d.jobId=next;d.reboundAt=new Date().toISOString();fs.writeFileSync(descriptor,JSON.stringify(d,null,2));}catch{}
     res.end(JSON.stringify({rebound:true,from:prev,to:activeJob}));return;
    }
    await ensurePage();let result;
    if(route==='/eval')result={value:await evaluate(body)};
    else if(route==='/screenshot'){
     // 与 web-access cdp-api.md 一致：GET /screenshot?target=&file=，仅对已绑定 target 截图。
     // 可选 clip=x,y,w,h ：只截页面坐标里的这个矩形（用于只拍详情面板，不拍整屏外围）。
     // 可选 beyond=1    ：配合 clip 允许渲染视口之外的内容（拍完整简历必需）。
     // 常规简历截图由 browser-client 截当前视口后本地裁切；不撑高容器或改视口。
     const q=new URL(req.url,'http://127.0.0.1').searchParams;
     const outFile=q.get('file')||'';
     if(!path.isAbsolute(outFile))throw Error('Absolute output file required');
     const params={format:q.get('format')==='jpg'?'jpeg':'png',captureBeyondViewport:false};
     const clipRaw=q.get('clip');
     if(clipRaw){
      const nums=clipRaw.split(',').map(Number);
      if(nums.length!==4||!nums.every(Number.isFinite)||nums[2]<=0||nums[3]<=0)throw Error('Invalid clip: expect x,y,w,h');
      params.clip={x:nums[0],y:nums[1],width:nums[2],height:nums[3],scale:1};
     }
     if(q.get('beyond')==='1')params.captureBeyondViewport=true;
     const shot=await c.send('Page.captureScreenshot',params,session);
     if(shot.error||!shot.result?.data)throw Error(JSON.stringify(shot.error||'Screenshot failed'));
     const buf=Buffer.from(shot.result.data,'base64');
     fs.mkdirSync(path.dirname(outFile),{recursive:true});
     fs.writeFileSync(outFile,buf);
     result={saved:true,file:outFile,bytes:buf.length,clip:params.clip||null,beyond:!!params.captureBeyondViewport};
    }
    else{
     const {frame,selector}=JSON.parse(body);
     if(route==='/clickTop'){
      // 顶层文档（沟通会话列表、顶部 tab 等不在 recommend iframe 里的元素）。
      // 仍走 Input.dispatchMouseEvent，事件 isTrusted=true，与真人点击不可区分。
      const clickBody=JSON.parse(body);
      const point=await evaluate(`(${topHitPoint.toString()})(${JSON.stringify(clickBody.selector)},${JSON.stringify(clickBody.text||null)})`);
      for(const params of [{type:'mouseMoved',...point},{type:'mousePressed',button:'left',clickCount:1,...point},{type:'mouseReleased',button:'left',clickCount:1,...point}]){const r=await c.send('Input.dispatchMouseEvent',params,session);if(r.error)throw Error(JSON.stringify(r.error));}
      result={clicked:true};res.end(JSON.stringify(result));return;
     }
     const point=await evaluate(`(${frameHitPoint.toString()})(${JSON.stringify(frame)},${JSON.stringify(selector)})`);
     for(const params of [{type:'mouseMoved',...point},{type:'mousePressed',button:'left',clickCount:1,...point},{type:'mouseReleased',button:'left',clickCount:1,...point}]){const r=await c.send('Input.dispatchMouseEvent',params,session);if(r.error)throw Error(JSON.stringify(r.error));}
     result={clicked:true};
    }
    res.end(JSON.stringify(result));
   }catch(e){res.writeHead(400);res.end(JSON.stringify({error:e.message}));}
   finally{if(ownsBusy)busy=false;}
  });
  server.requestTimeout=15000;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});port=server.address().port;
  fs.writeFileSync(descriptor,JSON.stringify({instanceId,pid:process.pid,base:`http://127.0.0.1:${port}`,targetId:target,jobId:job,endpoint,createdAt:new Date().toISOString()},null,2),{flag:'wx'});
  nextPhase('ready');timing.totalMs=Date.now()-started;
  fs.appendFileSync(path.join(root,'runtime','browser-startup-timings.jsonl'),JSON.stringify({timestamp:new Date().toISOString(),mode:'connect',status:'ready',instanceId,connectionAttempts:c.attemptCount,timing})+'\n');
  return {stop,descriptor,instanceId,base:`http://127.0.0.1:${port}`,timing};
 }catch(e){
  timing[phase+'Ms']=Date.now()-phaseStarted;timing.totalMs=Date.now()-started;
  try{
   fs.appendFileSync(path.join(root,'runtime','browser-startup-timings.jsonl'),JSON.stringify({timestamp:new Date().toISOString(),mode:'connect',status:'failed',phase,connectionAttempts:c.attemptCount,timing})+'\n');
   fs.writeFileSync(path.join(root,'runtime','browser-session-last-error.json'),JSON.stringify({checkedAt:new Date().toISOString(),targetId:target,jobId:job,code:e.message.startsWith('PAGE_CHECK:')?e.message:'CONNECTION_OR_START_FAILED',connectionAttempts:c.attemptCount,automaticRetry:false},null,2));}
  finally{await stop();}
  throw e;
 }
}
if(process.argv[1]&&fs.realpathSync(process.argv[1])===fs.realpathSync(fileURLToPath(import.meta.url))){
 const args=Object.fromEntries(process.argv.slice(2).map(a=>{const i=a.indexOf('=');if(!a.startsWith('--')||i<0)throw Error('Use --key=value');return[a.slice(2,i),a.slice(i+1)];}));
 try{
  const service=await startBoundSession({target:args.target,job:args.job,endpoint:args.endpoint});
   console.log(JSON.stringify({status:'ready',instanceId:service.instanceId,base:service.base,timing:service.timing}));
  for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{
   // stop() 收尾后必须显式退出：否则事件循环可能还挂着句柄，进程变成孤儿，
   // 下次启动被残留 lock 挡住（2026-10-25 实际踩到）。3 秒硬兜底。
   const hard=setTimeout(()=>process.exit(1),3000);hard.unref?.();
   service.stop().catch(console.error).finally(()=>{clearTimeout(hard);process.exit(0);});
  });
 }catch(e){console.error(e.message);process.exitCode=1;}
}
