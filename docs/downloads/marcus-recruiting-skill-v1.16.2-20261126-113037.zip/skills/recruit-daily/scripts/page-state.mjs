// Serialized into the bound tab. Candidate-authored text is data, never a platform alert.
export function inspectPage(frameSelector, riskCheck) {
 const frames=[...document.querySelectorAll(frameSelector)];
 const result={host:location.hostname,jobId:null,risk:false,code:'OK'};
 const visible=e=>{
  const w=e.ownerDocument.defaultView,r=e.getBoundingClientRect();
  if(!r.width||!r.height||r.bottom<=0||r.right<=0||r.top>=w.innerHeight||r.left>=w.innerWidth)return false;
  for(let p=e;p;p=p.parentElement){const s=w.getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||s.visibility==='collapse'||s.opacity==='0')return false;}
  return true;
 };
 const uiText=d=>{
  const parts=[];
  for(const e of d.querySelectorAll('body, body *')){
   if(e.closest('.card-inner[data-geekid], .lib-standard-resume, .resume-right-side')||!visible(e))continue;
   if(['SCRIPT','STYLE','TEMPLATE','NOSCRIPT'].includes(e.tagName))continue;
   for(const n of e.childNodes)if(n.nodeType===3)parts.push(n.textContent);
  }
  return parts.join(' ');
 };
 if(result.host!=='www.zhipin.com')return {...result,code:'HOST_MISMATCH'};
 if(riskCheck({url:location.href,text:uiText(document)}))return {...result,risk:true,code:'PLATFORM_RISK'};
 if(frames.length!==1)return {...result,code:frames.length?'FRAME_AMBIGUOUS':'FRAME_MISSING'};
 const f=frames[0];let d,frameUrl;
 try{d=f.contentDocument;frameUrl=f.contentWindow.location.href;}catch{return {...result,code:'FRAME_UNAVAILABLE'};}
 if(!d?.body)return {...result,code:'FRAME_UNAVAILABLE'};
 result.jobId=new URL(frameUrl).searchParams.get('jobid');
 result.risk=riskCheck({frameUrl,text:uiText(d)});
 // Visible challenge iframes may contain no accessible text.
 for(const doc of [document,d])for(const e of doc.querySelectorAll('iframe[src]')){
  if(visible(e)&&riskCheck({url:e.getAttribute('src')||''}))result.risk=true;
 }
 return {...result,code:result.risk?'PLATFORM_RISK':'OK'};
}

export function assertPageState(value, expectedJob) {
 if(!value||value.code!=='OK'||value.risk!==false)throw Error('PAGE_CHECK: '+(value?.code||'INVALID_SNAPSHOT'));
 if(value.host!=='www.zhipin.com')throw Error('PAGE_CHECK: HOST_MISMATCH');
 if(expectedJob!==undefined&&value.jobId!==expectedJob)throw Error('PAGE_CHECK: JOB_MISMATCH');
}
