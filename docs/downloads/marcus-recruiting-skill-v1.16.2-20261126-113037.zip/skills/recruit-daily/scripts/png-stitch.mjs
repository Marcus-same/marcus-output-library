// 纯 Node PNG 解码/编码/纵向拼接。零外部依赖（只用内置 zlib）。
// 只支持 Chrome Page.captureScreenshot 会产出的格式：8bit、非隔行、colorType 2(RGB) 或 6(RGBA)。
// 用途：把滚动截到的多屏瓷砖拼成一张长图。
import zlib from 'node:zlib';
import fs from 'node:fs';

const SIG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let c = -1;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

export function decodePng(buf) {
  if (buf.length < 8 || !buf.subarray(0, 8).equals(SIG)) throw new Error('not a PNG');
  let off = 8, ihdr = null;
  const idat = [];
  while (off + 8 <= buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('ascii', off + 4, off + 8);
    const data = buf.subarray(off + 8, off + 8 + len);
    if (type === 'IHDR') {
      ihdr = {
        width: data.readUInt32BE(0), height: data.readUInt32BE(4),
        bitDepth: data[8], colorType: data[9], interlace: data[12],
      };
    } else if (type === 'IDAT') idat.push(Buffer.from(data));
    else if (type === 'IEND') break;
    off += 12 + len;
  }
  if (!ihdr) throw new Error('IHDR missing');
  if (ihdr.bitDepth !== 8) throw new Error('unsupported bitDepth ' + ihdr.bitDepth);
  if (ihdr.interlace !== 0) throw new Error('interlaced PNG unsupported');
  const bpp = ihdr.colorType === 6 ? 4 : ihdr.colorType === 2 ? 3 : 0;
  if (!bpp) throw new Error('unsupported colorType ' + ihdr.colorType);

  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = ihdr.width * bpp;
  const out = Buffer.alloc(stride * ihdr.height);
  let p = 0;
  for (let y = 0; y < ihdr.height; y++) {
    const filter = raw[p++];
    const line = raw.subarray(p, p + stride);
    p += stride;
    const cur = out.subarray(y * stride, (y + 1) * stride);
    const prev = y ? out.subarray((y - 1) * stride, y * stride) : null;
    for (let x = 0; x < stride; x++) {
      const a = x >= bpp ? cur[x - bpp] : 0;
      const b = prev ? prev[x] : 0;
      const c = prev && x >= bpp ? prev[x - bpp] : 0;
      let v = line[x];
      if (filter === 0) v = v;
      else if (filter === 1) v = v + a;
      else if (filter === 2) v = v + b;
      else if (filter === 3) v = v + ((a + b) >> 1);
      else if (filter === 4) {
        const pa = Math.abs(b - c), pb = Math.abs(a - c), pc = Math.abs(a + b - 2 * c);
        v = v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c);
      } else throw new Error('bad filter ' + filter);
      cur[x] = v & 0xff;
    }
  }
  return { width: ihdr.width, height: ihdr.height, bpp, data: out };
}

export function encodePng({ width, height, bpp, data }) {
  const colorType = bpp === 4 ? 6 : 2;
  const stride = width * bpp;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0; // filter: none
    data.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; ihdr[9] = colorType; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([SIG, chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

// 纵向拼接：图片宽度必须一致。overlap 为相邻两张的重叠行数，拼时裁掉后一张的前 overlap 行。
export function stitchVertical(images, { overlap = 0 } = {}) {
  if (!images.length) throw new Error('no images');
  const width = images[0].width, bpp = images[0].bpp;
  for (const im of images) {
    if (im.width !== width) throw new Error(`width mismatch: ${im.width} != ${width}`);
    if (im.bpp !== bpp) throw new Error(`bpp mismatch: ${im.bpp} != ${bpp}`);
  }
  const cuts = images.map((im, i) => (i === 0 ? 0 : Math.min(overlap, im.height - 1)));
  const height = images.reduce((s, im, i) => s + im.height - cuts[i], 0);
  const data = Buffer.alloc(width * bpp * height);
  let y = 0;
  images.forEach((im, i) => {
    const startRow = cuts[i];
    const rows = im.height - startRow;
    im.data.copy(data, y * width * bpp, startRow * width * bpp, im.height * width * bpp);
    y += rows;
  });
  return { width, height, bpp, data };
}

export function stitchFiles(paths, { overlap = 0 } = {}) {
  return stitchVertical(paths.map((p) => decodePng(fs.readFileSync(p))), { overlap });
}
