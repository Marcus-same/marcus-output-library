import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {appendEvent,readEvents} from './action-store.mjs';
const fixture=()=>fs.mkdtempSync(path.join(os.tmpdir(),'recruit-store-test-'));
const base={actionId:'action',runId:'mock',platform:'boss',candidateId:'person',jobId:'job',role:'role'};
test('store enforces intent, identity, unknown recovery and final state',()=>{
  const root=fixture(),record=extra=>appendEvent(root,{...base,...extra});
  assert.throws(()=>record({stage:'greet_confirmed'}));
  assert.throws(()=>record({stage:'greet_pending'}));
  record({stage:'greet_pending',authorization:'OFFLINE TEST'});
  record({stage:'greet_unknown'});assert.equal(record({stage:'greet_unknown'}).saved,false);
  assert.throws(()=>record({stage:'greet_pending',authorization:'OFFLINE TEST'}));
  assert.throws(()=>record({stage:'greet_confirmed',candidateId:'other'}));
  record({stage:'greet_confirmed'});assert.throws(()=>record({stage:'greet_unknown'}));
  assert.equal(readEvents(root).length,3);
});
test('different action IDs cannot bypass business identity',()=>{
  const root=fixture();appendEvent(root,{...base,stage:'greet_pending',authorization:'TEST'});
  assert.throws(()=>appendEvent(root,{...base,actionId:'new-id',stage:'greet_pending',authorization:'TEST'}),/Existing send/);
  assert.equal(readEvents(root).length,1);
});
test('concurrent writers cannot enter the log lock',()=>{
  const root=fixture();fs.mkdirSync(path.join(root,'runtime'));fs.writeFileSync(path.join(root,'runtime/recruit-actions.jsonl.lock'),'test');
  assert.throws(()=>appendEvent(root,{...base,stage:'greet_pending',authorization:'TEST'}),/EEXIST/);
});
