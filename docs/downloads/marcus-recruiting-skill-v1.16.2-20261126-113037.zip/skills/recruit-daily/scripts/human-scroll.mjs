#!/usr/bin/env node
import {createBrowserClient} from './browser-client.mjs';
import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';
const {root: WORKSPACE} = assertBrowserAllowed(import.meta.url,{target:process.argv[2]});
import {pacingWait} from './pacing.mjs';
import {softRisk,readRiskFlag,writeRiskFlag} from './page-risk.mjs';
/**
 * 在已绑定的推荐页分步滚动。禁止切换入口。
 * node human-scroll.mjs <targetId> [maxRounds] [--min=N] [--out=names.txt]
 * --min 是经用户确认的显示名采样目标，不代表不同候选人人数。
 * --rotate 已禁用。身份或连接异常立即停止。
 */

const BASE = process.env.WEB_ACCESS_BASE || 'http://localhost:3456';
const TARGET = process.argv[2];
const client=createBrowserClient(import.meta.url,{target:TARGET});
const MAX_ROUNDS = parseInt(process.argv[3] || '20', 10);
const minArg = process.argv.find((a) => a.startsWith('--min='));
const MIN_CARDS = minArg ? parseInt(minArg.split('=')[1], 10) : 0;
if(process.argv.includes('--rotate'))throw Error('Entry rotation is disabled');
const ROTATE = false;
const outArg = process.argv.find((a) => a.startsWith('--out='));
const OUT = outArg ? outArg.split('=').slice(1).join('=') : null;

if(!Number.isSafeInteger(MAX_ROUNDS)||MAX_ROUNDS<1||MAX_ROUNDS>100||!Number.isSafeInteger(MIN_CARDS)||MIN_CARDS<0)throw Error('Invalid round/sample limits');
if (!TARGET) {
  console.error('用法: node human-scroll.mjs <targetId> [maxRounds] [--min=N] [--out=names.txt]');
  process.exit(1);
}

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ts = () => new Date().toTimeString().slice(0, 8);

// 「推荐」「最新」的字符编码，避免 shell 传参时中文被破坏
const TAB_REC = String.fromCharCode(25512, 33616); // 推荐
const TAB_LATEST = String.fromCharCode(26368, 26032); // 最新

async function ev(js){return JSON.parse(await client.ev(js));}
async function clickAt(selector){if(!selector.startsWith('::iframe::'))throw Error('Bound iframe selector required');return client.clickAtFrame(selector.slice('::iframe::'.length));}

const STATE_JS = `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
JSON.stringify({
  cards: d.querySelectorAll('.candidate-card-wrap').length,
  top: Math.round(d.documentElement.scrollTop),
  h: d.documentElement.scrollHeight,
  view: d.documentElement.clientHeight,
  tab: (d.querySelector('.tab-item.curr')||{}).innerText || ''
})`;

const NAMES_JS = `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var ns=[];d.querySelectorAll('.candidate-card-wrap').forEach(function(c){
  var n=c.querySelector('.name'); if(n && n.innerText.trim()) ns.push(n.innerText.trim());
});
JSON.stringify(ns)`;

const SET_TOP = (y) => `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.documentElement.scrollTop=${Math.max(0, Math.round(y))};
Math.round(d.documentElement.scrollTop)`;

async function stepScrollToBottom() {
  let steps = 0;
  for (;;) {
    const s = await ev(STATE_JS);
    const maxTop = s.h - s.view;
    if (s.top >= maxTop - 50) break;
    await ev(SET_TOP(Math.min(s.top + rand(400, 900), maxTop)));
    steps++;
    await sleep(rand(250, 700));
    if (steps > 60) break;
  }
  return steps;
}

async function bounceNudge() {
  const s = await ev(STATE_JS);
  const maxTop = s.h - s.view;
  await ev(SET_TOP(maxTop - rand(600, 1200)));
  await sleep(rand(250, 550));
  await ev(SET_TOP(maxTop));
}

/** 切换到目标标签（返回是否成功切换） */
async function switchTab(label) {
  const json = JSON.stringify(label);
  await ev(`var d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.querySelectorAll('.tab-item').forEach(function(e){e.removeAttribute('data-lobster-tab')});
var tgt=null;
d.querySelectorAll('.tab-item').forEach(function(e){ if(e.innerText.trim()===${json}) tgt=e; });
if(tgt) tgt.setAttribute('data-lobster-tab','go');
JSON.stringify({marked: !!tgt})`);
  await sleep(rand(400, 900));
  await clickAt('::iframe::[data-lobster-tab="go"]');
  await sleep(rand(2500, 4000));
}

(async () => {
  const seen = new Set();
  let switchesWithoutNew = 0;
  const tabCycle = [TAB_REC, TAB_LATEST];
  let cycleIdx = 0;

  // 续跑：若 --out 文件已存在，先读入已有名单，避免重复计数
  if (OUT) {
    const fs = await import('node:fs');
    if (fs.existsSync(OUT)) {
      fs.readFileSync(OUT, 'utf8')
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean)
        .forEach((n) => seen.add(n));
      console.log(`[${ts()}] 续跑模式：已载入历史名单 ${seen.size} 人`);
    }
  }

  // 当日风控 flag：软信号只读日拒绝翻页取样
  const todayFlag = readRiskFlag(WORKSPACE);
  if (todayFlag && todayFlag.level !== 'normal') {
    console.log(`[${ts()}] 今日风控状态 ${todayFlag.level}（${(todayFlag.reasons||[]).join(';')}），${todayFlag.level==='read_only'?'拒绝执行，降级为只读':'降速执行'}`);
    if (todayFlag.level === 'read_only') process.exit(3);
  }

  let prevCards = 0;
  let emptyStreak = 0;
  for (let round = 1; round <= MAX_ROUNDS; round++) {
    const waited = await pacingWait('scroll', WORKSPACE);
    if (waited > 0) console.log(`[${ts()}] pacing: 距上轮间隔等待 ${Math.round(waited/1000)}s`);
    const roundStart = Date.now();
    const before = await ev(STATE_JS);
    const steps = await stepScrollToBottom();
    const nudges = rand(1, 3);
    for (let n = 0; n < nudges; n++) {
      await bounceNudge();
      await sleep(rand(1500, 3500));
    }
    const after = await ev(STATE_JS);

    const names = await ev(NAMES_JS);
    let fresh = 0;
    names.forEach((n) => {
      if (!seen.has(n)) {
        seen.add(n);
        fresh++;
      }
    });

    console.log(
      `[${ts()}] round ${round}: 分步 ${steps} 段 + 回弹 ${nudges} 次 | 本批 ${after.cards} 张 (新增 ${fresh}) | 累计去重 ${seen.size} 人 | 高度 ${after.h}`
    );

    // 软信号检测：封号前兆 → 当日降级只读
    const envFlagged = await ev(`(()=>{var t=document.body?document.body.innerText:'';try{var f=document.querySelector('iframe[src*=recommend]');if(f&&f.contentDocument)t+=' '+f.contentDocument.body.innerText;}catch(e){}return /环境存在异常|安全验证|验证码/.test(t)?1:0})()`);
    emptyStreak = fresh === 0 && after.cards === 0 ? emptyStreak + 1 : 0;
    const soft = softRisk({
      cardCount: after.cards,
      prevCardCount: prevCards,
      emptyStreak,
      roundMs: Date.now() - roundStart,
      envError: envFlagged === 1,
    });
    prevCards = after.cards;
    if (soft.level !== 'normal') {
      console.log(`[${ts()}] 软信号 [${soft.level}]: ${soft.reasons.join('; ')}`);
      if (soft.level === 'read_only') {
        writeRiskFlag(WORKSPACE, { level: 'read_only', reasons: soft.reasons });
        console.log(`[${ts()}] 已写入当日只读 flag，立即停止翻页。今日仅保留只读动作。`);
        break;
      }
    }

    if (MIN_CARDS > 0 && seen.size >= MIN_CARDS) {
      console.log(`[${ts()}] 已达到最小取样人数（${seen.size} >= ${MIN_CARDS}），可以开始筛选`);
      break;
    }

    // 单标签停滞：若开启轮换，切换标签拿新批次
    if (after.cards === before.cards && fresh === 0) {
      if (ROTATE) {
        if (fresh === 0) switchesWithoutNew++;
        cycleIdx = (cycleIdx + 1) % tabCycle.length;
        const target = tabCycle[cycleIdx];
        console.log(`[${ts()}] 本标签停滞，轮换到「${target}」拉取新批次`);
        await switchTab(target);
        if (switchesWithoutNew >= 8) {
          console.log(`[${ts()}] 连续 8 次轮换无新增，判定已无更多可取样候选人（累计 ${seen.size} 人）`);
          break;
        }
      } else {
        console.log(`[${ts()}] 本标签无增长，停止；当前累计 ${seen.size} 个显示名`);
        break;
      }
    } else {
      switchesWithoutNew = 0;
    }
  }

  if (OUT) {
    const fs = await import('node:fs');
    fs.writeFileSync(OUT, [...seen].join('\n'), 'utf8');
    console.log(`[${ts()}] 已写出候选人名单：${OUT}（${seen.size} 人）`);
  }

  console.log(`[${ts()}] 本轮取样结束，累计去重候选人 ${seen.size} 人`);
  process.exit(MIN_CARDS > 0 && seen.size < MIN_CARDS ? 2 : 0);
})().catch((e) => {
  console.error('执行失败:', e.message);
  process.exit(1);
});
