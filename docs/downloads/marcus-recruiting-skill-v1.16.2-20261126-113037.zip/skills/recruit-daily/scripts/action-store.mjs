import fs from 'node:fs';
import path from 'node:path';
import {createHash,randomUUID} from 'node:crypto';
export const isSend=e=>typeof e.stage==='string'&&e.stage.startsWith('greet_');
export const samePersonJob=(a,b)=>a.platform===b.platform&&a.candidateId===b.candidateId&&(a.jobId&&b.jobId?a.jobId===b.jobId:a.role===b.role);
export const sendActionId=e=>createHash('sha256').update(JSON.stringify([e.platform,e.jobId||e.role,e.candidateId])).digest('hex');
// 复筛凭证用独立 actionId 命名空间：否则 reviewed 会先于 greet_pending 占用同一条动作，
// 触发 appendEvent 的「Existing action cannot be resent」保护，正常发送被误伤。
export const reviewActionId=e=>createHash('sha256').update(JSON.stringify([e.platform,'reviewed',e.jobId||e.role,e.candidateId])).digest('hex');
export function readEvents(root) {
  const file=path.join(root,'runtime','recruit-actions.jsonl');
  return fs.existsSync(file)?fs.readFileSync(file,'utf8').replace(/^\uFEFF/,'').split(/\r?\n/).filter(Boolean).map(JSON.parse):[];
}
export function appendEvent(root,event,now=new Date()) {
  for(const k of ['actionId','runId','platform','candidateId','role','stage'])if(typeof event[k]!=='string'||!event[k].trim())throw new Error(`Missing ${k}`);
  if(!['screened','reviewed','greet_pending','greet_confirmed','greet_failed','greet_unknown'].includes(event.stage))throw new Error('Invalid stage');
  if(isSend(event)&&(!event.jobId||typeof event.jobId!=='string'))throw new Error('Send event requires jobId');
  if(event.stage==='greet_pending'&&(typeof event.authorization!=='string'||!event.authorization.trim()))throw new Error('Explicit authorization required');
  const runtime=path.join(root,'runtime');fs.mkdirSync(runtime,{recursive:true});
  const file=path.join(runtime,'recruit-actions.jsonl'),lock=file+'.lock',fd=fs.openSync(lock,'wx');
  try {
    const all=readEvents(root),prior=all.filter(e=>e.actionId===event.actionId);
    if(prior.some(e=>!samePersonJob(e,event)||e.role!==event.role))throw new Error('actionId identity mismatch');
    const last=prior.at(-1);
    if(isSend(event)) {
      const business=all.filter(e=>isSend(e)&&samePersonJob(e,event));
      if(business.some(e=>e.actionId!==event.actionId))throw new Error('Existing send for this candidate and job; reconcile manually');
      if(last?.stage===event.stage)return {saved:false,reason:'duplicate-stage',actionId:event.actionId};
      if(last?.stage==='greet_confirmed')throw new Error('Confirmed send cannot be reopened');
      if(event.stage==='greet_pending'&&prior.length)throw new Error('Existing action cannot be resent');
      if(event.stage!=='greet_pending'&&!prior.some(e=>e.stage==='greet_pending'))throw new Error('Send requires prior pending record');
    } else if(last?.stage===event.stage)return {saved:false,reason:'duplicate-stage',actionId:event.actionId};
    const record={...event,eventId:randomUUID(),timestamp:now.toISOString()};
    const out=fs.openSync(file,'a');try{fs.writeSync(out,JSON.stringify(record)+'\n');fs.fsyncSync(out);}finally{fs.closeSync(out);}
    return {saved:true,eventId:record.eventId};
  } finally{fs.closeSync(fd);fs.unlinkSync(lock);}
}
