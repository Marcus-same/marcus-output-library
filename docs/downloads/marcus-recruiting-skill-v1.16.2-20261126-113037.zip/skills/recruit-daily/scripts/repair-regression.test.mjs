import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {spawnSync} from 'node:child_process';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {installBundled} from '../../recruit-init/scripts/install-web-access.mjs';
import {initWorkspace} from '../../recruit-init/scripts/init-workspace.mjs';
import {pageRisk} from './page-risk.mjs';
import {inspectPage} from './page-state.mjs';
import {readCandidates} from './read-safe.mjs';
import {candidateSnapshot} from './candidate-snapshot.mjs';
import {assertFilterApplied} from './filter-commit.mjs';
import {checkProxyRequest} from '../../web-access/scripts/proxy-security.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const paused={version:1,browserAutomation:'paused',allowNewTabs:false,allowBrowserLaunch:false,targetId:null};
function fixture(){const p=fs.mkdtempSync(path.join(os.tmpdir(),'recruit-v3-'));fs.writeFileSync(path.join(p,'AGENTS.md'),'TEST');fs.writeFileSync(path.join(p,'CONTEXT.md'),'TEST');return p;}
test('dependency repair uses reviewed local files and preserves machine config',()=>{
 const dir=fixture();fs.mkdirSync(path.join(dir,'skills/web-access'),{recursive:true});fs.writeFileSync(path.join(dir,'skills/web-access/config.env'),'USER_CONFIG_TEST');
 const result=installBundled(dir);assert.equal(result.network,false);assert.ok(result.installed.includes('skills/web-access/scripts/proxy-security.mjs'));assert.ok(result.installed.includes('skills/web-access/templates/config.env.template'));
 assert.equal(fs.readFileSync(path.join(dir,'skills/web-access/config.env'),'utf8'),'USER_CONFIG_TEST');assert.equal(installBundled(dir).installed.length,0);
});
test('missing or changed local source fails before writing; mismatched destination is not overwritten',()=>{
 const source=fixture(),dest=fixture();fs.cpSync(path.join(root,'skills/web-access'),path.join(source,'skills/web-access'),{recursive:true});
 fs.writeFileSync(path.join(source,'skills/web-access/scripts/cdp-proxy.mjs'),'UNREVIEWED');
 assert.throws(()=>installBundled(dest,source),/missing or changed/);assert.equal(fs.existsSync(path.join(dest,'skills/web-access')),false);
 assert.throws(()=>installBundled(dest,fixture()),/missing or changed/);
 fs.mkdirSync(path.join(dest,'skills/web-access/scripts'),{recursive:true});fs.writeFileSync(path.join(dest,'skills/web-access/scripts/cdp-proxy.mjs'),'KEEP');
 assert.throws(()=>installBundled(dest),/differs/);assert.equal(fs.readFileSync(path.join(dest,'skills/web-access/scripts/cdp-proxy.mjs'),'utf8'),'KEEP');assert.equal(fs.existsSync(path.join(dest,'skills/web-access/SKILL.md')),false);
});
test('initialization includes template and checksum manifest; dependency self-check succeeds',()=>{
 const dir=path.join(fixture(),'blank');initWorkspace(dir);
 assert.ok(fs.existsSync(path.join(dir,'skills/web-access/templates/config.env.template')));
 assert.ok(fs.existsSync(path.join(dir,'skills/recruit-init/assets/web-access-manifest.json')));
 assert.equal(installBundled(dir,dir).installed.length,0);assert.equal(fs.existsSync(path.join(dir,'skills/web-access/config.env')),false);
});
const plan=()=>({targetId:'target',jobId:'job',role:'role',candidates:[{candidateId:'A',name:'SameName'},{candidateId:'B',name:'SameName'}]});
const snap=c=>({unique:true,risk:false,jobId:'job',candidateId:c.candidateId,name:c.name,text:'Resume body',loaded:true});
test('batch reading rejects changed ID/job, ambiguous name, risk, missing text and stops before next candidate',async()=>{
 for(const patch of [{candidateId:'C'},{jobId:'other'},{unique:false},{risk:true},{loaded:false},{text:''}]){
  const opened=[],output=[];await assert.rejects(readCandidates({plan:plan(),target:'target',adapter:{open:async c=>{opened.push(c.candidateId);return snap(c);},read:async c=>({...snap(c),...patch}),close:async()=>{}},onResult:r=>output.push(r)}));
  assert.deepEqual(opened,['A']);assert.equal(output.length,0);
 }
});
test('same-name candidates remain separate by stable ID; close failure aborts subsequent reads',async()=>{
 const p=plan();const result=await readCandidates({plan:p,target:'target',chars:3,adapter:{open:async c=>snap(c),read:async c=>snap(c),close:async()=>{}}});
 assert.deepEqual(result.map(x=>x.candidateId),['A','B']);assert.equal(result[0].truncated,true);assert.equal(result[0].text,'Res');
 let count=0;await assert.rejects(readCandidates({plan:p,target:'target',adapter:{open:async c=>{count++;return snap(c);},read:async c=>snap(c),close:async()=>{throw Error('close failed');}}}),/close failed/);assert.equal(count,1);
});
test('DOM snapshot takes identity and text from the same unique panel',()=>{
 const d={defaultView:{getComputedStyle:()=>({display:'block',visibility:'visible'})}};
 const el=(id,name,body)=>({ownerDocument:d,getClientRects:()=>[{}],getAttribute:()=>id,innerText:body,querySelectorAll:s=>s==='name'?[el(null,null,name)]:s==='text'?[el(null,null,body)]:[]});
 let panels=[el('C','SameName','C resume')];const frame=el();frame.contentDocument=d;d.querySelectorAll=s=>s==='panel'?panels:s==='job'?[el('job')]:[];
 const document={querySelectorAll:s=>s==='frame'?[frame]:[]};
 const b={frame:'frame',job:{selector:'job',attribute:'id'},panel:{selector:'panel',attribute:'id',nameSelector:'name',textSelector:'text'}};
 const call=()=>vm.runInNewContext(`(${candidateSnapshot.toString()})(binding,{},true,true)`,{document,binding:b});
 const result=call();assert.equal(result.candidateId,'C');assert.equal(result.text,'C resume');panels.push(el('D','SameName','D resume'));assert.equal(call().unique,false);
});
test('restriction banner variants are detected on a normal URL, ordinary resume text is not',()=>{
 for(const text of ['安全提示','我们将暂时限制您通过 web 端登录账号','第三方招聘管理系统','限制到期解除后','预计开启时间：2026-10-21','账号已冻结'])assert.equal(pageRisk({url:'https://www.zhipin.com/web/boss/recommend',text}),true,text);
 assert.equal(pageRisk({text:'负责招聘系统开发，工作经历和教育背景'}),false);
 assert.equal(pageRisk({frameUrl:'https://www.zhipin.com/passport/login'}),true);
});
// 构造 inspectPage 能遍历的最小 DOM：一个可见的平台 UI 文本节点 + 一个推荐 iframe。
function mockDocument(uiText,{frameText='',cardText=null}={}){
 const win={innerHeight:800,innerWidth:1200,getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'})};
 const rect={width:100,height:20,top:0,left:0,bottom:20,right:100};
 const el=(text,inCard)=>({tagName:'DIV',ownerDocument:{defaultView:win},getBoundingClientRect:()=>rect,parentElement:null,
  closest:s=>(inCard&&s.includes('card-inner'))?{}:null,childNodes:[{nodeType:3,textContent:text}]});
 const frameDoc={body:{innerText:frameText},querySelectorAll:s=>{
  if(s==='iframe[src]')return [];
  return cardText===null?[]:[el(cardText,true)];
 }};
 const frame={contentDocument:frameDoc,contentWindow:{location:{href:'https://www.zhipin.com/web/frame/recommend/?jobid=J'}}};
 return {body:{innerText:uiText},querySelectorAll:s=>{
  if(s==='iframe[src]')return [];            // 无挑战 iframe
  if(s.includes('iframe'))return [frame];    // 唯一推荐 iframe
  return [el(uiText,false)];                 // 平台 UI 文本节点
 }};
}
function makeClient({document,sandboxExtra={}}){
 let source=fs.readFileSync(path.join(root,'skills/recruit-daily/scripts/browser-client.mjs'),'utf8').replace(/^import .*;\r?$/gm,'').replace('export function','function');
 let requests=0;
 const sandbox={pageRisk,inspectPage,process:{env:{}},URL,assertBrowserAllowed:()=>({policy:{}}),browserFetchFor:()=>async(_url,init)=>{requests++;const value=vm.runInNewContext(init.body,{document,URL,location:{hostname:'www.zhipin.com',href:'https://www.zhipin.com/web/boss/recommend'}});return {ok:true,json:async()=>({value})};},...sandboxExtra};
 const client=vm.runInNewContext(source+"\ncreateBrowserClient('file:///fake',{target:'target'});",sandbox);
 return {client,count:()=>requests};
}
test('real client rejects restriction banner before running the requested page operation',async()=>{
 const {client,count}=makeClient({document:mockDocument('安全提示：暂时限制您通过web端登录账号')});
 await assert.rejects(client.ev('SHOULD_NOT_EXECUTE'),/risk/);assert.equal(count(),1);
});
test('candidate resume text containing risk keywords does not block the page',async()=>{
 // 2026-10-26 实测故障：候选人简历写「Agent行为安全验证与研究」，旧 assertPage 把整页
 // innerText（含简历正文）喂给 pageRisk，正常推荐页被误判为 PLATFORM_RISK 而停摆。
 // 候选人撰写的文本是数据，不是平台告警——只有平台 UI 区域的文本才参与风控判定。
 const resume='Agent行为安全验证与研究：正常与攻击任务构造、行为取证、模型裁判与误判分析。验证码识别系统开发经验。';
 const {client}=makeClient({document:mockDocument('推荐牛人',{frameText:resume,cardText:resume})});
 const snapshot=await client.assertPage();
 assert.equal(snapshot.risk,false);assert.equal(snapshot.code,'OK');
 assert.equal(snapshot.jobId,'J');
});
test('filter success requires closed panel, no failed options, matching job and verified values',()=>{
 const good={panelOpen:false,failed:0,info:{found:true,count:3},expected:3,checked:{bad:0},jobId:'job',expectedJobId:'job'};assert.doesNotThrow(()=>assertFilterApplied(good));
 for(const bad of [{panelOpen:true},{failed:1},{checked:null},{checked:{bad:1}},{jobId:'other'},{info:{found:true,count:4}}])assert.throws(()=>assertFilterApplied({...good,...bad}),/未确认/);
});
test('paused proxy permits authenticated stop-only routes and denies browser requests and invalid origins',()=>{
 const opts={port:3456,token:'a'.repeat(64),policy:paused};const req={url:'/shutdown',method:'POST',headers:{host:'127.0.0.1:3456','x-recruiting-token':opts.token}};
 assert.equal(checkProxyRequest(req,opts).status,200);assert.equal(checkProxyRequest({...req,url:'/health?maintenance=stop',method:'GET'},opts).status,200);
 for(const url of ['/health','/targets','/eval?target=target','/new'])assert.notEqual(checkProxyRequest({...req,url},opts).status,200);
 for(const headers of [{host:'127.0.0.1:3456'},{...req.headers,origin:'https://example.invalid'},{...req.headers,host:'evil.invalid'}])assert.notEqual(checkProxyRequest({...req,headers},opts).status,200);
});
test('actual paused proxy route accepts matching shutdown without connecting or closing tabs',async()=>{
 const source=fs.readFileSync(path.join(root,'skills/web-access/scripts/cdp-proxy.mjs'),'utf8');const route=source.slice(source.indexOf('const server = http.createServer('),source.indexOf('// 服务端口的原子绑定'));
 let handler,connected=0,stopped=0,finish;const context={http:{createServer:fn=>{handler=fn;}},checkProxyRequest,accessToken:()=> 'a'.repeat(64),readPolicy:()=>paused,workspaceContext:{root:'fake'},PORT:3456,URL,connect:async()=>{connected++;},readBody:async()=>JSON.stringify({instanceId:'instance'}),INSTANCE_ID:'instance',maintenance:false,activeRequests:5,managedTabs:new Map(),connection:{pendingCount:1,state:'connected'},shutdown:()=>{stopped++;}};
 vm.runInNewContext(route,context);
 const res={statusCode:200,setHeader(){},once(_ev,cb){finish=cb;},end(text){this.body=JSON.parse(text);}};
 await handler({url:'/shutdown',method:'POST',headers:{host:'127.0.0.1:3456','x-recruiting-token':'a'.repeat(64)}},res);
 assert.equal(res.statusCode,202);assert.equal(connected,0);finish();assert.equal(stopped,1);
 context.readBody=async()=>JSON.stringify({instanceId:'wrong'});res.statusCode=200;await handler({url:'/shutdown',method:'POST',headers:{host:'127.0.0.1:3456','x-recruiting-token':'a'.repeat(64)}},res);assert.equal(res.statusCode,409);
});
test('actual shutdown closes only proxy connection and server, never user tabs',async()=>{
 const s=fs.readFileSync(path.join(root,'skills/web-access/scripts/cdp-proxy.mjs'),'utf8');const code=s.slice(s.indexOf('function shutdown(reason)'),s.indexOf('// 防止未捕获异常'));
 const calls=[];const context={shutdownPromise:null,maintenance:false,Promise,lifecycleLog(){},clearInterval(){},cleanupTimer:null,managedTabs:new Map([['user-tab',{}]]),closeAllManagedTabs:()=>assert.fail('must not close tabs'),connection:{close:()=>calls.push('connection')},server:{close:cb=>{calls.push('server');cb();}},process:{exit:code=>calls.push(code)}};
 await vm.runInNewContext(code+"\nshutdown('TEST');",context);assert.deepEqual(calls,['connection','server',0]);
});
test('paused maintenance stop CLI uses only fake local stop routes and never spawns a process',()=>{
 const dir=fixture();fs.cpSync(path.join(root,'skills'),path.join(dir,'skills'),{recursive:true});fs.writeFileSync(path.join(dir,'.recruiting-policy.json'),JSON.stringify(paused));fs.mkdirSync(path.join(dir,'runtime'));fs.writeFileSync(path.join(dir,'runtime/proxy-access-token'),'a'.repeat(64));
 const preload=path.join(dir,'fake-io.mjs'),log=path.join(dir,'requests.json');
 fs.writeFileSync(preload,`import fs from 'node:fs';import http from 'node:http';import net from 'node:net';import cp from 'node:child_process';import {EventEmitter} from 'node:events';import {syncBuiltinESMExports} from 'node:module';const calls=[];let stopped=false;const deny=()=>{throw Error('UNEXPECTED_IO');};cp.spawn=deny;net.createConnection=deny;globalThis.fetch=deny;http.createServer=deny;http.request=(opts,callback)=>{const req=new EventEmitter();req.destroy=e=>req.emit('error',e);req.end=()=>queueMicrotask(()=>{calls.push(opts.path);fs.writeFileSync(${JSON.stringify(log)},JSON.stringify(calls));if(stopped){req.emit('error',Object.assign(Error('gone'),{code:'ECONNREFUSED'}));req.emit('close');return;}const res=new EventEmitter();res.setEncoding=()=>{};res.statusCode=opts.path==='/shutdown'?202:200;callback(res);if(opts.path==='/shutdown')stopped=true;res.emit('data',JSON.stringify(stopped?{instanceId:'mock'}:{status:'ok',stopOnly:true,instanceId:'mock',activeRequests:2,pendingCommands:1,managedTabs:0,connectionState:'connected'}));res.emit('end');req.emit('close');});return req;};syncBuiltinESMExports();`);
 const result=spawnSync(process.execPath,['--import',pathToFileURL(preload).href,path.join(dir,'skills/web-access/scripts/proxy-maintenance.mjs'),'stop'],{encoding:'utf8',timeout:5000});
 assert.equal(result.status,0,result.stderr);assert.deepEqual(JSON.parse(fs.readFileSync(log)),['/health?maintenance=stop','/shutdown','/health?maintenance=stop']);assert.equal(JSON.parse(fs.readFileSync(path.join(dir,'.recruiting-policy.json'))).browserAutomation,'paused');
});
