import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {inspectPage,assertPageState} from './page-state.mjs';
import {pageRisk} from './page-risk.mjs';
import {archiveStaleSession} from './session-recovery.mjs';

function pageFixture(){
 const makeDoc=()=>{
  const doc={body:{},defaultView:{innerWidth:1000,innerHeight:800,getComputedStyle:e=>({display:e.hidden?'none':'block',visibility:'visible',opacity:'1'})},elements:[],iframes:[]};
  doc.querySelectorAll=s=>s==='body, body *'?doc.elements:s==='iframe[src]'?doc.iframes:[];
  return doc;
 };
 const top=makeDoc(),inner=makeDoc();
 const el=(doc,text,{candidate=false,hidden=false,y=20,tag='DIV'}={})=>({ownerDocument:doc,tagName:tag,parentElement:null,hidden,childNodes:[{nodeType:3,textContent:text}],closest:()=>candidate?{}:null,getBoundingClientRect:()=>({width:200,height:40,top:y,bottom:y+40,left:0,right:200})});
 const frame=el(top,'');frame.contentDocument=inner;frame.contentWindow={location:{href:'https://www.zhipin.com/web/frame/recommend/?jobid=J'}};frame.getAttribute=()=>frame.contentWindow.location.href;
 top.querySelectorAll=s=>s==='frame'?[frame]:s==='iframe[src]'?[frame]:top.elements;
 const snapshot=()=>vm.runInNewContext(`(${inspectPage.toString()})('frame',${pageRisk.toString()})`,{document:top,location:{hostname:'www.zhipin.com',href:'https://www.zhipin.com/web/chat/recommend'},URL});
 return {top,inner,frame,el,snapshot};
}
test('candidate mentions and hidden/offscreen templates do not impersonate visible platform challenges',()=>{
 const f=pageFixture();
 f.inner.elements.push(f.el(f.inner,'开发验证码登录、安全验证、账号冻结模块',{candidate:true}));
 f.top.elements.push(f.el(f.top,'验证码',{hidden:true}),f.el(f.top,'安全提示',{y:900}));
 assert.doesNotThrow(()=>assertPageState(f.snapshot(),'J'));
 f.inner.elements.push(f.el(f.inner,'请输入验证码'));
 assert.throws(()=>assertPageState(f.snapshot(),'J'),/PLATFORM_RISK/);
});
test('visible restriction banner, hidden parent and visible challenge iframe remain distinguishable',()=>{
 const f=pageFixture(),banner=f.el(f.inner,'账号已冻结');f.inner.elements.push(banner);
 assert.equal(f.snapshot().code,'PLATFORM_RISK');
 banner.parentElement=f.el(f.inner,'',{hidden:true});assert.equal(f.snapshot().code,'OK');
 const challenge=f.el(f.inner,'');challenge.getAttribute=()=> 'https://www.zhipin.com/captcha/challenge';f.inner.iframes.push(challenge);
 assert.equal(f.snapshot().code,'PLATFORM_RISK');challenge.hidden=true;assert.equal(f.snapshot().code,'OK');
});
test('job mismatch and inaccessible frame have specific diagnostics, no focus speculation',()=>{
 const f=pageFixture();assert.throws(()=>assertPageState(f.snapshot(),'OTHER'),/JOB_MISMATCH/);
 f.frame.contentDocument=null;assert.equal(f.snapshot().code,'FRAME_UNAVAILABLE');
 f.frame.contentWindow.location.href='https://www.zhipin.com/passport/login';f.frame.contentDocument=f.inner;
 assert.equal(f.snapshot().code,'PLATFORM_RISK');
});
test('risk words in URL query values are not challenge routes',()=>{
 assert.equal(pageRisk({url:'https://www.zhipin.com/web/chat/recommend?jobid=403abc&note=captcha'}),false);
 assert.equal(pageRisk({url:'https://www.zhipin.com/security-check/start'}),true);
});

function staleFixture(){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'session-recovery-')),runtime=path.join(root,'runtime');fs.mkdirSync(runtime);
 const file=path.join(runtime,'browser-session.json');fs.writeFileSync(file,JSON.stringify({pid:12345,base:'http://127.0.0.1:23456',instanceId:'old'}));
 const refused=async()=>{throw Object.assign(Error('offline'),{cause:{code:'ECONNREFUSED'}});};
 const dead=()=>{throw Object.assign(Error('dead'),{code:'ESRCH'});};
 return {root,runtime,file,refused,dead};
}
test('explicit stale recovery archives metadata only after refused service and dead PID; no browser access',async()=>{
 const f=staleFixture();let calls=0;
 const result=await archiveStaleSession(f.root,{token:'test',fetchImpl:async url=>{calls++;assert.equal(url.pathname,'/health');assert.equal(url.search,'?maintenance=stop');return f.refused();},probePid:f.dead});
 assert.equal(result.status,'archived');assert.equal(calls,1);assert.equal(fs.existsSync(f.file),false);
 assert.equal(fs.readdirSync(f.runtime).filter(x=>x.includes('.stale-')).length,1);
});
test('responsive, timeout, live/unknown PID, malformed lock or changed metadata are never removed',async()=>{
 for(const scenario of ['responsive','timeout','alive','denied','badlock','missingpid','changed']){
  const f=staleFixture();let fetchImpl=f.refused,probePid=f.dead;
  if(scenario==='responsive')fetchImpl=async()=>({status:403});
  if(scenario==='timeout')fetchImpl=async()=>{throw Error('timeout');};
  if(scenario==='alive')probePid=()=>{};
  if(scenario==='denied')probePid=()=>{throw Object.assign(Error('denied'),{code:'EPERM'});};
  if(scenario==='badlock')fs.writeFileSync(path.join(f.runtime,'browser-session.lock'),'');
  if(scenario==='missingpid')fs.writeFileSync(path.join(f.runtime,'browser-session.lock'),'{}');
  if(scenario==='changed')probePid=()=>{fs.appendFileSync(f.file,' ');f.dead();};
  await assert.rejects(archiveStaleSession(f.root,{token:'test',fetchImpl,probePid}));
  assert.equal(fs.existsSync(f.file),true,scenario);
  assert.equal(fs.existsSync(path.join(f.runtime,'browser-session-recovery.lock')),false);
 }
});
