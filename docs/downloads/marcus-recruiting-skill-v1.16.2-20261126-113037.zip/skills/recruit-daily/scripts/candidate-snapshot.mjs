// ID attributes and selectors must come from the verified existing page.
export function candidateSnapshot(binding,card,panel=false,readText=false) {
  const visible=e=>{const s=e.ownerDocument.defaultView.getComputedStyle(e);return e.getClientRects().length>0 && s.display!=='none' && s.visibility!=='hidden';};
  const frames=[...document.querySelectorAll(binding.frame)].filter(visible);
  if(frames.length!==1)throw Error('Ambiguous frame');
  const d=frames[0].contentDocument;if(!d)throw Error('Frame unavailable');
  let jobId=null;
  if(binding.job.source==='frame-url'){
    const url=new URL(frames[0].contentWindow.location.href);
    jobId=url.searchParams.get(binding.job.parameter||'jobid');
  }else{
    const jobs=[...document.querySelectorAll(binding.job.selector),...d.querySelectorAll(binding.job.selector)].filter(visible);
    jobId=jobs.length===1?jobs[0].getAttribute(binding.job.attribute):null;
  }
  const descriptor=panel?binding.panel:card;
  const items=[...d.querySelectorAll(descriptor.selector)].filter(visible);
  const item=items.length===1?items[0]:null;
  const names=item&&descriptor.nameSelector?[...item.querySelectorAll(descriptor.nameSelector)].filter(visible):[];
  let candidateId=item?.getAttribute(descriptor.attribute),name=names.length===1?names[0].innerText.trim():null;
  let unique=items.length===1&&names.length===1;
  // Explicit read-only bindings to native component data; never stamp a card ID
  // onto the dialog or infer identity from its list position/display name.
  if(panel&&descriptor.identitySource){
    const source=descriptor.identitySource;
    if(source.type!=='vue-record')throw Error('Unsupported identity source');
    const valueAt=(object,keys)=>{
      if(!Array.isArray(keys)||!keys.length||keys.some(k=>typeof k!=='string'||!k||['__proto__','prototype','constructor'].includes(k)))throw Error('Invalid identity path');
      return keys.reduce((v,k)=>v!=null&&Object.prototype.hasOwnProperty.call(v,k)?v[k]:undefined,object);
    };
    const nodes=item?[...item.querySelectorAll(source.selector)].filter(visible):[];
    const component=nodes.length===1?nodes[0].__vue__:null;
    if(!['$props','$data'].includes(source.recordPath?.[0]))throw Error('Identity record must be native component props/data');
    const record=component?valueAt({$props:component.$props,$data:component.$data},source.recordPath):null;
    const id=record?valueAt(record,source.idPath):null;
    const nativeName=record?valueAt(record,source.namePath):null;
    const valid=typeof id==='string'&&id.trim().length>0&&typeof nativeName==='string'&&nativeName.trim().length>0;
    candidateId=valid?id:null;name=valid?nativeName.trim():null;
    unique=items.length===1&&nodes.length===1&&valid&&names.length<=1&&(!names.length||names[0].innerText.trim()===name);
    if(source.jobIdPath&&record&&valueAt(record,source.jobIdPath)!==jobId)unique=false;
    if(descriptor.attribute&&item?.getAttribute(descriptor.attribute)&&item.getAttribute(descriptor.attribute)!==candidateId)unique=false;
  }
  const texts=readText&&item?[...item.querySelectorAll(binding.panel.textSelector)].filter(visible):[];
  const text=texts.length===1?texts[0].innerText.trim():'';
  return {jobId,candidateId,name,unique,risk:false,text,loaded:unique&&texts.length===1&&text.length>0};
}
