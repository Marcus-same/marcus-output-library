#!/usr/bin/env node
// 整包完整性校验：对 skills 根目录下所有文件比对 SHA256SUMS。
// 用途：分发出去后被改动/损坏能立刻发现；也用于打包前自检。
//
// 用法：
//   node skills/recruit-daily/scripts/verify-bundle.mjs [--root=<目录>] [--json]
//   node skills/recruit-daily/scripts/verify-bundle.mjs --write      # 重新生成 SHA256SUMS
// 退出码：0 全部一致 | 1 有不一致/缺失 | 2 参数或环境错误
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const SUMS = 'SHA256SUMS';
const SKIP_DIRS = new Set(['.agents', '.claude', '.qoder', 'node_modules', '__pycache__']);
const SKIP_EXT = new Set(['.pyc', '.log', '.lock']);
const SKIP_FILES = new Set([SUMS]);

export function defaultRoot(moduleUrl = import.meta.url) {
  // <root>/recruit-daily/scripts/verify-bundle.mjs
  return path.resolve(path.dirname(fileURLToPath(moduleUrl)), '..', '..');
}

export function listFiles(root) {
  const out = [];
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
      if (entry.isDirectory()) {
        if (SKIP_DIRS.has(entry.name)) continue;
        walk(path.join(dir, entry.name));
        continue;
      }
      if (!entry.isFile()) continue;
      if (SKIP_FILES.has(entry.name)) continue;
      if (SKIP_EXT.has(path.extname(entry.name))) continue;
      out.push(path.relative(root, path.join(dir, entry.name)).replace(/\\/g, '/'));
    }
  };
  walk(root);
  return out;
}

export const sha256 = (file) => createHash('sha256').update(fs.readFileSync(file)).digest('hex');

export function writeSums(root) {
  const lines = listFiles(root).map((rel) => `${sha256(path.join(root, rel))}  ${rel}`);
  const body = lines.join('\n') + '\n';
  fs.writeFileSync(path.join(root, SUMS), body, 'utf8');
  return { files: lines.length, path: path.join(root, SUMS) };
}

export function parseSums(text) {
  return text.split('\n').filter(Boolean).map((line) => {
    const m = line.match(/^([0-9a-f]{64})\s{2}(.+)$/);
    if (!m) throw new Error('Malformed SHA256SUMS line: ' + line.slice(0, 80));
    return { sha256: m[1], path: m[2] };
  });
}

export function verifyBundle(root) {
  const sumsPath = path.join(root, SUMS);
  if (!fs.existsSync(sumsPath)) throw new Error('SHA256SUMS missing: ' + sumsPath);
  const entries = parseSums(fs.readFileSync(sumsPath, 'utf8'));
  const mismatch = [], missing = [], extra = [];
  const declared = new Set();
  for (const e of entries) {
    declared.add(e.path);
    const file = path.join(root, e.path);
    if (!fs.existsSync(file)) { missing.push(e.path); continue; }
    if (sha256(file) !== e.sha256) mismatch.push(e.path);
  }
  for (const rel of listFiles(root)) if (!declared.has(rel)) extra.push(rel);
  return { declared: entries.length, mismatch, missing, extra, ok: !mismatch.length && !missing.length };
}

if (process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url))) {
  const args = Object.fromEntries(process.argv.slice(2).filter((a) => a.startsWith('--')).map((a) => {
    const i = a.indexOf('=');
    return i < 0 ? [a.slice(2), true] : [a.slice(2, i), a.slice(i + 1)];
  }));
  try {
    const root = args.root ? path.resolve(args.root) : defaultRoot();
    if (args.write) {
      const r = writeSums(root);
      console.log(JSON.stringify({ written: true, files: r.files, path: r.path }));
    } else {
      const r = verifyBundle(root);
      if (args.json) console.log(JSON.stringify(r, null, 2));
      else {
        console.log(`声明 ${r.declared} 个文件｜不一致 ${r.mismatch.length}｜缺失 ${r.missing.length}｜清单外新增 ${r.extra.length}`);
        for (const f of r.mismatch) console.log('  ~ 内容已变:', f);
        for (const f of r.missing) console.log('  - 文件缺失:', f);
        for (const f of r.extra) console.log('  + 未登记:', f);
      }
      if (!r.ok) process.exitCode = 1;
    }
  } catch (e) {
    console.error(e.message);
    process.exitCode = 2;
  }
}
