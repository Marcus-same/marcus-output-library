#!/usr/bin/env node
// 刷新 N 轮推荐池，逐轮读卡片并按 CONTEXT 硬规则打标，输出短名单（不发送、不切入口）。
// 用法：session-control.mjs run skills/recruit-daily/scripts/refresh-scan.mjs TARGET [cycles]
import fs from 'node:fs';
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';

const TARGET = process.argv[2];
const CYCLES = parseInt(process.argv[3] || '3', 10);
if (!TARGET) throw new Error('Usage: refresh-scan.mjs TARGET [cycles]');
if (!Number.isSafeInteger(CYCLES) || CYCLES < 1 || CYCLES > 8) throw new Error('cycles 1..8');
assertBrowserAllowed(import.meta.url, { target: TARGET });
const client = createBrowserClient(import.meta.url, { target: TARGET });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const FRAME = "document.querySelector('iframe[src*=recommend]').contentDocument";

const C9 = ['北京大学', '清华大学', '复旦大学', '上海交通大学', '浙江大学', '南京大学', '中国科学技术大学', '哈尔滨工业大学', '西安交通大学'];
const AI = /(Agent|智能体|多智能体|大模型|LLM|RAG|LangGraph|LangChain|检索增强|大语言模型|Agentic|SFT|微调|MCP|Function\s*Calling|多模态)/i;

const state = async () => JSON.parse(await client.ev(`(()=>{const d=${FRAME};return JSON.stringify({cards:d.querySelectorAll('.candidate-card-wrap').length,scrollTop:Math.round(d.documentElement.scrollTop),refresh:[...d.querySelectorAll('.btn-refresh')].filter(e=>e.getClientRects().length).length,noData:!!d.querySelector('.no-data-refresh')});})()`));
const readCards = async () => JSON.parse(await client.ev(`(()=>{const d=${FRAME};if(d.querySelector('.dialog-wrap.active'))throw Error('Detail panel open; close it first');
const cs=[...d.querySelectorAll('.candidate-card-wrap')].filter(e=>e.getClientRects().length);
return JSON.stringify(cs.map((c,i)=>{const inner=c.querySelector('.card-inner'),name=c.querySelector('.name');
return {i,geekId:inner?inner.getAttribute('data-geekid'):null,name:name?name.innerText.trim():null,text:(c.innerText||'').replace(/\\s*\\n+\\s*/g,' | ')};}));})()`));

function screen(cards) {
  const hits = [];
  for (const c of cards) {
    const t = (c.text || '').replace(/\s+/g, ' ');
    const seg = t.split('|').map(s => s.trim());
    const a = t.match(/(\d{2})岁/);
    const age = a ? Number(a[1]) : null;
    if (!age || age < 22 || age > 26) continue;
    if (!/期望 \| 北京/.test(t)) continue;
    const edus = [];
    for (let i = 0; i < seg.length; i++) {
      const e = /^(.{2,30}?)\s+(\S{1,24})\s+(本科|硕士|博士)$/.exec(seg[i + 1] || '');
      if (/^20\d{2}\s+20\d{2}$/.test(seg[i]) && e) edus.push({ start: +seg[i].slice(0, 4), school: e[1], degree: e[3] });
    }
    const b = edus.filter(x => x.degree === '本科').sort((x, y) => x.start - y.start)[0];
    if (!b || !C9.some(s => b.school.includes(s))) continue;
    if (!AI.test(t)) continue;
    hits.push({ geekId: c.geekId, name: c.name, age, bach: b.school, text: t });
  }
  return hits;
}

for (let cycle = 1; cycle <= CYCLES; cycle++) {
  let st = await state();
  for (let i = 0; i < 400 && !st.noData; i++) {
    await client.ev(`(()=>{const d=${FRAME};d.documentElement.scrollTop=Math.min(d.documentElement.scrollTop+900,d.documentElement.scrollHeight);return true;})()`);
    await sleep(350);
    st = await state();
  }
  if (st.refresh !== 1) { console.log(`cycle ${cycle}: NO_REFRESH_BUTTON cards=${st.cards}`); break; }
  const beforeCards = st.cards;
  await client.clickAtFrame('.btn-refresh');
  const t0 = Date.now();
  let after = st, ok = false;
  while (Date.now() - t0 < 25000) {
    await sleep(1200);
    after = await state();
    if (after.scrollTop === 0 && after.cards !== beforeCards && !after.noData) { ok = true; break; }
  }
  if (!ok) { console.log(`cycle ${cycle}: REFRESH_TIMEOUT ${JSON.stringify(after)}`); break; }
  const cards = await readCards();
  fs.writeFileSync(`runtime/cards-cycle${cycle}.json`, JSON.stringify(cards, null, 1));
  const hits = screen(cards);
  console.log(`cycle ${cycle}: cards=${cards.length} hardHits=${hits.length}`);
  for (const h of hits) console.log(`  HIT ${h.name} ${h.geekId} ${h.age}岁 ${h.bach} :: ${h.text.slice(0, 180)}`);
  if (cycle < CYCLES) await sleep(4000);
}
