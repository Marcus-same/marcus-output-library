#!/usr/bin/env node
import {createBrowserClient} from './browser-client.mjs';
import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';
const target=process.argv[2], id=process.argv[3];
if(!target||!id) throw Error('Usage: scroll-card-to-id TARGET CANDIDATE_ID');
const {root}=assertBrowserAllowed(import.meta.url,{target});
const client=createBrowserClient(import.meta.url,{target,workspace:root,frame:'iframe[src*=recommend]'});
const result=await client.ev(`(()=>{const f=document.querySelector('iframe[src*=recommend]');if(!f)throw Error('Frame missing');const d=f.contentDocument;if(d.querySelector('.dialog-wrap.active'))throw Error('Detail open');const e=d.querySelector(${JSON.stringify(`.card-inner[data-geekid="${id}"]`)});if(!e) return {found:false};e.scrollIntoView({block:'center'});return {found:true,top:e.getBoundingClientRect().top};})()`);
console.log(JSON.stringify(result));
