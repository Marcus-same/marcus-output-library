import fs from 'node:fs';
import {decodePng,encodePng} from './png-stitch.mjs';

// Crop locally. Never pass the resume rectangle to Chrome: a clipped surface
// capture can temporarily change rendering outside that rectangle.
export function cropViewport(image,clip,viewport){
 const [x,y,width,height]=clip||[];
 if(![x,y,width,height,viewport?.width,viewport?.height].every(Number.isFinite)||x<0||y<0||width<=0||height<=0||viewport.width<=0||viewport.height<=0||x+width>viewport.width+0.5||y+height>viewport.height+0.5)throw Error('Screenshot region outside visible viewport; keep BOSS fully visible');
 const sx=image.width/viewport.width,sy=image.height/viewport.height;
 if(Math.abs(sx-sy)>0.02*Math.max(sx,sy))throw Error('Screenshot viewport changed during capture');
 const left=Math.round(x*sx),top=Math.round(y*sy);
 const right=Math.min(image.width,Math.round((x+width)*sx)),bottom=Math.min(image.height,Math.round((y+height)*sy));
 const w=right-left,h=bottom-top;
 if(w<=0||h<=0)throw Error('Empty screenshot region');
 const data=Buffer.alloc(w*h*image.bpp);
 for(let row=0;row<h;row++)image.data.copy(data,row*w*image.bpp,((top+row)*image.width+left)*image.bpp,((top+row)*image.width+right)*image.bpp);
 return {width:w,height:h,bpp:image.bpp,data};
}

export async function captureVisibleRegion({file,clip,viewport,capture}){
 const rawFile=file+'.viewport.png';
 const raw=await capture(rawFile); // Deliberately no CDP clip or viewport override.
 const cropped=cropViewport(decodePng(fs.readFileSync(rawFile)),clip,viewport);
 fs.writeFileSync(file,encodePng(cropped));
 return {...raw,file,bytes:fs.statSync(file).size,clip,beyond:false,mode:'viewport-local-crop',viewportFile:rawFile,pixelWidth:cropped.width,pixelHeight:cropped.height};
}
