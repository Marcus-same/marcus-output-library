// 全局节奏控制（防封·主动降险）
// 原则：任何两个对外动作（greet/scroll/read）之间强制随机间隔；打招呼间隔更长；
//       01:00-06:00 禁止对外动作；状态落盘 <workspace>/runtime/pacing-state.json。
// 用法（模块内）：await pacingWait('greet', workspace)
// 用法（CLI）：   node pacing.mjs <greet|scroll|read> [--workspace=DIR]
//                node pacing.mjs status [--workspace=DIR]
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

// 各类动作的最小/最大间隔（秒）。greet 之间最长，避免连发。
const GAPS = {
  greet: [60, 120],
  read: [20, 90],
  scroll: [15, 45],
};
const DEFAULT_GAP = [20, 90];
// 凌晨时段（本地时间 01:00-05:59）大量动作本身就是异常信号
const NIGHT_START = 1, NIGHT_END = 6;

const rand = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function statePath(workspace) {
  return path.join(workspace, 'runtime', 'pacing-state.json');
}

function loadState(p) {
  try {
    const s = JSON.parse(fs.readFileSync(p, 'utf8'));
    if (typeof s !== 'object' || s === null) throw 0;
    return s;
  } catch { return {}; }
}

function saveState(p, s) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(s, null, 2));
}

/** 计算该动作还需等待的毫秒数。夜间直接抛 PACING_NIGHT。 */
export function requiredDelayMs(kind, state, now = new Date()) {
  const h = now.getHours();
  if (h >= NIGHT_START && h < NIGHT_END) {
    throw new Error('PACING_NIGHT: 01:00-06:00 为降险时段，禁止对外动作');
  }
  const [lo, hi] = GAPS[kind] || DEFAULT_GAP;
  const need = rand(lo, hi) * 1000;
  const last = kind === 'greet' && state.lastGreet ? state.lastGreet : state.lastAction;
  if (!last) return 0;
  const elapsed = now - new Date(last);
  return Math.max(0, need - elapsed);
}

/** 等待所需间隔并记录本次动作。返回实际等待毫秒。 */
export async function pacingWait(kind, workspace, { now = new Date() } = {}) {
  const p = statePath(workspace);
  const state = loadState(p);
  const wait = requiredDelayMs(kind, state, now);
  if (wait > 0) await sleep(wait);
  const at = new Date().toISOString();
  const next = { ...state, lastAction: at, lastKind: kind };
  if (kind === 'greet') next.lastGreet = at;
  next.history = [...(state.history || []), { kind, at }].slice(-200);
  saveState(p, next);
  return wait;
}

/** 只记录不等待（用于纯读取等无需节流的场景，一般不用）。 */
export function recordOnly(kind, workspace) {
  const p = statePath(workspace);
  const state = loadState(p);
  const at = new Date().toISOString();
  const next = { ...state, lastAction: at, lastKind: kind };
  if (kind === 'greet') next.lastGreet = at;
  saveState(p, next);
}

function main() {
  const args = process.argv.slice(2);
  const kind = args[0];
  const wsArg = args.find((a) => a.startsWith('--workspace='));
  const workspace = wsArg
    ? path.resolve(wsArg.split('=').slice(1).join('='))
    : path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../');
  const p = statePath(workspace);
  if (kind === 'status') {
    console.log(JSON.stringify(loadState(p), null, 2));
    return;
  }
  if (!GAPS[kind] && kind !== 'read') throw new Error('Usage: node pacing.mjs <greet|scroll|read|status> [--workspace=DIR]');
  pacingWait(kind, workspace).then((w) => console.log(`pacing: waited ${w}ms for ${kind}`));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();
