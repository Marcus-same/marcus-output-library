// Pure function serialized into the already-bound page.
export function pageRisk({url='',frameUrl='',text=''}={}) {
  const normalized=String(text).normalize('NFKC').replace(/\s+/g,'');
  // 只看主机名与路径：查询参数里出现 403/verify/captcha 属正常业务参数（如 jobid=403abc），
  // 不能当成风控挑战路由，否则会误判整页为 PLATFORM_RISK。
  const route=s=>{const raw=String(s||'');try{const u=new URL(raw,'https://placeholder.invalid');return u.hostname+u.pathname;}catch{return raw.split('?')[0].split('#')[0];}};
  return /403|verify|captcha|security-check|passport|login/i.test(route(url)+' '+route(frameUrl))
    || /安全验证|验证码|访问受限|异常访问|安全提示|账号.{0,12}(限制|封禁|冻结)|暂时限制.{0,20}登录|第三方招聘管理系统|限制到期解除|预计开启时间|账户.{0,12}(限制|封禁|冻结)|环境存在异常/.test(normalized);
}

// 软信号（封号前兆）检测：平台硬墙之前的异常征兆。
// - RECOMMEND_EMPTY：上一轮还有卡片、这一轮推荐池刷新后为空
// - EMPTY_STREAK：连续多轮零新增（连续 2 轮即升级为只读）
// - SLOW_LOAD：单轮耗时异常（>8s），可能被风控降速
// level: 'normal' | 'warn'（继续但降速观察）| 'read_only'（当日降级为只读并落盘 flag）
export function softRisk({cardCount=0,prevCardCount=0,emptyStreak=0,roundMs=0,envError=false}={}) {
  const reasons=[];
  if(envError) reasons.push('TOKEN_FLAGGED: 页面出现「环境存在异常」，token/seed 链路已被风控标记');
  if(cardCount===0&&prevCardCount>0) reasons.push('RECOMMEND_EMPTY: 推荐池刷新后卡片为空');
  if(emptyStreak>=2) reasons.push(`EMPTY_STREAK: 连续 ${emptyStreak} 轮无新增卡片`);
  if(roundMs>8000) reasons.push(`SLOW_LOAD: 本轮耗时 ${Math.round(roundMs/1000)}s，疑似被降速`);
  let level='normal';
  if(envError||reasons.length>=2||emptyStreak>=2) level='read_only';
  else if(reasons.length===1) level='warn';
  return {level,reasons};
}

// 当日只读 flag：<workspace>/runtime/risk-flag.json，格式 {date, level, reasons[]}
// 各脚本开工前必须检查：当日 level==='read_only' 则拒绝一切写操作（含打招呼）。
import fs from 'node:fs';
import path from 'node:path';
export function riskFlagPath(workspace){return path.join(workspace,'runtime','risk-flag.json');}
export function readRiskFlag(workspace,{today=new Date()}={}){
  try{
    const f=JSON.parse(fs.readFileSync(riskFlagPath(workspace),'utf8'));
    const d=today.toISOString().slice(0,10);
    return f.date===d?f:null; // 隔日自动失效
  }catch{return null;}
}
export function writeRiskFlag(workspace,{level,reasons=[],date}={}){
  const d=date||new Date().toISOString().slice(0,10);
  fs.mkdirSync(path.dirname(riskFlagPath(workspace)),{recursive:true});
  fs.writeFileSync(riskFlagPath(workspace),JSON.stringify({date:d,level,reasons,at:new Date().toISOString()},null,2));
}
export function assertNotReadOnly(workspace){
  const f=readRiskFlag(workspace);
  if(f&&f.level==='read_only') throw new Error(`RISK_READ_ONLY: 今日已触发软信号只读（${f.reasons.join(';')}），对外动作全部暂停`);
}
