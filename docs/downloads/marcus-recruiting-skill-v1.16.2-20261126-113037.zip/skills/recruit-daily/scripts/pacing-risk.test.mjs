// pacing.mjs / page-risk.mjs 软信号 单元测试
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { requiredDelayMs, statePath } from './pacing.mjs';
import { softRisk } from './page-risk.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

test('pacing: 首次动作无需等待', () => {
  const w = requiredDelayMs('greet', {}, new Date('2026-10-24T10:00:00'));
  assert.equal(w, 0);
});

test('pacing: greet 间隔不早于 60s', () => {
  const state = { lastGreet: '2026-10-24T10:00:00Z', lastAction: '2026-10-24T10:00:00Z' };
  // 距上次 30s → 必须还需等待
  const w = requiredDelayMs('greet', state, new Date('2026-10-24T10:00:30Z'));
  assert.ok(w > 0 && w <= 180000, `wait=${w}`);
});

test('pacing: 间隔足够时无需等待', () => {
  const state = { lastGreet: '2026-10-24T10:00:00Z', lastAction: '2026-10-24T10:00:00Z' };
  const w = requiredDelayMs('greet', state, new Date('2026-10-24T10:04:00Z'));
  assert.equal(w, 0);
});

test('pacing: 夜间 01:00-06:00 拒绝对外动作', () => {
  const night = new Date('2026-10-24T03:00:00');
  assert.throws(() => requiredDelayMs('scroll', {}, night), /PACING_NIGHT/);
});

test('pacing: statePath 在 workspace/runtime 下', () => {
  assert.equal(statePath('/ws'), path.join('/ws', 'runtime', 'pacing-state.json'));
});

test('softRisk: 正常轮次为 normal', () => {
  const r = softRisk({ cardCount: 20, prevCardCount: 20, emptyStreak: 0, roundMs: 3000 });
  assert.equal(r.level, 'normal');
  assert.deepEqual(r.reasons, []);
});

test('softRisk: 推荐池突然变空 → warn', () => {
  const r = softRisk({ cardCount: 0, prevCardCount: 20, emptyStreak: 0, roundMs: 3000 });
  assert.equal(r.level, 'warn');
  assert.ok(r.reasons[0].startsWith('RECOMMEND_EMPTY'));
});

test('softRisk: 连续 2 轮为空 → read_only', () => {
  const r = softRisk({ cardCount: 0, prevCardCount: 0, emptyStreak: 2, roundMs: 3000 });
  assert.equal(r.level, 'read_only');
});

test('softRisk: 加载过慢 → warn', () => {
  const r = softRisk({ cardCount: 20, prevCardCount: 20, emptyStreak: 0, roundMs: 9000 });
  assert.equal(r.level, 'warn');
  assert.ok(r.reasons[0].startsWith('SLOW_LOAD'));
});

test('softRisk: 两个 warn 信号叠加 → read_only', () => {
  const r = softRisk({ cardCount: 0, prevCardCount: 20, emptyStreak: 0, roundMs: 9000 });
  assert.equal(r.level, 'read_only');
});
