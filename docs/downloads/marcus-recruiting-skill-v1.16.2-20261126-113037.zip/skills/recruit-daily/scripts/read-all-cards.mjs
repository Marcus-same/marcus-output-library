#!/usr/bin/env node
// 一次性读取推荐 iframe 内全部 .candidate-card-wrap 卡片（不只可见区）。只读。
// 用法：node read-all-cards.mjs <targetId> --json-out=FILE
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';

const TARGET = process.argv[2];
if (!TARGET) throw new Error('Usage: read-all-cards.mjs TARGET --json-out=FILE');
const outArg = (process.argv.find((a) => a.startsWith('--json-out=')) || '').split('=').slice(1).join('=');
assertBrowserAllowed(import.meta.url, { target: TARGET });
const client = createBrowserClient(import.meta.url, { target: TARGET });

const cards = JSON.parse(await client.ev(`(()=>{
  const d=document.querySelector('iframe[src*=recommend]').contentDocument;
  if(d.querySelector('.dialog-wrap.active'))throw Error('Detail panel open; close it first');
  const cs=[...d.querySelectorAll('.candidate-card-wrap')];
  return JSON.stringify(cs.map((c,i)=>{
    const inner=c.querySelector('.card-inner'), name=c.querySelector('.name');
    return {i, geekId:inner?inner.getAttribute('data-geekid'):null,
      name:name?name.innerText.trim():null,
      text:(c.innerText||'').replace(/\\s*\\n+\\s*/g,' | ')};
  }));
})()`));

const fs = await import('node:fs');
fs.writeFileSync(outArg, JSON.stringify(cards, null, 1));
console.log(JSON.stringify({ count: cards.length, out: outArg }));
