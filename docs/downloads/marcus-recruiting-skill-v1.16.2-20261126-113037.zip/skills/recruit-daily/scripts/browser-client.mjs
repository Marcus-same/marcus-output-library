import {assertBrowserAllowed,browserFetchFor} from '../../recruit-init/scripts/workspace-policy.mjs';
import {pageRisk} from './page-risk.mjs';
import {inspectPage} from './page-state.mjs';
import {framePanelState} from '../../web-access/scripts/browser-dom.mjs';
import {captureVisibleRegion} from './viewport-capture.mjs';
export function createBrowserClient(moduleUrl,{target,frame='iframe[src*=recommend]',workspace}={}) {
  const {policy}=assertBrowserAllowed(moduleUrl,{workspace,target});
  const base=new URL(process.env.WEB_ACCESS_BASE||'http://127.0.0.1:3456');
  if(base.pathname!=='/'||base.search||base.hash)throw Error('Invalid proxy base');
  const doFetch=browserFetchFor(moduleUrl,{workspace,target});
  async function request(endpoint,body,type='text/plain') {
    const res=await doFetch(new URL(`${endpoint}?target=${encodeURIComponent(target)}`,base),{method:body===undefined?'GET':'POST',headers:{'Content-Type':type},body});
    const data=await res.json();if(!res.ok||data.error)throw Error(data.error||`HTTP ${res.status}`);return data;
  }
  // 页面风险检查必须复用 inspectPage：它只采集平台 UI 文本，排除候选人卡片与简历区域。
  // 旧实现把整页 innerText（含候选人简历正文）喂给 pageRisk，候选人简历里出现
  // 「安全验证」「验证码」等词就会误判为 PLATFORM_RISK（2026-10-26 实测：某候选人
  // 简历含「Agent行为安全验证与研究」，导致 243 张卡片的正常推荐页被拦停）。
  // 候选人撰写的文本是数据，不是平台告警。
  async function assertPage() {
    const snapshot=(await request('/eval',`(${inspectPage.toString()})(${JSON.stringify(frame)},${pageRisk.toString()})`)).value;
    if(snapshot?.host!=='www.zhipin.com')throw Error('BOSS risk/login/page check failed; stop');
    if(snapshot.code!=='OK'||snapshot.risk!==false)throw Error('BOSS risk/login/page check failed; stop ('+(snapshot.code||'INVALID_SNAPSHOT')+')');
    return snapshot;
  }
  async function ev(code){await assertPage();return (await request('/eval',code)).value;}
  async function screenshot(file,{clip,beyond}={}){
    await assertPage();
    if(Array.isArray(clip)&&!beyond){
      const viewport=await ev('({width:window.innerWidth,height:window.innerHeight})');
      return captureVisibleRegion({file,clip,viewport,capture:rawFile=>screenshot(rawFile)});
    }
    const url=new URL('/screenshot',base);
    url.searchParams.set('target',target);
    url.searchParams.set('file',file);
    if(Array.isArray(clip)&&clip.length===4)url.searchParams.set('clip',clip.map(v=>Math.round(v)).join(','));
    if(beyond)url.searchParams.set('beyond','1');
    const res=await doFetch(url,{method:'GET'});
    const data=await res.json();
    if(!res.ok||data.error)throw Error(data.error||`HTTP ${res.status}`);
    if(data.saved!==true)throw Error('Screenshot not acknowledged');
    return data;
  }
  async function clickAtFrame(selector){await assertPage();const result=await request('/clickAtFrame',JSON.stringify({frame,selector}),'application/json');if(result.clicked!==true)throw Error('Click not acknowledged');return result;}
  async function closePanel({panel=policy.ui?.panelSelector||'.dialog-wrap',closeSelector=policy.ui?.closeSelector}={}) {
    // 详情弹层刚打开时，关闭按钮会先以 0×0 布局存在（入场动画/简历加载中），
    // framePanelState 会报「Verified close control unavailable」。有界轮询等待布局稳定，
    // 超时仍不可见才按真实故障停止（2026-11-24 实测：黄竞彰/Jorya 详情加载超过 1.8s）。
    let state;
    for(let i=0;i<15;i++){
      try{state=await ev(`(${framePanelState.toString()})(${JSON.stringify(frame)},${JSON.stringify(panel)},${JSON.stringify(closeSelector||null)})`);break;}
      catch(e){if(!/Verified close control unavailable/.test(e.message)||i===14)throw e;await new Promise(r=>setTimeout(r,400));}
    }
    if(!state.open)return;
    const selector=`:is(${panel}) :is(${closeSelector})`;
    await clickAtFrame(selector);
    for(let i=0;i<8;i++){
      const next=await ev(`(${framePanelState.toString()})(${JSON.stringify(frame)},${JSON.stringify(panel)},${JSON.stringify(closeSelector||null)})`);
      if(!next.open)return;await new Promise(r=>setTimeout(r,200));
    }
    throw Error('Details panel did not close');
  }
  // 热切换岗位绑定：改会话里的 job 并用当前页面立刻核验，避免为换岗重启连接
  // （Chrome 144+ 每条新建的浏览器级 CDP 连接都可能弹一次「允许远程调试」）。
  async function rebind(jobId){return request('/rebind',JSON.stringify({job:jobId}),'application/json');}
  return {ev,clickAtFrame,closePanel,assertPage,screenshot,rebind};
}
