#!/usr/bin/env node
// 按 geekId 逐个打开候选人详情，读取右侧文字（经历概览+教育+技能），随后真实关闭。只读，不发送。
// 用法：node read-resumes.mjs <targetId> <list.json> [--json-out=<file>] [--chars=4000]
//   list.json: [{"name":"张三","geekId":"..."}]  建议每批 ≤5 人
// 输出每人：cardName / panelName（身份核对）/ text / education 片段
import fs from 'node:fs';
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';

const TARGET = process.argv[2];
const listFile = process.argv[3];
if (!TARGET || !listFile) throw new Error('Usage: read-resumes.mjs TARGET LIST.json [--json-out=FILE] [--chars=N]');
const outArg = (process.argv.find((a) => a.startsWith('--json-out=')) || '').split('=').slice(1).join('=');
const charsArg = parseInt((process.argv.find((a) => a.startsWith('--chars=')) || '').split('=')[1] || '4000', 10);
assertBrowserAllowed(import.meta.url, { target: TARGET });

const client = createBrowserClient(import.meta.url, { target: TARGET });
const list = JSON.parse(fs.readFileSync(listFile, 'utf8'));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const DIALOG = '.dialog-wrap';

const dialogOpen = () => client.ev(`(()=>{const d=document.querySelector('iframe[src*=recommend]').contentDocument;return !![...d.querySelectorAll('${DIALOG}')].filter(e=>e.getClientRects().length).length;})()`);

const results = [];
for (let i = 0; i < list.length; i++) {
  const { name, geekId } = list[i];
  try {
    for (let k = 0; k < 3; k++) {
      if (!(await dialogOpen())) break;
      await client.closePanel({ panel: DIALOG, closeSelector: '.close-btn' });
      await sleep(800);
    }
    const mark = JSON.parse(await client.ev(`(()=>{const d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.querySelectorAll('[data-rd]').forEach(e=>e.removeAttribute('data-rd'));
const cs=[...d.querySelectorAll('.card-inner[data-geekid="${geekId}"]')];
if(cs.length!==1)return JSON.stringify({ok:false,why:'card_count_'+cs.length});
const n=cs[0].querySelector('.name');if(!n)return JSON.stringify({ok:false,why:'no_name'});
n.setAttribute('data-rd','1');return JSON.stringify({ok:true,cardName:n.innerText.trim()});})()`));
    if (!mark.ok) { results.push({ name, geekId, error: mark.why }); console.error(`✗ ${name} ${mark.why}`); continue; }
    await client.clickAtFrame('[data-rd="1"]');
    await sleep(2600);

    const got = JSON.parse(await client.ev(`(()=>{const d=document.querySelector('iframe[src*=recommend]').contentDocument;
const p=[...d.querySelectorAll('${DIALOG}')].filter(e=>e.getClientRects().length);
if(!p.length)return JSON.stringify({open:false});
const nm=[...p[0].querySelectorAll('.name')].filter(e=>e.getClientRects().length).map(e=>e.innerText.trim());
const rs=[...d.querySelectorAll('.resume-right-side')].filter(e=>e.getClientRects().length);
const txt=rs.length?rs[0].innerText:'';
// 左侧简历正文全文（比右侧概览详细得多，用于深度判断）
const body=[...d.querySelectorAll('.lib-standard-resume')].filter(e=>e.getClientRects().length);
const bt=body.length?body[0].innerText:'';
return JSON.stringify({open:true,panelName:nm[0]||null,text:txt.slice(0,${charsArg}),len:txt.length,
  bodyText:bt.slice(0,${charsArg}),bodyLen:bt.length,
  education:(txt.match(/[^\\n]*(?:大学|学院|研究院)[^\\n]*/g)||[]).slice(0,6)});})()`));

    results.push({ i: i + 1, name, geekId, cardName: mark.cardName, panelName: got.panelName,
      text: got.text || '', textLen: got.len || 0,
      bodyText: got.bodyText || '', bodyLen: got.bodyLen || 0,
      education: got.education || [],
      identityMatch: got.panelName ? got.panelName === mark.cardName : null });
    console.log(`✓ ${i + 1}/${list.length} ${name} 面板名=${got.panelName || '-'} 右侧 ${got.len || 0} 字 正文 ${got.bodyLen || 0} 字${got.panelName && got.panelName !== mark.cardName ? '  ⚠身份不一致' : ''}`);
    await client.closePanel({ panel: DIALOG, closeSelector: '.close-btn' });
    await sleep(1000);
  } catch (e) {
    results.push({ name, geekId, error: String(e.message || e) });
    console.error(`✗ ${i + 1}/${list.length} ${name} — ${e.message}`);
    try { if (await dialogOpen()) await client.closePanel({ panel: DIALOG, closeSelector: '.close-btn' }); } catch {}
  }
}
if (outArg) fs.writeFileSync(outArg, JSON.stringify(results, null, 1), 'utf8');
console.log(JSON.stringify({ done: results.length, failed: results.filter((r) => r.error).length }, null, 1));
