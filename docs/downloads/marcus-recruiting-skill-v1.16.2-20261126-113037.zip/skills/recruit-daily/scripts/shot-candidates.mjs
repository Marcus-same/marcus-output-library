#!/usr/bin/env node
// Third-layer deep screening: open candidate detail by geekId -> capture the whole
// online resume by scrolling the panel -> stitch -> close the panel for real. Read-only.
//
// BOSS renders the resume body on a canvas inside a fixed-height panel, so a single
// screenshot only captures the first screen. We scroll the tallest scroll container
// inside the dialog, capture the panel region each time, and stitch vertically.
//
// Usage: node shot-candidates.mjs <targetId> <listFile.json> <outDir> --identity-plan=<verified-plan.json>
//   listFile: [{"name":"张三","geekId":"..."}]
// Output: <outDir>/NN_<id10>.png + _index.json
import fs from 'node:fs';
import path from 'node:path';
import { createBrowserClient } from './browser-client.mjs';
import { assertBrowserAllowed } from '../../recruit-init/scripts/workspace-policy.mjs';
import { decodePng, encodePng, stitchVertical } from './png-stitch.mjs';
import { candidateSnapshot } from './candidate-snapshot.mjs';
import { assertIdentity } from './greet-safe.mjs';

const TARGET = process.argv[2];
const listFile = process.argv[3];
const outDir = path.resolve(process.argv[4]);
const identityPlanFile = process.argv.find(x => x.startsWith('--identity-plan='))?.slice('--identity-plan='.length);
const identityPlan = identityPlanFile ? JSON.parse(fs.readFileSync(identityPlanFile, 'utf8').replace(/^\uFEFF/, '')) : null;
if (!TARGET || !listFile || !outDir) throw new Error('Usage: shot-candidates.mjs TARGET LIST.json OUTDIR');
assertBrowserAllowed(import.meta.url, { target: TARGET });

const client = createBrowserClient(import.meta.url, { target: TARGET });
const list = JSON.parse(fs.readFileSync(listFile, 'utf8'));
fs.mkdirSync(outDir, { recursive: true });
const sleep = ms => new Promise(r => setTimeout(r, ms));

const DIALOG = '.dialog-wrap';
// 与发送/读取计划使用同一个已核验关闭控件；不要硬编码旧适配的选择器。
const CLOSE = identityPlan?.binding?.panel?.closeSelector || '.close-btn';
if (!identityPlan?.binding?.panel?.closeSelector) console.error('WARN: identity plan 未提供 closeSelector，回退 .close-btn；请先核验');
const OVERLAP = 40;
const MAX_TILES = 24;

const dialogOpen = () => client.ev(`(()=>{const d=document.querySelector('iframe[src*=recommend]').contentDocument;return !![...d.querySelectorAll('${DIALOG}')].filter(e=>e.getClientRects().length).length;})()`);

const probe = async () => JSON.parse(await client.ev(`(()=>{
  const d=document.querySelector('iframe[src*=recommend]').contentDocument;
  const p=[...d.querySelectorAll('${DIALOG}')].filter(e=>e.getClientRects().length)[0];
  if(!p)return JSON.stringify({open:false});
  let best=null;
  for(const e of p.querySelectorAll('*')){
    const s=d.defaultView.getComputedStyle(e);
    const need=e.scrollHeight-e.clientHeight;
    if(need>20&&/(auto|scroll)/.test(s.overflowY)&&e.getClientRects().length&&(!best||need>best.need))best={e,need};
  }
  const f=document.querySelector('iframe[src*=recommend]'),fr=f.getBoundingClientRect();
  const pr=p.getBoundingClientRect();
  const panel=[fr.left+pr.left,fr.top+pr.top,pr.width,pr.height];
  if(!best){window.__wbScroll=null;return JSON.stringify({open:true,panel,scroll:false,need:0,top:0});}
  window.__wbScroll=best.e;
  const r=best.e.getBoundingClientRect();
  return JSON.stringify({open:true,panel,scroll:true,need:best.need,
    rect:[fr.left+r.left,fr.top+r.top,r.width,r.height],
    scrollH:best.e.scrollHeight,clientH:best.e.clientHeight,top:best.e.scrollTop});
})()`));

const setTop = (v) => client.ev(`(()=>{const e=window.__wbScroll;if(!e)return -1;e.scrollTop=${v};return e.scrollTop;})()`);

const report = [];
for (let i = 0; i < list.length; i++) {
  const { name, geekId } = list[i];
  const safe = `${String(i + 1).padStart(2, '0')}_${geekId.replace(/[^A-Za-z0-9]/g, '').slice(0, 10)}`;
  const file = path.join(outDir, safe + '.png');
  const tmpDir = path.join(outDir, '.tiles-' + safe);
  try {
    for (let k = 0; k < 3; k++) {
      if (!(await dialogOpen())) break;
      await client.closePanel({ panel: DIALOG, closeSelector: CLOSE });
      await sleep(800);
    }
    const mark = JSON.parse(await client.ev(`(()=>{const d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.querySelectorAll('[data-shot-open]').forEach(e=>e.removeAttribute('data-shot-open'));
const cs=[...d.querySelectorAll('.card-inner[data-geekid="${geekId}"], .card-inner[data-geek="${geekId}"]')];
if(cs.length!==1)return JSON.stringify({ok:false,why:'card_count_'+cs.length});
const n=cs[0].querySelector('.name');if(!n)return JSON.stringify({ok:false,why:'no_name'});
n.setAttribute('data-shot-open','1');return JSON.stringify({ok:true,cardName:n.innerText.trim()});})()`));
    if (!mark.ok) throw new Error(mark.why);
    await client.clickAtFrame('[data-shot-open="1"]');
    await sleep(2800);

    const panelName = await client.ev(`(()=>{const d=document.querySelector('iframe[src*=recommend]').contentDocument;
const p=[...d.querySelectorAll('${DIALOG}')].filter(e=>e.getClientRects().length);
if(!p.length)return null;const n=[...p[0].querySelectorAll('.name')].filter(e=>e.getClientRects().length);
return n.length?n[0].innerText.trim():null;})()`);

    const candidate = identityPlan?.candidates.find(x => x.candidateId === geekId);
    const verify = async () => {
      if (!candidate) throw Error('Verified identity plan required');
      assertIdentity(await client.ev(`(${candidateSnapshot.toString()})(${JSON.stringify(identityPlan.binding)},${JSON.stringify(candidate.card)},true,true)`), identityPlan, candidate);
    };
    await verify();
    let m, signature = '', stable = 0;
    for (let attempt = 0; attempt < 12; attempt++) {
      const next = await probe();
      const sig = JSON.stringify([next.scroll, next.scrollH, next.clientH, next.panel, next.rect]);
      stable = sig === signature ? stable + 1 : 0;
      signature = sig;
      m = next;
      if (stable >= 3) break;
      await sleep(1000);
    }
    if (stable < 3) throw Error('Resume geometry did not stabilize');
    if (!m.open) throw new Error('dialog_closed_unexpectedly');

    let mode = 'panel', tiles = 1, width = Math.round(m.panel[2]), height = Math.round(m.panel[3]);
    if (m.scroll && m.need > 24) {
      mode = 'scrolled';
      const h = Math.round(m.clientH);
      const step = Math.max(120, h - OVERLAP);
      const maxTop = Math.max(0, m.scrollH - h);
      const tops = [];
      for (let t = 0; t <= maxTop && tops.length < MAX_TILES; t += step) tops.push(Math.min(t, maxTop));
      if (tops[tops.length - 1] !== maxTop) tops.push(maxTop);
      await setTop(0);
      await sleep(250);

      fs.mkdirSync(tmpDir, { recursive: true });
      const parts = [];
      for (let t = 0; t < tops.length; t++) {
        await setTop(tops[t]);
        await sleep(1000);
        await verify();
        const state = await probe();
        if (Math.abs(state.top - tops[t]) > 2) throw Error('Resume scroll position mismatch after wait');
        if (state.scrollH !== m.scrollH || state.clientH !== m.clientH) throw Error('Resume geometry changed during capture');
        const tf = path.join(tmpDir, `t${String(t).padStart(2, '0')}.png`);
        await client.screenshot(tf, { clip: [m.rect[0], m.rect[1], m.rect[2], h] });
        parts.push({ file: tf, top: tops[t], img: decodePng(fs.readFileSync(tf)) });
      }
      await setTop(0);
      tiles = parts.length;

      const imgs = parts.map((p, t) => {
        const img = p.img;
        if (t === 0) return img;
        const dup = Math.max(0, Math.min(img.height - 1, Math.round((parts[t - 1].top + h - p.top) * img.height / h)));
        if (!dup) return img;
        return { width: img.width, height: img.height - dup, bpp: img.bpp, data: img.data.subarray(dup * img.width * img.bpp) };
      });
      const out = stitchVertical(imgs, { overlap: 0 });
      fs.writeFileSync(file, encodePng(out));
      width = out.width;
      height = out.height;
    } else {
      await client.screenshot(file, { clip: [m.panel[0], m.panel[1], m.panel[2], m.panel[3]] });
    }

    await verify();
    const m2 = await probe();
    if (m2.scrollH !== m.scrollH || m2.clientH !== m.clientH) throw Error('Resume geometry changed before completion');
    const pixelScale = m.scroll ? width / m.rect[2] : width / m.panel[2];
    const covered = m.scroll ? Math.min(1, height / Math.max(1, m.scrollH * pixelScale)) : 1;
    report.push({ i: i + 1, name, geekId, cardName: mark.cardName, panelName, file, mode, tiles, width, height,
      scrollNeed: m.need || 0, scrollH: m.scrollH || 0, clientH: Math.round(m.clientH || m.panel[3]),
      coverage: Math.round(covered * 100) / 100, scrollTopAfter: m2.top,
      complete: mode === 'panel' ? true : covered >= 0.95, ok: true });
    console.log(`OK ${i + 1}/${list.length} ${name}  ${mode}  ${width}x${height}  tiles=${tiles}  coverage=${Math.round(covered * 100)}%  ${Math.round(fs.statSync(file).size / 1024)}KB`);
    await client.closePanel({ panel: DIALOG, closeSelector: CLOSE });
    await sleep(1000);
  } catch (e) {
    report.push({ i: i + 1, name, geekId, ok: false, error: String(e.message || e) });
    console.error(`FAIL ${i + 1}/${list.length} ${name} — ${e.message}`);
    try { if (await dialogOpen()) await client.closePanel({ panel: DIALOG, closeSelector: CLOSE }); } catch {}
    process.exitCode = 1;
    break;
  }
}
fs.writeFileSync(path.join(outDir, '_index.json'), JSON.stringify(report, null, 2), 'utf8');
const done = report.filter(r => r.ok);
console.log(`done: success ${done.length} / failed ${report.filter(r => !r.ok).length}; scrolled ${done.filter(r => r.mode === 'scrolled').length}; panel ${done.filter(r => r.mode === 'panel').length}`);
