import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {spawnSync} from 'node:child_process';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {workspaceFor,readPolicy} from '../../recruit-init/scripts/workspace-policy.mjs';
import {checkProxyRequest} from '../../web-access/scripts/proxy-security.mjs';
import {framePanelState,frameHitPoint} from '../../web-access/scripts/browser-dom.mjs';
import {validateProfileRoot,pickExactProfile} from '../../recruit-grill/scripts/profile-schema.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
function fixture(){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'recruit-regression-'));
 fs.writeFileSync(path.join(dir,'AGENTS.md'),'OFFLINE TEST');fs.writeFileSync(path.join(dir,'CONTEXT.md'),'OFFLINE TEST');
 fs.cpSync(path.join(root,'skills'),path.join(dir,'skills'),{recursive:true});
 fs.mkdirSync(path.join(dir,'runtime'));fs.writeFileSync(path.join(dir,'runtime/proxy-access-token'),'a'.repeat(64));
 return dir;
}
const enabled={version:1,browserAutomation:'existing-tab',allowNewTabs:false,allowBrowserLaunch:false,targetId:'mock-target'};
function preload(dir,mode='block'){
 const file=path.join(dir,'block-io.mjs'),marker=path.join(dir,'io.json');
 fs.writeFileSync(file,`import fs from 'node:fs';import http from 'node:http';import net from 'node:net';import cp from 'node:child_process';import {syncBuiltinESMExports} from 'node:module';const marker=${JSON.stringify(marker)};const log=type=>{const old=fs.existsSync(marker)?JSON.parse(fs.readFileSync(marker)):[];old.push(type);fs.writeFileSync(marker,JSON.stringify(old));};const denied=()=>{log('UNEXPECTED_IO');throw Error('UNEXPECTED_IO');};http.createServer=denied;http.request=denied;net.createConnection=denied;cp.spawn=denied;cp.execFileSync=denied;syncBuiltinESMExports();globalThis.WebSocket=class{constructor(){denied();}};globalThis.fetch=async()=>{log('fake-fetch');${mode==='risk'?"return {ok:true,json:async()=>({value:{host:'www.zhipin.com',blocked:true}})}":"throw Error('UNEXPECTED_IO')"}};`);
 return {file,marker};
}
test('all browser CLI entries stop before I/O under paused policy',()=>{
 const dir=fixture();fs.writeFileSync(path.join(dir,'.recruiting-policy.json'),JSON.stringify({...enabled,browserAutomation:'paused'}));
 const {file,marker}=preload(dir);
 for(const rel of ['recruit-daily/scripts/greet-from-recommend.mjs','recruit-daily/scripts/batch-read-resume.mjs','recruit-daily/scripts/human-scroll.mjs','recruit-daily/scripts/apply-profile-filters.mjs','web-access/scripts/check-deps.mjs','web-access/scripts/cdp-proxy.mjs','web-access/scripts/proxy-maintenance.mjs','web-access/scripts/find-url.mjs']){
   const result=spawnSync(process.execPath,['--import',pathToFileURL(file).href,path.join(dir,'skills',rel),'mock-target','personA,personB'],{encoding:'utf8',timeout:15000});
   assert.notEqual(result.status,0,rel);assert.match(result.stderr,/BROWSER_PAUSED/,rel);assert.equal(fs.existsSync(marker),false,rel);
 }
});
test('missing policy fails closed and arbitrary workspace override is rejected',()=>{
 const dir=fixture();assert.throws(()=>readPolicy(dir),/BROWSER_PAUSED/);
 assert.throws(()=>workspaceFor(import.meta.url,dir),/Workspace override rejected/);
});
test('risk page halts batch after the first fake request with nonzero status',()=>{
 const dir=fixture();fs.writeFileSync(path.join(dir,'.recruiting-policy.json'),JSON.stringify(enabled));const {file,marker}=preload(dir,'risk');
 const planFile=path.join(dir,'read-plan.json');fs.writeFileSync(planFile,JSON.stringify({targetId:'mock-target',jobId:'job',role:'role',binding:{frame:'frame',job:{selector:'job',attribute:'id'},panel:{selector:'panel',attribute:'id',nameSelector:'name',closeSelector:'close',textSelector:'text'}},candidates:[{candidateId:'id',name:'Test',card:{selector:'card',attribute:'id',nameSelector:'name',openSelector:'open'}}]}));
 const result=spawnSync(process.execPath,['--import',pathToFileURL(file).href,path.join(dir,'skills/recruit-daily/scripts/batch-read-resume.mjs'),'mock-target',`--plan-file=${planFile}`],{encoding:'utf8',timeout:15000});
 assert.notEqual(result.status,0);assert.match(result.stderr,/Batch stopped/);assert.deepEqual(JSON.parse(fs.readFileSync(marker)),['fake-fetch']);
});
test('invalid profile cannot issue even a fake browser request',()=>{
 const dir=fixture();fs.writeFileSync(path.join(dir,'.recruiting-policy.json'),JSON.stringify(enabled));const {file,marker}=preload(dir);const profile=path.join(dir,'invalid.json');fs.writeFileSync(profile,JSON.stringify({profiles:[{job_title:'unrelated'}]}));
 const result=spawnSync(process.execPath,['--import',pathToFileURL(file).href,path.join(dir,'skills/recruit-daily/scripts/apply-profile-filters.mjs'),'mock-target',`--profile-file=${profile}`],{encoding:'utf8',timeout:15000});
 assert.notEqual(result.status,0);assert.match(result.stderr,/Invalid or incomplete profile/);assert.equal(fs.existsSync(marker),false);
});
test('proxy rejects external Origin, missing token, wrong Host, browser fetch and new tabs',()=>{
 const opts={port:3456,token:'a'.repeat(64),policy:enabled};
 const good={url:'/eval?target=mock-target',method:'POST',headers:{host:'127.0.0.1:3456','x-recruiting-token':opts.token}};
 assert.equal(checkProxyRequest(good,opts).status,200);
 for(const req of [{...good,headers:{...good.headers,origin:'https://outside.invalid'}},{...good,headers:{host:'127.0.0.1:3456'}},{...good,headers:{...good.headers,host:'outside.invalid'}},{...good,headers:{...good.headers,'sec-fetch-site':'cross-site'}},{...good,url:'/new'},{...good,url:'/eval?target=other'},{...good,method:'GET'}])assert.notEqual(checkProxyRequest(req,opts).status,200);
 assert.equal(checkProxyRequest(good,{...opts,policy:{browserAutomation:'paused'}}).status,503);
 assert.equal(checkProxyRequest({...good,url:'/clickAtFrame?target=mock-target'},opts).status,200);
});
test('actual proxy router rejects cross-origin input before connection',async()=>{
 const source=fs.readFileSync(path.join(root,'skills/web-access/scripts/cdp-proxy.mjs'),'utf8');
 const route=source.slice(source.indexOf('const server = http.createServer('),source.indexOf('// 服务端口的原子绑定'));
 let handler,connections=0;
 vm.runInNewContext(route,{http:{createServer:fn=>{handler=fn;}},checkProxyRequest,accessToken:()=> 'a'.repeat(64),readPolicy:()=>enabled,workspaceContext:{root:'mock'},PORT:3456,connect:async()=>{connections++;throw Error('must not connect');},URL});
 const response={setHeader:()=>{},end(){},statusCode:200};
 await handler({url:'/eval?target=mock-target',method:'POST',headers:{host:'127.0.0.1:3456',origin:'https://outside.invalid','x-recruiting-token':'a'.repeat(64)}},response);
 assert.equal(response.statusCode,403);assert.equal(connections,0);
});
test('exact role matching rejects missing titles, unrelated roles and ambiguity',()=>{
 assert.equal(pickExactProfile([{job_title:'unrelated-role'}],'different-role'),null);
 assert.equal(pickExactProfile([{job_title:'role'},{boss_job_title:'role'}],'role'),null);
 assert.equal(pickExactProfile([{job_title:'role'}],''),null);
 assert.equal(pickExactProfile([{job_title:'role'}],'role').job_title,'role');
 assert.ok(validateProfileRoot({profiles:[{job_title:'role'}]},{requireReady:true}).length);
});
test('panels close only with a unique verified real control, never by deleting DOM',()=>{
 const close={disabled:false,getClientRects:()=>[{}]};
 const panel={getClientRects:()=>[{}],querySelectorAll:()=>[close]};let panels=[];
 const frame={contentDocument:{querySelectorAll:()=>panels}};
 const context={document:{querySelectorAll:()=>[frame]}};
 const call=(selector)=>vm.runInNewContext(`(${framePanelState.toString()})('frame','panel',${JSON.stringify(selector)})`,context);
 assert.equal(call('close').open,false);panels=[panel];assert.throws(()=>call(null),/closeSelector/);assert.equal(call('close').open,true);
 close.disabled=true;assert.throws(()=>call('close'),/unavailable/);close.disabled=false;panels=[panel,panel];assert.throws(()=>call('close'),/Ambiguous/);
});
test('real-click geometry rejects an obscured target rather than clicking through it',()=>{
 const el={disabled:false,scrollIntoView:()=>{},getBoundingClientRect:()=>({left:0,top:0,width:10,height:10}),contains:()=>false};
 const d={defaultView:{getComputedStyle:()=>({display:'block',visibility:'visible'})},querySelectorAll:()=>[el],elementFromPoint:()=>({})};
 const frame={contentDocument:d,clientLeft:0,clientTop:0,getBoundingClientRect:()=>({left:0,top:0})};
 assert.throws(()=>vm.runInNewContext(`(${frameHitPoint.toString()})('frame','control')`,{document:{querySelectorAll:()=>[frame],elementFromPoint:()=>frame},getComputedStyle:()=>({transform:'none'}),innerWidth:100,innerHeight:100}),/obscured/);
});
test('legacy role-only pending records block new sends with stable job IDs',async()=>{
 const {runTransaction,shanghaiDate}=await import('./greet-safe.mjs');const dir=fixture();
 fs.writeFileSync(path.join(dir,'runtime/recruit-actions.jsonl'),JSON.stringify({actionId:'old',platform:'boss',candidateId:'id',role:'role',stage:'greet_unknown'})+'\n');
 const plan={targetId:'mock-target',jobId:'job',role:'role',candidates:[{candidateId:'id',name:'Test'}],authorization:{confirmed:true,date:shanghaiDate(),jobId:'job',targetId:'mock-target',candidateIds:['id'],evidence:'OFFLINE TEST'}};
 await assert.rejects(runTransaction({workspace:dir,plan,target:plan.targetId,send:true,adapter:{open:()=>assert.fail('must not open browser')}}),/Prior send/);
});
test('a writer inserting the same pending intent mid-run prevents a second send',async()=>{
 const {runTransaction,shanghaiDate}=await import('./greet-safe.mjs');const {appendEvent,sendActionId,reviewActionId}=await import('./action-store.mjs');const dir=fixture();let sends=0;
 const plan={targetId:'mock-target',jobId:'job',role:'role',candidates:[{candidateId:'id',name:'Test'}],authorization:{confirmed:true,date:shanghaiDate(),jobId:'job',targetId:'mock-target',candidateIds:['id'],evidence:'OFFLINE TEST'}};
 appendEvent(dir,{platform:'boss',candidateId:'id',jobId:'job',role:'role',runId:'seed',stage:'reviewed',actionId:reviewActionId({platform:'boss',candidateId:'id',jobId:'job'}),detail:'{}'});
 const event={platform:'boss',candidateId:'id',jobId:'job',role:'role',runId:'other',stage:'greet_pending',authorization:'TEST'};event.actionId=sendActionId(event);
 const snap={unique:true,risk:false,jobId:'job',candidateId:'id',name:'Test'};
 await assert.rejects(runTransaction({workspace:dir,plan,target:plan.targetId,send:true,adapter:{open:async()=>snap,inspect:async()=>{appendEvent(dir,event);return snap;},send:async()=>{sends++;}}}),/already exists/);
 assert.equal(sends,0);
});
