#!/usr/bin/env node
import {createBrowserClient} from './browser-client.mjs';
import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';
const target=process.argv[2];
if(!target) throw Error('Usage: scroll-recommend-top TARGET');
const {root}=assertBrowserAllowed(import.meta.url,{target});
const client=createBrowserClient(import.meta.url,{target,workspace:root,frame:'iframe[src*=recommend]'});
const result=await client.ev(`(()=>{const f=document.querySelector('iframe[src*=recommend]');if(!f)throw Error('Frame missing');const d=f.contentDocument;if(d.querySelector('.dialog-wrap.active'))throw Error('Detail open');const e=d.scrollingElement;if(!e)throw Error('Scroller missing');e.scrollTop=0;return {top:e.scrollTop,height:e.scrollHeight};})()`);
console.log(JSON.stringify(result));
