// 一次性建连：先复用健康的常驻会话，确认失效才清理元数据并建立「唯一一条」Chrome 连接。
// 目的：减少 Chrome 144+「允许远程调试」弹窗——每次新建 browser 级 CDP 连接都会弹一次，
// 因此这里只在真正失效时连一次，且绝不重试、绝不并发探测。
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {existingSession} from './session-control.mjs';
import {startBoundSession} from './bound-session.mjs';
import {archiveStaleSession} from './session-recovery.mjs';
import {workspaceFor,readPolicy,accessToken} from '../../recruit-init/scripts/workspace-policy.mjs';

const descriptorFile=root=>path.join(root,'runtime','browser-session.json');
const lockFile=root=>path.join(root,'runtime','browser-session.lock');

// 当天真实建连次数（来源：browser-startup-timings.jsonl 的 connect 记录）。弹窗预算基线是 1 次。
export function connectionsToday(root,{now=new Date()}={}){
 const file=path.join(root,'runtime','browser-startup-timings.jsonl');
 if(!fs.existsSync(file))return 0;
 const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 return fs.readFileSync(file,'utf8').split(/\r?\n/).filter(Boolean).map(line=>{try{return JSON.parse(line);}catch{return null;}})
  .filter(e=>e&&e.mode==='connect'&&typeof e.timestamp==='string'&&new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(e.timestamp))===day).length;
}

async function stopService({descriptor,token,fetchImpl=fetch}){
 const res=await fetchImpl(new URL('/shutdown',descriptor.base),{method:'POST',headers:{'X-Recruiting-Token':token,'Content-Type':'application/json'},body:JSON.stringify({instanceId:descriptor.instanceId}),redirect:'error',signal:AbortSignal.timeout(3000)});
 if(!res.ok)throw Error('Session stop rejected');return res.text();
}

// 只做「要不要新建连接」的判断，不接触 Chrome。返回值：{action:'reuse'|'start', lane, cleaned}
export async function planConnection({root,target,job,fetchImpl=fetch,archive,stop,now=()=>new Date()}){
 const policy=readPolicy(root);
 const wantTarget=target||policy.targetId;
 const token=accessToken(root);
 const archiveFn=archive||(r=>archiveStaleSession(r,{token}));
 const stopFn=stop||(d=>stopService({descriptor:d,token,fetchImpl}));
 if(!wantTarget)throw Error('Explicit target required (policy has no targetId)');
 if(typeof job!=='string'||!job.trim())throw Error('Explicit job required');
 const file=descriptorFile(root);
 if(!fs.existsSync(file)){
  if(fs.existsSync(lockFile(root)))throw Error('Stale session lock present; run session-control.mjs archive-stale first');
  return {action:'start',lane:'no_session',cleaned:[]};
 }
 let descriptor;
 try{descriptor=JSON.parse(fs.readFileSync(file,'utf8'));}catch{throw Error('Unreadable session descriptor; preserve files and inspect manually');}
 const cleaned=[];
 if(descriptor.targetId!==wantTarget||descriptor.jobId!==job){
  // 身份不符的旧描述文件不能被复用，也不能直接覆盖；先确认服务已停再归档。
  if(descriptor.instanceId){
   try{await stopFn(descriptor);cleaned.push('stopped_mismatched_instance');}
   catch(e){cleaned.push('stop_failed:'+e.message);}
  }
  const archived=await archiveFn(root);
  cleaned.push('archived:'+archived.status);
  return {action:'start',lane:'identity_mismatch',cleaned};
 }
 let session;
 try{session=await existingSession({rootOverride:root,target:wantTarget,job,fetchImpl});}
 catch(e){
  // 服务不可达：必须先证明进程已死才能归档，archive-stale 内部会拒绝活着的实例。
  const archived=await archiveFn(root);
  return {action:'start',lane:'unreachable',error:e.message,cleaned:[...cleaned,'archived:'+archived.status]};
 }
 if(session.health.connected)return {action:'reuse',lane:'healthy',session,cleaned};
 // 服务活着但 Chrome 连接已断：优雅停掉自己，再归档，然后只建一条新连接。
 try{await stopFn(session.descriptor);cleaned.push('stopped_disconnected_instance');}
 catch(e){cleaned.push('stop_failed:'+e.message);}
 const archived=await archiveFn(root).catch(e=>({status:'archive_refused',error:e.message}));
 cleaned.push('archived:'+archived.status);
 return {action:'start',lane:'disconnected',cleaned};
}

export async function connectSession({root,target,job,endpoint,start=startBoundSession,fetchImpl=fetch,archive,stop}={}){
 const wantTarget=target||readPolicy(root).targetId;
 const plan=await planConnection({root,target:wantTarget,job,fetchImpl,archive,stop});
 if(plan.action==='reuse'){
  return {status:'reused',lane:plan.lane,instanceId:plan.session.descriptor.instanceId,targetId:plan.session.descriptor.targetId,jobId:plan.session.descriptor.jobId,connectionAttempts:plan.session.health.connectionAttempts,cleaned:plan.cleaned};
 }
 const service=await start({target:wantTarget,job,endpoint,rootOverride:root});
 return {status:'started',lane:plan.lane,instanceId:service.instanceId,base:service.base,timing:service.timing,cleaned:plan.cleaned,service};
}

if(process.argv[1]&&fs.realpathSync(process.argv[1])===fs.realpathSync(fileURLToPath(import.meta.url))){
 const args=Object.fromEntries(process.argv.slice(2).map(a=>{const i=a.indexOf('=');if(!a.startsWith('--')||i<0)throw Error('Use --key=value');return[a.slice(2,i),a.slice(i+1)];}));
 const root=workspaceFor(import.meta.url);
 const target=args.target||readPolicy(root).targetId;
 const job=args.job;
 const endpoint=args.endpoint;
 try{
  if(!job)throw Error('Explicit --job required');
  const plan=await planConnection({root,target,job});
  if(plan.action==='reuse'){
   console.log(JSON.stringify({status:'reused',lane:plan.lane,instanceId:plan.session.descriptor.instanceId,targetId:plan.session.descriptor.targetId,jobId:plan.session.descriptor.jobId,connectionAttempts:plan.session.health.connectionAttempts,noChromeTouch:true,connectionsToday:connectionsToday(root)}));
  }else{
   if(!endpoint)throw Error('Explicit --endpoint required to start a new Chrome connection');
   console.log(JSON.stringify({preflight:plan.lane,cleaned:plan.cleaned,connectionsToday:connectionsToday(root),note:'Chrome 144+ 会为这一条新连接弹一次「允许远程调试」'}));
   const service=await startBoundSession({target,job,endpoint,rootOverride:root});
   console.log(JSON.stringify({status:'started',instanceId:service.instanceId,base:service.base,timing:service.timing}));
   for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{const hard=setTimeout(()=>process.exit(1),3000);hard.unref?.();service.stop().catch(console.error).finally(()=>{clearTimeout(hard);process.exit(0);});});
  }
 }catch(e){console.error(e.message);process.exitCode=1;}
}
