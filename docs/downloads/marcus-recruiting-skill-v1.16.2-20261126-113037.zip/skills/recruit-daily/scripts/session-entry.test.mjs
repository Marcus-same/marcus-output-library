import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import os from 'node:os';
import {fileURLToPath} from 'node:url';

test('canonical and .agents entry points reject invalid arguments instead of silently succeeding',()=>{
 const canonical=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..');
 const temp=fs.mkdtempSync(path.join(os.tmpdir(),'recruit-entry-'));
 const linked=path.join(temp,'skills');fs.symlinkSync(canonical,linked,process.platform==='win32'?'junction':'dir');
 for(const prefix of [canonical,linked]){
  for(const script of ['bound-session.mjs','session-control.mjs']){
   const result=spawnSync(process.execPath,[path.resolve(prefix,'recruit-daily/scripts',script),'invalid'],{encoding:'utf8',windowsHide:true});
   assert.notEqual(result.status,0,`${prefix}/${script} silently succeeded`);
   assert.ok(result.stderr.trim(),`${script} must explain the failure`);
   assert.doesNotMatch(result.stderr,/Cannot find module/);
  }
 }
});
