#!/usr/bin/env node
import fs from 'node:fs';
import {randomUUID,createHash} from 'node:crypto';
import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';
import {createBrowserClient} from './browser-client.mjs';
import {assertIdentity,validatePlan} from './greet-safe.mjs';
import {candidateSnapshot} from './candidate-snapshot.mjs';
import {readCandidates} from './read-safe.mjs';
import {appendEvent,reviewActionId} from './action-store.mjs';
// 第二层（右侧经历复筛）唯一的事实凭证：每读一人就落一条 reviewed 事件。
// 发送前 greet-safe 会校验这条记录，没有就不允许打招呼——防止「卡片正则直接接发送」。
const {root:workspace}=assertBrowserAllowed(import.meta.url,{target:process.argv[2]});

async function main() {
  const [target,...args]=process.argv.slice(2);
  if(!target||args.some(a=>!/^--(?:plan-file=.+|chars=\d+|json)$/.test(a)))throw Error('Usage: batch-read-resume.mjs TARGET --plan-file=PLAN.json [--chars=500] [--json]; names/indexes/rotation are unsupported');
  const planArgs=args.filter(a=>a.startsWith('--plan-file='));
  const charArgs=args.filter(a=>a.startsWith('--chars='));
  if(planArgs.length!==1||charArgs.length>1)throw Error('Exactly one identity plan required');
  const plan=JSON.parse(fs.readFileSync(planArgs[0].slice(12),'utf8').replace(/^\uFEFF/,''));
  validatePlan(plan,target,false);
  const chars=charArgs.length?Number(charArgs[0].slice(8)):500;
  if(!Number.isSafeInteger(chars)||chars<0)throw Error('Invalid chars');
  const b=plan.binding;
  const text=x=>typeof x==='string'&&x.trim();
  const native=b?.panel?.identitySource;
  const nativeIdentity=native?.type==='vue-record'&&text(native.selector)&&['recordPath','idPath','namePath'].every(k=>Array.isArray(native[k])&&native[k].length&&native[k].every(text));
  const jobBinding=b?.job?.source==='frame-url'||(text(b?.job?.selector)&&text(b?.job?.attribute));
  const panelBinding=nativeIdentity||(text(b?.panel?.attribute)&&text(b?.panel?.nameSelector));
  if(!text(b?.frame)||!jobBinding||!text(b.panel?.selector)||!panelBinding||!text(b.panel?.closeSelector)||!text(b.panel?.textSelector))throw Error('Missing verified job/panel/read bindings');
  for(const c of plan.candidates)for(const k of ['selector','attribute','nameSelector','openSelector'])if(!text(c.card?.[k]))throw Error('Missing verified candidate bindings');
  const client=createBrowserClient(import.meta.url,{target,frame:b.frame});
  const snapshot=(c,panel=false,read=false)=>client.ev(`(${candidateSnapshot.toString()})(${JSON.stringify(b)},${JSON.stringify(c.card)},${panel},${read})`);
  const close=()=>client.closePanel({panel:b.panel.selector,closeSelector:b.panel.closeSelector});
  // 详情面板有时只渲染「经历概览」骨架（实测 53 字），文本非空但根本没正文。
  // 低于这个长度不当作读到，继续轮询；一直不达标就停止本批，不用空壳下判断。
  const MIN_BODY=120;
  const adapter={
    async open(c){await close();assertIdentity(await snapshot(c),plan,c);await client.clickAtFrame(`:is(${c.card.selector}) :is(${c.card.openSelector})`);await new Promise(resolve=>setTimeout(resolve,1200));return snapshot(c,true);},
    async read(c){
      // Poll only empty/skeleton text for the SAME verified person. Identity failure is fatal.
      let last=0;
      for(let i=0;i<10;i++){
        const s=await snapshot(c,true,true);assertIdentity(s,plan,c);
        last=s&&typeof s.text==='string'?s.text.trim().length:0;
        if(s.loaded&&last>=MIN_BODY)return s;
        await new Promise(resolve=>setTimeout(resolve,400));
      }
      throw Error(`Resume body not rendered (max ${last} chars < ${MIN_BODY}); refusing to judge on an outline skeleton`);
    },close,
  };
  const runId=randomUUID();
  const recordReviewed=r=>{
    // detail 里保留复筛凭证：读到的正文长度、是否被截断、本次 --chars 上限。
    appendEvent(workspace,{
      actionId:reviewActionId({platform:'boss',jobId:plan.jobId,candidateId:r.candidateId}),
      runId,platform:'boss',jobId:plan.jobId,role:plan.role,candidateId:r.candidateId,stage:'reviewed',
      detail:JSON.stringify({textLen:r.fullLength,truncated:r.truncated,chars}),
    });
  };
  const screenActionId=candidateId=>createHash('sha256').update(JSON.stringify(['boss','screened',plan.jobId,candidateId])).digest('hex');
  const onResult=r=>{
    if(r.ok===false){
      // 读取失败（骨架/正文未加载）不写 reviewed：发送前的漏斗校验会继续拦住该人。
      appendEvent(workspace,{
        actionId:screenActionId(r.candidateId),
        runId,platform:'boss',jobId:plan.jobId,role:plan.role,candidateId:r.candidateId,stage:'screened',
        detail:JSON.stringify({ok:false,error:r.error}),
      });
    } else recordReviewed(r);
    console.log(JSON.stringify(r));
  };
  // 单人骨架/未加载继续下一位；身份、风险、关闭失败仍会由 readCandidates 抛出并停批。
  await readCandidates({plan,target,adapter,chars,minText:MIN_BODY,continueOnFailure:true,onResult});
}
main().catch(error=>{console.error('Batch stopped: '+error.message);process.exitCode=1;});
