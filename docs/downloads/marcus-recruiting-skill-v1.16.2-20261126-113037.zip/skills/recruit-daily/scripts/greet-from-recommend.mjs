#!/usr/bin/env node
import {createBrowserClient} from './browser-client.mjs';
import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';
assertBrowserAllowed(import.meta.url,{target:process.argv[2]});
// Default is preview. Sending requires --send plus a dated, explicit approval plan.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {runSafe,validatePlan} from './greet-safe.mjs';
import {candidateSnapshot} from './candidate-snapshot.mjs';
import {pacingWait} from './pacing.mjs';
import {assertNotReadOnly} from './page-risk.mjs';

async function main() {
  const args=process.argv.slice(2), target=args.shift();
  const options=Object.fromEntries(args.filter(a=>a.includes('=')).map(a=>{const i=a.indexOf('=');return [a.slice(2,i),a.slice(i+1)];}));
  if(!target || !options['plan-file'] || args.some(a=>!/^--(plan-file=.+|workspace=.+|send|dry)$/.test(a)) || (args.includes('--send')&&args.includes('--dry'))) throw new Error('Usage: node greet-from-recommend.mjs TARGET --plan-file=approved.json [--workspace=DIR] [--send|--dry]');
  const {root:workspace}=assertBrowserAllowed(import.meta.url,{workspace:options.workspace,target});
  const plan=JSON.parse(fs.readFileSync(options['plan-file'],'utf8').replace(/^\uFEFF/,''));
  const send=args.includes('--send');validatePlan(plan,target,send);
  if(send) assertNotReadOnly(workspace); // 当日软信号只读 flag 为 read_only 时禁止发送
  const client=createBrowserClient(import.meta.url,{target,workspace,frame:plan.binding?.frame});
  const ev=client.ev;
  // Probe descriptors must be derived from the actual current DOM, never guessed.
  const binding=plan.binding;
  const native=binding?.panel?.identitySource;
  const nativeIdentity=native?.type==='vue-record'&&native.selector&&['recordPath','idPath','namePath','jobIdPath'].every(k=>Array.isArray(native[k])&&native[k].length&&native[k].every(v=>typeof v==='string'&&v.trim()));
  const jobBinding=binding?.job?.source==='frame-url'||(binding?.job?.selector&&binding?.job?.attribute);
  const panelBinding=nativeIdentity||(binding?.panel?.attribute&&binding?.panel?.nameSelector);
  if(!binding?.frame || !jobBinding || !binding.panel?.selector || !panelBinding || !binding.panel?.closeSelector) throw new Error('Missing verified DOM/native bindings');
  if(nativeIdentity&&!(typeof plan.verificationEvidence==='string'&&plan.verificationEvidence.trim()))throw Error('Native sending binding requires current-page verification evidence');
  for(const c of plan.candidates) if(!c.card?.selector || !c.card?.attribute || !c.card?.nameSelector || !c.card?.openSelector) throw new Error('Missing candidate card bindings');
  const frame=JSON.stringify(binding.frame);
  async function probe(c,panel=false) {
    return await ev(`(${candidateSnapshot.toString()})(${JSON.stringify(binding)},${JSON.stringify(c.card)},${panel},false)`);
  }
  const {assertIdentity}=await import('./greet-safe.mjs');
  const click=client.clickAtFrame;
  const adapter={
    async open(c){await client.closePanel({panel:binding.panel.selector,closeSelector:binding.panel.closeSelector});const before=await probe(c);assertIdentity(before,plan,c);await click(`:is(${c.card.selector}) :is(${c.card.openSelector})`);await new Promise(r=>setTimeout(r,1800));return probe(c,true);},
    async inspect(c){const snapshot=await probe(c,true);const count=await ev(`(()=>{const d=document.querySelector(${frame}).contentDocument;return [...d.querySelectorAll(${JSON.stringify(':is('+binding.panel.selector+') .btn-sure-v2.btn-greet')})].filter(e=>e.getClientRects().length&&!e.disabled&&e.innerText.trim()==='打招呼').length;})()`);if(count!==1)throw new Error('Greet button not ready');return snapshot;},
    async send(){if(send) await pacingWait('greet',workspace);await click(':is('+binding.panel.selector+') .btn-sure-v2.btn-greet');},
    async confirm(c){
      // After a successful click BOSS may keep the detail dialog open while
      // updating the underlying card.  Probing the card first made a valid
      // send look unknown during that short transition.  Keep identity bound
      // to the native dialog when it is still open, then poll the card state.
      const deadline=Date.now()+7000;
      let lastIdentityError=null;
      while(Date.now()<deadline){
        try {
          const panelSnapshot=await probe(c,true);
          assertIdentity(panelSnapshot,plan,c);
        } catch(error) {
          // The dialog may close as part of the success transition.  In that
          // case the card identity check below is the safe fallback.
          try { const cardSnapshot=await probe(c); assertIdentity(cardSnapshot,plan,c); }
          catch(cardError){ lastIdentityError=cardError; await new Promise(r=>setTimeout(r,300)); continue; }
        }
        const sent=await ev(`(()=>{const d=document.querySelector(${frame})?.contentDocument;if(!d)return false;const card=d.querySelector(${JSON.stringify(c.card.selector)});const panel=d.querySelector(${JSON.stringify(binding.panel.selector)});const visible=e=>e&&e.getClientRects().length&&getComputedStyle(e).display!=='none'&&getComputedStyle(e).visibility!=='hidden';const hasContinue=root=>!!root&&[...root.querySelectorAll('button,[role="button"]')].some(e=>visible(e)&&e.innerText.trim()==='继续沟通');return hasContinue(card)||hasContinue(panel);})()`);
        if(sent===true)return true;
        await new Promise(r=>setTimeout(r,300));
      }
      if(lastIdentityError) throw lastIdentityError;
      return false;
    },
    async close(){await client.closePanel({panel:binding.panel.selector,closeSelector:binding.panel.closeSelector});},
  };
  console.log(JSON.stringify(await runSafe({workspace,plan,target,send,adapter}),null,2));
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) main().catch(e=>{console.error(e.message);process.exitCode=1;});
