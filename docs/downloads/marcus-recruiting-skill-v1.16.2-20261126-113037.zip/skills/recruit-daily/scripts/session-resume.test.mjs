import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {existingSession} from './session-control.mjs';

function fixture(t){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'recruit-resume-'));
 t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 fs.mkdirSync(path.join(root,'runtime'));
 const policy={version:1,browserAutomation:'existing-tab',allowNewTabs:false,allowBrowserLaunch:false,targetId:'T'};
 const descriptor={instanceId:'I',targetId:'T',jobId:'J',base:'http://127.0.0.1:12345'};
 fs.writeFileSync(path.join(root,'.recruiting-policy.json'),JSON.stringify(policy));
 fs.writeFileSync(path.join(root,'runtime/browser-session.json'),JSON.stringify(descriptor));
 fs.writeFileSync(path.join(root,'runtime/proxy-access-token'),'a'.repeat(64));
 return {root,descriptor,policy};
}
test('fast reuse makes one authenticated local health request and returns timing',async t=>{
 const f=fixture(t);let calls=0;
 const fetchImpl=async(url,options)=>{calls++;assert.equal(url.href,f.descriptor.base+'/health');assert.equal(options.headers['X-Recruiting-Token'],'a'.repeat(64));assert.equal(options.redirect,'error');return {ok:true,json:async()=>({...f.descriptor,connected:true,connectionAttempts:1})};};
 for(let i=0;i<2;i++){const result=await existingSession({rootOverride:f.root,target:'T',job:'J',fetchImpl});assert.equal(result.health.instanceId,'I');assert.ok(result.timing.totalMs>=0);}
 assert.equal(calls,2);
});
test('paused policy, mismatched target/job and missing descriptor stop before requests',async t=>{
 const f=fixture(t);const fetchImpl=()=>{throw Error('must not request');};
 await assert.rejects(existingSession({rootOverride:f.root,target:'other',fetchImpl}),/TARGET_MISMATCH/);
 await assert.rejects(existingSession({rootOverride:f.root,job:'other',fetchImpl}),/JOB_MISMATCH/);
 fs.writeFileSync(path.join(f.root,'.recruiting-policy.json'),JSON.stringify({...f.policy,browserAutomation:'paused'}));
 await assert.rejects(existingSession({rootOverride:f.root,fetchImpl}),/BROWSER_PAUSED/);
 fs.writeFileSync(path.join(f.root,'.recruiting-policy.json'),JSON.stringify(f.policy));
 fs.unlinkSync(path.join(f.root,'runtime/browser-session.json'));
 await assert.rejects(existingSession({rootOverride:f.root,fetchImpl}),/SESSION_MISSING/);
});
test('unreachable or wrong instance fails without retry',async t=>{
 const f=fixture(t);let calls=0;
 await assert.rejects(existingSession({rootOverride:f.root,fetchImpl:async()=>{calls++;throw Object.assign(Error('refused'),{code:'ECONNREFUSED'});}}),/SESSION_UNREACHABLE/);
 assert.equal(calls,1);
 await assert.rejects(existingSession({rootOverride:f.root,fetchImpl:async()=>({ok:true,json:async()=>({...f.descriptor,instanceId:'wrong'})})}),/identity mismatch/);
});
