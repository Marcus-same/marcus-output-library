import {existingSession} from './session-control.mjs';
import {createBrowserClient} from './browser-client.mjs';
const session=await existingSession();
process.env.WEB_ACCESS_BASE=session.descriptor.base;
const client=createBrowserClient(import.meta.url,{target:session.descriptor.targetId});
const state=await client.ev(`(()=>{const f=document.querySelector('iframe[src*=recommend]'),d=f?.contentDocument;return {frame:!!f,open:!!d?.querySelector('.filter-panel'),label:d?.querySelector('.filter-label')?.innerText||null}})()`);
if(!state.frame)throw Error('FRAME_MISSING');
if(!state.open)await client.clickAtFrame('.filter-label');
console.log(JSON.stringify(await client.ev(`(()=>{const f=document.querySelector('iframe[src*=recommend]');return {open:!!f?.contentDocument?.querySelector('.filter-panel')}})()`)));
