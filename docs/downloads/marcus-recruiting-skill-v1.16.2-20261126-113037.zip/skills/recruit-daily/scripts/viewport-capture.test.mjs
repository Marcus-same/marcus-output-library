import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {cropViewport,captureVisibleRegion} from './viewport-capture.mjs';
import {encodePng,decodePng} from './png-stitch.mjs';
function pixels(width,height){return {width,height,bpp:3,data:Buffer.from(Array.from({length:width*height*3},(_,i)=>i%251))};}
test('crop uses physical pixels at 2x display scale',()=>{
 const src=pixels(20,12),out=cropViewport(src,[2,1,4,3],{width:10,height:6});
 assert.equal(out.width,8);assert.equal(out.height,6);
 assert.deepEqual(out.data.subarray(0,24),src.data.subarray((2*20+4)*3,(2*20+12)*3));
});
test('unsafe or changed viewport stops instead of capturing beyond it',()=>{
 const src=pixels(20,12);
 for(const clip of [[-1,0,3,3],[8,0,4,3],[0,5,3,3],[0,0,0,2]])assert.throws(()=>cropViewport(src,clip,{width:10,height:6}));
 assert.throws(()=>cropViewport(src,[0,0,2,2],{width:10,height:10}),/changed/);
});
test('capture requests full viewport once and preserves original evidence',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'viewport-capture-')),file=path.join(dir,'crop.png');
 let calls=0;
 const result=await captureVisibleRegion({file,clip:[1,1,3,2],viewport:{width:10,height:6},capture:async rawFile=>{calls++;fs.writeFileSync(rawFile,encodePng(pixels(20,12)));return {saved:true};}});
 assert.equal(calls,1);assert.equal(result.mode,'viewport-local-crop');
 assert.equal(decodePng(fs.readFileSync(file)).width,6);
 assert.ok(fs.existsSync(result.viewportFile));
});
