#!/usr/bin/env node
// 检查「浏览器访问唯一入口」纪律：工作区里不允许出现绕过常驻会话的裸 CDP 连接。
//
// 背景（2026-11-24 真实事故）：agent 在 runtime/ 写了若干临时脚本，各自
// `new WebSocket('ws://127.0.0.1:9222/devtools/browser/...')` + Target.attachToTarget。
// 每开一条浏览器级 CDP 连接，Chrome 144+ 就弹一次「允许远程调试」，握手 2–8 秒。
// 结果：一次任务点了十几次「允许」，每步都慢。规定早就写在
// recruit-daily/references/connection-recovery.md L24/L38 与 web-access/SKILL.md L33/L35。
//
// 用法：node skills/recruit-daily/scripts/check-browser-access.mjs [--json]
// 退出码：0 无违规 | 1 发现违规 | 2 参数错误
//
// 白名单是有意的、最小化的：只有真正负责「建立/承载那一条连接」的模块可以碰裸 WS。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');

// 允许出现裸 WebSocket / Target.getTargets 的文件（相对工作区根，正斜杠）
const ALLOW = [
  'skills/web-access/scripts/cdp-connection.mjs',   // 唯一的连接实现
  'skills/web-access/scripts/cdp-proxy.mjs',        // 旧代理，仅保留以支持停止维护
  'skills/web-access/scripts/ws-compat.mjs',        // 零依赖 WebSocket 客户端
  'skills/web-access/scripts/ws-bind-check.mjs',    // 仅限首次接入的一次性验收
  'skills/web-access/scripts/browser-discovery.mjs',
  'skills/web-access/scripts/proxy-maintenance.mjs',
  'skills/recruit-daily/scripts/bound-session.mjs', // 常驻会话：整轮只建这一条
];

const RULES = [
  { name: 'raw-websocket', re: /new\s+WebSocket\s*\(/, hint: '裸 WebSocket 连接' },
  { name: 'target-probe', re: /Target\.getTargets|Target\.attachToTarget/, hint: '裸 CDP 探活/attach' },
  { name: 'hardcoded-cdp-url', re: /ws:\/\/127\.0\.0\.1:\d+\/devtools\/browser/, hint: '手写 CDP 地址' },
];

const SKIP_DIRS = new Set(['node_modules', '.git', '.agents', '.claude', '.qoder', '_shared', 'resumes', 'reports']);

// 分发包副本（marcus-recruiting-kit-*）是参考整包，不是本工作区运行代码，不参与检查。
// 本工作区真正的 skills 在 ./skills 下，那才是要被约束的对象。
function isKitCopy(name) {
  return /^marcus-recruiting-kit-/.test(name) || name === '_kit-1.16.1';
}

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name.startsWith('.')) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name) && !isKitCopy(e.name)) walk(p, out); }
    else if (e.isFile() && /\.(mjs|cjs|js)$/.test(e.name) && !/\.test\.(mjs|cjs|js)$/.test(e.name)) out.push(p);
  }
  return out;
}

const violations = [];
for (const file of walk(ROOT)) {
  const rel = path.relative(ROOT, file).split(path.sep).join('/');
  if (ALLOW.includes(rel)) continue;
  const lines = fs.readFileSync(file, 'utf8').split(/\r?\n/);
  for (const [i, line] of lines.entries()) {
    if (/^\s*(\/\/|\*|\/\*)/.test(line)) continue; // 注释里的说明不算违规
    for (const rule of RULES) {
      if (rule.re.test(line)) {
        violations.push({ file: rel, line: i + 1, rule: rule.name, hint: rule.hint, text: line.trim().slice(0, 140) });
      }
    }
  }
}

const json = process.argv.includes('--json');
if (json) {
  console.log(JSON.stringify({ ok: violations.length === 0, violations }, null, 2));
} else if (!violations.length) {
  console.log('OK：未发现绕过常驻会话的裸 CDP 连接。');
  console.log('允许的入口：browser-client.mjs（打在常驻会话本地端口上，单次约 200ms）。');
} else {
  console.error(`发现 ${violations.length} 处违规（每处都会让 Chrome 多弹一次「允许远程调试」）：`);
  for (const v of violations) console.error(`  ${v.file}:${v.line}  [${v.rule}] ${v.text}`);
  console.error('\n改为经常驻服务调用：见 skills/recruit-daily/references/connection-recovery.md L24。');
}
process.exitCode = violations.length ? 1 : 0;
