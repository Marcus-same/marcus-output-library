# BOSS 推荐池「刷新」按钮与换池流程（2026-11-24 实测）

> 本文件记录推荐池滚动到底、无更多候选人时，用页面自带「刷新」按钮获取新一批推荐的操作方法。
> 仅适用于**已绑定同一个 BOSS 招聘者 target** 的常驻会话；页面改版后必须重新核验选择器。

## 触发条件

推荐池被完整滚动到底（`iframe[src*=recommend]` 的 `documentElement.scrollTop` 到 `scrollHeight`）后，底部出现：

- 提示容器 `.no-data-refresh`，文案：**「当前列表没有更多牛人了，刷新获取最新列表」**；
- 按钮 `button.btn.btn-refresh`，文案：**「刷新」**（仅在底部、列表耗尽时可见）。

列表没有耗尽时没有这个按钮，不要提前找或强行刷新。

## 操作步骤

1. 在已绑定会话内，把推荐 iframe 滚到底：
   `d.documentElement.scrollTop = d.documentElement.scrollHeight`，等待约 1 秒。
2. 只读核验 `.btn-refresh` 唯一且可见（示例：`[...d.querySelectorAll('.btn-refresh')].filter(e=>e.getClientRects().length).length === 1`）。
3. 用 `clickAtFrame('.btn-refresh')` 做**真实点击**（禁止 DOM click）。
4. 等待约 3 秒，回读：
   - `.candidate-card-wrap` 数量变化（实测 450 张 → 15 张，新一批推荐）；
   - `scrollTop` 归零（回到列表顶部）；
   - `.no-data-refresh` 消失。
5. 用 `read-all-cards.mjs` 重新读取整批卡片，按最终台账号/姓名去重，再进入卡片初筛 → 读简历 → 判断 → 打招呼。

## 实测记录（2026-11-24）

- 刷新前：450 张卡片，滚到底可见 `.btn-refresh`；
- 点击后：15 张新卡片，`scrollTop=0`，`.no-data-refresh` 消失；
- 新批次中筛出候选人后正常读取详情、打招呼成功（`greet_confirmed`）。

## 约束与坑

- 刷新只是换一批**推荐**候选，不等于切到「精选 / 定向搜索」入口；入口授权规则不变。
- 每批新卡片必须重新去重（平台 `data-geekid` 或台账姓名+岗位），已打过招呼的人不能重复打。
- 必须先把当前批读完、筛完再刷新，避免丢失未处理的候选人。
- 刷新会重置滚动位置，刷新后从顶部重新读；不要在刷新过程中并发操作详情面板。
- 遇验证码、风控、登录异常、额度提示立即停止，不靠刷新绕过限制。
- 频率无官方保证；连续刷新可能被限流，单轮只做必要的批次刷新。
