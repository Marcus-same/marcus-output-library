# 简历截图：能力边界与标准流程

## 2026-10-28 发白与卡顿修复

当前 `browser-client.screenshot(file,{clip})` 默认只向 Chrome 请求当前完整视口截图，再在本地按 clip 裁切，保留 `.viewport.png` 原图。常规简历截图不向 Chrome 传局部 clip、不扩展视口、不撑高容器。下面接口的原生 clip/beyond 是底层能力，不代表日常截图应直接使用。

逐屏滚动后等待 1000ms，再按原生身份核验并截图。高分屏按实际像素比例裁掉重叠行、计算覆盖率，避免把 CSS 像素直接用于图片行数。截图区域超出视口或捕获时宽高比例变化则停止，不回退到扩展视口。

离线裁切与拼接10项检查通过；随后经用户明确授权重连同一页面，静态及三屏滚动截图实测通过，截图前后尺寸稳定、详情真实关闭、未发送消息。2026-10-28用户确认“没有发白”。这是当前环境的小样本结果，不代表所有浏览器或页面均已验证；断线仍不得自动重连。

第三层深判要"看完整简历"，而 BOSS 的简历正文在详情面板内部滚动，且是 **canvas 渲染**（DOM 里读不到正文）。本文说明截图能力的真实边界、怎么截全、截不全是怎么办。

## 一、`/screenshot` 接口

```
GET /screenshot?target=<targetId>&file=<绝对路径>[&clip=x,y,w,h][&beyond=1][&format=png|jpg]
```

- 只对已绑定 targetId 生效；请求须带 `X-Recruiting-Token`（`browser-client` 自动加）。
- 走常驻会话，不新建连接；每次请求前后都跑 `ensurePage()` 的岗位/风控校验。
- **方法是 GET**（`proxy-security.mjs` 定义），用 POST 会 `405 Wrong HTTP Method`。
- `clip=x,y,w,h`：只截**页面坐标**里的这个矩形（CSS 像素，相对主文档左上角）。用于只拍详情面板，不拍整屏外围。
- `beyond=1`：允许渲染**视口之外**的内容（`captureBeyondViewport`）。配合 clip 才能拍下高于一屏的区域。

## 二、能力边界（2026-10-25 实测修正）

- `Page.captureScreenshot` 是裸调，**本身不支持 fullPage**。
- **拉高视口无效**：把视口从 609 拉到 3226 / 4696，BOSS 详情面板高度不变（面板有固定高度），剩余滚动仍有 2595 / 4039px。1.4.11 曾据此声称"能截全"，实测不成立，已推翻。
- **左侧简历正文是 canvas**（class 含 `wasm-resume-layout`）：读 `.lib-standard-resume` 拿到的文本长度与右侧概览完全相同，说明 DOM 里没有正文。**深度判断只能靠像素**，没有文字兜底。

## 三、"截全"的正确做法：滚动 + 拼接（2026-10-25 三次实测后定案）

走过两条死路，记下来免得重犯：

| 尝试 | 结果 |
|---|---|
| 直接截一屏 | 只拍到简历开头 |
| 拉高视口（`Emulation.setDeviceMetricsOverride`） | **无效**：面板有固定高度，视口 3226/4696 时面板不变，剩余滚动仍 2595/4039px |
| 把容器 `height` 撑到 `scrollHeight` + `clip` + `beyond=1` | **无效**：正文是 canvas 且虚拟化，撑高后除原视口那块以外**整片空白** |

**唯一可行**：按容器可视高度逐屏滚动，每屏用 `clip` 只裁简历区域，再纵向拼接。

1. 找滚动容器（`overflow-y: auto|scroll` 且 `scrollHeight-clientHeight` 最大者）
2. 记容器**页面坐标矩形**与 `scrollHeight` / `clientHeight`
3. `step = clientHeight - 40`（留 40px 重叠，避免拼缝切在字中间）；最后一屏用 `scrollTop = scrollHeight - clientHeight` 收尾
4. 每屏：`scrollTop = top` → 等 1000ms → 通过 `browser-client.screenshot(file,{clip:rect})` 截当前视口并本地裁切，保存瓷砖及原视口图
5. 按**实际 top 差 × 图片像素/CSS像素比例**算出相邻重复行数，从后一张顶部裁掉，再纵向拼接
6. 滚回顶部，真实关闭详情
7. 覆盖率 = 拼接后像素高度 / (`scrollHeight` × 像素比例)，≥95% 记 `complete: true`

拼接由 `scripts/png-stitch.mjs` 完成：**纯 Node + 内置 zlib，零外部依赖**，只处理 Chrome 会产出的 8bit 非隔行 RGB/RGBA PNG。

## 四、标准流程：`shot-candidates.mjs`

```text
node skills/recruit-daily/scripts/session-control.mjs run \
  skills/recruit-daily/scripts/shot-candidates.mjs <targetId> <list.json> <outDir>
```

`list.json`：`[{"name":"张三","geekId":"5420ea00e7a1cd9433F43N66F1U~"}]`

每人流程：关残留详情 → 按 geekId 唯一定位卡片真实点击 → 核对面板名 → 量容器 → 需要滚动就走上面的逐屏拼接，否则单屏裁面板 → 滚回顶部 → 真实关闭。

产物：

```
<outDir>/NN_<id10>.png     整份简历长图（滚动拼接）或详情面板（无需滚动时）
<outDir>/_index.json       mode / tiles / width / height / scrollH / coverage / complete
```

**判读**：`coverage` ≥0.95 且 `complete:true` 才算截全。`tiles` 是实际抓了几屏，异常大说明简历超长，可对照 `MAX_TILES=24` 上限检查是否被截断。

实测样例（刘女士，2026-10-25）：5 屏 → 1524×5135，覆盖率 100%。


## 五、什么时候用哪个发送脚本

| 脚本 | 路径 | 何时用 |
|---|---|---|
| `greet-from-recommend.mjs` | 详情面板内点「打招呼」 | **默认**。需要面板身份核验、走 `candidateSnapshot`（支持 `panel.identitySource=vue-record`、`job.source=frame-url`） |
| `greet-from-card.mjs` | 卡片上直接点「打招呼」 | **备用**。面板拿不到候选人 ID 属性时用；同样复用 `greet-safe` 事务引擎，身份锚点是卡片原生 `data-geekid` |

两者都：默认预演、`--send` 才发、发送前 `assertNotReadOnly()`、两次之间 `pacingWait('greet')` 强制 60–120 秒。

## 六、仍未解决的

- **空白简历画布**：部分候选人详情两侧都是空白，等多久都不出内容。遇到记 `待确认`，换人。
- **详情关闭未确认**：关闭动画可能停滞；`closePanel` 会重试并回读，仍失败就停止整批。
- 这两项两个分支都没解决，不能因为"以前能过"就当没问题。

## 2026-10-29 加载稳定性补充

shot-candidates.mjs 现须传 --identity-plan=<本轮核验计划>，每屏核验原生候选人身份。捕获前等待几何数据连续稳定，滚动等待后核验实际scrollTop；捕获期间高度变化即停止该候选人的截图。滚动目标每次按当前真实容器更新，不沿用上一候选人的引用。瓷砖和原视口图保留为证据。本轮姜煜原先仅首屏却误标完整，修正后4屏实测覆盖项目和教育；证据runtime/resumes/20261029-fullstack10/repaired-shot-v2/。其后本轮7位候选人亦通过逐屏捕获及身份核验；这不保证其他页面适配。
