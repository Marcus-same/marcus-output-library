# 连接恢复与启动故障排查

恢复前读取现有授权和 `.recruiting-policy.json`，沿用已授权的浏览器、标签页及发布岗位范围。安装或升级本身不恢复连接。用户已明确授权恢复时不重复索取同一授权。

## 选择一个连接拥有者

### 每天第一条连接：只跑一次 `connect.mjs`

```text
node skills/recruit-daily/scripts/connect.mjs --job=<本轮jobId> [--target=<policy.targetId>] --endpoint=<已核验ws地址>
```

它先把「要不要新建连接」判断完，再决定是否连 Chrome：

| 情形 | 行为 | 新增 Chrome 连接 |
|---|---|---|
| 常驻会话健康 | 直接返回 `status:"reused"`，不碰 Chrome | 0 |
| 服务活着但 Chrome 已断 | 先优雅 stop，再 archive-stale，然后建一条 | 1 |
| 服务不可达 | 先 archive-stale（证明进程已死），然后建一条 | 1 |
| 无描述文件 | 直接建一条 | 1 |
| 描述文件 target/job 不符 | 不复用，stop + archive 后重建 | 1 |
| 策略为 paused | 任何请求前即报 `BROWSER_PAUSED` | 0 |

**不要再用裸 WebSocket 探测端点**（`ws://127.0.0.1:9222/devtools/browser/...` 手写连接、`Target.getTargets` 探活等）。每开一条 browser 级 CDP 连接，Chrome 144+ 就弹一次「允许远程调试」；探测会让弹窗数量翻倍。端点是否存活由 `connect.mjs` 的复用分支回答。

### 正常启动及继续任务：先快速复用

已有本轮绑定时只运行一次：

```text
node skills/recruit-daily/scripts/session-control.mjs resume --target=<本轮targetId> --job=<本轮jobId>
```

此命令先读取本地策略与描述文件，检查本轮target/job，再发一次有认证的本地 `/health` 请求（超时3秒）。成功输出 `reused`、实例ID、连接次数及耗时；不建立Chrome连接、不扫描端口、不发现或切换标签页。后续任务仍执行页面风险与岗位检查。缺失、失效、断线、身份不符均停止，不自动转入启动流程。

首次连接的阶段耗时与快速复用成功耗时追加到 `runtime/browser-startup-timings.jsonl`，不记录凭证或WebSocket地址。首次连接区分本地预检、Chrome握手、target查询、attach、页面及岗位核验、本地服务启动；失败记录所在阶段。45秒是等待Chrome许可/握手的上限，不是每次固定等待，不应为了提速直接缩短人工许可窗口。离线测试不能替代真实耗时验收。

仅首次接入、失效或需要恢复时执行下列排查；已有可用连接时不重跑初始化验收、不先检查所有浏览器。

招聘任务使用 `bound-session.mjs`；`session-control.mjs` 仅访问已运行的实例。不要先启动旧 `cdp-proxy` 再启动常驻服务，也不要为每个检查创建短连接。旧代理已运行时使用认证维护命令停止，确认停止后再启动常驻服务。

```text
node skills/recruit-daily/scripts/session-control.mjs status
node skills/recruit-daily/scripts/session-control.mjs archive-stale
node skills/recruit-daily/scripts/bound-session.mjs --target=<已核验targetId> --job=<已核验jobId> --endpoint=<已核验本机WebSocket地址>
```

仅在失效服务明确拒绝连接且拥有者进程已不存在时归档元数据。归档保留副本，不删除业务日志、台账或附件。启动参数必须用 `--key=value`，不要传位置参数。正式目录与项目级 junction 入口都应执行同样的启动逻辑；退出码0但无ready输出不能认定已启动。

Chrome可能提供 `/devtools/browser/<实例编号>` 地址，旧的无编号地址也可能有效；按已核验实际地址连接，不能擅自截断路径。端口文件读取受限时申请只读权限，不猜端口或换浏览器。配置授权后可从模板创建本地config.env，但此文件及令牌不进入安装包。

## Chrome 的调试授权：为什么反复弹窗，怎么少弹

**两代机制要分清（2026-10 实测）**

| 机制 | 触发条件 | 表现 |
|---|---|---|
| Chrome ≥136 | 用**默认** user-data-dir 传 `--remote-debugging-port` | 参数被**静默忽略**，端口不监听，无任何提示 |
| Chrome ≥144 | 走「接入现有浏览器」路径（`chrome://inspect/#remote-debugging` 开关 + 弹窗） | **每条新的浏览器级 CDP 连接**都弹一次「要允许远程调试吗」 |

关键在于：**Chrome 不会"记住上次允许"**。它不是忘了，而是客户端在不断申请**新的会话**。所以「点一次就永久授权」在浏览器侧没有开关——组策略 `RemoteDebuggingAllowed` 只做整体开关，也不提供自动同意。

**因此降频的唯一正确方向是：不要重连。** 具体三条：

1. **一条连接用到底**。任务开始建一次连接，任务之间不 `stop`；第二天用 `session-control resume` 复用（3 秒健康检查，不碰 Chrome）。
2. **换岗位不重启**。用 `switch-job.mjs`：它点击下拉切换后调会话的 `/rebind` 热改绑定并按当前页面立刻核验，失败会回滚。**不再需要 stop + 重新启动**（那会多一次握手、多一次弹窗）。
3. **只有真正失效才重启**：`SESSION_UNREACHABLE` / 进程已死 / `archive-stale` 之后。
4. **弹窗预算基线：一天 1 次**（当天首次建连）。若一天弹了多次，按顺序排查：是否有人手动 `stop` 后重启、是否跑了诊断/探活脚本多开了连接、是否失败重试堆叠。`runtime/browser-startup-timings.jsonl` 的 `mode:"connect"` 记录条数就是当天的真实建连次数。

**握手挂住时不要重试**：端口在监听、`DevToolsActivePort` 正常，但 WebSocket 握手一直挂着，通常就是 Chrome 在等授权。此时自动重试只会让弹窗堆叠。正确动作是告诉用户：切到 Chrome 窗口，检查 `chrome://inspect/#remote-debugging` 开关是否打开、有没有「允许远程调试」弹窗需要点允许。客户端没有 API 能代替这个点击。

> 注：用独立 user-data-dir 启动调试实例可以完全免弹窗，但那是全新 profile——没有现有登录态，需要重新登录 BOSS，与「复用用户已登录标签页」的策略冲突，不作为本工作区方案。

## 会话绑定过期：为什么读不到页面，正确顺序是什么（2026-11-24 实测）

**症状**：`session-control.mjs status` / `/health` 显示绑定 `jobId=A`，但任何 `/eval` 都返回
`PAGE_CHECK: JOB_MISMATCH`；再调 `/rebind A` 也被拒（`Rebind rejected: PAGE_CHECK: JOB_MISMATCH`）。

**原因**：页面 iframe 的 `jobid` 已经变成 B（换岗、下拉误点、SPA 重载都可能），会话绑定还是 A。
常驻会话的**所有**页面路由（`/eval`、`/screenshot`、`/clickAtFrame`）在求值前都执行
`assertPageState(value, activeJob)`，所以连「读一下页面当前是哪个岗位」都会被拦掉 ——
**不存在任何只读通道**能绕过这个闸门。

**唯一例外是 `/rebind`**：它先切换本地绑定，再用当前页面重新核验，不符则回滚并报错。
因此它同时是「切换器」和「探针」。

正确顺序（顺序反了就会卡死）：

1. **先 `rebind(目标jobId)`**。成功 ⇒ 页面本来就是目标岗位，只是绑定过期，**不需要点任何东西**。
2. 失败 ⇒ 页面确实不是目标岗位，这时才去点下拉切换。
3. **点完选项立刻 `rebind`**，然后才回读页面 jobid 做二次确认。点完先读一定被拦。

诊断「页面现在是什么岗位」：拿已知 jobId 列表逐个 `rebind` 做**成员测试**，成功者即当前岗位。
这一步只改本地会话绑定，不动页面、不新建连接、不弹授权。

```text
node skills/recruit-daily/scripts/switch-job.mjs <targetId> <jobId>
```

该脚本已按上述顺序实现（先 rebind 试探 → 需要才点下拉 → 点完先 rebind 再读）。

**严禁两种「绕开死结」的错误做法**：

- ❌ 裸开 WebSocket 去自己读页面。这既违反本文件 L24，也只会换来一次「允许远程调试」弹窗 + 2–8 秒握手。
- ❌ 点开岗位下拉再点回 label 想「关掉下拉」来枚举岗位。BOSS 会把那两次点击当成一次选中，
  **直接把页面切到列表里的某个岗位**（实测切到了「财务运营专员」）。枚举只读 DOM 里已存在的
  `.job-item` 节点，绝不点击。

静态自查（每轮寻源后建议跑一次）：

```text
node skills/recruit-daily/scripts/check-browser-access.mjs
```

它扫描整个工作区，发现绕过常驻会话的裸 CDP 连接就报错退出。

## 先区分连接、标签页、岗位

- 连接拒绝、握手失败：报告实际错误，超时停止。远程调试许可由用户在Chrome确认。
- `Bound tab unavailable`：指定target无法复用。用户授权列出现有标签页后，只读识别对应BOSS页面；不能新建、刷新或导航页面。识别存在歧义时请用户指定。
- `PAGE_CHECK: JOB_MISMATCH`：连接已经成功，但当前发布岗位不同。已确认本轮发布岗位时，在原页面核验下拉原生名称和值并真实切换，回读iframe实际URL中的jobid；不把它报告成端口故障，不重复询问同一选择。
- 发布名称不同可以对应同一个内部岗位，但不代表jobId相同。根据用户本轮选择更新画像绑定；不能为消除报错而随意接受当前岗位。
- 页面风险、身份不唯一、真实关闭失败、空白或未加载项目图：停止相关页面处理和发送。保持原BOSS标签页前台；后台可能暂停画布和关闭动画，但没有证据时不能把所有错误归咎于焦点。

## 验收

至少两次独立客户端任务复用同一实例，实例ID相同且连接次数1，并回读目标岗位。先保存连接验收证据，再设置及核验筛选。连接成功不代表简历画布、真实关闭或发送已通过。

2026-10-22实测边界：启动入口与带实例编号地址适配后，连接复用、选岗和筛选可通过；后续仍出现空白画布和关闭未确认。这两项仍需处理，不作为本次连接修复已解决的能力发布。
