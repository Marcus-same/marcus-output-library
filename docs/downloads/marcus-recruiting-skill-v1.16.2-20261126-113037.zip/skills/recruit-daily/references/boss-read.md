当前 BOSS 浏览器自动化处于暂停状态（`.recruiting-policy.json`）。安装或升级不构成恢复授权；不得探测、启动、重连或访问 BOSS。恢复必须由用户另行明确授权；恢复后也只复用用户指定的已有 targetId，不刷新、不新建标签页或独立浏览器，无法复用即停止。离线岗位梳理和本地简历工作不受影响。

# BOSS 卡片、文字与按需截图

执行前读 `boss-recommend-integration.md` 和 `boss-browser.md`。标准来自 CONTEXT 与对应岗位内部笔记，面板来自 `<role>.boss-profile.json`。

1. 在推荐 iframe 读取 `.candidate-card-wrap` 的可见文本和页面已有的稳定身份标识；序号只能用于当前页面诊断，不得当候选人身份。去重计数按不同候选人累计，不能只看 DOM 数量。
   一次读全池用 `../scripts/read-all-cards.mjs <targetId> --json-out=<file>`（只读，输出 `i/geekId/name/text`，含视口外卡片）；只读当前可见区用 `../scripts/read-cards.mjs`。两者都不点击、不发送。
2. 按浅到深逐批筛选：方向 → 可见硬门槛 → 命脉信号 → 排除信号。薪资只记录。
3. 初筛入选者先执行 `../scripts/batch-read-resume.mjs <targetId> --plan-file=<身份计划JSON> --json`；每批最多 5 人，同名、身份变化、缺少详情等立即停止整批。默认禁止切换入口找人。
4. truncated=true 时用 --chars=0 补读完整右侧文字。右侧文字不等于 canvas 项目全文，缺少项目证据不能直接认定候选人没有该能力。
5. 文字确认不合适者不截图；仍有潜力且缺完整项目证据者按集成流程截图，证据立即保存到本地台账。无每日截图数字上限，不进行全池截图或无目的重复截图。
   **截全简历**：使用 `scripts/shot-candidates.mjs` 逐屏滚动、等待1000ms、截当前视口后本地裁切，再按实际像素比例拼接；不拉高视口，不使用 `vh`。按 `_index.json` 的 `coverage` 和 `complete` 判断覆盖情况；详见 [`resume-screenshot.md`](resume-screenshot.md)。
6. 扩池使用 `../scripts/human-scroll.mjs`，分步滚动并记录新增身份。脚本累计 DOM 张数不能代替去重扫描数。
7. 普通推荐停止与进入精选的闸门见集成文档；岗位配置禁止的入口不能进入。截图失败、验证或登录异常时停止。



本地适配约束：本文 CLI、旧接口或切换入口说明不能覆盖暂停与单标签规则。脚本不支持 --rotate 或 --allow-tab-switch；找不到人、额度不足、验证或登录错误就停止。显示名数量不是稳定候选人数，不用凑样本目标驱动额外访问。

## 读取计划

本地修复补充（2026-10-21）：原生 DOM 属性仍为默认身份来源。若详情弹窗外壳无候选人 ID，可在只读检查确认后，使用 `binding.panel.identitySource`：`type="vue-record"`、唯一的内部组件 `selector`、`recordPath`、`idPath`、`namePath`，记录提供岗位 ID 时配置 `jobIdPath`（路径均为字符串数组）。ID 与姓名必须来自同一个页面原生记录，不得拷贝卡片 ID 到弹窗；读取计划必须保存真实页面核验依据。组件路径、字段缺失或身份不一致立即停止。此适配仅用于读取，不自动放宽发送脚本的 DOM 身份要求。

本工作区的真实读取计划和核验依据必须保存在自己的 `runtime/resumes/<本轮>/`，不复制作者或旧工作区的真实计划、ID或个人路径；不保证其他页面或改版后沿用。读取/关闭时保持原 BOSS 标签页在前台；后台曾观察到退出动画停滞，关闭校验失败仍停止，不移除DOM、不合成动画结束事件。

当前岗位 ID 可用 `binding.job={"source":"frame-url","parameter":"jobid"}` 从已经绑定的推荐 iframe 实际 URL 核验，不能用 iframe src 中的 null。

读取脚本通过常驻会话运行：`node skills/recruit-daily/scripts/session-control.mjs run skills/recruit-daily/scripts/batch-read-resume.mjs <targetId> --plan-file=<计划> --chars=0 --json`。该入口只复用 `runtime/browser-session.json` 指向的已认证实例，不创建或重连 Chrome。服务状态与停止使用同脚本的 `status`、`stop`；停止仅关闭本地连接，不关闭用户标签页。新建会话必须显式授权、指定现有 targetId 和本机端口，沿用暂停政策。

使用 `boss-greet.md` 的身份计划结构（读取不需要发送授权）：targetId、jobId、role、candidates 及 binding 均必需。额外填写 `binding.panel.textSelector`，用于唯一定位该详情里的可见简历正文。所有 ID 属性、卡片、岗位、详情、关闭和正文选择器须来自经授权的现有页面检查；不得用人工新加的属性伪造稳定 ID。

旧的 --names-file、姓名列表、索引和入口轮换均不再支持。输出总是 JSON 行，含 candidateId、jobId、name、text、loaded 与 truncated。打开前核对卡片，打开后及读取正文时核对详情身份；出现风险、重名、缺字段或未加载就停止，不能把内容归入另一人。只轮询同一已核验身份的空正文，不重新点击猜测恢复。

