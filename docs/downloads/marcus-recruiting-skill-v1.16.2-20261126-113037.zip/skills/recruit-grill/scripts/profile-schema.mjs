const text=x=>typeof x==='string'&&!!x.trim();
const object=x=>x&&typeof x==='object'&&!Array.isArray(x);
export function validateProfileRoot(root,{requireReady=false}={}) {
  const errors=[];
  if(!Array.isArray(root?.profiles)||root.profiles.length!==1) return ['profiles must contain exactly one role'];
  const p=root.profiles[0];if(!object(p))return ['Profile must be an object'];
  for(const k of ['job_title','calibrated_at','source']) if(!text(p[k])) errors.push(`Missing ${k}`);
  if(!['ready','needs_boss_binding','needs_user_decision'].includes(p.status)) errors.push('Invalid status');
  if(requireReady && p.status!=='ready') errors.push('Profile is not ready');
  if(p.status==='ready' && (!text(p.job_id)||!text(p.boss_job_title)))errors.push('Ready profile requires verified job ID and published title');
  if(p.selection_scope==='each_run'&&!text(p.binding_run_id)&&p.status==='ready')errors.push('Current binding_run_id required');
  const d=p.dimensions;
  if(!object(d))errors.push('dimensions must be an object');
  else {
    for(const k of ['age_range','activation','recent_not_viewed','gender','exchange_resume_with_colleague'])if(!text(d[k]))errors.push(`Missing dimensions.${k}`);
    for(const k of ['school','experience','degree'])if(!Array.isArray(d[k])||!d[k].length||d[k].some(v=>!text(v)))errors.push(`Invalid dimensions.${k}`);
    if(typeof d.school_first_degree_only!=='boolean')errors.push('Invalid first degree switch');
    const options={activation:['不限','刚刚活跃','今日活跃','3日内活跃','本周活跃','本月活跃'],recent_not_viewed:['不限','近14天没有'],gender:['不限','男','女'],exchange_resume_with_colleague:['不限','近一个月没有'],school:['不限','双一流院校','985','211','QS 100'],experience:['不限','在校/应届','26年毕业','27年毕业','27年后毕业','1年以内','1-3年','3-5年','5-10年','10年以上'],degree:['不限','本科','硕士','博士']};
    for(const [key,allowed] of Object.entries(options)){const values=Array.isArray(d[key])?d[key]:[d[key]];if(values.some(v=>!allowed.includes(v)))errors.push(`Unsupported dimension ${key}`);if(Array.isArray(d[key])&&d[key].includes('不限')&&d[key].length!==1)errors.push(`Unlimited cannot be combined in ${key}`);}
    if(d.age_range!=='不限'){const match=typeof d.age_range==='string'&&d.age_range.match(/^(\d{1,3})-(\d{1,3})$/);if(!match||Number(match[1])>Number(match[2])||Number(match[2])>150)errors.push('Invalid age range');}
    if(Object.keys(d).some(k=>/salary|薪资/i.test(k)))errors.push('Salary must not be a screening dimension');
  }
  const m=p.manual_checks;
  if(!object(m))errors.push('manual_checks must be an object');
  else {
    for(const k of ['location','exact_experience','major'])if(!text(m[k]))errors.push(`Missing manual_checks.${k}`);
    if(!Array.isArray(m.must_have)||!m.must_have.length||m.must_have.some(v=>!text(v)))errors.push('must_have required');
    if(!Array.isArray(m.exclude_if))errors.push('exclude_if must be an array');
    if(!text(m.salary_reference)||!m.salary_reference.includes('参考'))errors.push('Salary is reference only');
  }
  if(!object(p.channel_strategy))errors.push('channel_strategy required');
  else {for(const k of ['recommended','featured','targeted_search','latest'])if(typeof p.channel_strategy[k]!=='boolean')errors.push(`Invalid channel ${k}`);if(!Array.isArray(p.channel_strategy.other_channels))errors.push('other_channels must be an array');}
  for(const k of ['search_keywords','mapping_notes'])if(!Array.isArray(p[k])||!p[k].length||p[k].some(v=>!text(v)))errors.push(`Invalid ${k}`);
  return errors;
}
export function pickExactProfile(list,title) {
  if(!text(title)||!Array.isArray(list))return null;
  const hits=list.filter(p=>p&&(p.job_title?.trim()===title.trim()||p.boss_job_title?.trim()===title.trim()));
  return hits.length===1?hits[0]:null;
}
