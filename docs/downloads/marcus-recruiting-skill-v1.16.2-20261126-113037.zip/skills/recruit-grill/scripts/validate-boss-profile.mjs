import fs from 'node:fs';
import {validateProfileRoot} from './profile-schema.mjs';
try{const root=JSON.parse(fs.readFileSync(process.argv[2],'utf8').replace(/^\uFEFF/,''));const errors=validateProfileRoot(root);if(errors.length)throw Error(errors.join('\n'));console.log('Profile structure valid; this does not grant browser authorization');}catch(e){console.error(e.message);process.exitCode=1;}
