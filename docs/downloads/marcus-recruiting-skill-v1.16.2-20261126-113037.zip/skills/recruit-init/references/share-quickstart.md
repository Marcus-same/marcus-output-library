# Marcus recruiting skill · 分享版首次使用

## 快速开始：一次完成离线配置

使用不同的 AI 工具时，可按 [通用 Agent 入口](agent-compatibility.md)选择自动注册或直接读取文件。

解压后，把解压目录交给能操作本地文件的 AI，并告诉它目标工作区路径。可直接发送这句话：

> 用这个包初始化我的招聘工作区，路径是「填你的目录」。请校验安装包，运行离线初始化并告诉我结果。已有工作区只补缺，保留现有文件。

AI 可以自动检查 Node.js、核对包内清单并运行初始化。你只需要提供目标目录；目录已有内容时按修复模式处理。已有工作区如果还在使用旧版 Skill，这一步只补缺，更新已有 Skill 需另行处理。

手动操作时，在解压目录依次运行以下两条命令（需要 Node.js 18 或以上）：

    node skills/recruit-daily/scripts/verify-bundle.mjs --root=.
    node skills/recruit-init/scripts/init-workspace.mjs --workspace "你的招聘工作区绝对路径"

初始化已包含模板复制、Skill 注册和离线自检。成功后在 AI 工具打开目标工作区，直接说「新开岗位」，AI 会先给一张可填写的岗位画像卡。依赖排查按需处理；浏览器接入留到使用者明确授权后，另行完成平台验收。

下面是完整说明，供手动安装、换机和排查时查阅。


> 本文件与解压包根目录的 `README.md` 同源：本文件随 skill 进入工作区，`README.md` 是解压包入口版（多一段公司交付说明）。改任何一处都要同步另一处。

这是通用流程包，不是作者招聘工作区的备份。包含五个招聘 Skill（总入口、init、grill、daily、web-access）、执行脚本、空白模板；没有作者的公司背景、岗位画像、候选人、台账记录、简历、截图、日报、账号、登录态或个人配置。本精简包**不含**简历评估（resume-review）与未读过滤（chat-unread-filter）两个独立 skill，需要时另行安装。

## 0. 先校验下载包

在解压目录运行以下命令，验证包内登记的全部文件：

```text
node skills/recruit-daily/scripts/verify-bundle.mjs --root=.
```

它逐个比对包内 `SHA256SUMS` 登记的文件，输出 `"ok": true` 才算完整。

## 1. 解压并打开

将 ZIP 解压到自己选择的文件夹，例如 `D:\projects\my-recruiting-kit`。使用支持本地文件和命令执行的 AI 工具打开该目录，告诉它：

> 请阅读 README.md 和 skills/recruit-init/SKILL.md，帮我初始化一个全新的招聘工作区，放到我指定的目录。不导入作者历史数据，安装依赖或修改浏览器设置前先询问我。

**解压目录只是安装包，不是工作区**：不要在里面存候选人、台账、日报或截图。普通网页版聊天仅上传 ZIP 不等于安装，必须提供实际本地文件与浏览器执行能力。

## 2. 创建自己的空白工作区

初始化需要 **Node.js 18 或以上（推荐 22+）**；安装 Node 属于使用者自行确认的系统变更，本包不自动安装全局依赖。

先确认命令可用：

```text
node --version
```

- 显示 `v22.x` 或更高 → 最好，使用原生 WebSocket。
- 显示 `v18.x`–`v21.x` → 也可以用；包内 `ws-compat.mjs` 自带最小 WebSocket 实现，不需要 `npm install ws`（macOS 10.15 等老系统常见）。
- 提示找不到 `node` → 先安装 Node.js，**重开终端/命令行窗口**再试；仍然不行就把 Node 安装目录（含 `node.exe`）加入 PATH，或在命令里写完整路径（macOS 常见位置：`/opt/homebrew/bin/node`（Apple Silicon）、`/usr/local/bin/node`（Intel））。

在解压目录运行（Windows PowerShell、macOS/Linux 终端均可）：

```text
node skills/recruit-init/scripts/init-workspace.mjs --workspace "D:\projects\my-recruiting-workspace"
```

macOS/Linux 将目标替换成自己选择的绝对路径。脚本创建空白标准手册、只有表头的台账、目录和五个 Skill，并尝试注册项目级链接；已有文件一律保留，不覆盖，也不删除。链接失败会报告，仍可让 AI 读取工作区根目录 AGENTS.md。脚本不联网、不启动浏览器、不发消息。

之后在 AI 工具里打开**目标工作区**（不是解压目录）。先说“新开岗位”，填写自己的公司背景、岗位标准和 BOSS 发布岗位绑定，再说“处理今天的招聘”。没有岗位标准不能筛人，打招呼须另行授权。

## 2.1 换电脑 / 换系统适配（不同年份的 Mac、Windows、Linux）

脚本不写死某一台电脑的路径、系统或浏览器位置。换机后先跑环境自检（只读，不连浏览器）：

```text
node skills/recruit-init/scripts/env-report.mjs
```

它会打印系统版本、架构、Node 能力、这台机器上可能的浏览器及其用户数据目录，并给出适配提示。

### Node.js 与 macOS 年份

| 系统 | 可用 Node | 说明 |
|---|---|---|
| macOS 11 Big Sur 及更新（2013 年后机型，Intel / Apple Silicon） | 22+ 推荐 | 原生 WebSocket；Apple Silicon 装 arm64 版 |
| macOS 10.15 Catalina（2012–2013 部分机型） | 最高 Node 20 | 走包内 `ws-compat.mjs` 兼容层，功能不受影响 |
| macOS 10.13–10.14 | Node 18 官方已不支持 | 只能手工建目录；浏览器接入另行授权，或换一台新系统机器接 BOSS |
| Windows 10 / 11（x64、ARM64） | 18+ 推荐 22+ | 用 PowerShell；`.sh` 不适用，脚本一律用 `.mjs` |
| Linux（deb/rpm、Snap、Flatpak） | 18+ 推荐 22+ | 三种安装方式的数据目录都已覆盖 |

Node 低于 18 会直接报错停止，不猜、不降级。

### 浏览器与版本

支持 Chrome、Edge、Chromium、Chrome Beta/Dev/Canary、Brave、Vivaldi、Opera；macOS/Windows/Linux 各自的默认目录、Snap/Flatpak 目录都由 `platform-support.mjs` 统一维护。调试开关地址随品牌不同：`chrome://inspect/#remote-debugging`、`edge://inspect`、`brave://inspect`、`vivaldi://inspect`、`opera://inspect`。

同一个 Chrome 的不同年份版本，接入方式也不同：

| 浏览器版本 | 行为 | 复用时怎么做 |
|---|---|---|
| Chrome < 136 | 默认用户目录带 `--remote-debugging-port` 生效 | `DevToolsActivePort` 可用；WS 路径可能不带实例编号 |
| Chrome 136–143 | 对默认用户目录静默忽略调试参数 | 需要非默认 `user-data-dir`（由使用者自行启动，脚本不代劳） |
| Chrome ≥ 144 | 走 `chrome://inspect/#remote-debugging` 开关 | 每条新的浏览器级连接都会弹一次“允许远程调试”；路径可能带 `/devtools/browser/<id>` |

系统层面的差异也已处理：Windows 中文/空格路径与 GBK 控制台（乱码时 `chcp 65001`）、macOS 解压包的 Gatekeeper 隔离（必要时 `xattr -dr com.apple.quarantine <解压目录>`）、Linux 的 Snap/Flatpak 目录。便携版或公司定制浏览器可用环境变量 `WEB_ACCESS_BROWSER_DATA_DIRS="chrome=<路径>"` 指定，或用 `WEB_ACCESS_CDP_PORT` 绑定已核验端口。

**适配边界（别期待）**：脚本永远不会启动浏览器、新开标签页或换浏览器绕过限制；只复用使用者已登录的页面。本版在 Windows 上完成了离线与静态自检，macOS/Linux 的路径规则有单元测试覆盖，但**没有在真实 Mac 硬件上跑完浏览器验收**；真实连接仍按 `browser-acceptance.md` 逐项验收，不能凭本表宣称已在某台 Mac 上可用。

## 3. 浏览器依赖与暂停状态

首次接入或修复浏览器连接前必须执行 [浏览器验收流程](browser-acceptance.md)，验收清单在目标工作区的 `runtime/setup-status.json`。先完成离线检查，随后仅在明确授权范围内核验平台；不能因为目录建立成功就宣布可正式招聘。

本包附带本地适配的 web-access，初始化会离线复制并注册，不需要下载上游代码。已有依赖缺文件时，使用同一修复版的完整本地包补齐：

```text
node skills/recruit-init/scripts/install-web-access.mjs --workspace "目标工作区" --install --source="同一修复版的完整解压目录"
```

脚本核对包内 SHA-256 清单后只补缺，已有不同文件或源包不完整就停止。无联网兜底、不覆盖旧版本，也不生成登录配置或启动代理。不能用此命令升级不同版本。

当前 BOSS 自动化默认暂停。恢复必须另行明确授权，并且只绑定使用者指定的已有登录标签页。无法复用就停止，不启动浏览器、不新开页面、不引导重复登录。

经授权配置时，可从 `skills/web-access/templates/config.env.template` 手工创建本机 `config.env`；模板没有个人数据。访问令牌、已有浏览器选择及 targetId 须另行配置并核验。`check-deps.mjs` 不生成配置；配置缺失时停止，不能凭空补端口或把安装当作恢复授权。

只停止本地代理可使用 `node skills/web-access/scripts/proxy-maintenance.mjs stop`。暂停期间只允许该命令用凭证确认服务实例并关闭其连接，不连接浏览器、不关用户标签页、不重启代理。缺少凭证时停止报告，不猜测或强杀进程。

使用 daily 的常驻连接方案时，首次明确启动 `bound-session.mjs`，后续任务通过 `session-control.mjs run` 复用同一连接；状态与停止分别用 `session-control.mjs status`、`stop`，不与旧代理同时运行。Chrome 首次可能需点允许，连接保持期间不应每步重连；断线不自动重连，也不承诺永久免授权。以上启动及参数来源、权限检查以验收流程为准；建立空白工作区不执行这些启动命令。

## 4. 可选能力、自检与更新

- 猎聘 CLI 仅在使用者选择猎聘渠道后，经确认安装；BOSS 普通推荐路径不要求 Boss CLI。跨平台安装器是 `node skills/recruit-init/scripts/install-dependencies.mjs --check-only`（加 `--yes` 才会执行全局安装，会修改系统，必须先确认）。Unix 下也可继续用原来的 `.sh`。
- 项目级 skill 注册：初始化脚本已自动完成；手工建仓时用 `node skills/recruit-init/scripts/register-workspace-skills.mjs <workspace>`（Windows 用 junction，macOS/Linux 用相对符号链接；已有文件一律保留）。
- 换电脑先跑 `node skills/recruit-init/scripts/env-report.mjs` 看系统、Node 与浏览器候选；浏览器接入可行性用 `node skills/web-access/scripts/ws-bind-check.mjs`（暂停状态下会拒绝探测并说明）。
- 不连接飞书，不要求 lark-cli。PDF/Word 简历的读取能力由所用 AI 工具提供；无法读取时先报告缺失，不假装已看过。
- 包内 `*.test.mjs` 是开发自检，**只在初始化后的工作区里跑**（例如 `node skills/recruit-init/scripts/init-workspace.test.mjs`）。在解压目录直接跑测试或 daily 脚本会报 `Invalid recruiting workspace`，这是设计如此。
- 包内有两份校验清单：根 `SHA256SUMS` 覆盖整包，`skills/SHA256SUMS` 只覆盖 `skills/`。两份清单按约定都跳过校验清单文件自身，因此根清单不包含 `skills/SHA256SUMS`；需要更严格时分别校验两个根。
- 升级时先备份，更新流程文件但保留自己的 CONTEXT.md、JD、台账、候选人和 runtime 数据。初始化脚本只是补缺，不是升级工具；已有 Skill 不会被静默替换。
- 默认不向作者的网站、仓库或账号同步任何招聘数据。浏览器依赖随包离线提供，日常招聘需使用者自己的平台账号和浏览器权限；这不是免配置的独立桌面软件。

## 第三方组件

`skills/web-access` 来自开源项目 web-access（作者 一泽Eze，MIT 许可，本地适配版 2.5.4），保留原作者、许可与来源元数据，许可见该 skill 的 `SKILL.md`。其余 skill 为本工作区的流程文档与脚本。

## 当前工作区使用边界

当前 BOSS 浏览器自动化处于暂停状态（`.recruiting-policy.json`）。安装或升级不构成恢复授权；不得探测、启动、重连或访问 BOSS。恢复必须由用户另行明确授权；恢复后也只复用用户指定的已有 targetId，不刷新、不新建标签页或独立浏览器，无法复用即停止。离线岗位梳理和本地简历工作不受影响。

Start-Recruiting.ps1 仅输出禁用提示，不再启动独立 Chrome。旧的独立浏览器配置保留以免影响用户数据，不再使用。浏览器配置和检查须另行授权；当前暂停期间仅保留不恢复连接的停止维护入口。初始化只创建空白目录和文件，不联网、不操作浏览器。
