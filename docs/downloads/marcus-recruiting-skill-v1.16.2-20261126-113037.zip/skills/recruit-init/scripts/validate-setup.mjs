import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

// Offline only: do not import browser modules, probe endpoints or edit policy.
export function validateSetup(workspace){
 const root=path.resolve(workspace),errors=[];
 const required=['AGENTS.md','CONTEXT.md','.recruiting-policy.json','02-sourcing/dedup-ledger.csv','runtime/setup-status.json','skills/recruit-init/references/browser-acceptance.md',...['bound-session.mjs','session-control.mjs','session-recovery.mjs','page-state.mjs','inspect-bound-page.mjs','open-filter-panel.mjs','connection-repair.test.mjs','browser-client.mjs','candidate-snapshot.mjs','batch-read-resume.mjs','read-safe.mjs','session-identity.test.mjs'].map(n=>'skills/recruit-daily/scripts/'+n)];
 for(const name of required)if(!fs.existsSync(path.join(root,name)))errors.push('Missing '+name);
 let setup,policy;
 try{setup=JSON.parse(fs.readFileSync(path.join(root,'runtime/setup-status.json'),'utf8'));if(setup.schema!=='recruiting-workspace-setup-v1')errors.push('Invalid setup schema');}catch{errors.push('Unreadable setup status');}
 try{policy=JSON.parse(fs.readFileSync(path.join(root,'.recruiting-policy.json'),'utf8'));if(policy.version!==1||policy.allowNewTabs!==false||policy.allowBrowserLaunch!==false||!['paused','existing-tab'].includes(policy.browserAutomation))errors.push('Invalid browser policy');if(policy.browserAutomation==='existing-tab'&&!(typeof policy.targetId==='string'&&policy.targetId.trim()))errors.push('Active policy missing target');}catch{errors.push('Unreadable policy');}
 const stages=['authorization','existingTab','connectionReuse','jobBinding','filters','identityAndRead','realClose','screenshots','sending'];
 if(setup)for(const key of ['offline',...stages]){
  const step=key==='offline'?setup.offline:setup.browser?.[key];
  if(!step||!['pending','not_authorized','passed','failed'].includes(step.status)){errors.push('Invalid stage '+key);continue;}
  if(step.status==='passed'){
   if(typeof step.checkedAt!=='string'||!Number.isFinite(Date.parse(step.checkedAt)))errors.push('Passed stage missing timestamp: '+key);
   if(!Array.isArray(step.evidencePaths)||!step.evidencePaths.length)errors.push('Passed stage missing evidence: '+key);
   else for(const item of step.evidencePaths){
    if(typeof item!=='string'){errors.push('Invalid evidence path');continue;}
    const resolved=path.resolve(root,item),relative=path.relative(root,resolved);
    if(path.isAbsolute(item)||relative.startsWith('..')||path.isAbsolute(relative)||!fs.existsSync(resolved))errors.push('Missing/nonlocal evidence: '+key);
   }
  }
 }
 return {offlineReady:errors.length===0,browserVerifiedByThisCheck:false,browserPolicy:policy?.browserAutomation||'invalid',pendingBrowserStages:stages.filter(k=>setup?.browser?.[k]?.status!=='passed'),errors};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const args=process.argv.slice(2);if(args.length!==2||args[0]!=='--workspace')throw Error('Use --workspace PATH');const result=validateSetup(args[1]);console.log(JSON.stringify(result,null,2));if(!result.offlineReady)process.exitCode=1;}catch(e){console.error(e.message);process.exitCode=1;}
}
