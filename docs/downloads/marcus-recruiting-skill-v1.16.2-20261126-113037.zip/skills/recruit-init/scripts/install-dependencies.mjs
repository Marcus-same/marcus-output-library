// install-dependencies.mjs —— 跨平台的可选渠道 CLI 安装器（非必需）
//
// BOSS 普通推荐/沟通路径不需要 Boss CLI；只有使用者明确选择备用渠道或猎聘时才装。
// 与 install-dependencies.sh 等价，但不依赖 sh：Windows PowerShell / macOS / Linux 都能跑。
//
// 用法：
//   node install-dependencies.mjs --check-only      只检查，不安装（默认）
//   node install-dependencies.mjs --yes             确认后安装全局 npm 包
//
// 安全边界：会执行 `npm install -g`（系统级变更）。没有 --yes 一律不装，只打印计划。
// 不会自动改 shell profile / PATH，也不写 .env。

import fs from 'node:fs';
import path from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';

const BOSS_SOURCE = process.env.BOSS_CLI_SOURCE || 'git+https://github.com/Viy1204/boss-cli.git#main';
const LIEPIN_SOURCE = process.env.LIEPIN_CLI_SOURCE || '@viyzhu/liepin-cli';

function run(command, args, options = {}) {
  return execFileSync(command, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], ...options }).trim();
}

function which(command) {
  // Windows 上 npm 生成的是 boss.cmd；用 npm 自己解析，避免手拼扩展名。
  const probe = spawnSync(`${command} --version`, { shell: true, encoding: 'utf8' });
  return probe.status === 0;
}

function npmBinDir() {
  const prefix = run('npm', ['config', 'get', 'prefix']);
  return process.platform === 'win32' ? prefix : path.join(prefix, 'bin');
}

function main(argv) {
  const options = { checkOnly: true, confirmed: false };
  for (const arg of argv) {
    if (arg === '--check-only') options.checkOnly = true;
    else if (arg === '--yes') { options.confirmed = true; options.checkOnly = false; }
    else if (arg === '-h' || arg === '--help') {
      console.log(`Usage: node install-dependencies.mjs [--check-only | --yes]

Installs the optional Boss and Liepin CLIs globally. Requires --yes to change anything.

Environment overrides:
  BOSS_CLI_SOURCE    npm install source for Boss CLI
  LIEPIN_CLI_SOURCE  npm install source for Liepin CLI`);
      return;
    } else {
      console.error(`Error: unknown option: ${arg}`);
      process.exitCode = 2;
      return;
    }
  }

  const nodeMajor = Number(process.versions.node.split('.')[0]);
  if (nodeMajor < 18) {
    console.error(`Error: Node.js 18 or newer is required (found v${process.versions.node}).`);
    process.exitCode = 1;
    return;
  }

  let npmVersion;
  try { npmVersion = run('npm', ['--version']); }
  catch {
    console.error('Error: npm is required (install Node.js with npm, then reopen the terminal).');
    process.exitCode = 1;
    return;
  }

  const binDir = npmBinDir();
  const bossReady = which('boss');
  const liepinReady = which('liepin');

  console.log(JSON.stringify({
    node: `v${process.versions.node}`,
    npm: npmVersion,
    platform: process.platform,
    arch: process.arch,
    npmGlobalBin: binDir,
    bossCli: bossReady ? 'present' : 'missing',
    liepinCli: liepinReady ? 'present' : 'missing',
    bossSource: BOSS_SOURCE,
    liepinSource: LIEPIN_SOURCE,
    plan: options.checkOnly ? 'check-only' : 'install',
  }, null, 2));

  if (options.checkOnly) {
    console.log('Check only: no packages were installed. Add --yes to install after user confirmation.');
    return;
  }
  if (!options.confirmed) {
    console.error('Error: global install requires --yes after explicit user confirmation.');
    process.exitCode = 2;
    return;
  }

  console.log(`Installing Boss CLI from ${BOSS_SOURCE} ...`);
  const boss = spawnSync('npm', ['install', '-g', BOSS_SOURCE], { stdio: 'inherit', shell: process.platform === 'win32' });
  if (boss.status !== 0) {
    console.error('Error: Boss CLI install failed. No PATH changes were made.');
    process.exitCode = 1;
    return;
  }
  console.log(`Installing Liepin CLI from ${LIEPIN_SOURCE} ...`);
  const liepin = spawnSync('npm', ['install', '-g', LIEPIN_SOURCE], { stdio: 'inherit', shell: process.platform === 'win32' });
  if (liepin.status !== 0) {
    console.error('Error: Liepin CLI install failed.');
    process.exitCode = 1;
    return;
  }

  const finalBoss = which('boss');
  const finalLiepin = which('liepin');
  console.log(JSON.stringify({
    installed: true,
    bossCli: finalBoss ? 'ready' : 'not-on-PATH',
    liepinCli: finalLiepin ? 'ready' : 'not-on-PATH',
    npmGlobalBin: binDir,
  }, null, 2));
  if (!finalBoss || !finalLiepin) {
    console.error(`注意：已安装但命令不在 PATH。把 ${binDir} 加入 PATH，或重开终端后重试。`);
    process.exitCode = 1;
  } else {
    console.log('Next: run "boss login" and "liepin login" once in a new terminal (only if you chose those channels).');
  }
}

main(process.argv.slice(2));
