import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateSetup } from './validate-setup.mjs';

const sourceRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
// 精简安装包只装五个 skill：marcus 总入口、init、grill、daily 与 web-access。
// resume-review 与 chat-unread-filter 按使用者要求不随本包分发；如要加回，须同时改测试和文档引用。
export const names = ['marcus-recruiting-skill', 'recruit-init', 'recruit-grill', 'recruit-daily'];
const templates = path.join(sourceRoot, 'skills/recruit-init/templates');

export function initWorkspace(target) {
  const workspace = path.resolve(target);
  const report = { workspace, created: [], preserved: [], links: [], warnings: [] };
  // Refuse symlinked parents so a repair cannot write into an unrelated workspace.
  function ensureDirectory(directory) {
    const parent = path.dirname(directory);
    if (parent !== directory) ensureDirectory(parent);
    if (fs.existsSync(directory)) {
      const info = fs.lstatSync(directory);
      if (info.isSymbolicLink() || !info.isDirectory()) throw new Error(`Unsafe directory: ${directory}`);
    } else fs.mkdirSync(directory);
  }
  function copyMissing(source, destination) {
    ensureDirectory(path.dirname(destination));
    if (fs.existsSync(destination)) { report.preserved.push(destination); return; }
    // Also preserve broken links, which existsSync does not detect.
    try { fs.lstatSync(destination); report.preserved.push(destination); return; }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
    fs.copyFileSync(source, destination, fs.constants.COPYFILE_EXCL);
    report.created.push(destination);
  }
  function copyTree(source, destination) {
    ensureDirectory(destination);
    for (const item of fs.readdirSync(source, { withFileTypes: true })) {
      const src = path.join(source, item.name);
      const dst = path.join(destination, item.name);
      if (item.isDirectory()) copyTree(src, dst);
      else if (item.isFile() && /\.(md|mjs|js|py|sh|ps1|yaml|csv|json|template)$/.test(item.name)) copyMissing(src, dst);
    }
  }
  // Validate all required sources before creating the destination.
  for (const name of names) {
    if (!fs.existsSync(path.join(sourceRoot, 'skills', name, 'SKILL.md'))) throw new Error(`Missing skill: ${name}`);
  }
  for (const name of ['AGENTS.md', 'CONTEXT.md', 'dedup-ledger.csv', 'candidate-pool.md', 'jd-internal.md', 'interview-record.md', 'setup-status.json']) {
    if (!fs.existsSync(path.join(templates, name))) throw new Error(`Missing template: ${name}`);
  }
  ensureDirectory(workspace);
  copyMissing(path.join(templates, 'AGENTS.md'), path.join(workspace, 'AGENTS.md'));
  copyMissing(path.join(templates, 'CONTEXT.md'), path.join(workspace, 'CONTEXT.md'));
  // Preserve delivery terms with a new workspace without replacing existing agreements.
  const notice = path.join(sourceRoot, 'COMPANY-USE-NOTICE.md');
  if (fs.existsSync(notice)) copyMissing(notice, path.join(workspace, 'COMPANY-USE-NOTICE.md'));
  for (const name of names) copyTree(path.join(sourceRoot, 'skills', name), path.join(workspace, 'skills', name));
  if(fs.existsSync(path.join(sourceRoot,'skills/web-access/SKILL.md')))copyTree(path.join(sourceRoot,'skills/web-access'),path.join(workspace,'skills/web-access'));
  const policyFile=path.join(workspace,'.recruiting-policy.json');
  if(!fs.existsSync(policyFile)){fs.writeFileSync(policyFile,JSON.stringify({version:1,browserAutomation:'paused',allowNewTabs:false,allowBrowserLaunch:false,targetId:null},null,2),{flag:'wx'});report.created.push(policyFile);}
  for (const directory of ['01-jd/_internal', '01-jd/_dist', '02-sourcing', '03-interview', '04-offer', '05-onboarding', '_shared/templates', 'runtime/reports', 'runtime/resumes']) {
    ensureDirectory(path.join(workspace, directory));
  }
  copyMissing(path.join(templates,'setup-status.json'),path.join(workspace,'runtime/setup-status.json'));
  for (const name of ['dedup-ledger.csv', 'candidate-pool.md']) copyMissing(path.join(templates, name), path.join(workspace, '02-sourcing', name));
  for (const name of ['dedup-ledger.csv', 'candidate-pool.md', 'jd-internal.md', 'interview-record.md']) copyMissing(path.join(templates, name), path.join(workspace, '_shared/templates', name));
  const installedNames = [...names];
  if (fs.existsSync(path.join(workspace, 'skills/web-access/SKILL.md'))) installedNames.push('web-access');
  for (const adapter of ['.agents', '.claude', '.qoder']) {
    for (const name of installedNames) {
      const destination = path.join(workspace, adapter, 'skills', name);
      try {
        ensureDirectory(path.dirname(destination));
        try { fs.lstatSync(destination); report.preserved.push(destination); continue; }
        catch (error) { if (error.code !== 'ENOENT') throw error; }
        const source = path.join(workspace, 'skills', name);
        fs.symlinkSync(process.platform === 'win32' ? source : path.relative(path.dirname(destination), source), destination, process.platform === 'win32' ? 'junction' : 'dir');
        report.links.push(destination);
      } catch (error) { report.warnings.push(`${destination}: ${error.message}; use root AGENTS.md instead`); }
    }
  }
  report.acceptance=validateSetup(workspace);
  const setupFile=path.join(workspace,'runtime/setup-status.json');
  const offlineFile=path.join(workspace,'runtime/setup-offline-check.json');
  if(report.acceptance.offlineReady&&report.created.includes(setupFile)&&!fs.existsSync(offlineFile)){
    const checkedAt=new Date().toISOString();
    fs.writeFileSync(offlineFile,JSON.stringify({checkedAt,...report.acceptance},null,2),{flag:'wx'});
    report.created.push(offlineFile);
    const setup=JSON.parse(fs.readFileSync(setupFile,'utf8'));
    setup.offline={status:'passed',checkedAt,evidencePaths:['runtime/setup-offline-check.json']};
    fs.writeFileSync(setupFile,JSON.stringify(setup,null,2));
    report.acceptance=validateSetup(workspace);
  }
  if(!report.acceptance.offlineReady)report.warnings.push('Offline acceptance failed: '+report.acceptance.errors.join('; '));
  return report;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const args = process.argv.slice(2);
    if (args.length !== 2 || args[0] !== '--workspace') throw new Error('Usage: node init-workspace.mjs --workspace <directory>');
    if (Number(process.versions.node.split('.')[0]) < 18) throw new Error('Node.js 18+ is required (22+ recommended; Node 18–21 uses the bundled WebSocket compatibility layer)');
    const report=initWorkspace(args[1]);
    console.log(JSON.stringify(report, null, 2));
    if(!report.acceptance.offlineReady)process.exitCode=1;
  } catch (error) { console.error(error.message); process.exitCode = 1; }
}
