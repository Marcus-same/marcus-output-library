// env-report.mjs —— 本机环境自检（离线，不连浏览器）
//
// 换一台电脑、换一个系统版本时先跑这个：它会告诉你 Node 够不够、系统是什么版本、
// 这台机器上可能有哪些 Chromium 系浏览器、以及对应的适配提示。
// 只读本地文件，不连接 CDP、不启动浏览器、不发送请求。
//
// 用法：
//   node skills/recruit-init/scripts/env-report.mjs
//   node skills/recruit-init/scripts/env-report.mjs --json

import fs from 'node:fs';
import { describeEnvironment, formatEnvironmentReport } from '../../web-access/scripts/platform-support.mjs';

const asJson = process.argv.includes('--json');
const env = describeEnvironment();

// 只看「用户数据目录是否存在」和「DevToolsActivePort 是否残留」，不判断端口、不连接。
const browsers = env.browsers.map((browser) => {
  let installed = false;
  let devToolsFile = false;
  try { installed = fs.existsSync(browser.dataRoot) && fs.statSync(browser.dataRoot).isDirectory(); } catch { /* ignore */ }
  try { devToolsFile = fs.statSync(browser.devToolsPath).isFile(); } catch { /* ignore */ }
  return {
    id: browser.id,
    label: browser.label,
    inspectUrl: browser.inspectUrl,
    dataRoot: browser.dataRoot,
    installed,
    devToolsFile,
  };
});

if (asJson) {
  console.log(JSON.stringify({ ...env, browsers }, null, 2));
} else {
  console.log(formatEnvironmentReport(env));
  console.log('\n浏览器候选（只检查目录是否存在，不连接）：');
  for (const browser of browsers) {
    const installed = browser.installed ? '已安装' : '未发现';
    const marker = browser.devToolsFile ? '，有 DevToolsActivePort（可能残留，需 ws-bind-check 验证）' : '';
    console.log(`  - ${browser.label}（${browser.id}）：${installed}${marker}`);
    console.log(`    数据目录：${browser.dataRoot}`);
    console.log(`    调试开关：${browser.inspectUrl}`);
  }
  if (!browsers.some((b) => b.installed)) {
    console.log('\n未发现任何已知浏览器的用户数据目录。若你用的是便携版/公司定制版，可在 config.env 用 WEB_ACCESS_CDP_PORT 指定已核验端口。');
  }
  console.log('\n提示：本脚本不判断远程调试是否开启。授权恢复后用 ws-bind-check.mjs 核验。');
}
