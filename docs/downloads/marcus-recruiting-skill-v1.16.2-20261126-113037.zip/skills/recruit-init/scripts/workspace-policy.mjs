import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export function workspaceFor(moduleUrl, requested) {
  const root=fs.realpathSync(path.resolve(path.dirname(fileURLToPath(moduleUrl)),'../../..'));
  if(!fs.existsSync(path.join(root,'AGENTS.md')) || !fs.existsSync(path.join(root,'CONTEXT.md'))) throw new Error('Invalid recruiting workspace');
  if(requested && fs.realpathSync(path.resolve(requested)) !== root) throw new Error('Workspace override rejected: use this skill workspace');
  return root;
}
export function readPolicy(root, {maintenance=false}={}) {
  let policy;
  try {policy=JSON.parse(fs.readFileSync(path.join(root,'.recruiting-policy.json'),'utf8'));}
  catch {throw new Error('BROWSER_PAUSED: policy missing or unreadable');}
  if(maintenance && policy.version===1 && policy.browserAutomation==='paused' && policy.allowNewTabs===false && policy.allowBrowserLaunch===false)return policy;
  if(policy.version!==1 || policy.browserAutomation!=='existing-tab' || policy.allowNewTabs!==false || policy.allowBrowserLaunch!==false || typeof policy.targetId!=='string' || !policy.targetId.trim()) throw new Error('BROWSER_PAUSED: browser automation is suspended');
  return policy;
}
export function assertBrowserAllowed(moduleUrl,{workspace,target}={}) {
  const root=workspaceFor(moduleUrl,workspace);const policy=readPolicy(root);
  if(target!==undefined && target!==policy.targetId) throw new Error('Target is not the user-bound existing tab');
  return {root,policy};
}
export function accessToken(root) {
  const token=fs.readFileSync(path.join(root,'runtime','proxy-access-token'),'utf8').trim();
  if(!/^[a-f0-9]{64}$/.test(token)) throw new Error('Proxy credential missing or invalid');
  return token;
}
export function browserFetchFor(moduleUrl,{workspace,target}={}) {
  return async(input,init={})=>{
    const {root}=assertBrowserAllowed(moduleUrl,{workspace,target});
    const url=new URL(input);
    if(url.protocol!=='http:' || !['127.0.0.1','localhost','[::1]'].includes(url.hostname) || url.username || url.password) throw new Error('Only local proxy endpoints are allowed');
    const headers=new Headers(init.headers);headers.set('X-Recruiting-Token',accessToken(root));
    return fetch(url,{...init,headers,redirect:'error',signal:init.signal||AbortSignal.timeout(15000)});
  };
}
