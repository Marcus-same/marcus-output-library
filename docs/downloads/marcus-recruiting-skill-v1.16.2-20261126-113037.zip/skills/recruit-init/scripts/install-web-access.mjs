import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const sourceRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function safeParents(p){
  const parent=path.dirname(p);if(parent!==p)safeParents(parent);
  try{const s=fs.lstatSync(p);if(s.isSymbolicLink()||!s.isDirectory())throw Error('Unsafe directory: '+p);}catch(e){if(e.code!=='ENOENT')throw e;}
}
export function installBundled(workspace,source=sourceRoot) {
  workspace=path.resolve(workspace);source=path.resolve(source);
  for(const name of ['AGENTS.md','CONTEXT.md'])if(!fs.existsSync(path.join(workspace,name)))throw Error('Initialize the workspace first');
  const manifest=JSON.parse(fs.readFileSync(new URL('../assets/web-access-manifest.json',import.meta.url),'utf8'));
  if(manifest.version!==1||!Array.isArray(manifest.files)||!manifest.files.length)throw Error('Invalid bundle manifest');
  const missing=[],preserved=[],seen=new Set();
  // Validate every reviewed source and destination before the first write.
  for(const row of manifest.files){
    if(!/^skills\/web-access\/[a-zA-Z0-9_./-]+$/.test(row.path)||row.path.split('/').includes('..')||seen.has(row.path)||!/^[a-f0-9]{64}$/.test(row.sha256))throw Error('Invalid manifest entry');
    seen.add(row.path);
    const src=path.join(source,row.path),dst=path.join(workspace,row.path);
    safeParents(path.dirname(src));safeParents(path.dirname(dst));
    if(!fs.existsSync(src)||!fs.lstatSync(src).isFile()||hash(src)!==row.sha256)throw Error('Reviewed bundle missing or changed: '+row.path+'; obtain the matching complete local release, no upstream fallback');
    let exists=false;try{fs.lstatSync(dst);exists=true;}catch(e){if(e.code!=='ENOENT')throw e;}
    if(exists){if(!fs.lstatSync(dst).isFile()||hash(dst)!==row.sha256)throw Error('Existing dependency differs: '+row.path+'; explicit upgrade required');preserved.push(row.path);}
    else missing.push({src,dst,path:row.path});
  }
  for(const row of missing){safeParents(path.dirname(row.dst));fs.mkdirSync(path.dirname(row.dst),{recursive:true});fs.copyFileSync(row.src,row.dst,fs.constants.COPYFILE_EXCL);}
  return {installed:missing.map(x=>x.path),preserved,network:false};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try{
    const args=process.argv.slice(2);
    if(args.length<3||args.length>4||args[0]!=='--workspace'||args[2]!=='--install'||(args[3]&&!args[3].startsWith('--source=')))throw Error('Usage: install-web-access.mjs --workspace DIR --install [--source=LOCAL_COMPLETE_RELEASE]');
    console.log(JSON.stringify(installBundled(args[1],args[3]?.slice(9)),null,2));
  }catch(e){console.error(e.message);process.exitCode=1;}
}
