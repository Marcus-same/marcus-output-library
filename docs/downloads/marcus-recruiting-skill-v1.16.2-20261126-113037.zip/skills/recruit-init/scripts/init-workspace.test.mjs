import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import test from 'node:test';
import { initWorkspace, names } from './init-workspace.mjs';
import { validateSetup } from './validate-setup.mjs';

test('creates blank workspace, then preserves existing recruitment data', () => {
  const base = process.env.RECRUIT_TEST_ROOT;
  assert.ok(base && path.isAbsolute(base), 'Set RECRUIT_TEST_ROOT to an isolated absolute test directory');
  fs.mkdirSync(base, { recursive: true });
  const target = fs.mkdtempSync(path.join(base, 'blank-'));
  const first = initWorkspace(target);
  const ledger = path.join(target, '02-sourcing/dedup-ledger.csv');
  assert.equal(fs.readFileSync(ledger, 'utf8').trim().split(/\r?\n/).length, 1);
  assert.match(fs.readFileSync(path.join(target, 'CONTEXT.md'), 'utf8'), /待填写/);
  // 期望目录数从 names 推导，不硬编码：新增 skill 时只改 init-workspace.mjs 一处
  assert.equal(fs.readdirSync(path.join(target, 'skills')).length, names.length + (fs.existsSync(new URL('../../web-access/SKILL.md',import.meta.url))?1:0));
  assert.equal(JSON.parse(fs.readFileSync(path.join(target,'.recruiting-policy.json'),'utf8')).browserAutomation,'paused');
  assert.equal(fs.existsSync(path.join(target,'skills/web-access/config.env')),false);
  assert.equal(fs.readdirSync(path.join(target, 'runtime/reports')).length, 0);
  assert.equal(fs.existsSync(path.join(target,'runtime/browser-session.json')),false);
  assert.equal(fs.existsSync(path.join(target,'runtime/browser-session.lock')),false);
  assert.equal(fs.existsSync(path.join(target,'runtime/proxy-access-token')),false);
  assert.equal(fs.readdirSync(path.join(target,'runtime/resumes')).length,0);
  const statusFile=path.join(target,'runtime/setup-status.json');
  const status=JSON.parse(fs.readFileSync(statusFile,'utf8'));
  assert.equal(first.acceptance.offlineReady,true);
  assert.equal(first.acceptance.browserVerifiedByThisCheck,false);
  assert.equal(status.offline.status,'passed');
  assert.equal(fs.existsSync(path.join(target,status.offline.evidencePaths[0])),true);
  assert.equal(status.browser.existingTab.targetId,null);
  assert.equal(status.browser.jobBinding.jobId,null);
  assert.equal(status.browser.authorization.status,'not_authorized');
  assert.equal(status.browser.sending.status,'not_authorized');
  const verified=validateSetup(target);
  assert.equal(verified.offlineReady,true,JSON.stringify(verified.errors));
  assert.equal(verified.browserVerifiedByThisCheck,false);
  assert.ok(verified.pendingBrowserStages.includes('identityAndRead'));
  for(const script of ['bound-session.mjs','session-control.mjs','candidate-snapshot.mjs','batch-read-resume.mjs'])assert.equal(fs.existsSync(path.join(target,'skills/recruit-daily/scripts',script)),true);
  // 文档引用的脚本必须真实存在。
  // 2026-10-26 实测缺陷：v1.15.0 的 chat-unread-filter/SKILL.md 指向 scan-unread.mjs / act-unread.mjs，
  // 但这两个脚本没打进包，装完即用不了，而 VERSION.json 还声称「含 scan-unread/act-unread 脚本」。
  // 这条断言把「文档指向空气」变成构建期失败，而不是用户装完才发现。
  const dangling=[];
  for(const skill of fs.readdirSync(path.join(target,'skills'))){
    const md=path.join(target,'skills',skill,'SKILL.md');
    if(!fs.existsSync(md))continue;
    const text=fs.readFileSync(md,'utf8');
    for(const m of text.matchAll(/(?:node\s+)?((?:skills\/)?[A-Za-z0-9_.\-/]*scripts\/[A-Za-z0-9_.\-]+\.mjs)/g)){
      const ref=m[1];
      const candidates=ref.startsWith('skills/')
        ? [path.join(target,ref)]
        // 跨 skill 引用常写成「recruit-daily/scripts/x.mjs」（省略 skills/ 前缀），
        // 本 skill 内引用写成「scripts/x.mjs」，两种都要能解析。
        : [path.join(target,'skills',ref),path.join(target,'skills',skill,ref),path.join(target,ref)];
      if(!candidates.some(p=>fs.existsSync(p)))dangling.push(`${skill}/SKILL.md → ${ref}`);
    }
  }
  assert.deepEqual(dangling,[],'SKILL.md references scripts that are not in the bundle');
  status.browser.identityAndRead.status='passed';
  fs.writeFileSync(statusFile,JSON.stringify(status));
  assert.equal(validateSetup(target).offlineReady,false,'Cannot claim passed without evidence/time');
  status.browser.identityAndRead.status='failed';
  fs.writeFileSync(statusFile,JSON.stringify(status));
  assert.doesNotMatch(fs.readFileSync(path.join(target, 'AGENTS.md'), 'utf8'), /marcus-output-library/);
  assert.ok(first.created.length > 0);
  const marker = 'test-owned-content';
  fs.writeFileSync(ledger, marker);
  const second = initWorkspace(target);
  assert.equal(fs.readFileSync(ledger, 'utf8'), marker);
  assert.equal(second.created.length, 0);
  assert.equal(second.links.length, 0);
  assert.equal(JSON.parse(fs.readFileSync(statusFile,'utf8')).browser.identityAndRead.status,'failed','Repair must preserve actual acceptance state');
  console.log(`Test artifacts retained: ${target}`);
});
