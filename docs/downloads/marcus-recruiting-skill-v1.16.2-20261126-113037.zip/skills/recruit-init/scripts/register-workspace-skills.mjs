// register-workspace-skills.mjs —— 跨平台注册工作区 skills/ 到项目级入口
//
// 与 register-workspace-skills.sh 行为一致，但不需要 sh：Windows PowerShell 也能直接跑。
// 用法：node skills/recruit-init/scripts/register-workspace-skills.mjs <workspace>
//
// 规则（与 .sh 版本相同，扩展性优先）：
// - 只为 .agents / .claude / .qoder 三个已知项目级目录建链接；
// - 已有文件、目录、指向别处的链接一律保留并报告，绝不覆盖；
// - Windows 无符号链接权限时用 junction（目录联接），失败只报告不中断。

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const USAGE = `Usage: node register-workspace-skills.mjs <workspace>

Registers the workspace's canonical skills/ directory in project-local skill
discovery locations used by Codex, Claude Code, and Qoder. Existing files,
directories, and non-matching links are preserved.`;

function fail(message, code = 1) {
  console.error(`Error: ${message}`);
  process.exit(code);
}

function realpath(p) {
  try { return fs.realpathSync(p); } catch { return null; }
}

function main(argv) {
  if (argv.length !== 1 || argv[0] === '-h' || argv[0] === '--help') {
    console.log(USAGE);
    process.exit(argv.length === 1 ? 0 : 2);
  }
  const workspaceArg = path.resolve(argv[0]);
  if (!fs.existsSync(workspaceArg) || !fs.statSync(workspaceArg).isDirectory()) {
    fail(`workspace does not exist: ${workspaceArg}`);
  }
  const workspace = fs.realpathSync(workspaceArg);
  const skillsDir = path.join(workspace, 'skills');
  if (fs.lstatSync(skillsDir, { throwIfNoEntry: false })?.isSymbolicLink()) {
    fail(`canonical skills directory must not be a symbolic link: ${skillsDir}`);
  }
  if (!fs.existsSync(skillsDir) || !fs.statSync(skillsDir).isDirectory()) {
    fail(`canonical skills directory does not exist: ${skillsDir}`);
  }

  const skillDirs = fs.readdirSync(skillsDir, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && !entry.isSymbolicLink())
    .map((entry) => entry.name)
    .filter((name) => fs.existsSync(path.join(skillsDir, name, 'SKILL.md')));
  if (!skillDirs.length) {
    fail(`no local skill folders containing SKILL.md found in ${skillsDir}`);
  }

  const report = { created: [], unchanged: [], preserved: [], warnings: [] };

  const preserve = (message) => { report.preserved.push(message); };

  function registerRoot(adapterParent) {
    const adapterRoot = path.join(adapterParent, 'skills');
    const parentStat = fs.lstatSync(adapterParent, { throwIfNoEntry: false });
    if (parentStat?.isSymbolicLink()) {
      preserve(`symbolic-link adapter root preserved: ${adapterParent} -> ${fs.readlinkSync(adapterParent)}`);
      return;
    }
    if (parentStat && !parentStat.isDirectory()) {
      preserve(`existing adapter path preserved: ${adapterParent}`);
      return;
    }
    fs.mkdirSync(adapterParent, { recursive: true });
    const rootStat = fs.lstatSync(adapterRoot, { throwIfNoEntry: false });
    if (rootStat?.isSymbolicLink()) {
      preserve(`symbolic-link skills root preserved: ${adapterRoot} -> ${fs.readlinkSync(adapterRoot)}`);
      return;
    }
    if (rootStat && !rootStat.isDirectory()) {
      preserve(`existing skills path preserved: ${adapterRoot}`);
      return;
    }
    fs.mkdirSync(adapterRoot, { recursive: true });

    for (const name of skillDirs) {
      const source = path.join(skillsDir, name);
      const destination = path.join(adapterRoot, name);
      const relativeTarget = path.join('..', '..', 'skills', name);
      const stat = fs.lstatSync(destination, { throwIfNoEntry: false });

      if (stat?.isSymbolicLink()) {
        const resolvedDestination = realpath(destination);
        const resolvedSource = realpath(source);
        const actual = fs.readlinkSync(destination);
        // Windows 的 junction 与目录符号链接都走这里；比较解析后的真实路径即可，
        // 不比较链接字符串（junction 的 readlink 可能带 \\?\ 前缀或绝对路径）。
        if (resolvedDestination === resolvedSource && fs.existsSync(path.join(destination, 'SKILL.md'))) {
          report.unchanged.push(destination);
        } else {
          preserve(`existing link preserved: ${destination} -> ${actual}`);
        }
        continue;
      }
      if (stat) {
        preserve(`existing path preserved: ${destination}`);
        continue;
      }

      try {
        // Windows 用 junction（不需要管理员/开发者模式）；macOS/Linux 用相对符号链接，便于整目录搬迁。
        if (process.platform === 'win32') fs.symlinkSync(source, destination, 'junction');
        else fs.symlinkSync(relativeTarget, destination, 'dir');
        report.created.push(destination);
        console.log(`Registered: ${destination} -> ${process.platform === 'win32' ? source : relativeTarget}`);
      } catch (error) {
        report.warnings.push(`${destination}: ${error.message}; root AGENTS.md fallback available`);
        console.error(`Warning: could not link ${destination}: ${error.message}`);
      }
    }
  }

  for (const adapter of ['.agents', '.claude', '.qoder']) {
    registerRoot(path.join(workspace, adapter));
  }

  console.log(`Skill registration complete: created=${report.created.length} unchanged=${report.unchanged.length} preserved=${report.preserved.length} warnings=${report.warnings.length}`);
  for (const item of report.preserved) console.error(`Preserved: ${item}`);
  console.log('Universal fallback: open the workspace root so the agent can read AGENTS.md.');
  return report;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try { main(process.argv.slice(2)); }
  catch (error) { fail(error.message); }
}

export { main as registerWorkspaceSkills };
