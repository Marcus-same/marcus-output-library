---
name: recruit-init
description: >
  初始化招聘工作区：检查 Node.js 与 web-access 浏览器依赖，创建标准目录骨架
  （CONTEXT.md 事实源 + AGENTS.md 协作约定 + 01-jd~05-onboarding 漏斗目录 + 台账），
  把工作流文档拷进工作区，为 Codex / Claude Code / Qoder 注册项目级 skill，
  然后逐个岗位启动 /recruit-grill 梳理真实岗位要求。
  当用户说"初始化招聘工作区"、"帮我搭招聘环境"、"第一次用这套招聘工具"时使用。
---

当前 BOSS 浏览器自动化处于暂停状态（`.recruiting-policy.json`）。安装或升级不构成恢复授权；不得探测、启动、重连或访问 BOSS。恢复必须由用户另行明确授权；恢复后也只复用用户指定的已有 targetId，不刷新、不新建标签页或独立浏览器，无法复用即停止。离线岗位梳理和本地简历工作不受影响。


# recruit-init —— 初始化招聘工作区

首次使用时跑一次。目标：搭好一个「任何 AI 工具打开都能直接干活」的招聘工作区。

**首次启用或修复 BOSS 浏览器接入前，必须完整阅读并执行 [browser-acceptance.md](references/browser-acceptance.md)。** 该文档包含连接复用、标签页识别、筛选确认、原生详情身份和真实关闭的验收要求。离线建仓与平台验收分别交付，不得把安装完成写成 BOSS 已就绪。

## Step 1 前置依赖检查

首次下载的使用者必须读 `references/share-quickstart.md`，区分解压目录与目标工作区。

1. `node --version`：需要 Node.js ≥ 18（推荐 22+；18–21 走包内 WebSocket 兼容层，macOS 10.15 等老系统常见）。缺少 Node 时，报告并经确认安装；也可先按模板手工建目录。换机或换系统先跑 `node scripts/env-report.mjs` 看系统、Node 与浏览器候选。
2. BOSS 主路径需要 Chrome/Edge、使用者自己的招聘者登录态及 `web-access`。优先复用包内经过适配的依赖；缺失时经确认从同版完整本地包运行 `scripts/install-web-access.mjs --workspace <workspace> --install --source=<完整包目录>`，核对哈希后补齐，再注册项目链接。不下载上游兜底。此步骤不阻塞离线建仓。
3. 不默认运行浏览器探针，因为可能启动 Proxy；配置缺失会停止，模板仅供另行授权后手工配置；取得授权后按首次使用指南执行，所有 BOSS 动作复用使用者已授权的现有招聘者标签页。
4. Boss CLI、猎聘 CLI 只用于用户批准的备用或猎聘渠道；不要求 lark-cli，不连接飞书。安装入口保留为可选的 `scripts/install-dependencies.mjs --check-only`（加 `--yes` 才执行全局安装）与 Unix 下的 `install-dependencies.sh`，会安装全局包、可能修改 PATH，必须另行确认，不能默认运行。

依赖失败、网络不可用或暂未登录时记下待办，继续创建空白工作区；没有平台执行条件就不能报告已完成寻源或打招呼。

## Step 2 创建工作区骨架

**先探查，再动手**：问用户工作区放哪（推荐一个独立文件夹，如 `~/recruiting` 或桌面某目录），
看一眼目标位置——如果已存在 `CONTEXT.md` 或台账，说明是已有工作区，进入**修复模式**：
只补缺失的文件和目录，**绝不覆盖**已有的 CONTEXT/台账/JD，逐项报告补了什么。全新目录才走完整创建：

优先执行跨平台脚本：`node skills/recruit-init/scripts/init-workspace.mjs --workspace <workspace>`。
它离线复制模板和五个招聘流程，注册项目级链接，不导入源目录的实际 CONTEXT、JD、台账或 runtime。重跑只补缺，不作 Skill 升级。脚本不可用时才按下方结构手工补齐。

```
<workspace>/
├── AGENTS.md                 ← 从本 skill 的 templates/AGENTS.md 复制
├── CONTEXT.md                ← 从 templates/CONTEXT.md 复制
├── skills/                   ← 复制五个招聘流程（不带旧版 BOSS 或运行数据），
│                                这是所有工具共用的唯一 skill 内容源，工作区从此自足
├── .agents/skills/           ← 指向 skills/ 的项目级链接（Codex / Agent Skills 约定）
├── .claude/skills/           ← 指向 skills/ 的项目级链接（Claude Code）
├── .qoder/skills/            ← 指向 skills/ 的项目级链接（Qoder）
├── 01-jd/
│   ├── _internal/            ← 对内笔记（不外发）
│   └── _dist/                ← 生成物（PDF/HTML 等）
├── 02-sourcing/
│   ├── dedup-ledger.csv      ← 从 templates/dedup-ledger.csv 复制（只有表头）
│   └── candidate-pool.md     ← 从 templates/candidate-pool.md 复制
├── 03-interview/
├── 04-offer/
├── 05-onboarding/
├── _shared/templates/        ← 复制 jd-internal.md / interview-record.md /
│                                candidate-pool.md / dedup-ledger.csv 四个模板
└── runtime/
    ├── reports/              ← 本地日报与 review 汇总
    └── resumes/              ← 邮件简历附件与导入去重索引
```

要点：
- 使用初始化脚本时直接读取其离线自检结果，无需重复运行验证脚本。仅手工建仓时必须创建 `runtime/setup-status.json`，并运行 `node skills/recruit-init/scripts/validate-setup.mjs --workspace <目标工作区>`。只做离线检查，不启动浏览器。平台各项未授权/未实测状态须如实保留。
- `AGENTS.md` / `CONTEXT.md` 原样复制模板，**不要现场即兴改写结构**——两份文件的分区是后续工作流的接口。
- `skills/` 是唯一内容源；不要向工具目录重复复制 skill，避免后续版本不一致。
- 新建工作区时同时创建 `runtime/reports/` 和 `runtime/resumes/`；修复模式只补缺失目录，不动已有附件或索引。

跨平台初始化脚本已完成注册尝试。手工建仓且需补链接时，优先用不需要 sh 的 Node 版本（Windows PowerShell 同样适用），Unix 下也可继续用 `.sh`：

```bash
node skills/recruit-init/scripts/register-workspace-skills.mjs <workspace>
sh   skills/recruit-init/scripts/register-workspace-skills.sh <workspace>
```

脚本为 `.agents/skills/`、`.claude/skills/`、`.qoder/skills/` 创建指向同一份
`skills/` 的相对符号链接。它可重复执行：正确链接保持不变；遇到已有文件、目录或指向其他位置的链接时
只报告并保留，**绝不覆盖**。

兼容边界：
- Codex 自动扫描 `.agents/skills/`；Qoder 自动扫描 `.qoder/skills/`；Claude Code 使用 `.claude/skills/`。
- ZCode 直接读取工作区根目录 `AGENTS.md`；如果用户还想在 ZCode 的 Skills 面板看到这些流程，提示其在
  Settings → Skills 中从 Codex 或 Claude Code 来源导入，选择 Symlink 与当前 Project。
- WorkBuddy、MiniMax Code 或其他未提供稳定项目级 skill 目录的工具，统一依靠根目录 `AGENTS.md`
  路由到 `skills/`。不要猜测或创建未经该工具官方文档确认的隐藏目录。
- 新增或修改 skill 后，如当前工具没有立刻显示，刷新技能列表或新开任务；必要时重启工具。

## Step 3 逐岗梳理

问用户当前在招几个岗位、分别叫什么，写进 `CONTEXT.md`「在招岗位与优先级」表（状态先标"待梳理"）。

然后**逐个岗位**走 `skills/recruit-grill/SKILL.md` 的流程（一次只梳理一个岗位，梳理完一个再下一个）。
用户如果说"今天先梳理一个，其他改天"，尊重——CONTEXT 里留着"待梳理"状态即可。

## Step 4 收尾

**假设用户不懂技术术语**：解释文件用途时说人话——CONTEXT.md 是"你的招聘标准手册，AI 每次干活前必读"，
台账是"所有候选人的总名单，防止重复联系"，不要说"事实源""幂等"这类词。

汇报三件事：
1. 建了什么（目录树 + 两个核心文件的作用一句话 + 已注册的工具入口）；
2. 还欠什么（未装的 CLI、未登录的账号、未梳理的岗位）；
3. 怎么用：**以后每天打开这个工作区，说"处理今天的招聘"即可**（工作流见 `skills/recruit-daily/SKILL.md`）。

收尾必须补充验收状态：离线检查结果、连接复用/岗位绑定/筛选/读取/关闭哪些已真实验证、截图和发送哪些未获授权或未测试；证据写入 setup-status。没有真实通过证据的项目不能标为通过，不能复用作者或旧工作区的会话、账号、候选人记录代替验收。
