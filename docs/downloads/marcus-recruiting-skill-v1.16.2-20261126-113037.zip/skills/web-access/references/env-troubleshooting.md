# CDP 接入环境陷阱排查剧本（2026-10-24 实测沉淀）

本文档来自一次真实的误诊事故：误判「Chrome 136+ 默认目录忽略调试参数」，
导致不必要地新开独立调试浏览器。以下结论均在用户机器上实测验证。

## 铁律：不要凭 HTTP 探测下结论

**错误推理链（已发生过，勿重蹈）：**
HTTP `/json/version` 不通 → 断定端口没开 → 断定 Chrome 忽略调试参数 → 新开独立 profile。
每一步都可能错。

**正确排查顺序：**

1. **TCP 直连测端口**（`checkPort` / `browser-discovery.mjs` 的做法，不走代理，最可靠）
2. **读 `DevToolsActivePort` 文件**（各平台路径见 `browser-discovery.mjs` 的 `knownBrowsers()`）
3. **用文件里的浏览器级 WebSocket 验证**：`ws://127.0.0.1:<port><wsPath>` 发 `Target.getTargets`
4. HTTP `/json/*` 接口返回 404 **属正常现象**（Chrome 受限模式），不代表端口不可用

## 陷阱清单

### 1. 本机代理劫持 127.0.0.1 请求
若系统配置了 HTTP 代理（如 7890），`curl http://127.0.0.1:9222/...` 会被代理截走，
返回代理的错误或空响应，极易误判为"端口不通"。
- 命令行探测必须加 `--noproxy '*'`
- 脚本内用 TCP socket / WebSocket 直连（Node 的 net/ws 不受 HTTP 代理影响）
- PowerShell `Invoke-WebRequest` 默认也走系统代理，需 `-Proxy $null` 或改用 TCP

### 2. HTTP 发现接口 404 ≠ 端口不可用
Chrome 新版（136+ 行为）对默认用户目录的 CDP HTTP 发现接口（`/json/version`、`/json/list`）
返回 404，但**浏览器级 WebSocket 完全可用**。必须用 `DevToolsActivePort` 文件第二行的
`/devtools/browser/<uuid>` 路径连接，不能用 `/json/list` 拿 `webSocketDebuggerUrl`。

### 3. `DevToolsActivePort` 可能是残留假信号
浏览器上次带调试参数运行后正常关闭，文件会残留。判断方法：**WS 连得上才是活的**。
连不上 → 文件过期，不要基于它做任何操作。

### 4. `127.0.0.1` 与 `localhost` 行为可能不同
部分 Chrome 版本对 Host 头校验：`127.0.0.1` 404 而 `localhost` 200（或相反）。
WS 路径用文件里给的原始路径 + `127.0.0.1` 最稳；两个 host 都值得试。

### 5. 不要新开独立调试浏览器
"复用已有标签页"是硬纪律。HTTP 接口 404 不是新开浏览器的理由——走 WS。
只有用户明确授权换方案时才能变更接入方式。

## 跨机型差异（macOS / Windows / Linux）

目录与版本规则集中在 `scripts/platform-support.mjs`，不要在别的脚本里另写一套路径。换机先跑
`node skills/recruit-init/scripts/env-report.mjs`（只读，不连浏览器）确认系统、Node 和浏览器候选。

- **macOS**：浏览器数据目录在 `~/Library/Application Support/…`（Chrome、Edge、Brave、Vivaldi 各通道都覆盖）。
  Apple Silicon 装 arm64 Node；Intel 装 x64。macOS 10.15 及更早装不了 Node 22，本包用 `ws-compat.mjs`
  内置 WebSocket 客户端兜底（Node 18–21 可用，无需 `npm install ws`）。解压包被 Gatekeeper 拦住时执行
  `xattr -dr com.apple.quarantine <解压目录>`。
- **Windows**：目录在 `%LOCALAPPDATA%`；Opera 在 `%APPDATA%`。用 PowerShell，`.sh` 不适用，一律用 `.mjs`。
  中文/空格路径已支持（命令里加引号）；控制台乱码先 `chcp 65001`。
- **Linux**：deb/rpm 在 `~/.config/…`，Snap 在 `~/snap/chromium/common/chromium`，Flatpak 在
  `~/.var/app/<app-id>/config/…`，均已登记。
- **Chrome 版本决定接入方式**：<136 默认目录带调试参数生效；136–143 对默认目录静默忽略，需要非默认
  `user-data-dir`；≥144 走 `chrome://inspect/#remote-debugging`，每条新连接都弹一次允许，WS 路径可能带
  `/devtools/browser/<id>`。Edge/Brave/Vivaldi/Opera 的开关地址分别是 `edge://inspect`、`brave://inspect`、
  `vivaldi://inspect`、`opera://inspect`。脚本不启动浏览器，也不代为创建 profile。
- 便携版/公司定制浏览器：`WEB_ACCESS_BROWSER_DATA_DIRS="chrome=<路径>"` 指定数据目录，或在 `config.env`
  用 `WEB_ACCESS_CDP_PORT` 绑定已核验端口。

## 一键核验

```bash
node web-access/scripts/ws-bind-check.mjs          # 人类可读
node web-access/scripts/ws-bind-check.mjs --json   # 机读（含 targetId 列表）
```

输出含每个检测到的浏览器的端口活性、WS 连通性、当前页面标签列表，
以及 `DevToolsActivePort` 是否为残留假信号的判定。
