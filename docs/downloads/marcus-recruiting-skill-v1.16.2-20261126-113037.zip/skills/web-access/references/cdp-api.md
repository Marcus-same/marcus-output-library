# 招聘工作区受限 API

当前 BOSS 浏览器自动化处于暂停状态（`.recruiting-policy.json`）。安装或升级不构成恢复授权；不得探测、启动、重连或访问 BOSS。恢复必须由用户另行明确授权；恢复后也只复用用户指定的已有 targetId，不刷新、不新建标签页或独立浏览器，无法复用即停止。离线岗位梳理和本地简历工作不受影响。

本地适配版本只监听 127.0.0.1。业务请求在连接浏览器前都要通过暂停策略、Host、来源与 X-Recruiting-Token 校验。拒绝网页 Origin 和 Sec-Fetch 请求；仅允许本机程序带凭证访问。调用应使用 browser-client 或 workspace-policy 的封装，不照搬上游无凭证 curl 示例。

| 接口 | 方法 | 范围 |
|---|---|---|
| /health、/targets | GET | 已认证，targets 只返回绑定标签页 |
| /info、/screenshot | GET | 仅绑定 targetId |
| /eval、/click、/clickAt、/clickAtFrame、/setFiles、/scroll | POST | 仅绑定 targetId；调用仍需对应用户授权 |
| /shutdown | POST | 已认证且实例身份一致；运行模式需空闲，暂停模式可中断代理连接但保留用户网页 |

/new、/navigate、/back、/close 在此工作区版本始终拒绝。/clickAtFrame 要求 JSON 的 frame 与 selector，必须唯一匹配可见且无遮挡的控件，不做 DOM click 回退，也不重试发送。

暂停状态仅允许带正确凭证的 GET /health?maintenance=stop 与 POST /shutdown 用于停止维护；普通 health、targets、业务请求及 restart 仍拒绝。停止不会建立浏览器连接或关闭标签页；本地离线代码审查不使用这些接口。运行状态变化不能视作恢复授权。
