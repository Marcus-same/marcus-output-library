// platform-support.mjs —— 机型/系统/浏览器三件事的唯一事实源
//
// 目的：把「不同年份的 Mac」「Windows 10/11」「各类 Linux 发行版」以及
// Chrome / Edge / Chromium 各通道版本之间的差异集中到这里，其他脚本只消费。
//
// 设计约束：
// 1. 纯本地、不联网、不探测：只做路径与版本的计算，是否可达由调用方决定。
// 2. 必须可注入 platform/env/home 供单元测试覆盖三种系统（本机只测得了 Windows）。
// 3. 不擅自启动或切换浏览器；这里只回答「有哪些浏览器可能在这台机器上」。
//
// 版本事实（截至 2026-11）：
// - Chrome < 136：带 --remote-debugging-port 用默认 user-data-dir 可以生效，
//   DevToolsActivePort 会写到用户数据目录。老 Mac 上常见的旧 Chrome 属于这一类。
// - Chrome 136–143：对默认 user-data-dir 静默忽略调试参数；需要非默认目录。
// - Chrome >= 144：走 chrome://inspect/#remote-debugging 开关，每条新的浏览器级
//   CDP 连接都会弹一次「允许远程调试」，实例路径可能带 /devtools/browser/<id>。
// - Node 22+ 自带 WebSocket；Node 18–21 由本包的 ws-compat.mjs 兜底；
//   macOS 10.15 及更早的系统装不了 Node 22，必须靠兜底。

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

// macOS Darwin release → 产品版本。用于不调用 sw_vers 时的粗略判断。
const DARWIN_TO_MACOS = {
  25: '26', 24: '15', 23: '14', 22: '13', 21: '12', 20: '11',
  19: '10.15', 18: '10.14', 17: '10.13', 16: '10.12', 15: '10.11',
};

const MACOS_SUPPORT = [
  { min: 11, label: 'macOS 11 Big Sur 及更新', node: '22+ 原生 WebSocket，推荐' },
  { min: 10.15, label: 'macOS 10.15 Catalina', node: '最高 Node 20；本包用内置 ws 兼容层，可用' },
  { min: 10.13, label: 'macOS 10.13–10.14', node: 'Node 18 官方不支持；无 Node 时只能手工建目录并改用支持新系统的机器接入 BOSS' },
];

// ---------------------------------------------------------------------------
// 浏览器目录目录：每项 = { id, label, vendor, dataRoot, inspectUrl, channels[] }
// dataRoot 是「用户数据目录」本身（DevToolsActivePort 就在它下面）。
// ---------------------------------------------------------------------------

function chromeChannels(base, brand) {
  // brand: { label, vendor, inspect }
  return [
    { ...brand, dataRoot: base },
  ];
}

function macBrowsers(home) {
  const appSupport = path.join(home, 'Library', 'Application Support');
  const defs = [
    { id: 'chrome', label: 'Chrome', vendor: 'Google', root: 'Google/Chrome', inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-beta', label: 'Chrome Beta', vendor: 'Google', root: 'Google/Chrome Beta', inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-dev', label: 'Chrome Dev', vendor: 'Google', root: 'Google/Chrome Dev', inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-canary', label: 'Chrome Canary', vendor: 'Google', root: 'Google/Chrome Canary', inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chromium', label: 'Chromium', vendor: 'Chromium', root: 'Chromium', inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'edge', label: 'Microsoft Edge', vendor: 'Microsoft', root: 'Microsoft Edge', inspect: 'edge://inspect' },
    { id: 'edge-beta', label: 'Microsoft Edge Beta', vendor: 'Microsoft', root: 'Microsoft Edge Beta', inspect: 'edge://inspect' },
    { id: 'brave', label: 'Brave', vendor: 'Brave', root: 'BraveSoftware/Brave-Browser', inspect: 'brave://inspect' },
    { id: 'vivaldi', label: 'Vivaldi', vendor: 'Vivaldi', root: 'Vivaldi', inspect: 'vivaldi://inspect' },
  ];
  return defs.map((d) => ({ ...d, dataRoot: path.join(appSupport, d.root), source: 'default' }));
}

function winBrowsers(env) {
  const local = env.LOCALAPPDATA || path.join(env.USERPROFILE || '', 'AppData', 'Local');
  const roamin = env.APPDATA || path.join(env.USERPROFILE || '', 'AppData', 'Roaming');
  const defs = [
    { id: 'chrome', label: 'Chrome', vendor: 'Google', root: path.join(local, 'Google', 'Chrome', 'User Data'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-beta', label: 'Chrome Beta', vendor: 'Google', root: path.join(local, 'Google', 'Chrome Beta', 'User Data'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-dev', label: 'Chrome Dev', vendor: 'Google', root: path.join(local, 'Google', 'Chrome Dev', 'User Data'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-canary', label: 'Chrome Canary', vendor: 'Google', root: path.join(local, 'Google', 'Chrome SxS', 'User Data'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chromium', label: 'Chromium', vendor: 'Chromium', root: path.join(local, 'Chromium', 'User Data'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'edge', label: 'Microsoft Edge', vendor: 'Microsoft', root: path.join(local, 'Microsoft', 'Edge', 'User Data'), inspect: 'edge://inspect' },
    { id: 'edge-beta', label: 'Microsoft Edge Beta', vendor: 'Microsoft', root: path.join(local, 'Microsoft', 'Edge Beta', 'User Data'), inspect: 'edge://inspect' },
    { id: 'brave', label: 'Brave', vendor: 'Brave', root: path.join(local, 'BraveSoftware', 'Brave-Browser', 'User Data'), inspect: 'brave://inspect' },
    { id: 'vivaldi', label: 'Vivaldi', vendor: 'Vivaldi', root: path.join(local, 'Vivaldi', 'User Data'), inspect: 'vivaldi://inspect' },
    { id: 'opera', label: 'Opera', vendor: 'Opera', root: path.join(roamin, 'Opera Software', 'Opera Stable'), inspect: 'opera://inspect' },
  ];
  return defs.map((d) => ({ ...d, dataRoot: d.root, source: 'default' }));
}

function linuxBrowsers(home) {
  const config = path.join(home, '.config');
  const flatpak = path.join(home, '.var', 'app');
  const defs = [
    { id: 'chrome', label: 'Chrome', vendor: 'Google', root: path.join(config, 'google-chrome'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-beta', label: 'Chrome Beta', vendor: 'Google', root: path.join(config, 'google-chrome-beta'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chromium', label: 'Chromium', vendor: 'Chromium', root: path.join(config, 'chromium'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'edge', label: 'Microsoft Edge', vendor: 'Microsoft', root: path.join(config, 'microsoft-edge'), inspect: 'edge://inspect' },
    { id: 'edge-beta', label: 'Microsoft Edge Beta', vendor: 'Microsoft', root: path.join(config, 'microsoft-edge-beta'), inspect: 'edge://inspect' },
    { id: 'brave', label: 'Brave', vendor: 'Brave', root: path.join(config, 'BraveSoftware', 'Brave-Browser'), inspect: 'brave://inspect' },
    { id: 'vivaldi', label: 'Vivaldi', vendor: 'Vivaldi', root: path.join(config, 'vivaldi'), inspect: 'vivaldi://inspect' },
    // Snap / Flatpak 是 Linux 上很常见的两种安装方式，用户数据目录位置不同。
    { id: 'chromium-snap', label: 'Chromium (Snap)', vendor: 'Snap', root: path.join(home, 'snap', 'chromium', 'common', 'chromium'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chrome-flatpak', label: 'Chrome (Flatpak)', vendor: 'Flatpak', root: path.join(flatpak, 'com.google.Chrome', 'config', 'google-chrome'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'chromium-flatpak', label: 'Chromium (Flatpak)', vendor: 'Flatpak', root: path.join(flatpak, 'org.chromium.Chromium', 'config', 'chromium'), inspect: 'chrome://inspect/#remote-debugging' },
    { id: 'edge-flatpak', label: 'Edge (Flatpak)', vendor: 'Flatpak', root: path.join(flatpak, 'com.microsoft.Edge', 'config', 'microsoft-edge'), inspect: 'edge://inspect' },
  ];
  return defs.map((d) => ({ ...d, dataRoot: d.root, source: 'default' }));
}

// 统一入口：返回当前平台所有「可能安装」的浏览器（不判断是否真的装了）。
// options 全部可注入，方便在 Windows 上单测 darwin/linux 分支。
export function browserCatalog({
  platform = process.platform,
  env = process.env,
  home = os.homedir(),
} = {}) {
  let list;
  if (platform === 'darwin') list = macBrowsers(home);
  else if (platform === 'win32') list = winBrowsers(env);
  else if (platform === 'linux') list = linuxBrowsers(home);
  else list = [];

  // 允许用环境变量追加/覆盖数据目录（公司统一部署、便携版浏览器）。
  // WEB_ACCESS_BROWSER_DATA_DIRS="chrome=<路径>;vivaldi=<路径>"
  const extra = env.WEB_ACCESS_BROWSER_DATA_DIRS || '';
  const overrides = new Map();
  for (const part of extra.split(';')) {
    const i = part.indexOf('=');
    if (i <= 0) continue;
    const id = part.slice(0, i).trim();
    const dir = part.slice(i + 1).trim();
    if (id && dir) overrides.set(id, dir);
  }

  return list.map((b) => {
    if (!overrides.has(b.id)) return b;
    return { ...b, dataRoot: overrides.get(b.id), source: 'env' };
  });
}

// 兼容浏览器发现脚本的既有接口：只给 id/label/vendor/devToolsPath。
export function browserEntries(options = {}) {
  return browserCatalog(options).map((b) => ({
    id: b.id,
    label: b.label,
    vendor: b.vendor,
    inspectUrl: b.inspect,
    dataRoot: b.dataRoot,
    devToolsPath: path.join(b.dataRoot, 'DevToolsActivePort'),
    source: b.source,
  }));
}

// 按 id 找到某个浏览器（含 env 覆盖后的路径）。
export function browserById(id, options = {}) {
  return browserEntries(options).find((b) => b.id === id) || null;
}

// ---------------------------------------------------------------------------
// 操作系统信息
// ---------------------------------------------------------------------------

export function macVersion({ platform = process.platform, release = os.release(), read = null } = {}) {
  if (platform !== 'darwin') return null;
  // 优先问系统（最准），失败再按 Darwin 内核版本映射。
  try {
    const run = read || (() => execFileSync('sw_vers', ['-productVersion'], { encoding: 'utf8', timeout: 3000 }).trim());
    const v = String(run()).trim();
    if (/^\d+(\.\d+){0,2}$/.test(v)) return v;
  } catch { /* 沙箱或非 mac 环境 */ }
  const major = Number(String(release).split('.')[0]);
  return DARWIN_TO_MACOS[major] || null;
}

export function macVersionSupport(version) {
  if (!version) return null;
  const [maj, min = 0] = version.split('.').map(Number);
  const asNum = maj >= 11 ? maj : Number(`${maj}.${min}`);
  for (const row of MACOS_SUPPORT) {
    if (asNum >= row.min) return row;
  }
  return MACOS_SUPPORT[MACOS_SUPPORT.length - 1];
}

// ---------------------------------------------------------------------------
// Node 能力
// ---------------------------------------------------------------------------

export const NODE_MINIMUM = 18;
export const NODE_RECOMMENDED = 22;

export function nodeCapabilities(versions = process.versions, hasWebSocket = typeof globalThis.WebSocket === 'function') {
  const version = versions.node || '0.0.0';
  const major = Number(version.split('.')[0]);
  const supported = major >= NODE_MINIMUM;
  const nativeWebSocket = hasWebSocket && major >= 22;
  return {
    version,
    major,
    supported,
    nativeWebSocket,
    mode: !supported ? 'unsupported' : nativeWebSocket ? 'native' : 'compat',
    note: !supported
      ? `Node ${NODE_MINIMUM}+ 才可运行；当前 ${major}`
      : nativeWebSocket
        ? '原生 WebSocket'
        : `Node ${major}：使用内置 ws 兼容层（无需安装 ws 包）`,
  };
}

// ---------------------------------------------------------------------------
// 环境描述：给 doctor / 文档 / 报告统一使用
// ---------------------------------------------------------------------------

export function describeEnvironment({
  platform = process.platform,
  arch = process.arch,
  release = os.release(),
  versions = process.versions,
  macReader = null,
  home = os.homedir(),
  env = process.env,
} = {}) {
  const node = nodeCapabilities(versions);
  const mac = macVersion({ platform, release, read: macReader });
  const support = platform === 'darwin' ? macVersionSupport(mac) : null;
  const browsers = browserEntries({ platform, env, home });
  const advice = [];

  if (!node.supported) advice.push(`需要升级 Node.js 到 ${NODE_MINIMUM}+（推荐 ${NODE_RECOMMENDED}+）`);
  else if (node.mode === 'compat') advice.push('Node 18–21 可用，但走兼容层；升级到 22+ 更稳');

  if (platform === 'darwin') {
    if (!mac) advice.push('无法识别 macOS 版本；按 Node 与 Chrome 的实际版本判断');
    else if (support) advice.push(`${support.label}：${support.node}`);
    if (arch === 'arm64') advice.push('Apple Silicon：Node 请装 arm64 版本；误装 x64 也能通过 Rosetta 运行，但更慢');
    if (arch === 'x64') advice.push('Intel Mac：Node 官方 x64 构建可用；macOS 11 以上才支持 Node 22');
    advice.push('首次运行解压包可能被 Gatekeeper 拦截：必要时执行 xattr -dr com.apple.quarantine <解压目录>');
  } else if (platform === 'win32') {
    advice.push('Windows：不要用 PowerShell 直接跑 .sh；跨平台脚本用 .mjs / .ps1');
    advice.push('中文路径与空格路径已支持；命令里给路径加引号');
    advice.push('默认控制台编码可能是 GBK：中文乱码时执行 chcp 65001，或改用 Windows Terminal');
  } else if (platform === 'linux') {
    advice.push('Linux：Snap/Flatpak 安装的 Chromium 数据目录与 deb 不同，已在目录表中覆盖');
  } else {
    advice.push(`未适配的平台 ${platform}：脚本仍可跑，但浏览器路径需要手工配置`);
  }

  return {
    platform,
    platformLabel: { darwin: 'macOS', win32: 'Windows', linux: 'Linux' }[platform] || platform,
    arch,
    release,
    macVersion: mac,
    macSupport: support,
    node,
    browsers,
    advice,
  };
}

// 人类可读的多行报告（env-report.mjs 与文档共用措辞）。
export function formatEnvironmentReport(envDesc) {
  const lines = [];
  const label = envDesc.platformLabel;
  const mac = envDesc.macVersion ? `（macOS ${envDesc.macVersion}）` : '';
  lines.push(`系统：${label}${mac}｜架构：${envDesc.arch}｜内核：${envDesc.release}`);
  lines.push(`Node：v${envDesc.node.version}｜${envDesc.node.mode}｜${envDesc.node.note}`);
  const installed = envDesc.browsers.filter((b) => {
    try { return fs.existsSync(b.dataRoot); } catch { return false; }
  });
  lines.push(`浏览器候选：${envDesc.browsers.length} 个；本机存在用户数据目录：${installed.length ? installed.map((b) => b.label).join('、') : '未发现'}`);
  if (envDesc.advice.length) {
    lines.push('适配提示：');
    for (const item of envDesc.advice) lines.push(`  - ${item}`);
  }
  return lines.join('\n');
}
