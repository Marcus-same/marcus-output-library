#!/usr/bin/env node
import {assertBrowserAllowed,workspaceFor,readPolicy,accessToken} from '../../recruit-init/scripts/workspace-policy.mjs';
const stopOnly=process.argv.length===3 && process.argv[2]==='stop';
const workspaceContext=stopOnly?{root:workspaceFor(import.meta.url)}:assertBrowserAllowed(import.meta.url);
if(stopOnly)readPolicy(workspaceContext.root,{maintenance:true});
// 集中维护共享 Proxy；身份与忙碌状态由服务端拥有，不扫描或强杀系统进程。
import { spawn } from 'node:child_process';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SCRIPTS = path.dirname(fileURLToPath(import.meta.url));
const STOP_TIMEOUT_MS = 15000;

class MaintenanceError extends Error {
  constructor(message, details = {}, exitCode = 1) {
    super(message);
    this.details = details;
    this.exitCode = exitCode;
  }
}

function requestJson(port, pathname, { method = 'GET', body, timeoutMs = 1000 } = {}) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? null : JSON.stringify(body);
    const req = http.request({
      hostname: '127.0.0.1', port, path: pathname, method,
      headers: payload === null ? {'X-Recruiting-Token':accessToken(workspaceContext.root)} : {
        'X-Recruiting-Token':accessToken(workspaceContext.root),
        'content-type': 'application/json',
        'content-length': Buffer.byteLength(payload),
      },
    }, res => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', chunk => {
        text += chunk;
        if (text.length > 1024 * 1024) req.destroy(new Error('维护响应过大'));
      });
      res.on('error', reject);
      res.on('end', () => {
        try { resolve({ code: res.statusCode, body: JSON.parse(text) }); }
        catch { reject(new MaintenanceError('Proxy 返回了无效 JSON；保留当前服务')); }
      });
    });
    // 使用总时限，持续发送零碎响应也不能拖住维护流程。
    const timer = setTimeout(() => req.destroy(new Error('Proxy 维护请求超时')), timeoutMs);
    req.once('close', () => clearTimeout(timer));
    req.on('error', reject);
    req.end(payload);
  });
}

async function readHealth(port, timeoutMs = 1000) {
  let result;
  try { result = await requestJson(port, stopOnly?'/health?maintenance=stop':'/health', { timeoutMs }); }
  catch (error) {
    if (error.code === 'ECONNREFUSED') return null;
    throw error;
  }
  if (result.code !== 200 || result.body?.status !== 'ok') {
    throw new MaintenanceError('端口上的服务未满足 Proxy 健康契约；保留当前服务', { response: result.body });
  }
  return result.body;
}

function requireIdentity(health) {
  if (typeof health.instanceId !== 'string' || !health.instanceId) {
    throw new MaintenanceError('旧服务没有 instanceId，无法安全维护；需要一次性迁移，禁止自动强停', { health }, 2);
  }
}

function isBusy(health) {
  return ['activeRequests', 'managedTabs', 'pendingCommands'].some(key => health[key] > 0)
    || ['discovering', 'connecting'].includes(health.connectionState);
}

async function waitForDeparture(port, instanceId) {
  const deadline = Date.now() + STOP_TIMEOUT_MS;
  // 次数同时有界，避免持续快速响应导致无界轮询。
  for (let attempt = 0; attempt < 30 && Date.now() < deadline; attempt++) {
    const health = await readHealth(port, Math.max(1, Math.min(1000, deadline - Date.now())));
    if (!health) return null;
    requireIdentity(health);
    if (health.instanceId !== instanceId) return health;
    await new Promise(resolve => setTimeout(resolve, Math.min(500, Math.max(1, deadline - Date.now()))));
  }
  throw new MaintenanceError('目标 Proxy 在 15 秒内未退出；没有强停或启动第二个实例', { instanceId });
}

async function requestStop(port, health) {
  requireIdentity(health);
  if (isBusy(health) && health.stopOnly!==true) {
    throw new MaintenanceError('Proxy 正在连接、执行任务或仍拥有标签页，请等任务完成并清理后再维护', { status: 'busy', health }, 2);
  }
  let result;
  try {
    result = await requestJson(port, '/shutdown', {
      method: 'POST', body: { instanceId: health.instanceId },
    });
  } catch (error) {
    // 另一维护者可能刚好停止了同一实例，后续仍只观察旧身份。
    if (error.code !== 'ECONNREFUSED') throw error;
    return waitForDeparture(port, health.instanceId);
  }
  if (result.code === 409) {
    const current = await readHealth(port);
    if (!current) return null;
    requireIdentity(current);
    if (current.instanceId !== health.instanceId) return current;
    throw new MaintenanceError('Proxy 拒绝维护，当前服务已保留', {
      status: isBusy(current) ? 'busy' : 'conflict', health: current, response: result.body,
    }, 2);
  }
  if (result.code !== 202 || result.body?.instanceId !== health.instanceId) {
    throw new MaintenanceError('Proxy 未确认停止目标实例；当前服务已保留', { response: result.body });
  }
  return waitForDeparture(port, health.instanceId);
}

function runCheckDeps(port, browserId) {
  assertBrowserAllowed(import.meta.url);
  console.log('proxy: 维护启动一次；浏览器可能需要一次授权，请按 check-deps 提示等待');
  return new Promise((resolve, reject) => {
    const args = [path.join(SCRIPTS, 'check-deps.mjs')];
    if (browserId && browserId !== 'unknown') args.push('--browser', browserId);
    const child = spawn(process.execPath, args, {
      env: { ...process.env, CDP_PROXY_PORT: String(port) },
      stdio: 'inherit', windowsHide: true,
    });
    child.once('error', reject);
    child.once('exit', (code, signal) => resolve({ code, signal }));
  });
}

function restartedResult(health, previous, reused, startup) {
  if (!health) throw new MaintenanceError('维护启动后未读到健康服务', { startup });
  requireIdentity(health);
  if (health.instanceId === previous?.instanceId) {
    throw new MaintenanceError('维护后仍是旧实例，没有确认升级完成', { health, startup });
  }
  const expectedBrowserId = previous?.browser?.id;
  if (typeof expectedBrowserId === 'string' && expectedBrowserId && expectedBrowserId !== 'unknown'
    && health.browser?.id !== expectedBrowserId) {
    throw new MaintenanceError('新实例的浏览器不符合维护前的选择；新实例已保留', {
      status: 'conflict', expectedBrowserId, health, ...(startup ? { startup } : {}),
    }, 2);
  }
  if (health.maintenance) {
    throw new MaintenanceError('新实例正在被维护，暂不能确认可用', { health, startup });
  }
  if (health.connected !== true) {
    return { status: 'waitingAuthorization', reused, health, ...(startup ? { startup } : {}) };
  }
  if (startup && startup.code !== 0) {
    throw new MaintenanceError('健康服务已运行，但启动检查未通过，请查看上述提示', { health, startup });
  }
  return { status: 'ready', reused, health };
}

async function main() {
  const [action = 'status', ...extra] = process.argv.slice(2);
  if (action === '--help' && !extra.length) {
    console.log('用法：node proxy-maintenance.mjs [status|restart|stop]；CDP_PROXY_PORT 默认 3456');
    return;
  }
  if (!['status', 'restart', 'stop'].includes(action) || extra.length) {
    throw new MaintenanceError('用法：node proxy-maintenance.mjs [status|restart|stop]', {}, 2);
  }
  const rawPort = process.env.CDP_PROXY_PORT || '3456';
  const port = Number(rawPort);
  if (!/^\d+$/.test(rawPort) || port < 1 || port > 65535) {
    throw new MaintenanceError('CDP_PROXY_PORT 必须是 1 到 65535 的整数', {}, 2);
  }
  const health = await readHealth(port);
  if (action === 'status') {
    console.log(JSON.stringify(health ? { status: 'running', health } : { status: 'stopped' }));
    return;
  }
  const replacement = health ? await requestStop(port, health) : null;
  if (action === 'stop') {
    console.log(JSON.stringify(replacement
      ? { status: 'replaced', stoppedInstanceId: health.instanceId, health: replacement }
      : { status: 'stopped', ...(health ? { stoppedInstanceId: health.instanceId } : {}) }));
    return;
  }
  let result;
  if (replacement) {
    result = restartedResult(replacement, health, true);
  } else {
    const startup = await runCheckDeps(port, health?.browser?.id);
    result = restartedResult(await readHealth(port), health, false, startup);
  }
  console.log(JSON.stringify(result));
  if (result.status === 'waitingAuthorization') process.exitCode = 3;
}

try { await main(); }
catch (error) {
  console.error(JSON.stringify({ status: 'error', message: error.message, ...error.details }));
  process.exitCode = error.exitCode || 1;
}
