// Pure browser-side routines, serialized into the already-bound page by the proxy.
export function frameHitPoint(frame,selector) {
  const frames=[...document.querySelectorAll(frame)];if(frames.length!==1)throw Error('Ambiguous frame');
  const f=frames[0],d=f.contentDocument;if(!d)throw Error('Frame unavailable');
  const visible=e=>{const s=d.defaultView.getComputedStyle(e),r=e.getBoundingClientRect();return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';};
  const hits=[...d.querySelectorAll(selector)].filter(visible);if(hits.length!==1||hits[0].disabled)throw Error('Ambiguous or disabled control');
  const el=hits[0];el.scrollIntoView({block:'center'});
  if(getComputedStyle(f).transform!=='none')throw Error('Transformed iframe is not supported');
  const r=el.getBoundingClientRect(),fr=f.getBoundingClientRect();const px=r.left+r.width/2,py=r.top+r.height/2;
  const x=fr.left+f.clientLeft+px,y=fr.top+f.clientTop+py;
  if(x<0||y<0||x>=innerWidth||y>=innerHeight)throw Error('Control outside viewport');
  const inside=d.elementFromPoint(px,py);if(!inside||!(inside===el||el.contains(inside))||document.elementFromPoint(x,y)!==f)throw Error('Control is obscured');
  return {x,y};
}
export function framePanelState(frame,panel,closeSelector) {
  const frames=[...document.querySelectorAll(frame)];if(frames.length!==1)throw Error('Ambiguous frame');
  const d=frames[0].contentDocument;if(!d)throw Error('Frame unavailable');
  const visible=e=>!!e.getClientRects().length;
  const panels=[...d.querySelectorAll(panel)].filter(visible);
  if(!panels.length)return {open:false};
  if(panels.length!==1)throw Error('Ambiguous details panel');
  if(!closeSelector)throw Error('Verified closeSelector required');
  const controls=[...panels[0].querySelectorAll(closeSelector)].filter(visible);
  if(controls.length!==1||controls[0].disabled)throw Error('Verified close control unavailable');
  return {open:true};
}
