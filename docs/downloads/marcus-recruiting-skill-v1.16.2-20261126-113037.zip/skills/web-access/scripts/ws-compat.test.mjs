import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import test from 'node:test';
import { CompatWebSocket, resolveWebSocket } from './ws-compat.mjs';
import { createCdpConnection } from './cdp-connection.mjs';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

// 测试用：按浏览器（服务端）方向编码帧，不加掩码。
function serverFrame(opcode, payload) {
  const data = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), 'utf8');
  let header;
  if (data.length < 126) {
    header = Buffer.from([0x80 | opcode, data.length]);
  } else if (data.length < 65536) {
    header = Buffer.allocUnsafe(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(data.length, 2);
  } else {
    header = Buffer.allocUnsafe(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(data.length), 2);
  }
  return Buffer.concat([header, data]);
}

// 解析客户端发来的（带掩码的）帧。
function readClientFrames(socket, onMessage) {
  let buffer = Buffer.alloc(0);
  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);
    for (;;) {
      if (buffer.length < 2) return;
      const opcode = buffer[0] & 0x0f;
      const masked = (buffer[1] & 0x80) !== 0;
      let length = buffer[1] & 0x7f;
      let offset = 2;
      if (length === 126) {
        if (buffer.length < 4) return;
        length = buffer.readUInt16BE(2);
        offset = 4;
      } else if (length === 127) {
        if (buffer.length < 10) return;
        length = Number(buffer.readBigUInt64BE(2));
        offset = 10;
      }
      const maskKey = buffer.subarray(offset, offset + 4);
      if (masked) offset += 4;
      if (buffer.length < offset + length) return;
      let payload = buffer.subarray(offset, offset + length);
      if (masked) {
        const copy = Buffer.allocUnsafe(payload.length);
        for (let i = 0; i < payload.length; i++) copy[i] = payload[i] ^ maskKey[i % 4];
        payload = copy;
      }
      buffer = buffer.subarray(offset + length);
      onMessage(opcode, payload);
    }
  });
}

function startWsServer(onMessage) {
  const server = http.createServer();
  const sockets = new Set();
  server.on('upgrade', (req, socket) => {
    sockets.add(socket);
    socket.on('close', () => sockets.delete(socket));
    const accept = crypto.createHash('sha1').update(req.headers['sec-websocket-key'] + GUID).digest('base64');
    socket.write([
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${accept}`,
      '', '',
    ].join('\r\n'));
    socket.setNoDelay(true);
    readClientFrames(socket, (opcode, payload) => onMessage(socket, opcode, payload));
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve({
      port: server.address().port,
      close() {
        for (const socket of sockets) socket.destroy();
        server.close();
      },
    }));
  });
}

function waitForMessage(socketInstance) {
  return new Promise((resolve, reject) => {
    socketInstance.addEventListener('message', (event) => resolve(String(event.data)));
    socketInstance.addEventListener('error', (event) => reject(event.error || new Error('ws error')));
  });
}

test('CompatWebSocket handshake, send, receive and close', async () => {
  const { close, port } = await startWsServer((socket, opcode, payload) => {
    if (opcode === 0x1) socket.write(serverFrame(0x1, `echo:${payload}`));
    else if (opcode === 0x8) { socket.write(serverFrame(0x8, payload)); socket.end(); }
  });
  try {
    const ws = new CompatWebSocket(`ws://127.0.0.1:${port}/devtools/browser/test-1`);
    const message = waitForMessage(ws);
    await new Promise((resolve, reject) => {
      ws.addEventListener('open', resolve);
      ws.addEventListener('error', (event) => reject(event.error || new Error('connect error')));
    });
    ws.send('hello 中文');
    assert.equal(await message, 'echo:hello 中文');
    const closed = new Promise((resolve) => ws.addEventListener('close', resolve));
    ws.close();
    const event = await closed;
    assert.equal(event.code, 1000);
  } finally {
    close();
  }
});

test('CompatWebSocket answers server ping with pong', async () => {
  let pong = null;
  const { close, port } = await startWsServer((socket, opcode, payload) => {
    if (opcode === 0x1 && payload.toString() === 'ready') {
      // 服务端 → 客户端发 ping；客户端必须回 pong
      socket.write(serverFrame(0x9, 'keepalive'));
    } else if (opcode === 0xA) {
      pong = payload.toString();
      socket.write(serverFrame(0x1, 'done'));
      socket.end();
    }
  });
  try {
    const ws = new CompatWebSocket(`ws://127.0.0.1:${port}/devtools/browser/test-2`);
    await new Promise((resolve, reject) => {
      ws.addEventListener('open', resolve);
      ws.addEventListener('error', (event) => reject(event.error || new Error('connect error')));
    });
    ws.send('ready');
    await new Promise((resolve) => setTimeout(resolve, 150));
    assert.equal(pong, 'keepalive');
    ws.close();
  } finally {
    close();
  }
});

test('createCdpConnection works with the builtin WebSocket implementation', async () => {
  const { close, port } = await startWsServer((socket, opcode, payload) => {
    if (opcode !== 0x1) return;
    const command = JSON.parse(payload.toString('utf8'));
    socket.write(serverFrame(0x1, JSON.stringify({ id: command.id, result: { targetInfos: [{ targetId: 'T1' }] } })));
  });
  try {
    const connection = createCdpConnection({
      WebSocketImpl: CompatWebSocket,
      discoverUrl: async () => `ws://127.0.0.1:${port}/devtools/browser/test-3`,
      commandTimeoutMs: 3000,
    });
    await connection.connect();
    assert.equal(connection.connected, true);
    const response = await connection.send('Target.getTargets', {});
    assert.equal(response.result.targetInfos[0].targetId, 'T1');
    connection.close();
    assert.equal(connection.connected, false);
  } finally {
    close();
  }
});

test('resolveWebSocket prefers native and can force the builtin fallback', () => {
  const native = resolveWebSocket();
  if (typeof globalThis.WebSocket === 'function') {
    assert.equal(native.source, 'native');
    assert.equal(native.WebSocket, globalThis.WebSocket);
  } else {
    assert.equal(native.source, 'builtin');
  }
  const builtin = resolveWebSocket({ forceBuiltin: true });
  assert.equal(builtin.source, 'builtin');
  assert.equal(builtin.WebSocket, CompatWebSocket);
});

test('在「没有原生 WebSocket」的运行时里自动落到内置实现（模拟 Node 18–21 / 老 Mac）', () => {
  // 直接在当前进程临时摘掉 globalThis.WebSocket，等价于 Node 18–21 的运行时
  // （老 Mac 常见：macOS ≤10.15 装不了 Node 22）。不 spawn 子进程，避免沙箱管道限制。
  const original = globalThis.WebSocket;
  try {
    delete globalThis.WebSocket;
    const resolved = resolveWebSocket();
    assert.equal(resolved.source, 'builtin');
    assert.equal(resolved.WebSocket, CompatWebSocket);
  } finally {
    if (original) globalThis.WebSocket = original;
  }
});
