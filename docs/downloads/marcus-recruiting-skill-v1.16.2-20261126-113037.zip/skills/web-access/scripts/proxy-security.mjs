import {timingSafeEqual} from 'node:crypto';

export function checkProxyRequest(req,{port,token,policy}) {
  const headers=req.headers;
  if(headers.origin!==undefined || headers['sec-fetch-site']!==undefined) return {status:403,error:'Browser-origin requests are forbidden'};
  if(!new Set([`127.0.0.1:${port}`,`localhost:${port}`,`[::1]:${port}`]).has(headers.host)) return {status:403,error:'Invalid Host'};
  const supplied=headers['x-recruiting-token'];
  if(typeof token!=='string' || !/^[a-f0-9]{64}$/.test(token) || typeof supplied!=='string' || Buffer.byteLength(supplied)!==Buffer.byteLength(token) || !timingSafeEqual(Buffer.from(supplied),Buffer.from(token))) return {status:403,error:'Unauthorized local request'};
  let url;try{url=new URL(req.url,`http://127.0.0.1:${port}`);}catch{return {status:400,error:'Invalid URL'};}
  const stopping=(url.pathname==='/shutdown' && req.method==='POST') || (url.pathname==='/health' && req.method==='GET' && url.searchParams.get('maintenance')==='stop');
  const valid=policy?.version===1 && policy.allowNewTabs===false && policy.allowBrowserLaunch===false;
  if(!valid || (policy.browserAutomation!=='existing-tab' && !(policy.browserAutomation==='paused' && stopping)) || (policy.browserAutomation==='existing-tab' && !policy.targetId))return {status:503,error:'BROWSER_PAUSED'};
  const methods=new Map([['/health','GET'],['/targets','GET'],['/info','GET'],['/screenshot','GET'],['/eval','POST'],['/click','POST'],['/clickAt','POST'],['/clickAtFrame','POST'],['/clickTop','POST'],['/rebind','POST'],['/setFiles','POST'],['/scroll','POST'],['/shutdown','POST']]);
  if(!methods.has(url.pathname)) return {status:403,error:'Endpoint disabled in existing-tab mode'};
  if(req.method!==methods.get(url.pathname)) return {status:405,error:'Wrong HTTP method'};
  if(!['/health','/targets','/shutdown'].includes(url.pathname) && url.searchParams.get('target')!==policy.targetId) return {status:403,error:'Target mismatch'};
  return {status:200};
}
