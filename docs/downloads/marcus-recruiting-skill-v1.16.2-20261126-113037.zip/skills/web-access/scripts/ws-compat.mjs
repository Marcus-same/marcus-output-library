// ws-compat.mjs —— WebSocket 兼容层
//
// 为什么需要：Node 22+ 自带浏览器级 WebSocket，但 macOS 10.15 及更早的机器装不了
// Node 22（Node 22 要求 macOS 11+），而招聘工作区可能就在这类机器上。原先的代码直接
// 用全局 WebSocket，或依赖 npm 安装 ws 包；前者在 Node 18–21 直接 ReferenceError，
// 后者需要联网装依赖。这里提供一个零依赖的最小 RFC 6455 客户端：只支持客户端连接、
// 文本帧、ping/pong、close 与分片重组，足够 CDP 使用。
//
// 用法：
//   const WS = resolveWebSocket();        // 直接拿到构造函数（原生优先）
//   const { WebSocket: WS2, source } = resolveWebSocket({ forceBuiltin: true });

import net from 'node:net';
import http from 'node:http';
import crypto from 'node:crypto';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const OPEN = 1;
const CONNECTING = 0;
const CLOSING = 2;
const CLOSED = 3;

function parseWsUrl(raw) {
  const url = new URL(raw);
  if (url.protocol !== 'ws:') throw new Error(`ws-compat 只支持 ws://，收到 ${url.protocol}`);
  const port = Number(url.port || 80);
  return { host: url.hostname, port, path: `${url.pathname || '/'}${url.search || ''}` };
}

function mask(payload) {
  const key = crypto.randomBytes(4);
  const out = Buffer.allocUnsafe(payload.length);
  for (let i = 0; i < payload.length; i++) out[i] = payload[i] ^ key[i % 4];
  return { key, out };
}

function frame(opcode, payload) {
  const data = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), 'utf8');
  let header;
  if (data.length < 126) {
    header = Buffer.allocUnsafe(2);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | data.length;
    const { key, out } = mask(data);
    return Buffer.concat([header, key, out]);
  }
  if (data.length < 65536) {
    header = Buffer.allocUnsafe(4);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | 126;
    header.writeUInt16BE(data.length, 2);
    const { key, out } = mask(data);
    return Buffer.concat([header, key, out]);
  }
  header = Buffer.allocUnsafe(10);
  header[0] = 0x80 | opcode;
  header[1] = 0x80 | 127;
  header.writeBigUInt64BE(BigInt(data.length), 2);
  const { key, out } = mask(data);
  return Buffer.concat([header, key, out]);
}

// 只做客户端需要的事件对象；cdp-connection 同时兼容 EventTarget 与 EventEmitter。
class CompatWebSocket {
  constructor(rawUrl) {
    this.url = String(rawUrl);
    this.readyState = CONNECTING;
    this.binaryType = 'nodebuffer';
    this._listeners = { open: [], message: [], error: [], close: [] };
    this._buffer = Buffer.alloc(0);
    this._fragments = [];
    this._fragmentOpcode = 0;
    this._closed = false;
    this._socket = null;
    this._connect();
  }

  addEventListener(type, handler) {
    const key = String(type);
    if (!this._listeners[key]) this._listeners[key] = [];
    this._listeners[key].push(handler);
  }

  removeEventListener(type, handler) {
    const list = this._listeners[String(type)];
    if (!list) return;
    const i = list.indexOf(handler);
    if (i >= 0) list.splice(i, 1);
  }

  // 兼容 ws EventEmitter 风格；两个参数时 (event, listener) 同 Node 的 on。
  on(type, handler) { this.addEventListener(type, handler); return this; }
  once(type, handler) {
    const wrap = (...args) => { this.removeEventListener(type, wrap); handler(...args); };
    this.addEventListener(type, wrap);
    return this;
  }

  _emit(type, event) {
    for (const handler of [...(this._listeners[type] || [])]) {
      try { handler(event); } catch { /* 监听器异常不中断协议处理 */ }
    }
  }

  _connect() {
    let target;
    try { target = parseWsUrl(this.url); }
    catch (error) { this._fail(error); return; }

    const key = crypto.randomBytes(16).toString('base64');
    const req = http.request({
      host: target.host,
      port: target.port,
      path: target.path,
      method: 'GET',
      // 必须绕过系统代理：本机 127.0.0.1 的 CDP 端口不能被 HTTP 代理劫持。
      agent: false,
      headers: {
        Connection: 'Upgrade',
        Upgrade: 'websocket',
        'Sec-WebSocket-Key': key,
        'Sec-WebSocket-Version': '13',
        Host: `${target.host}:${target.port}`,
      },
    });
    req.on('upgrade', (res, socket, head) => {
      const expected = crypto.createHash('sha1').update(key + GUID).digest('base64');
      if (res.headers['sec-websocket-accept'] !== expected) {
        socket.destroy();
        this._fail(new Error('ws-compat 握手校验失败'));
        return;
      }
      this._socket = socket;
      socket.setNoDelay(true);
      this.readyState = OPEN;
      this._emit('open', { type: 'open', target: this });
      if (head && head.length) this._onData(head);
      socket.on('data', (chunk) => this._onData(chunk));
      socket.on('error', (error) => this._fail(error));
      socket.on('close', () => this._onClose(1006, 'socket closed'));
    });
    req.on('response', (res) => {
      // 不是 101：CDP 端口在等授权或不是 WS 端点。
      res.resume();
      this._fail(new Error(`ws-compat 握手被拒绝 HTTP ${res.statusCode}`));
    });
    req.on('error', (error) => this._fail(error));
    req.end();
  }

  _fail(error) {
    if (this._closed) return;
    this._closed = true;
    this.readyState = CLOSED;
    this._emit('error', { type: 'error', error, message: error?.message });
    this._emit('close', { type: 'close', code: 1006, reason: String(error?.message || '') });
    try { this._socket?.destroy(); } catch { /* ignore */ }
  }

  _onClose(code, reason) {
    if (this._closed) return;
    this._closed = true;
    this.readyState = CLOSED;
    this._emit('close', { type: 'close', code, reason });
  }

  _onData(chunk) {
    this._buffer = Buffer.concat([this._buffer, chunk]);
    // 循环解帧：一条 TCP 数据里可能有多帧，也可能只有半帧。
    for (;;) {
      const buf = this._buffer;
      if (buf.length < 2) return;
      const fin = (buf[0] & 0x80) !== 0;
      const opcode = buf[0] & 0x0f;
      const masked = (buf[1] & 0x80) !== 0;
      let length = buf[1] & 0x7f;
      let offset = 2;
      if (length === 126) {
        if (buf.length < 4) return;
        length = buf.readUInt16BE(2);
        offset = 4;
      } else if (length === 127) {
        if (buf.length < 10) return;
        length = Number(buf.readBigUInt64BE(2));
        offset = 10;
      }
      const maskKey = masked ? buf.subarray(offset, offset + 4) : null;
      if (masked) offset += 4;
      if (buf.length < offset + length) return;
      let payload = buf.subarray(offset, offset + length);
      if (maskKey) {
        const copy = Buffer.allocUnsafe(payload.length);
        for (let i = 0; i < payload.length; i++) copy[i] = payload[i] ^ maskKey[i % 4];
        payload = copy;
      }
      this._buffer = buf.subarray(offset + length);
      this._handleFrame(fin, opcode, payload);
      if (this.readyState === CLOSED) return;
    }
  }

  _handleFrame(fin, opcode, payload) {
    if (opcode === 0x8) {
      const code = payload.length >= 2 ? payload.readUInt16BE(0) : 1005;
      const reason = payload.length > 2 ? payload.subarray(2).toString('utf8') : '';
      try { this._socket?.write(frame(0x8, payload)); } catch { /* ignore */ }
      this._onClose(code, reason);
      try { this._socket?.end(); } catch { /* ignore */ }
      return;
    }
    if (opcode === 0x9) { // ping → pong
      try { this._socket?.write(frame(0xA, payload)); } catch { /* ignore */ }
      return;
    }
    if (opcode === 0xA) return; // pong 忽略

    if (opcode === 0x0) {
      this._fragments.push(payload);
    } else if (opcode === 0x1 || opcode === 0x2) {
      this._fragmentOpcode = opcode;
      this._fragments = [payload];
    } else {
      return;
    }
    if (!fin) return;
    const complete = Buffer.concat(this._fragments);
    const kind = this._fragmentOpcode;
    this._fragments = [];
    if (kind === 0x1) {
      this._emit('message', { type: 'message', data: complete.toString('utf8') });
    } else {
      this._emit('message', { type: 'message', data: complete });
    }
  }

  send(data) {
    if (this.readyState !== OPEN) throw new Error('ws-compat: WebSocket 未连接');
    const text = typeof data === 'string' ? data : String(data);
    this._socket.write(frame(0x1, text));
  }

  close(code = 1000, reason = '') {
    if (this.readyState === CLOSED || this.readyState === CLOSING) return;
    this.readyState = CLOSING;
    const payload = Buffer.allocUnsafe(2 + Buffer.byteLength(reason));
    payload.writeUInt16BE(code, 0);
    payload.write(reason, 2);
    try { this._socket?.write(frame(0x8, payload)); } catch { /* ignore */ }
    // 发完 close 帧等对端回 close；对端不回也不能挂住进程，1 秒后强制销毁。
    const timer = setTimeout(() => {
      try { this._socket?.destroy(); } catch { /* ignore */ }
      this._onClose(code, reason);
    }, 1000);
    timer.unref?.();
  }
}

// 选择实现：原生优先；Node 18–21 走内置兼容层（无需 npm 安装 ws）。
export function resolveWebSocket({ forceBuiltin = false } = {}) {
  if (!forceBuiltin && typeof globalThis.WebSocket === 'function') {
    return { WebSocket: globalThis.WebSocket, source: 'native' };
  }
  return { WebSocket: CompatWebSocket, source: 'builtin' };
}

// 给需要「只要构造函数」的地方留一个直取入口。
export function webSocketClass({ forceBuiltin = false } = {}) {
  return resolveWebSocket({ forceBuiltin }).WebSocket;
}

export { CompatWebSocket };
