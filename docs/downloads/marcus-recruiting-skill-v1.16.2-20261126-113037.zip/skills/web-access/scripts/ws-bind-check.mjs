// ws-bind-check.mjs — CDP 接入一键核验
// 排查"能不能复用已有浏览器"时使用；只读，不导航、不新建、不关闭任何标签页。
// 用法：node ws-bind-check.mjs [--json]
//
// 背景：HTTP /json/* 接口在 Chrome 受限模式下返回 404，不能作为端口活性依据。
// 本脚本只信两样东西：TCP 直连 + DevToolsActivePort 文件里的浏览器级 WebSocket。
// 详细陷阱见 ../references/env-troubleshooting.md

import fs from 'node:fs';
import net from 'node:net';
import { knownBrowsers, checkPort } from './browser-discovery.mjs';
import { resolveWebSocket } from './ws-compat.mjs';
import { describeEnvironment } from './platform-support.mjs';

const asJson = process.argv.includes('--json');
// 原生优先；Node 18–21 用内置兼容层，老 Mac（macOS ≤10.15）也能跑。
const WebSocketImpl = resolveWebSocket().WebSocket;

// 策略闸门：暂停状态下按纪律不探测（与 browser-discovery/checkPort 的 assert 一致），
// 但给出明确解释而不是裸抛错——本脚本的用途正是"恢复授权前"的可行性核验。
async function withPolicyGate(fn) {
  try {
    return await fn();
  } catch (e) {
    const msg = String(e.message || e);
    if (asJson) { console.log(JSON.stringify([{ verdict: msg }])); return; }
    if (msg.includes('BROWSER_PAUSED')) {
      console.log('BROWSER_PAUSED：工作区策略为暂停状态，按纪律不探测浏览器。');
      console.log('这是预期行为。用户明确授权恢复后（policy.browserAutomation=existing-tab + targetId）重跑本脚本。');
    } else if (msg.includes('Invalid recruiting workspace')) {
      console.log('未检测到有效招聘工作区：请在含 AGENTS.md 与 CONTEXT.md 的工作区副本里运行本脚本（解压目录不是工作区）。');
    } else {
      console.error('ERR:', msg);
    }
  }
}

function wsProbe(port, wsPath, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const url = `ws://127.0.0.1:${port}${wsPath}`;
    let ws;
    try { ws = new WebSocketImpl(url); }
    catch (e) { return resolve({ ok: false, error: String(e.message || e) }); }
    const timer = setTimeout(() => { try { ws.close(); } catch {} resolve({ ok: false, error: 'timeout' }); }, timeoutMs);
    ws.addEventListener('open', () => ws.send(JSON.stringify({ id: 1, method: 'Target.getTargets', params: {} })));
    ws.addEventListener('error', (e) => { clearTimeout(timer); resolve({ ok: false, error: String(e.message || 'ws error') }); });
    ws.addEventListener('message', (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id !== 1) return;
      clearTimeout(timer);
      ws.close();
      const pages = (m.result?.targetInfos || [])
        .filter(t => t.type === 'page')
        .map(t => ({ targetId: t.targetId, title: t.title, url: t.url }));
      resolve({ ok: true, pages });
    });
  });
}

const results = [];
await withPolicyGate(async () => {
  for (const browser of knownBrowsers()) {
    const r = { browser: browser.id, label: browser.label, devToolsPath: browser.devToolsPath };
    let content;
    try { content = fs.readFileSync(browser.devToolsPath, 'utf8'); }
    catch { r.filePresent = false; results.push(r); continue; }
    r.filePresent = true;
    const lines = content.trim().split(/\r?\n/).filter(Boolean);
    r.port = parseInt(lines[0], 10) || null;
    r.wsPath = lines[1] || null;
    if (!(r.port > 0 && r.port < 65536)) { r.portValid = false; results.push(r); continue; }
    r.tcpAlive = await checkPort(r.port);
    if (!r.tcpAlive) { r.verdict = 'STALE_FILE: DevToolsActivePort 是残留假信号（端口未监听）'; results.push(r); continue; }
    if (!r.wsPath) { r.verdict = 'NO_WS_PATH: 文件缺少浏览器级 WS 路径'; results.push(r); continue; }
    const probe = await wsProbe(r.port, r.wsPath);
    if (!probe.ok) { r.verdict = `WS_FAIL: ${probe.error}`; results.push(r); continue; }
    r.verdict = 'OK: 可复用（WS 连通，仅绑定下方列出的既有 target）';
    r.pages = probe.pages;
    results.push(r);
  }
});

if (asJson) {
  console.log(JSON.stringify(results, null, 2));
} else if (results.length) {
  const env = describeEnvironment();
  console.log(`环境：${env.platformLabel}${env.macVersion ? ` ${env.macVersion}` : ''} / ${env.arch} / Node v${env.node.version}（${env.node.mode}）`);
  console.log(`候选浏览器 ${env.browsers.length} 个：${env.browsers.map(b => `${b.label}(${b.id})`).join('、')}\n`);
  for (const r of results) {
    console.log(`== ${r.label} (${r.browser})`);
    if (!r.filePresent) { console.log('   DevToolsActivePort 不存在（浏览器未带调试参数运行过）'); continue; }
    console.log(`   端口 ${r.port} TCP: ${r.tcpAlive ? '通' : '不通'} | WS: ${r.verdict}`);
    for (const p of r.pages || []) console.log(`   - ${p.targetId.slice(0, 10)} | ${(p.title || '').slice(0, 40)} | ${p.url.slice(0, 70)}`);
  }
}
