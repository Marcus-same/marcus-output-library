import {assertBrowserAllowed} from '../../recruit-init/scripts/workspace-policy.mjs';

// 浏览器 CDP 端口发现 + 选择 - 单一职责模块
// 被 check-deps.mjs 和 cdp-proxy.mjs 共享。
//
// 选择规则（resolution）：
//   1. 调用方传入 override 参数（来自命令行 --browser） → 严格模式，找不到则硬错
//   2. config.env 里 WEB_ACCESS_BROWSER 设了 → 严格模式，找不到则硬错
//   3. 都没设 → "ask" 模式，提示调用方询问用户
//
// 不擅自降级：偏好不可用一律硬错，让用户介入。
// 持久态只有 config.env 一处；override 是单次 spawn 通过命令行参数表达，不读 process.env。

import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { browserEntries } from './platform-support.mjs';

const SKILL_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CONFIG_PATH = path.join(SKILL_ROOT, 'config.env');

// 浏览器目录的唯一事实源在 platform-support.mjs（三大系统 + 各通道 + Snap/Flatpak）。
// 加新浏览器：只改那里，这里不要重复硬编码路径。
// 说明：Node 18–21 没有原生 WebSocket，探测与连接走 ws-compat.mjs 的内置兼容层。
export function knownBrowsers() {
  return browserEntries({ platform: os.platform(), env: process.env, home: os.homedir() })
    .map(({ devToolsPath, ...rest }) => ({ ...rest, devToolsPath }));
}

// TCP 端口监听检测
// 用 TCP connect 而非 WebSocket，避免触发浏览器的远程调试授权弹窗。
export function checkPort(port, host = '127.0.0.1', timeoutMs = 2000) {
  assertBrowserAllowed(import.meta.url);
  return new Promise((resolve) => {
    const socket = net.createConnection(port, host);
    const timer = setTimeout(() => { socket.destroy(); resolve(false); }, timeoutMs);
    socket.once('connect', () => { clearTimeout(timer); socket.destroy(); resolve(true); });
    socket.once('error',   () => { clearTimeout(timer); resolve(false); });
  });
}

// 读 config.env 文件（不写入 process.env，分清来源）
// 格式：KEY=VALUE，# 开头是注释
function readConfig() {
  const cfg = {};
  let content;
  try { content = fs.readFileSync(CONFIG_PATH, 'utf8'); }
  catch { return cfg; }
  for (const line of content.split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('=');
    if (i === -1) continue;
    const k = t.slice(0, i).trim();
    const v = t.slice(i + 1).trim();
    if (k) cfg[k] = v;
  }
  return cfg;
}

// 读取偏好无需探测浏览器；已有 Proxy 的连接状态由 /health 说明。
export function getConfiguredBrowserId() {
  return readConfig().WEB_ACCESS_BROWSER || null;
}

// 显式端口只绑定已配置的浏览器，不能被另一个浏览器的 override 借用。
async function detectAll(browsers, configuredEndpoint) {
  const detected = [];
  const inaccessible = [];
  for (const browser of browsers) {
    if (configuredEndpoint?.id === browser.id) {
      if (await checkPort(configuredEndpoint.port)) {
        detected.push({ ...browser, port: configuredEndpoint.port, wsPath: configuredEndpoint.wsPath || null, endpointSource: 'config-port' });
      }
      continue;
    }
    let content;
    try { content = fs.readFileSync(browser.devToolsPath, 'utf8'); }
    catch (error) {
      if (error.code === 'EPERM' || error.code === 'EACCES') {
        inaccessible.push({ ...browser, code: error.code });
      }
      continue;
    }
    const lines = content.trim().split(/\r?\n/).filter(Boolean);
    const port = parseInt(lines[0], 10);
    if (!(port > 0 && port < 65536)) continue;
    if (!(await checkPort(port))) continue;
    detected.push({ ...browser, port, wsPath: lines[1] || null });
  }
  return { detected, inaccessible };
}

// 决策入口
// 参数：override — 调用方解析自命令行 --browser 的值（null 表示未传）
// 返回 { kind, browser?, source?, detected, configured, override?, inaccessible, message? }
//   kind ∈ 'ok' | 'ambiguous' | 'mismatch' | 'empty' | 'config-error'
//   source ∈ 'override' | 'preference' | undefined
//   ambiguous = 没设偏好 + 至少一个浏览器开了 toggle，需问用户
//   mismatch  = override/配偏好设了但未检测到对应 toggle，硬错
//   empty     = 0 浏览器开 toggle 且未设偏好/override
export async function selectBrowser(override = null) {
  assertBrowserAllowed(import.meta.url);
  const config = readConfig();
  const configured = config.WEB_ACCESS_BROWSER || null;
  const browsers = knownBrowsers();
  let configuredEndpoint = null;
  if (config.WEB_ACCESS_CDP_PORT) {
    const rawPort = config.WEB_ACCESS_CDP_PORT;
    const port = Number(rawPort);
    let message;
    if (!configured) message = 'WEB_ACCESS_CDP_PORT 必须与 WEB_ACCESS_BROWSER 一起配置';
    else if (!browsers.some(browser => browser.id === configured)) {
      message = `WEB_ACCESS_CDP_PORT 绑定的浏览器 "${configured}" 不在当前平台的支持列表中`;
    } else if (!/^\d+$/.test(rawPort) || port < 1 || port > 65535) {
      message = 'WEB_ACCESS_CDP_PORT 必须是 1 到 65535 的十进制整数';
    }
    if (message) return { kind: 'config-error', message, detected: [], configured, inaccessible: [] };
    const wsPath = config.WEB_ACCESS_CDP_WS_PATH || null;
    if (wsPath && !/^\/devtools\/browser\/[A-Za-z0-9-]+$/.test(wsPath)) return { kind: 'config-error', message: 'Invalid WEB_ACCESS_CDP_WS_PATH', detected: [], configured, inaccessible: [] };
    configuredEndpoint = { id: configured, port, wsPath };
  }
  const { detected, inaccessible } = await detectAll(browsers, configuredEndpoint);
  const facts = { detected, configured, inaccessible };

  // 1. 命令行 override（最高优先，单次有效）
  if (override) {
    const match = detected.find(b => b.id === override);
    if (match) return { kind: 'ok', browser: match, source: 'override', ...facts, override };
    return { kind: 'mismatch', source: 'override', ...facts, override };
  }

  // 2. config.env preference（持久）
  if (configured) {
    const match = detected.find(b => b.id === configured);
    if (match) return { kind: 'ok', browser: match, source: 'preference', ...facts };
    return { kind: 'mismatch', source: 'preference', ...facts };
  }

  // 3. 无偏好 —— 一律询问用户（哪怕 detected 只有一个）
  if (detected.length === 0) {
    return { kind: 'empty', ...facts };
  }
  return { kind: 'ambiguous', ...facts };
}

// 兜底：扫描常用固定端口
// 适用场景：用户手动 --remote-debugging-port=9222 启动浏览器，
// 此时 DevToolsActivePort 可能不在默认 user-data-dir。
export async function findFallbackPort() {
  for (const port of [9222, 9229, 9333]) {
    if (await checkPort(port)) return port;
  }
  return null;
}
