#!/usr/bin/env node
import {assertBrowserAllowed,browserFetchFor,readPolicy,accessToken} from '../../recruit-init/scripts/workspace-policy.mjs';
const workspaceContext=assertBrowserAllowed(import.meta.url);
const browserFetch=browserFetchFor(import.meta.url);
// find-url - 从本地 Chromium 系浏览器（Chrome / Edge）书签/历史中检索 URL
// 用于定位公网搜索覆盖不到的目标（组织内部系统、SSO 后台、内网域名等）。
//
// 用法：
//   node find-url.mjs [关键词...] [--only bookmarks|history] [--limit N] [--since 1d|7h|YYYY-MM-DD]
//
//   <关键词>             空格分词、多词 AND，匹配 title + url；可省略
//   --only <source>      限定数据源（bookmarks / history），默认两者都查
//   --browser <id>       限定浏览器（chrome / edge / chromium / brave / vivaldi …），默认遍历所有已安装的
//   --limit N            条数上限，默认 20；0 = 不限
//   --since <window>     时间窗（仅作用于历史）。1d / 7h / 30m 或 YYYY-MM-DD
//   --sort recent|visits 历史排序：按最近访问 / 按访问次数，默认 recent
//
// 示例：
//   node find-url.mjs 财务小智
//   node find-url.mjs agent skills
//   node find-url.mjs github --since 7d --only history
//   node find-url.mjs --since 7d --only history --sort visits   # 最近一周高频网站
//   node find-url.mjs --since 2d --only history --limit 0
//   node find-url.mjs github --browser edge                     # 只查 Edge

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { browserEntries } from './platform-support.mjs';

const require = createRequire(import.meta.url);

// --- 参数解析 -----------------------------------------------------------
function parseArgs(argv) {
  const a = { keywords: [], only: null, browser: null, limit: 20, since: null, sort: 'recent' };
  for (let i = 0; i < argv.length; i++) {
    const v = argv[i];
    if (v === '--only')         a.only    = argv[++i];
    else if (v === '--browser') a.browser = argv[++i];
    else if (v === '--limit')   a.limit   = parseInt(argv[++i], 10);
    else if (v === '--since')   a.since   = parseSince(argv[++i]);
    else if (v === '--sort')    a.sort    = argv[++i];
    else if (v === '-h' || v === '--help') { printUsage(); process.exit(0); }
    else if (v.startsWith('--')) die(`未知参数: ${v}`);
    else a.keywords.push(v);
  }
  if (a.only && !['bookmarks', 'history'].includes(a.only)) die(`--only 仅支持 bookmarks|history`);
  if (!['recent', 'visits'].includes(a.sort)) die(`--sort 仅支持 recent|visits`);
  if (Number.isNaN(a.limit) || a.limit < 0) die('--limit 需为非负整数');
  return a;
}

function parseSince(s) {
  if (!s) die('--since 需要值');
  const m = s.match(/^(\d+)([dhm])$/);
  if (m) {
    const n = parseInt(m[1], 10);
    const ms = { d: 86400000, h: 3600000, m: 60000 }[m[2]];
    return new Date(Date.now() - n * ms);
  }
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) die(`无效 --since 值: ${s}（用 1d / 7h / 30m / YYYY-MM-DD）`);
  return d;
}

function die(msg) { console.error(msg); process.exit(1); }
function printUsage() { console.error(fs.readFileSync(new URL(import.meta.url)).toString().split('\n').slice(1, 21).map(l => l.replace(/^\/\/ ?/, '')).join('\n')); }

// --- 浏览器用户数据目录（跨平台 + 多浏览器） -----------------------------
// 目录表在 platform-support.mjs：macOS / Windows / Linux 各通道 + Snap/Flatpak 全覆盖。
// 合并同一目录的多个 id（例如 chrome 与 chrome-beta 指向不同目录，这里只做去重保护）。
function knownBrowserDataDirs() {
  const seen = new Set();
  return browserEntries({ platform: os.platform(), env: process.env, home: os.homedir() })
    .filter((b) => {
      if (seen.has(b.dataRoot)) return false;
      seen.add(b.dataRoot);
      return true;
    })
    .map((b) => ({ id: b.id, label: b.label, dir: b.dataRoot }));
}

// --- Profile 枚举 -------------------------------------------------------
function listProfiles(dataDir) {
  try {
    const state = JSON.parse(fs.readFileSync(path.join(dataDir, 'Local State'), 'utf-8'));
    const info = state?.profile?.info_cache || {};
    const list = Object.keys(info).map(dir => ({ dir, name: info[dir].name || dir }));
    if (list.length) return list;
  } catch { /* 回退 */ }
  return [{ dir: 'Default', name: 'Default' }];
}

// --- 书签检索 -----------------------------------------------------------
function searchBookmarks(profileDir, profileName, browserLabel, keywords) {
  const file = path.join(profileDir, 'Bookmarks');
  if (!fs.existsSync(file)) return [];
  let data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf-8')); } catch { return []; }
  if (!keywords.length) return [];  // 书签无时间维度，无关键词不返回

  const needles = keywords.map(k => k.toLowerCase());
  const out = [];
  function walk(node, trail) {
    if (!node) return;
    if (node.type === 'url') {
      const hay = `${node.name || ''} ${node.url || ''}`.toLowerCase();
      if (needles.every(n => hay.includes(n))) {
        out.push({ browser: browserLabel, profile: profileName, name: node.name || '', url: node.url || '', folder: trail.join(' / ') });
      }
    }
    if (Array.isArray(node.children)) {
      const sub = node.name ? [...trail, node.name] : trail;
      for (const c of node.children) walk(c, sub);
    }
  }
  for (const root of Object.values(data.roots || {})) walk(root, []);
  return out;
}

// --- 历史检索（SQLite 运行时锁定，需 copy 到 tmp） ------------------------
const WEBKIT_EPOCH_DIFF_US = 11644473600000000n;  // 1601→1970 微秒差

// 历史库是「运行中还被浏览器锁着」的 SQLite 文件，必须复制到 tmp 再读。
// 两条读取路径：sqlite3 命令行（macOS/Linux 常自带）→ Node 内置 node:sqlite（Node 22.5+）。
// 这样 Windows 没装 sqlite3、或老 Mac 上 sqlite3 不完整时也能查历史。
function queryWithNodeSqlite(file, sql) {
  let mod;
  try { mod = require('node:sqlite'); } catch { return null; }
  if (!mod?.DatabaseSync) return null;
  let db;
  try {
    db = new mod.DatabaseSync(file, { readOnly: true });
    return db.prepare(sql).all();
  } catch {
    return null;
  } finally {
    try { db?.close(); } catch { /* ignore */ }
  }
}

function sqliteUnavailableHint() {
  if (os.platform() === 'darwin') return '未找到 sqlite3 命令（macOS 一般自带；可用 xcode-select --install 修复），Node 22.5+ 也会自动改用内置 node:sqlite。';
  if (os.platform() === 'win32') return '未找到 sqlite3 命令。Windows 可用 `winget install sqlite.sqlite` 安装后重开终端；Node 22.5+ 会优先尝试内置 node:sqlite。';
  return '未找到 sqlite3 命令。可用包管理器安装（如 apt install sqlite3 / dnf install sqlite），Node 22.5+ 会自动改用内置 node:sqlite。';
}

function queryHistory(file, sql) {
  try {
    const raw = execFileSync('sqlite3', ['-separator', '\t', file, sql], { encoding: 'utf-8', maxBuffer: 50 * 1024 * 1024 });
    const text = raw.trim();
    if (!text) return [];
    return text.split('\n').map((line) => {
      const [title, url, visit, visit_count] = line.split('\t');
      return { title, url, visit, visit_count };
    });
  } catch (error) {
    if (error.code !== 'ENOENT') return []; // CLI 存在但查询失败：按空结果处理
    const fallback = queryWithNodeSqlite(file, sql);
    if (fallback === null) { die(sqliteUnavailableHint()); return []; }
    return fallback;
  }
}

function searchHistory(profileDir, profileName, browserLabel, keywords, since, limit, sort) {
  const src = path.join(profileDir, 'History');
  if (!fs.existsSync(src)) return [];
  const tmp = path.join(os.tmpdir(), `browser-history-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.sqlite`);
  try {
    fs.copyFileSync(src, tmp);
    const conds = ['last_visit_time > 0'];
    for (const kw of keywords) {
      const esc = kw.toLowerCase().replace(/'/g, "''");
      conds.push(`LOWER(title || ' ' || url) LIKE '%${esc}%'`);
    }
    if (since) {
      const webkitUs = BigInt(since.getTime()) * 1000n + WEBKIT_EPOCH_DIFF_US;
      conds.push(`last_visit_time >= ${webkitUs}`);
    }
    const limitClause = limit === 0 ? -1 : limit;
    const orderBy = sort === 'visits'
      ? 'visit_count DESC, last_visit_time DESC'
      : 'last_visit_time DESC';
    const sql = `SELECT title, url,
      datetime((last_visit_time - 11644473600000000)/1000000, 'unixepoch', 'localtime') AS visit,
      visit_count
      FROM urls WHERE ${conds.join(' AND ')}
      ORDER BY ${orderBy} LIMIT ${limitClause};`;

    return queryHistory(tmp, sql).map((row) => ({
      browser: browserLabel,
      profile: profileName,
      title: row.title,
      url: row.url,
      visit: row.visit,
      visit_count: parseInt(row.visit_count, 10),
    }));
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
  }
}

// --- 输出格式化 ---------------------------------------------------------
// 用 `|` 作字段分隔符；字段内含 `|` 的替换成 `│`（全宽竖线）避免歧义
const clean = s => String(s ?? '').replaceAll('|', '│').trim();

function originTag(item, showBrowser, showProfile) {
  if (showBrowser && showProfile) return '@' + clean(item.browser) + '-' + clean(item.profile);
  if (showBrowser) return '@' + clean(item.browser);
  if (showProfile) return '@' + clean(item.profile);
  return null;
}

function printBookmarks(items, showBrowser, showProfile) {
  console.log(`[书签] ${items.length} 条`);
  for (const b of items) {
    const segs = [clean(b.name) || '(无标题)', clean(b.url)];
    if (b.folder) segs.push(clean(b.folder));
    const tag = originTag(b, showBrowser, showProfile);
    if (tag) segs.push(tag);
    console.log('  ' + segs.join(' | '));
  }
}

function printHistory(items, showBrowser, showProfile, sortLabel) {
  console.log(`[历史] ${items.length} 条（${sortLabel}）`);
  for (const h of items) {
    const segs = [clean(h.title) || '(无标题)', clean(h.url), h.visit];
    if (h.visit_count > 1) segs.push(`visits=${h.visit_count}`);
    const tag = originTag(h, showBrowser, showProfile);
    if (tag) segs.push(tag);
    console.log('  ' + segs.join(' | '));
  }
}

// --- main ---------------------------------------------------------------
const args = parseArgs(process.argv.slice(2));

let browsers = knownBrowserDataDirs().filter(b => fs.existsSync(b.dir));
if (args.browser) {
  const filtered = browsers.filter(b => b.id === args.browser);
  if (!filtered.length) {
    const available = browsers.map(b => b.id).join('、') || '无';
    die(`未找到浏览器 ${args.browser} 的用户数据目录（已检测到：${available}；可用 id 见 platform-support.mjs）`);
  }
  browsers = filtered;
}
if (!browsers.length) die('未找到任何 Chromium 系浏览器的用户数据目录（Chrome / Edge / Chromium / Brave / Vivaldi）');

const doBookmarks = args.only !== 'history';
const doHistory   = args.only !== 'bookmarks';

const bookmarks = [];
const history = [];
for (const browser of browsers) {
  const profiles = listProfiles(browser.dir);
  for (const p of profiles) {
    const pDir = path.join(browser.dir, p.dir);
    if (!fs.existsSync(pDir)) continue;
    if (doBookmarks) bookmarks.push(...searchBookmarks(pDir, p.name, browser.label, args.keywords));
    if (doHistory)   history.push(...searchHistory(pDir, p.name, browser.label, args.keywords, args.since, args.limit === 0 ? 0 : args.limit * 2, args.sort));
  }
}

// 历史跨 profile/浏览器 合并后按指定 sort 重排 + 切顶
if (args.sort === 'visits') {
  history.sort((a, b) => (b.visit_count || 0) - (a.visit_count || 0) || (b.visit || '').localeCompare(a.visit || ''));
} else {
  history.sort((a, b) => (b.visit || '').localeCompare(a.visit || ''));
}
const bookmarksOut = args.limit === 0 ? bookmarks : bookmarks.slice(0, args.limit);
const historyOut   = args.limit === 0 ? history   : history.slice(0, args.limit);

// 仅当结果真的横跨多个 browser/profile 时才输出 @ 标注（避免单源场景噪音）
const seenBrowsers = new Set([...bookmarksOut, ...historyOut].map(x => x.browser));
const seenProfiles = new Set([...bookmarksOut, ...historyOut].map(x => x.profile));
const showBrowser = seenBrowsers.size > 1;
const showProfile = seenProfiles.size > 1;

const sortLabel = args.sort === 'visits' ? '按访问次数' : '按最近访问';
if (doBookmarks) printBookmarks(bookmarksOut, showBrowser, showProfile);
if (doBookmarks && doHistory) console.log();
if (doHistory)   printHistory(historyOut, showBrowser, showProfile, sortLabel);

if (!args.keywords.length && doBookmarks && !doHistory) {
  console.error('\n提示：书签无时间维度，无关键词查询无意义。加关键词或切换 --only history。');
}
