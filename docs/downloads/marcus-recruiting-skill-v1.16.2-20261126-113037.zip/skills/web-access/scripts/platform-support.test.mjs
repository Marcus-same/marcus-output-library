import assert from 'node:assert/strict';
import test from 'node:test';
import path from 'node:path';
import {
  browserCatalog,
  browserEntries,
  browserById,
  macVersion,
  macVersionSupport,
  nodeCapabilities,
  describeEnvironment,
  NODE_MINIMUM,
} from './platform-support.mjs';

const home = path.join(path.sep, 'Users', 'tester');
const macRoot = (rest) => path.join(home, 'Library', 'Application Support', ...rest.split('/'));

test('macOS catalog covers Chrome channels, Edge, Brave and Vivaldi', () => {
  const list = browserCatalog({ platform: 'darwin', env: {}, home });
  const ids = list.map((b) => b.id);
  for (const id of ['chrome', 'chrome-beta', 'chrome-dev', 'chrome-canary', 'chromium', 'edge', 'brave', 'vivaldi']) {
    assert.ok(ids.includes(id), `missing ${id}`);
  }
  assert.equal(browserById('chrome', { platform: 'darwin', env: {}, home }).dataRoot, macRoot('Google/Chrome'));
  assert.equal(browserById('brave', { platform: 'darwin', env: {}, home }).dataRoot, macRoot('BraveSoftware/Brave-Browser'));
  // 每个条目的 DevToolsActivePort 必须落在用户数据目录下，不能拼错层级
  for (const entry of browserEntries({ platform: 'darwin', env: {}, home })) {
    assert.equal(entry.devToolsPath, path.join(entry.dataRoot, 'DevToolsActivePort'));
  }
});

test('Windows catalog uses LOCALAPPDATA and supports roaming Opera', () => {
  const env = { LOCALAPPDATA: 'C:\\Users\\tester\\AppData\\Local', APPDATA: 'C:\\Users\\tester\\AppData\\Roaming' };
  const chrome = browserById('chrome', { platform: 'win32', env, home });
  assert.equal(chrome.dataRoot, path.join(env.LOCALAPPDATA, 'Google', 'Chrome', 'User Data'));
  const edge = browserById('edge', { platform: 'win32', env, home });
  assert.equal(edge.dataRoot, path.join(env.LOCALAPPDATA, 'Microsoft', 'Edge', 'User Data'));
  const opera = browserById('opera', { platform: 'win32', env, home });
  assert.equal(opera.dataRoot, path.join(env.APPDATA, 'Opera Software', 'Opera Stable'));
});

test('Linux catalog covers config dirs and Snap/Flatpak installs', () => {
  const list = browserEntries({ platform: 'linux', env: {}, home });
  const byId = Object.fromEntries(list.map((b) => [b.id, b]));
  assert.equal(byId.chrome.dataRoot, path.join(home, '.config', 'google-chrome'));
  assert.equal(byId['chromium-snap'].dataRoot, path.join(home, 'snap', 'chromium', 'common', 'chromium'));
  assert.equal(byId['chrome-flatpak'].dataRoot, path.join(home, '.var', 'app', 'com.google.Chrome', 'config', 'google-chrome'));
});

test('WEB_ACCESS_BROWSER_DATA_DIRS overrides a data directory without dropping the entry', () => {
  const env = { WEB_ACCESS_BROWSER_DATA_DIRS: 'chrome=/opt/portable/chrome; vivaldi=/data/vivaldi' };
  const chrome = browserById('chrome', { platform: 'linux', env, home });
  assert.equal(chrome.dataRoot, '/opt/portable/chrome');
  assert.equal(chrome.source, 'env');
  assert.equal(browserById('vivaldi', { platform: 'linux', env, home }).dataRoot, '/data/vivaldi');
  assert.ok(browserById('edge', { platform: 'linux', env, home }), 'unrelated browsers stay available');
});

test('unsupported platforms return an empty catalog instead of throwing', () => {
  assert.deepEqual(browserCatalog({ platform: 'aix', env: {}, home }), []);
});

test('macOS version maps from Darwin release and prefers sw_vers output', () => {
  assert.equal(macVersion({ platform: 'darwin', release: '19.6.0' }), '10.15');
  assert.equal(macVersion({ platform: 'darwin', release: '20.6.0' }), '11');
  assert.equal(macVersion({ platform: 'darwin', release: '24.1.0' }), '15');
  assert.equal(macVersion({ platform: 'darwin', release: '24.1.0', read: () => '15.2' }), '15.2');
  assert.equal(macVersion({ platform: 'win32', release: '10.0.22631' }), null);
  assert.equal(macVersionSupport('10.15').min, 10.15);
  assert.equal(macVersionSupport('15').min, 11);
  assert.equal(macVersionSupport('10.14').min, 10.13);
});

test('Node capability gate: 18+ supported, 22+ native, older unsupported', () => {
  assert.equal(NODE_MINIMUM, 18);
  const old = nodeCapabilities({ node: '16.20.2' }, false);
  assert.equal(old.supported, false);
  assert.equal(old.mode, 'unsupported');
  const legacy = nodeCapabilities({ node: '20.11.1' }, false);
  assert.equal(legacy.supported, true);
  assert.equal(legacy.mode, 'compat');
  assert.equal(legacy.nativeWebSocket, false);
  const modern = nodeCapabilities({ node: '24.0.0' }, true);
  assert.equal(modern.mode, 'native');
});

test('describeEnvironment reports Apple Silicon advice and browser count', () => {
  const env = describeEnvironment({ platform: 'darwin', arch: 'arm64', release: '23.4.0', versions: { node: '22.1.0' }, env: {}, home });
  assert.equal(env.platformLabel, 'macOS');
  assert.equal(env.macVersion, '14');
  assert.ok(env.advice.some((line) => line.includes('Apple Silicon')));
  assert.equal(env.browsers.length, browserCatalog({ platform: 'darwin', env: {}, home }).length);
});
