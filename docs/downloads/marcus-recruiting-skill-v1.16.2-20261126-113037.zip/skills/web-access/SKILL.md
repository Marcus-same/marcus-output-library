---
name: web-access
license: MIT
description: >
  招聘工作区的受控浏览器依赖；仅在用户明确授权恢复后，复用指定的现有浏览器标签页。
  不用于通用联网路由，不创建浏览器或标签页。
metadata:
  author: 一泽Eze
  version: "2.5.4-local.3"
  github: https://github.com/eze-is/web-access
---

# 招聘工作区浏览器依赖

授权解释遵循 `../recruit-daily/references/authorization-and-continuation.md`：下面暂停文字为历史默认，以当前策略与当前对话的明确授权核对；已授权的恢复与指定页面不重复确认。保持单一 targetId 与真实安全停止条件。

招聘常驻连接的启动、失效标签页与岗位不匹配排查见 [连接恢复流程](../recruit-daily/references/connection-recovery.md)。Chrome实际WebSocket路径可包含浏览器实例编号，按核验地址完整保留。不要将旧代理和新常驻服务同时启动。

当前 BOSS 浏览器自动化处于暂停状态（`.recruiting-policy.json`）。安装或升级不构成恢复授权；不得探测、启动、重连或访问 BOSS。恢复必须由用户另行明确授权；恢复后也只复用用户指定的已有 targetId，不刷新、不新建标签页或独立浏览器，无法复用即停止。离线岗位梳理和本地简历工作不受影响。

## BOSS 页面使用要求

经授权执行页面操作时，必须保持原来的 BOSS 标签页打开，并让窗口处于前台；不要刷新，也不要切换到其他页面。详情弹层的关闭动画完成并通过只读校验后，才能处理下一位候选人。不要在操作期间最小化窗口。后台运行或切走页面可能暂停退出动画和按钮状态更新，导致关闭状态或候选人身份无法可靠读取；遇到这种情况立即停止，不强行点击、不移除 DOM、不自动重连。

这是基于原作者固定提交的本地适配版本，保留已有作者、许可证和来源元数据。

跨机型/跨系统差异集中在 `scripts/platform-support.mjs`（macOS / Windows / Linux 的浏览器目录、Chrome 各通道、Snap/Flatpak、Node 能力判定），不要在其他脚本里重新硬编码路径。Node 22+ 用原生 WebSocket；Node 18–21（macOS 10.15 等老系统无法装 Node 22）由 `scripts/ws-compat.mjs` 提供零依赖的最小 WebSocket 客户端，不支持时停止而不猜测。换机先跑 `../recruit-init/scripts/env-report.mjs` 做离线自检；浏览器版本与调试开关差异见 [references/env-troubleshooting.md](references/env-troubleshooting.md)。

本工作区的招聘约束优先于通用浏览器使用建议：只使用已由用户明确指定的现有 targetId，禁止 /new、/navigate、/back、/close，禁止并行创建页面。遇 403、验证、登录异常、权限不足立即停止，不换入口、不重复登录。

浏览器业务入口在网络请求和进程启动前检查工作区暂停策略。唯一维护例外是用户要求停止时的 `proxy-maintenance.mjs stop`：只鉴权读取本机服务身份并停止连接，不连接浏览器、不关闭网页、不启动服务。策略缺失或无效也停止，不能删除暂停文件绕过。凭证由工作区 runtime/proxy-access-token 提供，未设置时停止；不要在报告、公开文件或聊天中输出凭证。暂停策略与凭证应在另行授权恢复时配置，本次不生成、不启用。

页面脚本使用 recruit-daily/scripts/browser-client.mjs，统一绑定 targetId、风险检查、真实 iframe 点击和真实关闭。DOM 选择器必须来自经授权的页面检查；不支持或不唯一时停止，不删除页面元素假装关闭，也不回退 DOM click。

建立工作区、首次接入或修复前必须读 `../recruit-init/references/browser-acceptance.md` 并保留逐项验收记录。经授权建立连接后，优先由 daily 的 `bound-session.mjs` 维护单一常驻连接，`session-control.mjs` 只复用既有实例；不可每一步开关 WebSocket，不与旧代理并行启动。该会话的 `session-control.mjs stop` 也仅通过已认证的停止维护路径关闭连接，不访问页面或关闭标签页。接入超时/断线停止，不自动重连；Chrome 再次请求许可时由使用者处理，不承诺永久免确认。

API 与受限模式见 [references/cdp-api.md](references/cdp-api.md)。本次修复只做离线验证，不构成真实平台可用性保证。

## 接入核验与环境陷阱（2026-10-24 实测沉淀）

判断"能否复用已有浏览器"时，**不得凭 HTTP `/json/*` 探测下结论**——Chrome 受限模式下该接口返回 404，但浏览器级 WebSocket 仍可用；且本机 HTTP 代理会劫持 127.0.0.1 请求造成假阴性。正确做法：TCP 直连测端口 → 读 `DevToolsActivePort` 文件 → 用文件里的 WS 路径连 `Target.getTargets` 验证（同时识别残留假信号文件）。

> ⚠️ **上面这段只适用于「首次接入 / 连接已确认失效」的一次性验收**，不是日常手段。
> 已有可用常驻会话时**禁止**再跑 `ws-bind-check.mjs` 或任何裸 WS 探活：
> 每开一条浏览器级 CDP 连接，Chrome 144+ 就弹一次「允许远程调试」，握手还要 2–8 秒。
> 日常页面操作只走 `recruit-daily/scripts/browser-client.mjs`（或 `runtime/browser-service.mjs`）
> 打在常驻服务上的本地 HTTP 端口，单次约 200ms，零新增弹窗。
> 依据见 [connection-recovery.md](../recruit-daily/references/connection-recovery.md) L24/L38。

一键核验：`node web-access/scripts/ws-bind-check.mjs [--json]`（只读，不导航不新建；暂停状态下按策略拒绝探测并说明）。完整排查剧本见 [references/env-troubleshooting.md](references/env-troubleshooting.md)——含"误判 Chrome 忽略调试参数→错误新开独立 profile"的真实事故复盘，接入前必读。

注意：`workspace-policy.mjs` 按 `../../..` 相对路径定位工作区根，策略闸门只在**工作区副本**（如 `D:\recruiting\skills`）下可解析；用户级副本的脚本供打包分发，运行核验请用工作区副本。
