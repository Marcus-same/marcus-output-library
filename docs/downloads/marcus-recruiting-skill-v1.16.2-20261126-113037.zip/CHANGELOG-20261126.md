# 2026-11-26 修改记录

1. `recruit-daily/scripts/greet-safe.mjs`
   - 发送锁存在时不再裸抛 `EEXIST`，改为 `GREET_LOCK_HELD`，提示先核实发送进程，不自动删锁、不自动重试。
2. `recruit-daily/scripts/greet-lock-status.mjs`（新增）
   - 只读查看 `runtime/greet-run.lock` 的年龄与未完结的 `greet_pending`，给出处理顺序。
3. `recruit-daily/scripts/read-safe.mjs` / `batch-read-resume.mjs`
   - 单人右侧简历“骨架/正文未加载”不再中断整批：记 `screened` 失败并继续下一位；身份/风险/关闭失败仍停批。
4. `recruit-daily/scripts/shot-candidates.mjs`
   - 关闭控件改为读取 identity plan 的 `binding.panel.closeSelector`，不再硬编码旧的 `.boss-popup__close`。
5. `recruit-daily/SKILL.md`
   - 写明三级漏斗是默认口径：`reviewed` 只是最低发送闸门；高匹配但缺完整项目证据的，先按需截图深判再决定是否打招呼。
6. `recruit-daily/references/ledger-and-report.md`
   - 截图深判=0 且“高匹配/初筛通过”>0 时，日报必须标“第三层未执行”。
7. `recruit-daily/references/recovery-and-identity.md`
   - 补“pending 候选不在推荐池时查沟通会话列表；仍无法确认记待确认、不重发”；
   - 补锁诊断命令 `node skills/recruit-daily/scripts/greet-lock-status.mjs`。
8. 测试
   - 新增 `GREET_LOCK_HELD` 与 `continueOnFailure` 用例；本包内脚本离线测试通过。
