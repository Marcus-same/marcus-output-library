"use strict";
const calendarHtml = "<!doctype html>\n<html lang=\"zh-CN\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>TaskHub · 日历</title>\n<style>\n:root{color-scheme:light;--bg:#f7f8f5;--line:#e7eae5;--ink:#242d28;--soft:#606e66;--accent:#296653;--pale:#e5f1ea;--hour:58px;font:14px/1.45 Inter,system-ui,\"Microsoft YaHei\",sans-serif}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink)}button,input,select{font:inherit}button{cursor:pointer;color:inherit;border:1px solid var(--line);border-radius:8px;background:white;padding:7px 11px}button:hover{border-color:#9caea3}button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--accent);outline-offset:2px}button.primary{background:var(--accent);color:white;border-color:var(--accent)}button[aria-pressed=true]{background:var(--pale);color:#204c3d;border-color:#b6d2c1}button:disabled{opacity:.4;cursor:default}[hidden]{display:none!important}.shell{max-width:1500px;margin:auto;padding:22px 26px}.top,.bar,.actions,.aside-head,.legend{display:flex;align-items:center;gap:9px;flex-wrap:wrap}.top{justify-content:space-between;margin-bottom:24px}.brand{font-weight:750;letter-spacing:-.02em}.brand b{display:inline-grid;place-items:center;width:29px;height:29px;background:var(--accent);color:white;border-radius:9px;margin-right:9px}.prototype{font-size:12px;color:var(--soft)}.bar{justify-content:space-between;margin-bottom:15px}h1{font-size:27px;letter-spacing:-.04em;margin:0}h2{font-size:15px;margin:0}.range{color:var(--soft);font-size:13px;margin-top:5px}.layout{display:flex;align-items:flex-start;gap:14px}.calendar{flex:1;min-width:0;border:1px solid var(--line);border-radius:14px;background:white;overflow:hidden}.scroll{overflow:auto;max-height:72vh}.grid{display:grid;min-width:680px;grid-template-columns:52px repeat(var(--days),minmax(85px,1fr))}.grid.day{min-width:0}.date-head,.axis-head{position:sticky;top:0;z-index:3;background:white;border-bottom:1px solid var(--line);padding:9px 8px}.date-head{display:flex;gap:7px;align-items:center;color:var(--soft);border-left:1px solid var(--line);font-size:12px}.date-head strong{font-size:17px;color:var(--ink)}.date-head.today{background:#edf6ef}.date-head.today strong{color:var(--accent)}.axis{font-size:11px;color:var(--soft);position:relative}.axis span{position:absolute;right:8px;transform:translateY(3px)}.day-track{position:relative;border-left:1px solid var(--line);background:repeating-linear-gradient(to bottom,transparent 0,transparent calc(var(--hour) - 1px),var(--line) calc(var(--hour) - 1px),var(--line) var(--hour));}.day-track.target{background-color:#edf6ef}.block{position:absolute;min-width:0;text-align:left;overflow:hidden;padding:2px 5px;border-radius:6px;border:0;border-inline-start:3px solid #77a694;background:#e3f0e9;color:#24493d;display:block;white-space:nowrap;cursor:grab;font-size:12px}.block.event{background:#ebeafa;border-color:#9b95c8;color:#41396a}.block.done{opacity:.68}.block small{font-size:10px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.block strong{display:block;overflow:hidden;text-overflow:ellipsis}.block.short small{display:none}.block:active{cursor:grabbing}.legend{padding:9px 13px;color:var(--soft);font-size:12px;border-top:1px solid var(--line)}.dot{width:8px;height:8px;border-radius:99px;background:#77a694}.dot.event{background:#9b95c8}.aside{width:245px;flex:none;background:white;border:1px solid var(--line);border-radius:14px;padding:13px}.aside-head{justify-content:space-between}.aside p,.muted{color:var(--soft);font-size:12px}.task{width:100%;display:block;text-align:left;margin-top:8px;background:#f8faf8;cursor:grab}.task span{display:block;color:var(--soft);font-size:11px;margin-top:4px}dialog{border:1px solid var(--line);border-radius:15px;padding:20px;width:min(460px,calc(100% - 24px));color:var(--ink);box-shadow:0 20px 60px #233a2929}dialog::backdrop{background:#23342d48}form{display:grid;gap:12px}label{display:grid;gap:4px;color:var(--soft);min-width:0}input,select{width:100%;min-width:0;padding:8px;border:1px solid #ccd6ce;border-radius:7px;color:var(--ink);background:white}.fields{display:grid;grid-template-columns:1.2fr 1fr .7fr;gap:8px}.danger{color:#9a3235}.status{min-height:20px;margin:7px 0 0;color:var(--soft);font-size:12px}.editor-actions{border-top:1px solid var(--line);padding-top:11px}.right{margin-inline-start:auto}@media(max-width:800px){.shell{padding:14px}.layout{display:block}.aside{margin-top:12px;width:auto}.scroll{max-height:64vh}.bar{align-items:flex-start}}@media(max-width:400px){.fields{grid-template-columns:1fr 1fr}.fields label:first-child{grid-column:1/-1}}\n.block[data-tone],.dot[data-tone]{background:var(--card-bg);border-color:var(--card-line);color:var(--card-ink)}.dot[data-tone]{background:var(--card-line)}\n[data-tone=jade]{--card-bg:#e1f1e8;--card-line:#5e9c80;--card-ink:#214b39}\n[data-tone=blue]{--card-bg:#e3eef9;--card-line:#6b96c0;--card-ink:#244867}\n[data-tone=amber]{--card-bg:#f7edd8;--card-line:#bd9048;--card-ink:#644917}\n[data-tone=lilac]{--card-bg:#eee7f8;--card-line:#9a81ba;--card-ink:#533c70}\n[data-tone=rose]{--card-bg:#f7e5eb;--card-line:#bd8295;--card-ink:#6a3547}\n[data-tone=teal]{--card-bg:#e0f0f0;--card-line:#589ca0;--card-ink:#255356}\n.legend-item{display:inline-flex;align-items:center;gap:5px;margin-inline-end:7px}.block.event{border-inline-start:3px double var(--card-line)}\n:root{--bg:#fff;--ink:#242424;--soft:#747474;--line:#ececec;--accent:#303030}\n.shell{max-width:none;padding:0;min-height:100dvh;display:grid;grid-template-columns:214px minmax(0,1fr) 252px;grid-template-rows:auto minmax(0,1fr) auto}\n.shell:has(#pool[hidden]){grid-template-columns:214px minmax(0,1fr)}\n.sidebar{grid-column:1;grid-row:1/-1;background:#f7f7f7;border-right:1px solid var(--line);padding:18px 14px}\n.brand{margin-bottom:28px}.brand b{width:23px;height:23px;border-radius:6px;font-size:12px}.month-head{display:flex;align-items:center;justify-content:space-between;gap:4px;margin-bottom:8px}.month-head strong{font-size:13px}.month-head button{background:none;border:0;padding:3px 6px;color:var(--soft)}\n.mini{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));text-align:center;gap:2px 0}.mini span{color:var(--soft);font-size:10px;padding:5px 0}.mini button{border:0;background:transparent;padding:4px 0;border-radius:5px;font-size:12px}.mini button.other{color:#a4a4a4}.mini button.in-week{background:#eaeaea}.mini button.selected{background:#ee514b;color:white}.mini button:hover:not(.selected){background:#dedede}\n.sources{margin-top:22px;padding-top:16px;border-top:1px solid var(--line);display:grid;gap:5px}.sources h2{font-size:11px;color:var(--soft);font-weight:500;margin-bottom:6px}.sources button{display:flex;align-items:center;gap:8px;background:transparent;border:0;text-align:left;font-size:12px;padding:6px}.sources button:hover{background:#ececec}.sources button[aria-pressed=false]{color:#898989}.sources button[aria-pressed=false] .dot{background:transparent;border:1px solid var(--card-line)}\n.top{grid-column:2;grid-row:1;margin:0;padding:10px 14px;justify-content:flex-end;border-bottom:1px solid var(--line)}\n.workspace{grid-column:2;grid-row:2;min-width:0}.bar{margin:0;padding:14px 16px 9px;min-height:75px}.bar h1{font-size:25px}.range{font-size:11px;margin-top:2px}.actions{gap:5px}.top button,.bar button{font-size:12px;padding:5px 8px;border-radius:6px}.bar .actions button[aria-pressed=true],#tasks-only[aria-pressed=true]{background:#efefef;border-color:#d9d9d9;color:#242424}\n.calendar{border:0;border-radius:0}.scroll{max-height:calc(100dvh - 158px);min-height:240px}.grid{min-width:0;grid-template-columns:46px repeat(var(--days),minmax(74px,1fr))}.date-head,.axis-head{padding:7px 5px}.date-head{justify-content:center;gap:5px}.date-head strong{font-size:14px;order:2}.date-head.today{background:white}.date-head.today strong{background:#ee514b;color:#fff;padding:0 4px;border-radius:4px}.day-track.target{background-color:#f2f5fa}.block{border-radius:4px;text-align:start;font-weight:500}.block.event{border-inline-start-style:solid}.block small{font-size:10px}.now-line{position:absolute;left:0;right:0;z-index:2;border-top:1px solid #e64a43;pointer-events:none}.now-line:before{content:'';width:6px;height:6px;border-radius:100%;background:#e64a43;position:absolute;top:-4px;left:0}\n.aside{grid-column:3;grid-row:1/-1;width:auto;margin:0;padding:16px 14px;border:0;border-left:1px solid var(--line);border-radius:0;min-height:100%;overflow:hidden}.aside-head{gap:6px}.aside-head button{border:0;background:transparent;padding:3px 6px}.aside input{border-color:var(--line);background:#fafafa;margin:10px 0 6px}.task{border-radius:5px;background:white;padding:8px;font-size:12px}.task span{font-size:10px}.side-note{border-top:1px solid var(--line);margin-top:17px;padding-top:10px}.shell>.status{grid-column:2;margin:0;padding:6px 12px;border-top:1px solid var(--line);font-size:11px}\n@media(max-width:1120px){.shell{grid-template-columns:174px minmax(0,1fr) 184px}.shell:has(#pool[hidden]){grid-template-columns:174px minmax(0,1fr)}.sidebar,.aside{padding:12px 10px}}\n@media(max-width:800px){.shell,.shell:has(#pool[hidden]){display:block}.sidebar{display:none}.top{justify-content:space-between}.top:before{content:'TaskHub';font-weight:750}.aside{min-height:0;border:0;border-top:1px solid var(--line);margin:0;padding:14px}.bar{padding:10px}.scroll{max-height:62dvh}.grid:not(.day):not(.month){min-width:630px}}\n.grid.month{grid-template-columns:repeat(7,minmax(0,1fr));min-width:0}.month-cell{min-height:105px;min-width:0;padding:5px;border-right:1px solid var(--line);border-bottom:1px solid var(--line);display:flex;flex-direction:column;gap:3px}.month-cell.other{background:#fafafa}.month-cell.target{background:#edf4fc}.month-number{align-self:flex-start;padding:1px 5px;border:0;background:transparent;font-size:12px}.month-number.today{background:#ee514b;color:white}.month-card{position:static;width:100%;height:auto;padding:3px 4px;text-overflow:ellipsis}.month-cell .more-day{font-size:11px;border:0;padding:2px;background:transparent;text-align:start}\n.mini button.today{background:#ee514b;color:white}\n@media(max-width:600px){.month-cell{min-height:72px;padding:2px}.month-card{font-size:10px}.month-card small{display:none}}\n\n.shell{height:100dvh;min-height:0;overflow:hidden;grid-template-columns:var(--left-width,214px) minmax(0,1fr) var(--right-width,252px)}\n.shell:has(#pool[hidden]){grid-template-columns:var(--left-width,214px) minmax(0,1fr)}\n.shell:has(#left-panel[hidden]){--left-width:0px}.sidebar,.aside{min-height:0;height:100%;display:flex;flex-direction:column;overflow:hidden;padding:0}\n.side-head{display:flex;align-items:center;justify-content:space-between;gap:6px;padding:14px 12px;flex:none;border-bottom:1px solid var(--line)}.side-head .brand{margin:0}.side-head button{border:0;background:transparent;padding:3px 6px}\n.side-scroll{flex:1;min-height:0;overflow:auto;padding:16px 12px}.side-group+.side-group{margin-top:24px}.side-group h2,.side-footer h2{font-size:11px;font-weight:650;color:#626262;margin:0 0 7px}.sources{padding:0;border:0;margin:0}.sources button,.agent-target,.agent-run,.task,.side-footer button{color:#505050}.sources button[aria-pressed=true],.agent-tabs button[aria-pressed=true],#toggle-left[aria-pressed=true],#pool-toggle[aria-expanded=true]{background:#e1e8e2;color:#203b2e}.sources button[aria-pressed=false]{color:#5c5c5c}.sources #legend{display:grid;gap:3px}.sources #legend button{width:100%}.agent-section{margin-top:23px}.side-footer{flex:none;padding:12px;border-top:1px solid var(--line);display:grid;gap:3px}.side-footer button{text-align:start;background:transparent;border:0;padding:5px 7px}.side-footer button:hover{background:#e8e8e8}.side-footer .upgrade{margin-top:6px;background:#dcebe1;color:#214c37;font-weight:700}.side-footer .upgrade:hover{background:#cfe5d6}.workspace{display:flex;flex-direction:column;min-height:0}.calendar{flex:1;min-height:0;display:flex}.calendar .scroll{min-height:0;max-height:none;width:100%}.shell>.status{min-width:0}.side-scroll .agent-tabs{margin-top:0}\n@media(max-width:1120px){.shell{--left-width:174px;--right-width:184px}}@media(max-width:800px){.shell,.shell:has(#pool[hidden]){display:flex;flex-direction:column}.top{flex:none}.workspace{flex:1}.shell>.status{flex:none}.sidebar,.aside{display:flex;position:fixed;top:0;bottom:0;width:min(270px,85vw);z-index:8;background:white;box-shadow:0 0 20px #2222}.sidebar{left:0}.aside{right:0}.grid:not(.day):not(.month){min-width:630px}}\n\n.shell:has(#left-panel[hidden]){grid-template-columns:0 minmax(0,1fr) var(--right-width,252px)}\n.shell:has(#left-panel[hidden]):has(#pool[hidden]){grid-template-columns:0 minmax(0,1fr)}\n.calendar-feedback{grid-column:2;display:flex;align-items:center;gap:8px;padding:4px 12px;border-top:1px solid var(--line)}\n.calendar-feedback>.status{margin:0}.side-footer a{padding:5px 7px;border-radius:6px;text-decoration:none;font-size:12px}\n@media(max-width:800px){.shell:has(#left-panel[hidden]),.shell:has(#left-panel[hidden]):has(#pool[hidden]){display:flex}.calendar-feedback{flex:none}}\n.sources #legend label{display:grid;gap:4px;margin:0 0 9px;font-size:12px}.sources #legend select{padding:5px;max-width:100%}</style>\n</head>\n<body><main class=\"shell\">\n<aside id=\"left-panel\" class=\"sidebar\" aria-label=\"月历和分类\"><div class=\"side-head\"><div class=\"brand\"><b>✓</b>TaskHub</div><button id=\"close-left\" aria-label=\"收起月历侧栏\">‹</button></div><div class=\"side-scroll\"><section><h2>日期导航</h2><div class=\"month-head\"><strong id=\"mini-title\"></strong><div><button id=\"mini-prev\" aria-label=\"上个月\">‹</button><button id=\"mini-next\" aria-label=\"下个月\">›</button></div></div><div id=\"mini\" class=\"mini\" aria-label=\"月历\"></div></section><section class=\"sources\"><h2>按待办筛选</h2><div id=\"legend\"></div></section></div><footer class=\"side-footer\"><button id=\"side-settings\">设置</button><button id=\"side-help\">帮助</button><button class=\"upgrade\" id=\"side-upgrade\">↑ 查看更新</button></footer></aside>\n<header class=\"top\"><div class=\"actions\"><button id=\"left-toggle\" aria-controls=\"left-panel\" aria-expanded=\"true\">月历侧栏</button><button id=\"tasks-only\" aria-pressed=\"false\">只看待办</button></div></header>\n<div class=\"workspace\"><section class=\"bar\" aria-label=\"日历导航\"><div><h1 id=\"month-title\">日历</h1><div class=\"range\" id=\"range\"></div></div><div class=\"actions\"><button id=\"week\" aria-pressed=\"true\">周</button><button id=\"day\" aria-pressed=\"false\">日</button><button id=\"month\" aria-pressed=\"false\">月</button><button id=\"today\">今天</button><button id=\"previous\" aria-label=\"上一段日期\">‹</button><button id=\"next\" aria-label=\"下一段日期\">›</button></div></section>\n<section class=\"calendar\" aria-label=\"日程时间表\"><div class=\"scroll\" id=\"scroll\"><div class=\"grid\" id=\"grid\"></div></div></section></div>\n<aside class=\"aside\" id=\"pool\" hidden><div class=\"side-head\"><h2>未排期待办</h2><button id=\"close-pool\" aria-label=\"收起待办栏\">×</button></div><div class=\"side-scroll\"><input id=\"pool-search\" type=\"search\" aria-label=\"搜索未排期待办\" placeholder=\"搜索待办、分类或项目…\"><div id=\"tasks\"></div><section class=\"sources\" id=\"deck-section\" hidden><h2>Agent Deck</h2><div id=\"deck-targets\"></div></section><p class=\"side-note\">拖到日历排期，或点待办选择时间。</p></div></aside>\n<div class=\"calendar-feedback\"><p class=\"status\" id=\"status\" role=\"status\">正在读取 Obsidian 日历…</p><button id=\"reload\">刷新日历</button></div>\n</main>\n<dialog id=\"info\"><form method=\"dialog\"><h2 id=\"info-title\"></h2><p id=\"info-text\"></p><button id=\"info-close\" type=\"button\">关闭</button></form></dialog><dialog id=\"editor\"><form id=\"form\" novalidate><div class=\"aside-head\"><h2 id=\"editor-title\"></h2><button id=\"close-editor\" type=\"button\" aria-label=\"关闭\">×</button></div><label>名称<input id=\"title\" required maxlength=\"120\"></label><div class=\"fields\"><label>日期<input id=\"date\" type=\"date\" required></label><label>开始<input id=\"time\" type=\"time\" required></label><label>时长（分钟）<input id=\"duration\" type=\"number\" min=\"15\" max=\"720\" step=\"15\" required></label></div><p class=\"muted\" id=\"detail\" hidden></p><p class=\"status\" id=\"error\" role=\"alert\" hidden></p><div class=\"actions editor-actions\"><button type=\"button\" id=\"agent-source\">打开原待办</button><label id=\"deck-choice-label\">交给 Agent<select id=\"deck-choice\"></select></label><button type=\"button\" id=\"agent-delegate\">预览委派</button><button type=\"button\" id=\"copy\">复制</button><button type=\"button\" id=\"copy-block\">再安排一段</button><button type=\"button\" id=\"remove\">移出日历</button><button type=\"button\" id=\"delete\" class=\"danger\">删除</button><button class=\"primary right\" type=\"button\" id=\"save-editor\">保存</button></div></form></dialog>\n<dialog id=\"confirm\"><form method=\"dialog\"><h2 id=\"confirm-title\"></h2><div class=\"actions\"><button id=\"confirm-cancel\" type=\"button\" autofocus>取消</button><button id=\"confirm-delete\" type=\"button\" class=\"danger\">确认删除</button></div></form></dialog>\n<script>\nconst $=id=>document.getElementById(id);\nconst dayKey=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');\nconst at=s=>new Date(s+'T12:00:00');\nconst shift=(d,n)=>{const next=new Date(d);next.setDate(next.getDate()+n);return next;};\nconst monday=d=>shift(d,-(d.getDay()+6)%7);\nconst clock=n=>String(Math.floor(n/60)).padStart(2,'0')+':'+String(n%60).padStart(2,'0');\nconst minutes=s=>{const [h,m]=s.split(':').map(Number);return h*60+m;};\nconst today=new Date();\nlet agents=[];\nlet tasks=[],blocks=[],waiting=false,loaded=false,loading=false,revision=0;\nlet current=today,mode=matchMedia('(max-width: 700px)').matches?'day':'week',dragging=null,editing=null,suppressClick=false,tasksOnly=false;\nlet externalDrag=null,externalTimer=0,waitdog=0,pointerDrag=null,gridRange={low:480,high:1140};\nconst setFormDisabled=disabled=>$('form').querySelectorAll('button,input,select').forEach(el=>el.disabled=disabled);\nfunction recover(reason){\n  waiting=false;loading=false;clearTimeout(waitdog);waitdog=0;setFormDisabled(false);\n  if(reason)status(reason);\n}\nconst send=(action,payload={})=>{\n  if(waiting){status('上一个操作还在进行，请稍候。');return;}\n  waiting=true;loading=action==='load';\n  clearTimeout(waitdog);waitdog=setTimeout(()=>{if(waiting)recover('操作超时，已重置。请重试；反复出现就点「刷新日历」。');},5000);\n  setFormDisabled(true);\n  status(action==='load'?'正在读取 Obsidian 日历…':'正在保存…');\n  parent.postMessage({type:'taskhub-calendar',action,revision,...payload},'*');\n};\nconst slotsOf=id=>blocks.filter(block=>block.taskId===id);\nconst toSlot=({date,start,length,tone})=>({date,start,length,tone:tone||''});\nconst changeTask=(task,slots)=>send('save-task',{taskId:task.id,title:task.title,slots:slots.map(toSlot)});\nconst palette={jade:'浅绿',blue:'雾蓝',amber:'浅琥珀',lilac:'淡紫',rose:'豆沙粉',teal:'浅青'};\nconst categoryTones={'招聘':'jade','薪酬':'amber','收集箱':'teal'};\nlet categoryFilter='',projectFilter='';\nconst taskMime='application/x-taskhub-task';\nconst acceptsDrop=event=>!!dragging||!!externalDrag||Array.from(event.dataTransfer?.types??[]).includes(taskMime);\nconst dropData=event=>dragging||externalDrag||{token:event.dataTransfer?.getData(taskMime)};\nlet miniMonth=new Date(today.getFullYear(),today.getMonth(),1,12);\nfunction matchesFilters(block){const task=findTask(block.taskId);return (!categoryFilter||task?.category===categoryFilter)&&(!projectFilter||task?.project===projectFilter);}\nfunction toneOf(block){\n  if(block.kind!=='task')return block.tone||'lilac';\n  const task=findTask(block.taskId),key=task?.category||task?.project||'';\n  if(!key)return 'teal';\n  const tones=Object.keys(palette);\n  const hash=Array.from(key).reduce((value,char)=>(Math.imul(value,31)+char.codePointAt(0))>>>0,0);\n  return Object.hasOwn(categoryTones,key)?categoryTones[key]:tones[hash%tones.length];\n}\nconst findTask=id=>tasks.find(task=>task.id===id);\nconst titleOf=block=>block.kind==='task'?findTask(block.taskId)?.title: block.title;\nconst status=text=>{$('status').textContent=text;};\nfunction dates(){\n  if(mode==='day')return [current];\n  const first=mode==='month'?new Date(current.getFullYear(),current.getMonth(),1,12):current;\n  return Array.from({length:mode==='month'?42:7},(_,i)=>shift(monday(first),i));\n}\nfunction moveBlock(data,date,start){\n  if(!loaded){status('日历正在更新，请稍后重试。');return;}\n  if(waiting){status('上一个操作还在进行，请稍后再拖。');return;}\n  if(data.token){send('schedule-dragged-task',{token:data.token,slot:{date,start,length:Math.min(30,1440-start)}});return;}\n  const block=blocks.find(item=>item.id===data.blockId);\n  if(!block&&data.taskId==null){status('这次拖动没有把待办带过来，请重新拖一次，或点右侧待办选择时间。');return;}\n  const length=block?.length??Math.min(30,1440-start);\n  if(start+length>1440){status('这段安排会跨过午夜，请选择更早的时间。');return;}\n  const slot={...block,date,start,length};\n  if(block?.kind==='event')send('save-event',{id:block.eventId,title:block.title,slot:toSlot(slot)});\n  else {\n    const task=findTask(block?.taskId??data.taskId);\n    if(task)changeTask(task,block?slotsOf(task.id).map(item=>item.id===block.id?slot:item):[...slotsOf(task.id),slot]);\n  }\n}\nfunction renderMonth(grid,shown,relevant){\n  for(const label of ['周一','周二','周三','周四','周五','周六','周日'])grid.append(node('div',label,'date-head'));\n  for(const date of shown){\n    const key=dayKey(date),cell=node('div','','month-cell');cell.dataset.date=key;\n    if(date.getMonth()!==current.getMonth())cell.classList.add('other');\n    const number=node('button',String(date.getDate()),'month-number'+(key===dayKey(new Date())?' today':''));\n    number.setAttribute('aria-label','查看 '+key);number.onclick=()=>{mode='day';navigate(date);};cell.append(number);\n    cell.ondragover=event=>{event.preventDefault();if(acceptsDrop(event))cell.classList.add('target');};\n    cell.ondragleave=event=>{if(!cell.contains(event.relatedTarget))cell.classList.remove('target');};\n    cell.ondrop=event=>{\n      event.preventDefault();\n      if(!acceptsDrop(event)){status('这次拖动没被识别为待办：浏览器没有把待办数据送进日历。请用右侧「待办栏」拖拽，或点任务行「安排」。');return;}\n      const data=dropData(event);dragging=null;\n      cell.classList.remove('target');setTimeout(()=>{suppressClick=false;},0);\n      const block=blocks.find(item=>item.id===data.blockId);\n      moveBlock(data,key,block?.start??540);\n    };\n    const items=relevant.filter(block=>block.date===key).sort((a,b)=>a.start-b.start);\n    for(const block of items.slice(0,3)){\n      const button=node('button',clock(block.start)+' '+titleOf(block),'block month-card '+block.kind);\n      button.title=button.textContent;button.dataset.tone=toneOf(block);\n      bindDrag(button,{blockId:block.id});button.onclick=()=>{if(!suppressClick)openEditor(block);};cell.append(button);\n    }\n    if(items.length>3){const more=node('button','+'+(items.length-3)+' 项','more-day');more.onclick=()=>{mode='day';navigate(date);};cell.append(more);}\n    grid.append(cell);\n  }\n}\nfunction node(tag,text,cls){const value=document.createElement(tag);if(text)value.textContent=text;if(cls)value.className=cls;return value;}\nconst monthLabel=date=>date.getFullYear()+' 年 '+(date.getMonth()+1)+' 月';\nfunction navigate(date){current=date;miniMonth=new Date(date.getFullYear(),date.getMonth(),1,12);render();}\nfunction renderMini(keys){\n  $('mini-title').textContent=monthLabel(miniMonth);\n  const mini=$('mini');mini.replaceChildren();\n  for(const name of '一二三四五六日')mini.append(node('span',name));\n  const start=monday(miniMonth);\n  for(let index=0;index<42;index++){\n    const date=shift(start,index),key=dayKey(date),button=node('button',String(date.getDate()));\n    button.setAttribute('aria-label',key);\n    if(date.getMonth()!==miniMonth.getMonth())button.classList.add('other');\n    if(keys.includes(key))button.classList.add('in-week');\n    if(key===dayKey(current)){button.classList.add('selected');button.setAttribute('aria-current','date');}\n    button.onclick=()=>navigate(date);mini.append(button);\n  }\n}\nfunction bindDrag(button,data){\n  button.draggable=true;\n  button.addEventListener('dragstart',event=>{dragging=data;clearExternalDrag();suppressClick=true;event.dataTransfer.setData('text/plain','TaskHub');event.dataTransfer.effectAllowed='move';});\n  button.addEventListener('dragend',()=>{dragging=null;document.querySelectorAll('.target').forEach(el=>el.classList.remove('target'));setTimeout(()=>{suppressClick=false;},0);});\n}\nfunction render(){\n  const shown=dates(), keys=shown.map(dayKey);\n  $('month-title').textContent=monthLabel(current);\n  renderMini(keys);\n  $('tasks-only').setAttribute('aria-pressed',String(tasksOnly));\n  const legend=$('legend');legend.replaceChildren();\n  for(const [key,label,selected] of [['category','分类',categoryFilter],['project','项目',projectFilter]]){\n    const values=[...new Set(tasks.map(task=>task[key]).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'zh-CN'));\n    if(!values.length){if(key==='category')categoryFilter='';else projectFilter='';continue;}\n    const field=node('label',label),select=node('select');\n    for(const value of ['',...values]){const option=node('option',value||'全部'+label);option.value=value;select.append(option);}\n    select.value=values.includes(selected)?selected:'';\n    if(key==='category')categoryFilter=select.value;else projectFilter=select.value;\n    select.onchange=()=>{if(key==='category')categoryFilter=select.value;else projectFilter=select.value;render();};\n    field.append(select);legend.append(field);\n  }\n  const relevant=blocks.filter(b=>keys.includes(b.date)&&(!tasksOnly||b.kind==='task')&&matchesFilters(b));\n  const firstHour=Math.min(8,...relevant.map(b=>Math.floor(b.start/60))), lastHour=Math.max(19,...relevant.map(b=>Math.ceil((b.start+b.length)/60)));\n  const low=firstHour*60, high=lastHour*60, height=(lastHour-firstHour)*58;gridRange={low,high};\n  const grid=$('grid');grid.replaceChildren();grid.classList.toggle('day',mode==='day');grid.classList.toggle('month',mode==='month');grid.style.setProperty('--days',shown.length);\n  $('range').textContent=mode==='month'?'':keys.length===1?keys[0]:keys[0]+' — '+keys.at(-1);\n  for(const view of ['week','day','month']) $(view).setAttribute('aria-pressed',String(mode===view));\n  if(mode==='month')renderMonth(grid,shown,relevant);\n  else {\n  grid.append(node('div','','axis-head'));\n  shown.forEach((d,i)=>{const head=node('div','','date-head');if(keys[i]===dayKey(today))head.classList.add('today');head.append(node('strong',String(d.getDate())),node('span','周'+'日一二三四五六'[d.getDay()]));grid.append(head);});\n  const axis=node('div','','axis');axis.style.height=height+'px';\n  for(let hour=firstHour;hour<lastHour;hour++){const label=node('span',clock(hour*60));label.style.top=(hour-firstHour)*58+'px';axis.append(label);}grid.append(axis);\n  for(const date of keys){\n    const track=node('div','','day-track');track.style.height=height+'px';track.dataset.date=date;grid.append(track);\n    const now=new Date(), nowMinute=now.getHours()*60+now.getMinutes();\n    if(date===dayKey(now)&&nowMinute>=low&&nowMinute<high){const line=node('div','','now-line');line.style.top=(nowMinute-low)/60*58+'px';line.setAttribute('aria-hidden','true');track.append(line);}\n    const slot=event=>Math.max(low,Math.min(high-15,low+Math.floor((event.clientY-track.getBoundingClientRect().top)/58*4)*15));\n    track.addEventListener('dragover',event=>{event.preventDefault();if(acceptsDrop(event))track.classList.add('target');});\n    track.addEventListener('dragleave',event=>{if(!track.contains(event.relatedTarget)) track.classList.remove('target');});\n    track.addEventListener('drop',event=>{event.preventDefault();const start=slot(event);\n      if(!acceptsDrop(event)){track.classList.remove('target');status('这次拖动没被识别为待办：浏览器没有把待办数据送进日历。请用右侧「待办栏」拖拽，或点任务行「安排」。');return;}\n      const data=dropData(event);dragging=null;track.classList.remove('target');setTimeout(()=>{suppressClick=false;},0);\n      moveBlock(data,date,start);\n    });\n    const items=relevant.filter(b=>b.date===date).sort((a,b)=>a.start-b.start);\n    for(let pos=0;pos<items.length;){\n      const group=[];let end=items[pos].start+1;\n      while(pos<items.length&&items[pos].start<end){const block=items[pos++];end=Math.max(end,block.start+block.length);group.push(block);}\n      const lanes=[], placements=[];\n      for(const block of group){let lane=lanes.findIndex(stop=>stop<=block.start);if(lane<0)lane=lanes.length;lanes[lane]=block.start+block.length;placements.push({block,lane});}\n      for(const {block,lane} of placements){const name=titleOf(block);const button=node('button','','block '+block.kind+(block.length<35?' short':''));button.type='button';\n        button.dataset.tone=toneOf(block);\n        button.title=(block.kind==='task'?'待办 · ':'日程 · ')+clock(block.start)+'–'+clock(block.start+block.length)+' '+name;\n        button.style.top=((block.start-low)/60*58)+'px';button.style.height=Math.max(13,block.length/60*58-2)+'px';\n        button.style.left=`calc(${lane/lanes.length*100}% + 2px)`;button.style.width=`calc(${100/lanes.length}% - 4px)`;\n        button.append(node('strong',name),node('small',clock(block.start)+'–'+clock(block.start+block.length)));\n        bindDrag(button,{blockId:block.id});button.addEventListener('click',()=>{if(!suppressClick)openEditor(block);});track.append(button);}\n    }\n  }\n  }\n  const targets=$('deck-targets');targets.replaceChildren();\n  $('deck-section').hidden=!agents.length;\n  for(const agent of agents){\n    const target=node('button',agent.name);\n    target.title='拖入待办，打开委派确认';\n    const taskId=()=>dragging?.taskId??blocks.find(block=>block.id===dragging?.blockId)?.taskId;\n    target.ondragover=event=>{if(taskId()!=null)event.preventDefault();};\n    target.ondrop=event=>{\n      const id=taskId();if(id==null)return;\n      event.preventDefault();dragging=null;setTimeout(()=>{suppressClick=false;},0);\n      send('delegate',{taskId:id,agent:agent.id});\n    };\n    target.onclick=()=>status('把待办卡片拖到 '+agent.name+'，或在卡片中选择 Agent。');\n    targets.append(target);\n  }\n  renderPool();\n}\nfunction renderPool(){\n  const pool=$('tasks');pool.replaceChildren();\n  const search=$('pool-search').value.trim().toLowerCase();\n  const pending=tasks.filter(task=>matchesFilters({taskId:task.id})&&!blocks.some(block=>block.taskId===task.id)&&(!search||[task.title,task.category,task.project].join(' ').toLowerCase().includes(search)));\n  if(!pending.length)pool.append(node('p',search?'没有匹配的未排期待办。':'暂无未排期待办。'));\n  for(const task of pending){const button=node('button',task.title,'task');button.append(node('span',[task.category,task.project,task.due?'截止 '+task.due:''].filter(Boolean).join(' · ')));bindDrag(button,{taskId:task.id});\n    button.addEventListener('click',()=>{if(!suppressClick)openEditor({kind:'task',taskId:task.id,date:dayKey(current),start:540,length:30});});pool.append(button);}\n}\nfunction openEditor(value){\n  if(!loaded){status('日历还没加载完，稍候再点。');return;}\n  if(waiting){status('上一个操作还在进行，请稍候。');return;}\n  editing={...value};const existing=Boolean(value.id),task=findTask(value.taskId);\n  $('editor-title').textContent=existing?'编辑安排':task?'安排待办':'复制待办';\n  $('title').value=titleOf(value)||'';$('title').readOnly=!!task;$('date').value=value.date;$('time').value=clock(value.start);$('duration').value=value.length;\n  $('agent-source').hidden=!task;\n  $('agent-delegate').hidden=$('deck-choice-label').hidden=!task||!agents.length;\n  $('deck-choice').replaceChildren();\n  for(const agent of agents){const option=node('option',agent.name);option.value=agent.id;$('deck-choice').append(option);}\n  $('copy').hidden=!existing||!task;$('copy-block').hidden=!existing||!task;$('remove').hidden=!existing||!task;$('delete').hidden=!existing;\n  $('delete').textContent=task?'删除待办':'删除日程';$('copy').textContent=task?'复制待办':'复制日程';\n  $('detail').hidden=!task?.due;$('detail').textContent=task?.due?'截止日期 '+task.due+' · 改排期时保留此日期':'';$('error').hidden=true;\n  if(!$('editor').open)$('editor').showModal();\n}\nfunction copy(sameTask){\n  const source=editing, task=findTask(source.taskId);const date=dayKey(shift(at(source.date),1));\n  openEditor({...source,id:undefined,date,taskId:sameTask?source.taskId:undefined,title:titleOf(source),kind:source.kind});\n  editing.eventId=undefined;\n  if(task&&!sameTask){$('title').value=task.title+'（副本）';editing.sourceId=task.id;}\n  if(!task)$('title').value=source.title+'（副本）';\n  $('editor-title').textContent=sameTask?'再安排一段':task?'复制待办':'复制日程';\n}\nfunction commitEditor(){\n  if(!editing)return;\n  const title=$('title').value.trim(),start=minutes($('time').value),length=Number($('duration').value),date=$('date').value;\n  if(!title||!date||!Number.isFinite(start)||start+length>1440){$('error').hidden=false;$('error').textContent='请填写名称与有效时间，安排须在当天结束。';return;}\n  const slot={date,start,length,tone:editing.kind==='event'?editing.tone:undefined};\n  if(editing.kind==='task'){\n    const task=findTask(editing.taskId);\n    const previous=task?slotsOf(task.id):[];\n    const slots=editing.id?previous.map(item=>item.id===editing.id?slot:item):[...previous,slot];\n    send('save-task',{taskId:editing.taskId,title,sourceId:editing.sourceId,slots:slots.map(toSlot)});\n  } else send('save-event',{id:editing.eventId,title,slot});\n}\n$('form').addEventListener('submit',event=>{event.preventDefault();commitEditor();});\n$('form').addEventListener('keydown',event=>{if(event.key==='Enter'&&event.target instanceof HTMLInputElement){event.preventDefault();commitEditor();}});\n$('save-editor').onclick=()=>commitEditor();\n$('agent-delegate').onclick=()=>send('delegate',{taskId:editing.taskId,agent:$('deck-choice').value});\n$('agent-source').onclick=()=>send('open-source',{taskId:editing.taskId});\n$('copy').onclick=()=>copy(false);$('copy-block').onclick=()=>copy(true);\n$('remove').onclick=()=>{const task=findTask(editing.taskId);if(task)changeTask(task,slotsOf(task.id).filter(item=>item.id!==editing.id));};\n$('delete').onclick=()=>{const task=findTask(editing.taskId);$('confirm-title').textContent=task?'删除这条待办及其所有时间块？':'删除这条日程？';$('confirm').returnValue='cancel';$('confirm').showModal();};\n$('confirm').addEventListener('close',()=>{\n  if($('confirm').returnValue!=='delete')return;\n  if(editing.taskId!=null)send('delete-task',{taskId:editing.taskId});\n  else send('delete-event',{id:editing.eventId});\n});\nwindow.addEventListener('message',event=>{\n  if(event.source!==parent)return;\n  const data=event.data;\n  if(data?.type==='taskhub-state'){\n    if(revision!==data.revision){\n      dragging=null;pointerDrag=null;clearExternalDrag();\n      document.querySelectorAll('.target').forEach(el=>el.classList.remove('target'));\n    }\n    if(revision!==data.revision&&$('editor').open){\n      $('confirm').close('cancel');$('editor').close();editing=null;\n      status('待办已更新，请重新选择要编辑的安排。');\n    }\n    revision=data.revision;\n    tasks=data.tasks;agents=data.agents??[];\n    blocks=[...data.events.map(item=>({...item,eventId:item.id,id:'event-'+item.id,kind:'event'})),\n      ...tasks.flatMap(task=>task.slots.map((slot,index)=>({...slot,id:'task-'+task.id+'-'+index,kind:'task',taskId:task.id})))];\n    if(loading)recover();\n    loaded=true;render();\n    if(!waiting&&!$('status').textContent.startsWith('已保存')&&!$('status').textContent.startsWith('待办已更新'))status('');\n    return;\n  }\n  if(data?.type==='taskhub-drag-state'){\n    if(data.active&&data.token){\n      externalDrag={token:data.token};\n      clearTimeout(externalTimer);externalTimer=setTimeout(clearExternalDrag,5000);\n      status('已识别待办，放到时段或日期格即可排期。');\n    }\n    return;\n  }\n  if(data?.type==='taskhub-pointer-drag'){\n    const clearTargets=()=>document.querySelectorAll('.target').forEach(el=>el.classList.remove('target'));\n    if(data.action==='begin'){pointerDrag=data.token?{token:data.token}:null;status('待办正在拖入：放到时段或日期格上，松手即可排期。');return;}\n    if(data.action==='cancel'){pointerDrag=null;clearTargets();return;}\n    const hit=hitSlot(data.x,data.y);\n    clearTargets();if(hit)hit.el.classList.add('target');\n    if(data.action==='drop'){\n      if(hit&&pointerDrag){send('schedule-dragged-task',{token:pointerDrag.token,slot:hit.slot});pointerDrag=null;}\n      else {pointerDrag=null;if(!hit)status('请放到具体的时段或日期格上，再松手。');}\n    }\n    return;\n  }\n  if(data?.type==='taskhub-refresh-error'){loaded=false;recover(data.text);return;}\n  if(!['taskhub-saved','taskhub-error','taskhub-opened','taskhub-delegate-preview'].includes(data?.type))return;\n  recover();\n  if(data.type==='taskhub-delegate-preview'){if($('editor').open)$('editor').close();status('请在 Agent Deck 确认窗口核对任务内容。');return;}\n  if(data.type==='taskhub-opened'){$('editor').close();status('已打开原待办');return;}\n  if(data.type==='taskhub-saved'){loaded=false;if($('editor').open)$('editor').close();status('已保存到 Obsidian');}\n  else {status(data.text);$('error').hidden=false;$('error').textContent=data.text;}\n});\n$('info-close').onclick=()=>$('info').close();\n$('confirm-cancel').onclick=()=>$('confirm').close('cancel');\n$('confirm-delete').onclick=()=>$('confirm').close('delete');\n$('close-editor').onclick=()=>$('editor').close();\nfunction hitSlot(x,y){\n  const el=document.elementFromPoint(x,y);if(!el)return null;\n  const track=el.closest('.day-track');\n  if(track&&track.dataset.date){\n    const top=track.getBoundingClientRect().top;\n    const minute=Math.max(0,Math.min(1439,(y-top)/58*60));\n    const start=Math.max(gridRange.low,Math.min(gridRange.high-15,gridRange.low+Math.floor(minute/15)*15));\n    return {el:track,slot:{date:track.dataset.date,start,length:Math.min(30,1440-start)}};\n  }\n  const cell=el.closest('.month-cell');\n  if(cell&&cell.dataset.date)return {el:cell,slot:{date:cell.dataset.date,start:540,length:30}};\n  return null;\n}\n\n$('tasks-only').onclick=()=>{tasksOnly=!tasksOnly;render();status(tasksOnly?'当前只显示已排期的待办。':'当前显示待办和日程。');};\n\nfor(const view of ['week','day','month'])$(view).onclick=()=>{mode=view;render();};\nfunction page(delta){navigate(mode==='month'?new Date(current.getFullYear(),current.getMonth()+delta,1,12):shift(current,mode==='week'?7*delta:delta));}\n$('previous').onclick=()=>page(-1);$('next').onclick=()=>page(1);$('today').onclick=()=>navigate(new Date());\nfunction moveMini(delta){miniMonth=new Date(miniMonth.getFullYear(),miniMonth.getMonth()+delta,1,12);renderMini(dates().map(dayKey));}\n$('mini-prev').onclick=()=>moveMini(-1);$('mini-next').onclick=()=>moveMini(1);\n$('pool-search').oninput=renderPool;\n\nrender();\nfunction showLeft(show){$('left-panel').hidden=!show;$('left-toggle').setAttribute('aria-expanded',String(show));}\n$('left-toggle').onclick=()=>showLeft($('left-panel').hidden);\n$('close-left').onclick=()=>showLeft(false);\nif(matchMedia('(max-width: 800px)').matches)showLeft(false);\n$('reload').onclick=()=>send('load');\n$('side-upgrade').onclick=()=>parent.postMessage({type:'taskhub-calendar',action:'show-updates'},'*');\nfor(const [id,title,message] of [\n  ['side-settings','设置','任务目录、提醒和备份可在 Obsidian 设置 → TaskHub 中调整。'],\n  ['side-help','帮助','按住任务行末尾的 ⠿ 拖到日历时段或日期格上，松手即可排期；也可以从右侧待办栏拖入，或点待办选择时间。改排期会保留原截止日期。']\n]) $(id).onclick=()=>{$('info-title').textContent=title;$('info-text').textContent=message;$('info').showModal();};\nfunction clearExternalDrag(){externalDrag=null;clearTimeout(externalTimer);externalTimer=0;}\ndocument.addEventListener('dragenter',()=>{if(!dragging&&!externalDrag){status('检测到拖动，正在确认…');parent.postMessage({type:'taskhub-calendar',action:'drag-probe'},'*');}});\ndocument.addEventListener('dragleave',event=>{if(!event.relatedTarget)clearExternalDrag();});\ndocument.addEventListener('drop',()=>setTimeout(clearExternalDrag,0));\ndocument.addEventListener('dragend',()=>clearExternalDrag());\nsend('load');\n</script>\n</body>\n</html>\n";
const core = (() => {
const priorities = [
    "",
    "🔺",
    "⏫",
    "🔼",
    "🔽",
    "⏬"
];
const scopes = [
    "今天",
    "逾期",
    "全部",
    "未排期"
];
const knownScopes = [
    ...scopes,
    "收集箱",
    "项目",
    "已完成"
];
const checkbox = /^(\s*(?:[-+*]|\d+[.)])\s+(?:(?:DELEGATED|DOING|TOREVIEW|NEEDOK|DONE|WAITING|FAILED|STOPPED)\s+)?\[)([^\]\r\n])(\]\s+)(.+)$/u;
const tag = /(^|\s)#(分类|category|cat|项目|project)\/([\p{L}\p{M}\p{N}_/-]+)/giu;
const flatCategory = /(^|\s)#(招聘|工作|人事|行政|财务|学习|个人|生活|收集箱|收件箱|未分类|inbox)(?=\s|$)/giu;
const symbols = "(?:🔺|⏫|🔼|🔽|⏬)";
const dateField = /(?:^|\s)([📅📆🗓]️?\s*(\d{4}-\d{2}-\d{2})|\[due::\s*(\d{4}-\d{2}-\d{2})\s*\])/gu;
const markers = new RegExp("(^|\\s)(" + symbols + "|[📅📆🗓🛫⏳➕✅❌]️?\\s*\\d{4}-\\d{2}-\\d{2}|🔁|🆔|⛔|🏁|\\[(?:taskhub-time|taskhub-repeat|taskhub-block|taskhub-calendar-tone|taskhub-calendar-extra|taskhub-board|due|priority|scheduled|start|created|completion|done|cancelled|repeat|recurrence|id|dependsOn)::|<!-- taskhub-id:|\\^[\\w-]+\\s*$)", "u");
const inlinePriorities = {
    highest: "🔺",
    high: "⏫",
    medium: "🔼",
    low: "🔽",
    lowest: "⏬"
};
const idPattern = /<!-- taskhub-id:([a-z0-9-]{8,80}) -->/g;
const blockId = /(?:^|\s)\^taskhub-([a-z0-9-]{8,80})\s*$/;
function localDay(d = new Date()) {
    return [
        d.getFullYear(),
        d.getMonth() + 1,
        d.getDate()
    ].map((v)=>String(v).padStart(2, "0")).join("-");
}
function validDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const d = new Date(value + "T00:00:00Z");
    return Number.isFinite(d.getTime()) && d.toISOString().slice(0, 10) === value;
}
function emailSubject(text) {
    const headers = text.replace(/^\uFEFF/, "").split(/\r?\n\r?\n/, 1)[0].replace(/\r?\n[ \t]+/g, " ");
    const subject = headers.match(/^subject:[ \t]*(.*)$/im)?.[1];
    if (!subject) throw new Error("邮件缺少 Subject 标题。请选择导出的 .eml 邮件文件。");
    const decoded = subject.replace(/(\?=)\s+(?==\?)/g, "$1").replace(/=\?([^?]+)\?([bq])\?([^?]*)\?=/gi, (word, charset, encoding, data)=>{
        try {
            const bytes = encoding.toLowerCase() === "b" ? atob(data) : data.replace(/_/g, " ").replace(/=([0-9a-f]{2})/gi, (_match, hex)=>String.fromCharCode(parseInt(hex, 16)));
            return new TextDecoder(charset, {
                fatal: true
            }).decode(Uint8Array.from(bytes, (c)=>c.charCodeAt(0)));
        } catch  {
            return word;
        }
    });
    const result = decoded.replace(/[\r\n\0]/g, " ").trim().slice(0, 500);
    if (!result) throw new Error("邮件主题为空");
    return result;
}
const repeatRules = [
    "daily",
    "mwf",
    "month-end"
];
function validRepeatRule(rule) {
    if (repeatRules.some((value)=>value === rule)) return true;
    if (/^monthly:(?:[1-9]|[12]\d|3[01])$/.test(rule)) return true;
    if (!/^weekly:[0-6](?:,[0-6]){0,6}$/.test(rule)) return false;
    const days = rule.slice(7).split(",");
    return new Set(days).size === days.length;
}
function nextRepeatDate(rule, after) {
    if (!validDate(after)) throw new Error("重复任务需要有效的截止日期");
    if (!validRepeatRule(rule)) throw new Error("未知重复规则");
    const date = new Date(after + "T12:00:00");
    if (rule === "daily") date.setDate(date.getDate() + 1);
    else if (rule === "mwf" || rule.startsWith("weekly:")) {
        const weekdays = rule === "mwf" ? [
            1,
            3,
            5
        ] : rule.slice(7).split(",").map(Number);
        do {
            date.setDate(date.getDate() + 1);
        }while (!weekdays.includes(date.getDay()))
    } else if (rule.startsWith("monthly:")) {
        const day = Number(rule.slice(8));
        for(let offset = 0; offset <= 12; offset++){
            const candidate = new Date(date.getFullYear(), date.getMonth() + offset, day, 12);
            if (candidate.getDate() === day && candidate > date) return localDay(candidate);
        }
        throw new Error("未找到下一次月度日期");
    } else if (rule === "month-end") {
        const end = (offset)=>{
            const result = new Date(date.getFullYear(), date.getMonth() + offset + 1, 0, 12);
            while([
                0,
                6
            ].includes(result.getDay()))result.setDate(result.getDate() - 1);
            return result;
        };
        return localDay(end(0)) > after ? localDay(end(0)) : localDay(end(1));
    }
    return localDay(date);
}
function taskField(task, key) {
    return task.metadata.match(new RegExp("\\[taskhub-" + key + "::\\s*([^\\]\\r\\n]+)\\]"))?.[1].trim() ?? "";
}
function validSlot(slot) {
    return !!slot && validDate(slot.date) && Number.isInteger(slot.start) && slot.start >= 0 && Number.isInteger(slot.length) && slot.length >= 15 && slot.length <= 720 && slot.start + slot.length <= 1440 && (!slot.tone || [
        "jade",
        "blue",
        "amber",
        "lilac",
        "rose",
        "teal"
    ].includes(slot.tone));
}
function taskSlots(task) {
    const [date, time, length] = taskField(task, "block").split(" ");
    const [hour, minute] = (time ?? "").split(":").map(Number);
    const first = {
        date,
        start: hour * 60 + minute,
        length: Number(length),
        tone: taskField(task, "calendar-tone")
    };
    const extra = taskField(task, "calendar-extra");
    const items = extra ? JSON.parse(decodeURIComponent(extra)) : [];
    if (!Array.isArray(items) || items.some((item)=>!validSlot(item))) throw new Error("有待办的日历排期格式无效，请检查原笔记。");
    return [
        ...validSlot(first) ? [
            first
        ] : [],
        ...items
    ];
}
function withTaskSlots(task, slots) {
    if (slots.length > 50 || slots.some((slot)=>!validSlot(slot))) throw new Error("请填写有效的排期，每个待办最多 50 段。");
    const [first, ...extra] = slots;
    const hour = first ? String(Math.floor(first.start / 60)).padStart(2, "0") : "";
    const minute = first ? String(first.start % 60).padStart(2, "0") : "";
    const block = setTaskField(task, "block", first ? `${first.date} ${hour}:${minute} ${first.length}` : "");
    const colored = setTaskField({
        ...task,
        raw: block
    }, "calendar-tone", first?.tone ?? "");
    return setTaskField({
        ...task,
        raw: colored
    }, "calendar-extra", extra.length ? encodeURIComponent(JSON.stringify(extra)) : "");
}
function setTaskField(task, key, value) {
    const raw = task.raw.replace(new RegExp("[ \\t]*\\[taskhub-" + key + "::[^\\]\\r\\n]*\\]", "g"), "");
    if (!value) return raw;
    const tail = raw.match(/\s+\^[\w-]+\s*$/)?.index ?? raw.length;
    return raw.slice(0, tail) + " [taskhub-" + key + ":: " + value + "]" + raw.slice(tail);
}
function parseQuickTitle(value, now = new Date()) {
    const match = value.trim().match(/^(今天|明天|后天|(?:本|下)?周[一二三四五六日天]|\d{4}-\d{2}-\d{2})\s*(.*)$/u);
    if (!match) return null;
    const [, dateWord, rest] = match;
    const date = new Date(now);
    if (/^\d/.test(dateWord) && !validDate(dateWord)) return null;
    if (dateWord.endsWith("天") && [
        "今天",
        "明天",
        "后天"
    ].includes(dateWord)) {
        date.setDate(date.getDate() + [
            "今天",
            "明天",
            "后天"
        ].indexOf(dateWord));
    } else if (dateWord.includes("周")) {
        const weekday = "一二三四五六日".indexOf(dateWord.at(-1).replace("天", "日"));
        const offset = weekday - (date.getDay() + 6) % 7;
        const weeks = dateWord.startsWith("下") || !dateWord.startsWith("本") && offset < 0 ? 7 : 0;
        date.setDate(date.getDate() + offset + weeks);
    }
    const due = /^\d/.test(dateWord) ? dateWord : localDay(date);
    let title = rest.trim(), time = "";
    const clock = title.match(/^(上午|下午|晚上|中午|早上)?\s*(\d{1,2})(?::(\d{2})|[点时](半|\d{1,2}分)?)(?!\d)\s*/u);
    if (clock) {
        let hour = Number(clock[2]);
        const minute = clock[4] === "半" ? 30 : Number(clock[3] ?? clock[4]?.slice(0, -1) ?? 0);
        if (minute > 59 || hour > 23 || clock[1] && (hour < 1 || hour > 12)) return null;
        if ([
            "下午",
            "晚上",
            "中午"
        ].includes(clock[1]) && hour < 12) hour += 12;
        if ([
            "上午",
            "早上"
        ].includes(clock[1]) && hour === 12) hour = 0;
        time = String(hour).padStart(2, "0") + ":" + String(minute).padStart(2, "0");
        title = title.slice(clock[0].length).trim();
    }
    return title ? {
        title,
        due,
        time
    } : null;
}
function tagsIn(text) {
    return Array.from(text.matchAll(tag));
}
function clean(text) {
    return text.replace(/\s{2,}/g, " ").trim();
}
function parseLine(raw, path, line) {
    const match = raw.match(checkbox);
    if (!match) return null;
    const [, prefix, status, , body] = match;
    const cut = body.search(markers);
    const leading = cut < 0 ? body : body.slice(0, cut);
    const metadata = cut < 0 ? "" : body.slice(cut).trim();
    const tags = tagsIn(body);
    const namespacedCategory = tags.find((t)=>/^(分类|category|cat)$/i.test(t[2]))?.[3];
    const flat = namespacedCategory ? undefined : Array.from(body.matchAll(flatCategory))[0]?.[2];
    const category = namespacedCategory ?? flat ?? "";
    const project = tags.find((t)=>/^(项目|project)$/i.test(t[2]))?.[3] ?? "";
    const date = Array.from(body.matchAll(dateField))[0];
    const dateValue = date?.[2] ?? date?.[3] ?? "";
    const priority = metadata.match(new RegExp("(?:^|\\s)(" + symbols + ")(?=\\s|$)", "u"))?.[1] ?? inlinePriorities[metadata.match(/\[priority::\s*(\w+)\s*\]/i)?.[1]?.toLowerCase() ?? ""] ?? "";
    const title = leading.replace(tag, "$1").replace(flatCategory, (full, space, name)=>name === category ? space : full).trim();
    if (!title) return null;
    return {
        path,
        line,
        raw,
        prefix,
        status,
        body,
        title,
        metadata,
        category,
        project,
        due: validDate(dateValue) ? dateValue : "",
        priority,
        time: body.match(/\[taskhub-time::\s*((?:[01]\d|2[0-3]):[0-5]\d)\s*\]/)?.[1] ?? "",
        ids: [
            ...Array.from(body.matchAll(idPattern), (m)=>m[1]),
            body.match(blockId)?.[1]
        ].filter((v)=>!!v),
        recurring: /🔁|\[(?:repeat|recurrence)::/iu.test(metadata)
    };
}
function parseNote(text, path) {
    const tasks = [];
    let fence = "";
    let comment = false;
    let frontmatter = false;
    text.split(/\r?\n/).forEach((line, i)=>{
        if (i === 0 && /^\uFEFF?---\s*$/.test(line)) {
            frontmatter = true;
            return;
        }
        if (frontmatter) {
            if (/^(---|\.\.\.)\s*$/.test(line)) frontmatter = false;
            return;
        }
        if (comment) {
            if (line.includes("-->")) comment = false;
            return;
        }
        const delimiter = line.match(/^\s{0,3}(\x60{3,}|~{3,})(.*)$/);
        if (fence) {
            if (delimiter && delimiter[1][0] === fence[0] && delimiter[1].length >= fence.length && !delimiter[2].trim()) fence = "";
            return;
        }
        if (delimiter) {
            fence = delimiter[1];
            return;
        }
        if (/^\s*<!--/.test(line)) {
            comment = !line.includes("-->");
            return;
        }
        const task = parseLine(line, path, i);
        if (task) tasks.push(task);
    });
    return tasks;
}
function draftOf(task) {
    return {
        title: task?.title ?? "",
        category: task?.category ?? "",
        project: task?.project ?? "",
        priority: task?.priority ?? "",
        due: task?.due ?? "",
        time: task?.time ?? ""
    };
}
function validateDraft(draft) {
    const value = {
        ...draft,
        time: draft.time ?? "",
        title: draft.title.trim(),
        category: draft.category.trim().replace(/ +/g, "_"),
        project: draft.project.trim().replace(/ +/g, "_")
    };
    if (!value.title || /[\r\n\0]/.test(value.title) || value.title.length > 1000) throw new Error("请输入 1–1000 字的单行任务内容。");
    for (const field of [
        value.category,
        value.project
    ]){
        if (field && (field.length > 100 || !/^[\p{L}\p{M}\p{N}_-]+(?:\/[\p{L}\p{M}\p{N}_-]+)*$/u.test(field) || !/[\p{L}_-]/u.test(field))) throw new Error("分类和项目需使用有效的标签名称。");
    }
    if (!priorities.some((p)=>p === value.priority)) throw new Error("优先级无效。");
    if (value.due && !validDate(value.due)) throw new Error("截止日期无效。");
    if (value.time && (!value.due || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value.time))) throw new Error("请先选择截止日期，再设置有效时间（00:00–23:59）。");
    return value;
}
function safePath(value) {
    const parts = value.trim().replace(/\\/g, "/").replace(/\/+$/, "").split("/");
    if (parts.some((p)=>!p || p === "." || p === ".." || /[:*?"<>|\x00-\x1F]/.test(p) || p.startsWith(".") || /[. ]$/.test(p) || /^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(p))) throw new Error("请输入库内相对路径。");
    return parts.join("/");
}
function tagValue(field, value, source) {
    const pattern = field === "category" ? /^(分类|category|cat)$/i : /^(项目|project)$/i;
    const namespace = source && tagsIn(source.body).find((m)=>pattern.test(m[2]))?.[2];
    return value ? "#" + (namespace || (field === "category" ? "分类" : "项目")) + "/" + value : "";
}
function renderLine(draft, globalTag, old, id) {
    const d = validateDraft(draft);
    if (old && Object.keys(d).every((k)=>d[k] === old[k])) return old.raw;
    if (old) {
        const tags = tagsIn(old.body);
        if (tags.filter((t)=>/^(分类|category|cat)$/i.test(t[2])).length > 1 || tags.filter((t)=>/^(项目|project)$/i.test(t[2])).length > 1) throw new Error("此任务含多个分类或项目标签，请在原笔记编辑以保留全部标签。");
    }
    let title = d.title;
    if (!old && globalTag && !title.split(/\s+/).includes(globalTag)) title += " " + globalTag;
    let metadata = old?.metadata ?? "";
    metadata = metadata.replace(tag, "$1");
    const oldFlat = old?.category;
    if (oldFlat) metadata = metadata.replace(flatCategory, (full, space, name)=>name === oldFlat ? space : full);
    const legacy = d.category && Array.from((" #" + d.category).matchAll(flatCategory)).length && !title.split(/\s+/).includes("#" + d.category) ? "#" + d.category : "";
    if (d.due !== old?.due) metadata = metadata.replace(dateField, " ");
    if (d.priority !== old?.priority) metadata = metadata.replace(new RegExp("(^|\\s)(" + symbols + "(?=\\s|$)|\\[priority::\\s*\\w+\\s*\\])", "gu"), "$1");
    if (d.time !== (old?.time ?? "")) metadata = metadata.replace(/\[taskhub-time::[^\]]*\]/g, "");
    const block = metadata.match(/(?:^|\s)(\^[\w-]+)\s*$/)?.[1] ?? "";
    if (block) metadata = metadata.trimEnd().slice(0, -block.length);
    return [
        old ? old.prefix + old.status + "]" : "- [ ]",
        title,
        tagValue("category", d.category, old),
        legacy,
        tagValue("project", d.project, old),
        d.priority !== old?.priority ? d.priority : "",
        d.due && d.due !== old?.due ? "📅 " + d.due : "",
        d.time && d.time !== (old?.time ?? "") ? "[taskhub-time:: " + d.time + "]" : "",
        metadata.trim(),
        id ? "^taskhub-" + id : block
    ].filter(Boolean).join(" ");
}
function appendLine(text, line) {
    const eol = text.includes("\r\n") ? "\r\n" : "\n";
    return text + (text.endsWith(eol + eol) || !text ? "" : text.endsWith(eol) ? eol : eol + eol) + line + eol;
}
function replaceLine(text, target, replacement) {
    const rows = text.split(/(\r?\n)/);
    const matches = parseNote(text, target.path).filter((t)=>t.raw === target.raw);
    if (matches.length !== 1) throw new Error("任务原文已变更或有相同记录，请刷新后在原笔记检查。");
    rows[matches[0].line * 2] = replacement;
    return rows.join("");
}
function deleteTaskLine(text, target) {
    const matches = parseNote(text, target.path).filter((task)=>task.raw === target.raw);
    if (matches.length !== 1) throw new Error("任务原文已变更或有相同记录，请刷新后重试。");
    const rows = text.split(/(\r?\n)/);
    const index = matches[0].line * 2;
    const indentation = (line)=>(line.match(/^[ \t]*/)?.[0] ?? "").replace(/\t/g, "    ").length;
    for(let next = index + 2; next < rows.length; next += 2){
        if (!rows[next].trim()) continue;
        if (indentation(rows[next]) > indentation(rows[index])) throw new Error("该任务下有子任务或缩进正文，请先在原笔记处理后再删除。");
        break;
    }
    rows.splice(index, 2);
    return rows.join("");
}
function finished(task) {
    return /[xX]/.test(task.status) || /(?:^|\s)(?:❌\s*\d{4}-\d{2}-\d{2}|\[cancelled::\s*\d{4}-\d{2}-\d{2}\s*\])/u.test(task.metadata);
}
function completionStamp(task) {
    const day = task.metadata.match(/✅\s*(\d{4}-\d{2}-\d{2})|\[(?:completion|done)::\s*(\d{4}-\d{2}-\d{2})\s*\]/u);
    const date = day?.[1] ?? day?.[2];
    if (!date) return "";
    const time = taskField(task, "completed-time");
    return /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time) ? date + " " + time : date;
}
function completionLine(task, today, time = "") {
    if (task.recurring || ![
        " ",
        "x",
        "X"
    ].includes(task.status) || /❌|\[cancelled::/u.test(task.metadata)) throw new Error("请在原笔记通过 Tasks 修改循环任务或自定义状态。");
    const body = task.body.replace(/(?:^|\s)(?:✅\s*\d{4}-\d{2}-\d{2}|\[(?:completion|done)::\s*\d{4}-\d{2}-\d{2}\s*\]|\[taskhub-completed-time::[^\]\r\n]*\])/gu, "");
    const suffix = task.raw.slice(task.prefix.length + 2, task.raw.length - task.body.length);
    if (finished(task)) return task.prefix + " ]" + suffix + body;
    const tail = body.match(/\s+(?=<!-- taskhub-id:|\^[\w-]+\s*$)/)?.index ?? body.length;
    const stamp = time ? " [taskhub-completed-time:: " + time + "]" : "";
    return task.prefix + "x]" + suffix + body.slice(0, tail) + " ✅ " + today + stamp + body.slice(tail);
}
function key(text) {
    return clean(text.normalize("NFKC")).toLowerCase();
}
function isDuplicate(tasks, draft, globalTag, exclude) {
    const titleKey = (title)=>key(title.split(/\s+/).filter((t)=>!globalTag || t !== globalTag).join(" "));
    return tasks.some((t)=>!finished(t) && !(exclude && t.path === exclude.path && t.line === exclude.line) && titleKey(t.title) === titleKey(draft.title) && key(t.category) === key(draft.category) && key(t.project) === key(draft.project) && t.due === draft.due && (t.time ?? "") === (draft.time ?? ""));
}
function filterTasks(tasks, query, today, nowTime = "") {
    return tasks.filter((t)=>{
        const scope = query.scope ?? "全部";
        const status = query.status ?? (scope === "已完成" ? "done" : "");
        if (status === "done") {
            if (!finished(t)) return false;
        } else if (status !== "all" && finished(t)) return false;
        if (scope === "今天" && t.due !== today) return false;
        if (scope === "逾期" && (!t.due || t.due > today || t.due === today && (!t.time || t.time >= nowTime))) return false;
        if (scope === "未排期" && taskSlots(t).length) return false;
        if (scope === "收集箱" && (t.project || t.category && !/^(inbox|收集箱|收件箱|未分类)$/i.test(t.category))) return false;
        if (scope === "项目" && !t.project) return false;
        return (!query.category || key(t.category) === key(query.category)) && (!query.project || key(t.project) === key(query.project)) && (!query.priority || (query.priority === "none" ? !t.priority : t.priority === query.priority)) && (!query.search || key(t.body).includes(key(query.search)) || completionStamp(t).includes(key(query.search).trim()));
    }).sort((a, b)=>(query.status === "done" || query.scope === "已完成" ? completionStamp(b).localeCompare(completionStamp(a)) : 0) || (a.due || "9999").localeCompare(b.due || "9999") || (a.time || "23:59").localeCompare(b.time || "23:59") || [
            "🔺",
            "⏫",
            "🔼",
            "",
            "🔽",
            "⏬"
        ].indexOf(a.priority) - [
            "🔺",
            "⏫",
            "🔼",
            "",
            "🔽",
            "⏬"
        ].indexOf(b.priority));
}
function parseQuery(source) {
    const q = {};
    for (const row of source.split(/\r?\n/)){
        if (!row.trim()) continue;
        const m = row.match(/^\s*(scope|category|project|priority|search)\s*:\s*(.*?)\s*$/);
        if (!m) throw new Error("不支持的查询条件：" + row);
        if (m[1] === "scope" && !knownScopes.includes(m[2])) throw new Error("未知任务视图：" + m[2]);
        if (m[1] === "priority" && m[2] !== "none" && !priorities.some((p)=>p === m[2])) throw new Error("未知优先级：" + m[2]);
        Object.assign(q, {
            [m[1]]: m[2]
        });
    }
    return q;
}
function parseCapture(text) {
    if (text.length > 16000) throw new Error("录入数据太长。");
    const raw = JSON.parse(text.replace(/^\uFEFF/, ""));
    if (!raw || raw.version !== 1 || typeof raw.id !== "string" || !/^[a-z0-9-]{8,80}$/.test(raw.id) || typeof raw.source !== "string" || !raw.task || typeof raw.task.title !== "string") throw new Error("录入数据格式无效。");
    const fields = {
        title: raw.task.title,
        category: raw.task.category ?? "",
        project: raw.task.project ?? "",
        due: raw.task.due ?? "",
        priority: raw.task.priority ?? "",
        time: raw.task.time ?? ""
    };
    if (Object.values(fields).some((v)=>typeof v !== "string")) throw new Error("录入字段必须为文本。");
    return {
        version: 1,
        id: raw.id,
        source: raw.source,
        task: validateDraft(fields)
    };
}

return {priorities,scopes,localDay,validDate,emailSubject,repeatRules,validRepeatRule,nextRepeatDate,taskField,validSlot,taskSlots,withTaskSlots,setTaskField,parseQuickTitle,parseLine,parseNote,draftOf,validateDraft,safePath,renderLine,appendLine,replaceLine,deleteTaskLine,finished,completionStamp,completionLine,isDuplicate,filterTasks,parseQuery,parseCapture};
})();
const { ItemView, MarkdownRenderChild, Modal, Notice, Plugin, PluginSettingTab, Setting, TFile, TFolder, WorkspaceLeaf } = require("obsidian");
const { appendLine, completionLine, completionStamp, draftOf, filterTasks, finished, isDuplicate, localDay, parseCapture, parseQuickTitle, parseNote, parseQuery, priorities, renderLine, replaceLine, safePath, scopes, validateDraft, nextRepeatDate, validRepeatRule, taskField, setTaskField, validDate, emailSubject, deleteTaskLine, validSlot, taskSlots, withTaskSlots } = core;
const VIEW = "taskhub-workbench";
const CALENDAR_VIEW = "taskhub-calendar";
const TASK_DRAG = "application/x-taskhub-task";
const DECK_AGENTS = [
    {
        id: "codex",
        name: "Codex"
    },
    {
        id: "claude",
        name: "Claude Code"
    },
    {
        id: "workbuddy",
        name: "WorkBuddy"
    },
    {
        id: "dsh",
        name: "DeepSeek Harness"
    },
    {
        id: "antigravity",
        name: "Antigravity"
    }
];
const defaults = {
    folder: "00-任务中枢/待办库",
    tag: "#task",
    queue: "00-任务中枢/TaskHub-录入队列",
    backups: "00-任务中枢/TaskHub-备份",
    autoImport: false,
    linkedFolders: "01-Daily\n06-工作",
    reminders: false,
    promoteTomorrow: false
};
const priorityLabels = [
    "普通",
    "最高",
    "高",
    "中",
    "低",
    "最低"
];
function report(error) {
    new Notice("TaskHub · " + (error instanceof Error ? error.message : String(error)), 7000);
}
function addOptions(select, values, value) {
    for (const [id, label] of values)select.createEl("option", {
        value: id,
        text: label
    });
    select.value = value;
}
function priorityOptions(normal) {
    return priorities.map((p, i)=>[
            p,
            i === 0 ? normal : p + " " + priorityLabels[i]
        ]);
}
function clockTime(d = new Date()) {
    return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}
function under(path, folder) {
    return path.startsWith(folder + "/");
}
class TaskHub extends Plugin {
    settings = {
        ...defaults
    };
    changes = new Set();
    pending = Promise.resolve();
    timer;
    day = localDay();
    reminderKeys = new Set();
    checkingReminders = false;
    alive = true;
    hotkeyStatus = "全局快捷键尚未启动";
    async onload() {
        const saved = await this.loadData();
        if (saved) {
            for (const key of [
                "folder",
                "queue",
                "backups",
                "tag",
                "linkedFolders"
            ])if (typeof saved[key] === "string") this.settings[key] = saved[key];
            this.settings.autoImport = saved.autoImport === true;
            this.settings.reminders = saved.reminders === true;
            this.settings.promoteTomorrow = saved.promoteTomorrow === true;
        }
        this.registerView(VIEW, (leaf)=>new Workbench(leaf, this));
        this.registerView(CALENDAR_VIEW, (leaf)=>new TaskCalendar(leaf, this));
        this.addRibbonIcon("list-todo", "打开 TaskHub", ()=>void this.openView().catch(report));
        this.addCommand({
            id: "capture",
            name: "快捷录入任务",
            callback: ()=>new TaskEditor(this).open()
        });
        this.registerDoubleControl();
        this.startWindowsHotkey();
        this.addCommand({
            id: "global-hotkey-status",
            name: "查看全局快捷键状态",
            callback: ()=>new Notice(this.hotkeyStatus, 10000)
        });
        this.addCommand({
            id: "calendar",
            name: "打开任务日历",
            callback: ()=>void this.openCalendar().catch(report)
        });
        this.registerObsidianProtocolHandler("taskhub-capture", ()=>{
            if (!document.querySelector(".modal-container")) new TaskEditor(this).open();
        });
        this.registerObsidianProtocolHandler("taskhub-web", (params)=>{
            if (document.querySelector(".modal-container")) return;
            try {
                const url = new URL(params.url ?? "");
                if (![
                    "https:",
                    "http:"
                ].includes(url.protocol) || url.username || url.password || url.href.length > 700) return;
                const title = (params.title ?? "").replace(/[\r\n\0]/g, " ").trim().slice(0, 220);
                new TaskEditor(this, undefined, {
                    title: (title || "阅读网页") + " " + url.href
                }).open();
            } catch  {
                new Notice("网页地址无效");
            }
        });
        this.addCommand({
            id: "workbench",
            name: "打开任务工作台",
            callback: ()=>void this.openView().catch(report)
        });
        this.addCommand({
            id: "weekly-review",
            name: "开始每周回顾",
            callback: ()=>new WeeklyReview(this).open()
        });
        this.addCommand({
            id: "import-email",
            name: "从邮件文件录入任务",
            callback: ()=>new EmailCapture(this).open()
        });
        this.addCommand({
            id: "toggle-reminders",
            name: "切换到期提醒",
            callback: ()=>void this.updateSettings({
                    ...this.settings,
                    reminders: !this.settings.reminders
                }).then(()=>new Notice(this.settings.reminders ? "到期提醒已开启" : "到期提醒已关闭")).catch(report)
        });
        this.addCommand({
            id: "backup",
            name: "创建任务库备份",
            callback: ()=>void this.backup().then((p)=>new Notice("备份已保存 · " + p)).catch(report)
        });
        this.addCommand({
            id: "migrate",
            name: "接管旧版任务库",
            callback: ()=>new Migration(this).open()
        });
        this.addCommand({
            id: "import-captures",
            name: "导入外部录入队列",
            callback: ()=>void this.importQueue(true).catch(report)
        });
        this.addCommand({
            id: "insert-query",
            name: "插入动态任务查询",
            editorCallback: (editor)=>{
                const selected = editor.getSelection().trim();
                new QueryEditor(this, selected, (block)=>editor.replaceRange(block, editor.getCursor("to"))).open();
            }
        });
        this.registerMarkdownCodeBlockProcessor("taskhub", (source, el, ctx)=>ctx.addChild(new InlineTasks(el, this, source)));
        this.addSettingTab(new HubSettings(this));
        for (const event of [
            "create",
            "modify",
            "delete"
        ]){
            this.registerEvent(this.app.vault.on(event, (file)=>{
                if (this.includesTaskPath(file.path)) this.changed();
            }));
        }
        this.registerEvent(this.app.vault.on("rename", (file, old)=>{
            if ([
                file.path,
                old
            ].some((path)=>this.includesTaskPath(path) || this.taskFolders().includes(path))) this.changed();
        }));
        this.registerInterval(window.setInterval(()=>{
            const now = localDay();
            if (this.day !== now) this.reminderKeys.clear();
            this.day = now;
            this.changed();
            if (this.settings.autoImport) this.autoImport();
            if (this.settings.reminders) void this.checkReminders().catch(report);
        }, 15000));
        this.app.workspace.onLayoutReady(()=>{
            if (this.alive && this.settings.autoImport) this.autoImport();
        });
    }
    async checkReminders(now = new Date()) {
        if (!this.settings.reminders || this.checkingReminders) return;
        this.checkingReminders = true;
        try {
            const today = localDay(now);
            const tasks = await this.tasks();
            if (!this.alive || !this.settings.reminders) return;
            for (const task of tasks){
                if (finished(task) || !task.time || task.due !== today) continue;
                const elapsed = now.getTime() - new Date(task.due + "T" + task.time + ":00").getTime();
                const key = JSON.stringify([
                    task.path,
                    task.title,
                    task.due,
                    task.time
                ]);
                if (!(elapsed >= 0 && elapsed < 300000) || this.reminderKeys.has(key)) continue;
                this.reminderKeys.add(key);
                new Notice("任务到期 · " + task.time + " · " + task.title, 12000);
            }
        } finally{
            this.checkingReminders = false;
        }
    }
    onunload() {
        this.alive = false;
        window.clearTimeout(this.timer);
        this.changes.clear();
        this.app.workspace.detachLeavesOfType(VIEW);
        this.app.workspace.detachLeavesOfType(CALENDAR_VIEW);
    }
    registerDoubleControl() {
        let pressedAt;
        let lastTap;
        const reset = ()=>{
            pressedAt = undefined;
            lastTap = undefined;
        };
        this.registerDomEvent(window, "blur", reset);
        this.registerDomEvent(window, "pointerdown", reset, true);
        this.registerDomEvent(window, "keydown", (event)=>{
            if (event.key !== "Control" || event.altKey || event.shiftKey || event.metaKey) {
                reset();
                return;
            }
            if (!event.repeat) {
                if (pressedAt !== undefined) reset();
                else pressedAt = Date.now();
            }
        }, true);
        this.registerDomEvent(window, "keyup", (event)=>{
            if (event.key !== "Control") return;
            const now = Date.now();
            if (pressedAt === undefined || now - pressedAt > 300 || event.ctrlKey) {
                reset();
                return;
            }
            pressedAt = undefined;
            if (lastTap !== undefined && now - lastTap <= 400) {
                reset();
                if (!document.querySelector(".modal-container")) new TaskEditor(this).open();
            } else lastTap = now;
        }, true);
    }
    startWindowsHotkey() {
        try {
            if (typeof require !== "function") return;
            const runtime = require("process");
            if (runtime.platform !== "win32") return;
            const adapter = this.app.vault.adapter;
            const base = adapter.getBasePath?.();
            if (!base || !this.manifest.dir) throw new Error("无法定位全局快捷键组件。");
            const path = require("path");
            const args = [
                "--parent",
                String(runtime.pid)
            ];
            const vault = this.app.vault.getName?.();
            if (vault) args.push("--vault", vault);
            const child = require("child_process").spawn(path.join(base, this.manifest.dir, "TaskHub-Wake.exe"), args, {
                windowsHide: true,
                stdio: [
                    "ignore",
                    "pipe",
                    "pipe"
                ]
            });
            this.hotkeyStatus = "正在启动 Windows 全局快捷键";
            child.stdout.on("data", (data)=>{
                this.hotkeyStatus = data.toString().trim();
                if (this.hotkeyStatus.includes("READY")) new Notice("TaskHub 全局双击 Ctrl 已启动");
            });
            child.stderr.on("data", (data)=>{
                this.hotkeyStatus = data.toString().trim();
            });
            child.on("error", (error)=>{
                this.hotkeyStatus = "全局快捷键启动失败：" + error.message;
                report(new Error(this.hotkeyStatus));
            });
            child.on("exit", (code)=>{
                if (!this.alive) return;
                this.hotkeyStatus = code === 2 ? "旧版 TaskHub 助手仍在运行，请退出托盘中的助手，再重新启用插件。" : "全局快捷键进程已退出，退出码：" + code + "。" + this.hotkeyStatus;
                new Notice(this.hotkeyStatus, 12000);
            });
            this.register(()=>{
                if (child.exitCode === null) child.kill();
            });
        } catch (error) {
            this.hotkeyStatus = String(error);
            report(error);
        }
    }
    importing = false;
    autoImport() {
        if (this.importing) return;
        this.importing = true;
        void this.importQueue(false).catch(report).finally(()=>{
            this.importing = false;
        });
    }
    subscribe(callback) {
        this.changes.add(callback);
        return ()=>this.changes.delete(callback);
    }
    changed() {
        window.clearTimeout(this.timer);
        this.timer = window.setTimeout(()=>this.changes.forEach((callback)=>callback()), 120);
    }
    serial(operation) {
        const current = this.pending.then(operation);
        this.pending = current.catch(()=>{});
        return current;
    }
    async openView() {
        let leaf = this.app.workspace.getLeavesOfType(VIEW)[0];
        if (!leaf) {
            leaf = this.app.workspace.getLeaf("tab");
            await leaf.setViewState({
                type: VIEW,
                active: true
            });
        }
        await this.app.workspace.revealLeaf(leaf);
    }
    async openCalendar() {
        const workspace = this.app.workspace;
        let leaf = workspace.getLeavesOfType(CALENDAR_VIEW)[0];
        if (!leaf) {
            let split;
            const base = workspace.getLeavesOfType(VIEW)[0] ?? workspace.getMostRecentLeaf();
            try {
                split = base ? workspace.createLeafBySplit(base, "vertical") : undefined;
            } catch  {
                split = undefined;
            }
            leaf = split ?? workspace.getRightLeaf(true) ?? workspace.getLeaf("tab");
            await leaf.setViewState({
                type: CALENDAR_VIEW,
                active: true
            });
        }
        await workspace.revealLeaf(leaf);
    }
    calendarToggling = false;
    async toggleCalendar() {
        if (this.calendarToggling) return;
        this.calendarToggling = true;
        try {
            const existing = this.app.workspace.getLeavesOfType(CALENDAR_VIEW);
            if (existing.length) existing.forEach((leaf)=>leaf.detach());
            else await this.openCalendar();
        } finally{
            this.calendarToggling = false;
        }
    }
    draggedTask;
    beginTaskDrag(task, transfer) {
        const token = Date.now().toString(36) + Math.random().toString(36).slice(2);
        this.draggedTask = {
            token,
            task
        };
        transfer.setData(TASK_DRAG, token);
        transfer.effectAllowed = "linkMove";
        return token;
    }
    taskDragState() {
        return this.draggedTask ? {
            active: true,
            token: this.draggedTask.token
        } : {
            active: false
        };
    }
    endTaskDrag(token) {
        window.setTimeout(()=>{
            if (this.draggedTask?.token === token) this.draggedTask = undefined;
        }, 4000);
    }
    scheduleDraggedTask(token, slot) {
        const drag = this.draggedTask;
        if (!drag || drag.token !== token) throw new Error("请重新拖动待办。");
        this.draggedTask = undefined;
        const task = drag.task;
        if (!validSlot(slot)) throw new Error("请拖到有效的日期和时间。");
        const slots = taskSlots(task);
        if (slots.some((item)=>item.date === slot.date && item.start === slot.start && item.length === slot.length)) return Promise.resolve();
        return this.saveCalendarTask(task, task.title, [
            ...slots,
            slot
        ]);
    }
    getAgentDeck() {
        const registry = this.app.plugins;
        const deck = registry?.getPlugin?.("agent-deck");
        return deck && typeof deck.delegateDrop === "function" ? deck : undefined;
    }
    calendarAgents() {
        const deck = this.getAgentDeck();
        return deck ? DECK_AGENTS.filter((agent)=>deck.agentEnabled?.(agent.id) !== false) : [];
    }
    async delegateCalendarTask(task, agent) {
        const deck = this.getAgentDeck();
        if (!deck) throw new Error("请安装并启用有兼容委派入口的 Agent Deck。");
        if (!this.calendarAgents().some((item)=>item.id === agent)) throw new Error("该 Agent 当前不可用。");
        const file = this.app.vault.getAbstractFileByPath(task.path);
        if (!(file instanceof TFile) || !this.includesTaskPath(task.path)) throw new Error("原任务文件已移动。");
        const matches = parseNote(await this.app.vault.read(file), task.path).filter((item)=>item.raw === task.raw);
        if (matches.length !== 1 || finished(matches[0])) throw new Error("任务已变更，请刷新日历后重试。");
        await deck.delegateDrop(agent, {
            path: task.path,
            line: matches[0].line,
            lineText: matches[0].raw
        }, null);
    }
    async calendarEvents() {
        const file = this.app.vault.getAbstractFileByPath(this.settings.folder + "/TaskHub-calendar.json");
        return file instanceof TFile ? parseCalendarEvents(await this.app.vault.read(file)) : [];
    }
    changeCalendarEvent(event, previous, remove = false) {
        return this.serial(async ()=>{
            if (!validSlot(event) || !event.title.trim() || event.title.length > 120) throw new Error("日程内容或时间无效。");
            const vault = this.app.vault, path = this.settings.folder + "/TaskHub-calendar.json";
            await this.makeFolders(this.settings.folder);
            const file = vault.getAbstractFileByPath(path);
            const update = (text)=>{
                const events = parseCalendarEvents(text), index = events.findIndex((item)=>item.id === event.id);
                if (previous) {
                    if (index < 0 || JSON.stringify(events[index]) !== JSON.stringify(previous)) throw new Error("日程已变更，请刷新后重试。");
                    if (remove) events.splice(index, 1);
                    else events[index] = event;
                } else {
                    if (index >= 0) throw new Error("日程已存在。");
                    events.push(event);
                }
                return JSON.stringify(events, null, 2) + "\n";
            };
            if (file instanceof TFile) await vault.process(file, update);
            else if (!file) await vault.create(path, update("[]"));
            else throw new Error("日程文件路径被占用。");
            this.changed();
        });
    }
    saveCalendarTask(task, title, slots, source) {
        return this.serial(async ()=>{
            const draft = validateDraft({
                ...draftOf(task ?? source),
                title
            });
            if (!task) {
                await this.add(draft, undefined, [], false, slots);
                return;
            }
            const raw = renderLine(draft, this.settings.tag, task);
            if (raw !== task.raw && !finished(task) && isDuplicate(await this.tasks(undefined, true), draft, this.settings.tag, task)) throw new Error("编辑后会与另一条未完成任务重复。");
            await this.writeTask(task, withTaskSlots({
                ...task,
                raw
            }, slots));
        });
    }
    files(folder = this.settings.folder) {
        return this.app.vault.getMarkdownFiles().filter((file)=>under(file.path, folder));
    }
    taskFolders() {
        return [
            ...new Set([
                this.settings.folder,
                ...this.settings.linkedFolders.split(/\r?\n/).map((s)=>s.trim()).filter(Boolean)
            ])
        ];
    }
    includesTaskPath(path) {
        return this.taskFolders().some((folder)=>under(path, folder)) && ![
            this.settings.backups,
            this.settings.queue
        ].some((folder)=>under(path, folder));
    }
    async tasks(folder, fresh = false) {
        const vault = this.app.vault;
        const files = folder ? this.files(folder) : vault.getMarkdownFiles().filter((file)=>this.includesTaskPath(file.path));
        const groups = await Promise.all(files.map(async (f)=>parseNote(await (fresh ? vault.read(f) : vault.cachedRead(f)), f.path)));
        return groups.flat();
    }
    async updateSettings(next) {
        return this.serial(()=>this.applySettings(next));
    }
    async applySettings(next) {
        const setting = {
            ...next,
            folder: safePath(next.folder),
            queue: safePath(next.queue),
            backups: safePath(next.backups)
        };
        setting.tag = setting.tag.trim();
        if (setting.tag && !/^#[\p{L}\p{M}\p{N}_/-]+$/u.test(setting.tag)) throw new Error("全局任务标记需为单个 #标签。");
        const dirs = [
            setting.folder,
            setting.queue,
            setting.backups
        ];
        if (dirs.some((a, i)=>dirs.some((b, j)=>j !== i && (a.toLowerCase() === b.toLowerCase() || under(a, b))))) throw new Error("任务库、录入队列和备份需要各自独立的目录。");
        setting.linkedFolders = setting.linkedFolders.split(/\r?\n/).map((s)=>s.trim()).filter(Boolean).map(safePath).join("\n");
        if (setting.linkedFolders.split("\n").filter(Boolean).some((p)=>[
                setting.backups,
                setting.queue
            ].some((q)=>p === q || under(p, q) || under(q, p)))) throw new Error("联动目录不能包含备份或录入队列目录。");
        await this.saveData(setting);
        this.settings = setting;
        this.changed();
    }
    async makeFolders(path) {
        const vault = this.app.vault;
        let parent = "";
        for (const part of safePath(path).split("/")){
            parent = parent ? parent + "/" + part : part;
            const current = vault.getAbstractFileByPath(parent);
            if (current && !(current instanceof TFolder)) throw new Error("文件占用了目录 · " + parent);
            if (!current) await vault.createFolder(parent);
        }
    }
    async add(draft, id, steps = [], daily = false, slots = []) {
        const d = validateDraft(draft);
        const { folder, tag } = this.settings;
        const tasks = await this.tasks(undefined, true);
        if (id) {
            const received = tasks.filter((t)=>t.ids.includes(id));
            if (received.length > 1) throw new Error("多个任务使用同一外部录入 ID，请先检查原笔记。");
            if (received.length === 1) return false;
        }
        if (isDuplicate(tasks, d, tag)) {
            if (id) throw new Error("任务重复，外部录入已保留以便核对。");
            throw new Error("已有同内容、分类、项目和截止日的未完成任务。");
        }
        const month = localDay().slice(0, 7);
        const [year, number] = month.split("-");
        const legacyMonth = new RegExp("(^|[^0-9])" + year + "(?:[-_年]?)0?" + Number(number) + "(?:月)?([^0-9]|$)");
        const monthly = this.files(folder).filter((file)=>legacyMonth.test(file.basename));
        const standard = folder + "/" + month + ".md";
        const preferred = monthly.find((file)=>file.path === standard);
        if (!preferred && monthly.length > 1) throw new Error("找到多份本月任务笔记，请保留唯一月度文件或使用 " + month + ".md 作为录入目标。");
        const path = preferred?.path ?? monthly[0]?.path ?? standard;
        const vault = this.app.vault;
        const raw = renderLine(d, tag, undefined, id) + (daily ? " [taskhub-repeat:: daily]" : "");
        const line = slots.length ? withTaskSlots(parseNote(raw, path)[0], slots) : raw;
        const childLines = steps.map((title)=>"    " + renderLine({
                ...d,
                title,
                due: "",
                time: "",
                priority: ""
            }, tag, undefined, Date.now().toString(36) + "-" + Math.random().toString(36).slice(2)));
        const insert = (text)=>{
            const lines = [
                line,
                ...childLines
            ];
            const next = appendLine(text, lines.join(text.includes("\r\n") ? "\r\n" : "\n"));
            const offset = next.split(/\r?\n/).length - 1 - lines.length;
            const parsed = parseNote(next, path);
            if (lines.some((raw, index)=>!parsed.some((task)=>task.line === offset + index && task.raw === raw))) throw new Error("月度笔记末尾无法写入任务，请检查代码块或注释是否关闭。");
            return next;
        };
        await this.makeFolders(folder);
        const target = vault.getAbstractFileByPath(path);
        if (target instanceof TFile) {
            await vault.process(target, (text)=>{
                if (isDuplicate(parseNote(text, path), d, tag)) throw new Error("目标文件已有重复任务。");
                return insert(text);
            });
        } else if (!target) {
            await vault.create(path, insert("# " + month + " 任务\n"));
        } else {
            throw new Error("月度文件路径已被占用 · " + path);
        }
        this.changed();
        return true;
    }
    createFromTemplate(title, steps) {
        return this.serial(async ()=>{
            if (!steps.length || steps.length > 30) throw new Error("请填写 1–30 条步骤");
            await this.add({
                title,
                category: "",
                project: "",
                due: "",
                priority: ""
            }, undefined, steps);
        });
    }
    createHabit(title) {
        return this.serial(async ()=>{
            await this.add({
                title,
                category: "",
                project: "",
                due: localDay(),
                priority: ""
            }, undefined, [], true);
        });
    }
    save(draft, task) {
        return this.serial(async ()=>{
            if (!task) {
                await this.add(draft);
                return;
            }
            const d = validateDraft(draft);
            const existing = await this.tasks(undefined, true);
            const matches = existing.filter((t)=>t.path === task.path && t.raw === task.raw);
            if (matches.length !== 1) throw new Error("任务已变更或有相同记录，请刷新后重试。");
            const current = matches[0];
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            if (this.settings.promoteTomorrow && !finished(current) && current.due !== d.due && d.due === localDay(tomorrow) && [
                "",
                "🔽",
                "⏬"
            ].includes(d.priority) && d.priority === current.priority) d.priority = "🔼";
            const replacement = renderLine(d, this.settings.tag, current);
            if (replacement === current.raw) return;
            if (!finished(current) && isDuplicate(existing, d, this.settings.tag, current)) throw new Error("编辑后会与另一条未完成任务重复。");
            await this.writeTask(current, replacement);
        });
    }
    toggle(task) {
        return this.serial(async ()=>{
            const now = new Date();
            const today = localDay(now);
            const replacement = completionLine(task, today, clockTime(now));
            const rule = taskField(task, "repeat");
            if (!rule) {
                await this.writeTask(task, replacement);
                return;
            }
            if (finished(task)) throw new Error("此重复任务已生成下一次，请在原笔记中处理历史记录");
            const due = nextRepeatDate(rule, task.due > today ? task.due : today);
            const raw = renderLine({
                ...draftOf(task),
                due
            }, this.settings.tag);
            const successor = raw + " [taskhub-repeat:: " + rule + "]";
            await this.writeGroup(task, (text)=>{
                const updated = replaceLine(text, task, replacement);
                const next = appendLine(updated, successor);
                if (!parseNote(next, task.path).some((row)=>row.raw === successor && row.line === next.split(/\r?\n/).length - 2)) throw new Error("原笔记末尾无法插入下一次重复任务");
                return next;
            });
        });
    }
    updateField(task, key, value) {
        return this.serial(async ()=>{
            if (key === "repeat" && value && (!validRepeatRule(value) || !task.due || task.recurring || finished(task))) throw new Error("请为未完成的普通任务设置截止日期后再添加重复规则");
            if (key === "board" && ![
                "",
                "进行中"
            ].includes(value)) throw new Error("看板状态无效");
            if (key === "block" && value) {
                const match = value.match(/^(\d{4}-\d{2}-\d{2}) ((?:[01]\d|2[0-3]):[0-5]\d) (15|30|45|60|90|120)$/);
                if (!match || !validDate(match[1])) throw new Error("请选择有效的排期日期、时间和时长");
                const [hour, minute] = match[2].split(":").map(Number);
                if (hour * 60 + minute + Number(match[3]) > 1440) throw new Error("时间块不能跨午夜");
            }
            const raw = setTaskField(task, key, value);
            if (raw !== task.raw) await this.writeTask(task, raw);
        });
    }
    addSubtask(task, title) {
        return this.serial(()=>{
            const draft = validateDraft({
                title,
                category: "",
                project: "",
                due: "",
                priority: ""
            });
            const indent = task.raw.match(/^\s*/)?.[0] ?? "";
            const child = indent + "    " + renderLine(draft, this.settings.tag);
            return this.writeGroup(task, (text)=>replaceLine(text, task, task.raw + (text.includes("\r\n") ? "\r\n" : "\n") + child));
        });
    }
    async writeGroup(task, transform) {
        const vault = this.app.vault;
        const file = vault.getAbstractFileByPath(task.path);
        if (!this.includesTaskPath(task.path) || !(file instanceof TFile)) throw new Error("任务文件已移动。");
        await vault.process(file, transform);
        this.changed();
    }
    deleteTask(task) {
        return this.serial(()=>this.writeGroup(task, (text)=>deleteTaskLine(text, task)));
    }
    async writeTask(task, replacement) {
        const vault = this.app.vault;
        const file = vault.getAbstractFileByPath(task.path);
        if (!this.includesTaskPath(task.path) || !(file instanceof TFile)) throw new Error("任务文件已移动。");
        await vault.process(file, (text)=>replaceLine(text, task, replacement));
        this.changed();
    }
    async openSource(task) {
        const file = this.app.vault.getAbstractFileByPath(task.path);
        if (!(file instanceof TFile)) throw new Error("原笔记已移动。");
        const leaf = this.app.workspace.getLeaf("tab");
        await leaf.openFile(file, {
            eState: {
                line: task.line
            }
        });
    }
    async createBackup(folder) {
        const files = folder ? this.files(folder) : this.app.vault.getMarkdownFiles().filter((file)=>this.includesTaskPath(file.path));
        const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
        const path = this.settings.backups + "/" + timestamp + "-" + Math.random().toString(36).slice(2, 8) + ".json";
        const notes = await Promise.all(files.map(async (f)=>({
                path: f.path,
                content: await this.app.vault.read(f)
            })));
        const calendarPath = this.settings.folder + "/TaskHub-calendar.json";
        const calendarFile = this.app.vault.getAbstractFileByPath(calendarPath);
        const calendar = calendarFile instanceof TFile ? {
            path: calendarPath,
            content: await this.app.vault.read(calendarFile)
        } : undefined;
        await this.makeFolders(this.settings.backups);
        await this.app.vault.create(path, JSON.stringify({
            version: 1,
            createdAt: new Date().toISOString(),
            settings: {
                ...this.settings
            },
            sourceFolder: folder,
            notes,
            calendar
        }, null, 2));
        return path;
    }
    backup() {
        return this.serial(()=>this.createBackup());
    }
    migrate(folder) {
        return this.serial(async ()=>{
            const path = safePath(folder);
            if (!this.files(path).length) throw new Error("目录内没有 Markdown 笔记，请检查旧任务库路径。");
            if ([
                this.settings.backups,
                this.settings.queue
            ].some((p)=>under(p, path) || under(path, p) || path.toLowerCase() === p.toLowerCase())) throw new Error("旧任务目录与队列或备份目录重叠。");
            const tasks = await this.tasks(path, true);
            if (!tasks.length) throw new Error("目录内没有可识别的 Markdown 任务。");
            const backup = await this.createBackup(path);
            await this.applySettings({
                ...this.settings,
                folder: path
            });
            return {
                count: tasks.length,
                backup
            };
        });
    }
    importQueue(manual) {
        return this.serial(async ()=>{
            const { queue } = this.settings;
            const vault = this.app.vault;
            if (!await vault.adapter.exists(queue)) {
                if (manual) new Notice("录入队列为空");
                return;
            }
            const paths = (await vault.adapter.list(queue)).files.filter((p)=>under(p, queue) && p.endsWith(".taskhub.json")).sort();
            let added = 0, removed = 0;
            const errors = [];
            for (const path of paths){
                try {
                    const original = await vault.adapter.read(path);
                    const entry = parseCapture(original);
                    if (await this.add(entry.task, entry.id)) added++;
                    if (await vault.adapter.read(path) !== original) throw new Error("队列文件在导入过程中发生变化，已保留以便重试。");
                    await vault.adapter.remove(path);
                    removed++;
                } catch (error) {
                    errors.push(path.split("/").at(-1) + " · " + (error instanceof Error ? error.message : String(error)));
                }
            }
            if (manual || removed) new Notice("TaskHub · 新增 " + added + " 条，确认 " + removed + " 份队列文件，待处理 " + errors.length + " 份。");
            if (manual && errors.length) new Notice(errors.slice(0, 5).join("\n"), 10000);
        });
    }
}
class HubModal extends Modal {
    setTitle(title) {
        super.setTitle(title);
        this.modalEl?.addClass("taskhub-modal");
        this.contentEl.addClass("taskhub-dialog");
    }
}
class TaskEditor extends HubModal {
    hub;
    task;
    preset;
    constructor(hub, task, preset = {}){
        super(hub.app), this.hub = hub, this.task = task, this.preset = preset;
    }
    onOpen() {
        const { contentEl } = this;
        this.setTitle(this.task ? "编辑任务" : "新建任务");
        const form = contentEl.createEl("form", {
            cls: "taskhub-form"
        });
        const draft = {
            ...draftOf(this.task),
            ...!this.task ? this.preset : {}
        };
        const input = (parent, label, type, key)=>{
            const row = parent.createEl("label", {
                text: label
            });
            const el = row.createEl("input", {
                type,
                value: draft[key] ?? ""
            });
            el.addEventListener("input", ()=>{
                draft[key] = el.value;
            });
            return el;
        };
        const title = input(form, "要做什么？", "text", "title");
        title.required = true;
        title.maxLength = 1000;
        title.placeholder = "例如：联系候选人，确认周五面试时间";
        form.createEl("p", {
            text: "只写内容即可保存；分类、项目与日期可以稍后补充。",
            cls: "taskhub-muted"
        });
        const fields = form.createDiv({
            cls: "taskhub-fields"
        });
        const category = input(fields, "分类", "text", "category");
        category.placeholder = "例如：招聘、个人";
        const project = input(fields, "项目", "text", "project");
        project.placeholder = "例如：FDE 招聘";
        const due = input(fields, "截止日期", "date", "due");
        const time = input(fields, "截止时间（可选）", "time", "time");
        time.step = "60";
        const suggestion = this.task ? undefined : form.createDiv({
            cls: "taskhub-quick-suggestion"
        });
        if (suggestion) {
            const preview = ()=>{
                suggestion.empty();
                const parsed = parseQuickTitle(title.value);
                if (!parsed) return;
                suggestion.createEl("span", {
                    text: "识别到 " + parsed.due + (parsed.time ? " " + parsed.time : "")
                });
                suggestion.createEl("button", {
                    text: "应用日期时间",
                    attr: {
                        type: "button"
                    }
                }).addEventListener("click", ()=>{
                    title.value = draft.title = parsed.title;
                    due.value = draft.due = parsed.due;
                    time.value = draft.time = parsed.time;
                    suggestion.empty();
                    title.focus();
                });
            };
            title.addEventListener("input", preview);
        }
        due.addEventListener("input", ()=>{
            if (!due.value) {
                draft.time = "";
                time.value = "";
            }
        });
        const priority = fields.createEl("label", {
            text: "优先级"
        }).createEl("select");
        addOptions(priority, priorityOptions("普通"), draft.priority);
        priority.addEventListener("change", ()=>{
            draft.priority = priority.value;
        });
        const dates = form.createDiv({
            cls: "taskhub-date-shortcuts"
        });
        for (const [label, offset] of [
            [
                "今天",
                0
            ],
            [
                "明天",
                1
            ],
            [
                "一周后",
                7
            ],
            [
                "不设日期",
                -1
            ]
        ]){
            dates.createEl("button", {
                text: label,
                attr: {
                    type: "button"
                }
            }).addEventListener("click", ()=>{
                const date = new Date();
                date.setDate(date.getDate() + Math.max(0, offset));
                due.value = draft.due = offset < 0 ? "" : localDay(date);
                if (offset < 0) {
                    draft.time = "";
                    time.value = "";
                }
            });
        }
        void this.hub.tasks().then((tasks)=>{
            for (const [el, key] of [
                [
                    category,
                    "category"
                ],
                [
                    project,
                    "project"
                ]
            ]){
                if (!el.isConnected) return;
                const list = form.createEl("datalist");
                list.id = "taskhub-" + key + "-" + Math.random().toString(36).slice(2);
                el.setAttribute("list", list.id);
                for (const value of new Set(tasks.map((t)=>t[key]).filter(Boolean)))list.createEl("option", {
                    value
                });
            }
        }).catch(report);
        const status = form.createDiv({
            cls: "taskhub-form-status",
            attr: {
                "aria-live": "polite"
            }
        });
        const footer = form.createDiv({
            cls: "taskhub-editor-footer"
        });
        let keep;
        if (!this.task) {
            const label = footer.createEl("label", {
                cls: "taskhub-keep"
            });
            keep = label.createEl("input", {
                type: "checkbox"
            });
            label.createEl("span", {
                text: "保存后继续添加"
            });
        }
        const submit = footer.createEl("button", {
            text: this.task ? "保存修改" : "添加任务",
            cls: "mod-cta",
            attr: {
                type: "submit"
            }
        });
        const task = this.task;
        if (task) {
            const remove = footer.createEl("button", {
                text: "删除任务",
                cls: "taskhub-danger",
                attr: {
                    type: "button"
                }
            });
            const confirm = form.createDiv({
                cls: "taskhub-confirm"
            });
            confirm.hidden = true;
            confirm.createEl("p", {
                text: "确认从原笔记删除这条任务？"
            });
            const actions = confirm.createDiv({
                cls: "taskhub-actions"
            });
            const cancel = actions.createEl("button", {
                text: "取消",
                attr: {
                    type: "button"
                }
            });
            const accept = actions.createEl("button", {
                text: "确认删除",
                cls: "mod-warning",
                attr: {
                    type: "button"
                }
            });
            remove.addEventListener("click", ()=>{
                confirm.hidden = false;
                submit.disabled = true;
                remove.disabled = true;
                cancel.focus();
            });
            cancel.addEventListener("click", ()=>{
                confirm.hidden = true;
                submit.disabled = false;
                remove.disabled = false;
                remove.focus();
            });
            accept.addEventListener("click", ()=>{
                if (accept.disabled) return;
                accept.disabled = cancel.disabled = true;
                void this.hub.deleteTask(task).then(()=>{
                    new Notice("任务已删除");
                    this.close();
                }).catch((error)=>{
                    status.setText(error instanceof Error ? error.message : String(error));
                }).finally(()=>{
                    accept.disabled = cancel.disabled = false;
                });
            });
        }
        form.addEventListener("submit", (event)=>{
            event.preventDefault();
            if (submit.disabled) return;
            submit.disabled = true;
            submit.setText("正在保存…");
            status.setText("");
            const next = {
                ...draft
            };
            const controls = Array.from(form.querySelectorAll("input,select,button"));
            controls.forEach((control)=>{
                control.disabled = true;
            });
            void this.hub.save(next, this.task).then(()=>{
                if (keep?.checked) {
                    draft.title = "";
                    title.value = "";
                    suggestion?.empty();
                    status.setText("已添加。分类、项目和日期已保留，可继续录入。");
                } else {
                    new Notice(this.task ? "修改已保存" : "任务已添加");
                    this.close();
                }
            }).catch((error)=>{
                status.setText(error instanceof Error ? error.message : String(error));
            }).finally(()=>{
                controls.forEach((control)=>{
                    control.disabled = false;
                });
                submit.setText(this.task ? "保存修改" : "添加任务");
                title.focus();
            });
        });
        title.focus();
    }
    onClose() {
        this.contentEl.empty();
    }
}
class EmailCapture extends HubModal {
    hub;
    generation = 0;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("邮件转任务");
        const el = this.contentEl;
        el.createEl("p", {
            text: "选择导出的 .eml 邮件。插件在本地读取主题，生成可编辑的录入预览。"
        });
        const input = el.createEl("input", {
            type: "file",
            attr: {
                accept: ".eml,message/rfc822",
                "aria-label": "选择邮件文件"
            }
        });
        const status = el.createEl("p", {
            attr: {
                "aria-live": "polite"
            }
        });
        const preview = el.createEl("button", {
            text: "打开录入预览",
            cls: "mod-cta"
        });
        preview.disabled = true;
        let title = "";
        input.addEventListener("change", ()=>{
            const id = ++this.generation, file = input.files?.[0];
            title = "";
            preview.disabled = true;
            status.setText("");
            if (!file) return;
            void file.slice(0, 65536).text().then((text)=>{
                if (id !== this.generation) return;
                title = emailSubject(text);
                status.setText("邮件主题 · " + title);
                preview.disabled = false;
            }).catch((error)=>{
                if (id === this.generation) status.setText(error instanceof Error ? error.message : String(error));
            });
        });
        preview.addEventListener("click", ()=>{
            if (title) {
                this.close();
                new TaskEditor(this.hub, undefined, {
                    title: "处理邮件：" + title
                }).open();
            }
        });
    }
    onClose() {
        this.generation++;
        this.contentEl.empty();
    }
}
class TaskJump extends HubModal {
    destinations;
    constructor(destinations, hub){
        super(hub.app), this.destinations = destinations;
    }
    onOpen() {
        this.setTitle("跳转到");
        const input = this.contentEl.createEl("input", {
            type: "search",
            placeholder: "搜索视图",
            attr: {
                "aria-label": "搜索视图"
            }
        });
        const list = this.contentEl.createDiv({
            cls: "taskhub-review-nav"
        });
        const matches = ()=>this.destinations.filter(([name])=>name.includes(input.value.trim()));
        const choose = (action)=>{
            this.close();
            action();
        };
        const render = ()=>{
            list.empty();
            for (const [name, action] of matches())list.createEl("button", {
                text: name
            }).addEventListener("click", ()=>choose(action));
        };
        input.addEventListener("input", render);
        input.addEventListener("keydown", (event)=>{
            const first = matches()[0];
            if (event.key === "Enter" && !event.isComposing && first) {
                event.preventDefault();
                choose(first[1]);
            }
        });
        render();
        input.focus();
    }
    onClose() {
        this.contentEl.empty();
    }
}
class Routines extends HubModal {
    hub;
    version = 0;
    release;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("例行清单");
        const el = this.contentEl;
        el.addClass("taskhub-dialog");
        const tabs = el.createDiv({
            cls: "taskhub-nav"
        });
        const template = tabs.createEl("button", {
            text: "清单模板"
        });
        const habit = tabs.createEl("button", {
            text: "每日习惯"
        });
        const panel = el.createDiv();
        const switchTo = (daily)=>{
            this.version++;
            this.release?.();
            this.release = undefined;
            panel.empty();
            template.setAttribute("aria-pressed", String(!daily));
            habit.setAttribute("aria-pressed", String(daily));
            if (daily) this.renderHabits(panel);
            else this.renderTemplates(panel);
        };
        template.addEventListener("click", ()=>switchTo(false));
        habit.addEventListener("click", ()=>switchTo(true));
        switchTo(false);
    }
    renderHabits(el) {
        const form = el.createDiv({
            cls: "taskhub-section"
        });
        const title = form.createEl("label", {
            text: "新习惯"
        }).createEl("input", {
            type: "text",
            placeholder: "例如：每天整理收集箱"
        });
        const create = form.createEl("button", {
            text: "添加每日习惯",
            cls: "mod-cta"
        });
        const stats = el.createEl("p", {
            cls: "taskhub-muted"
        });
        const list = el.createDiv();
        const refresh = async ()=>{
            const version = ++this.version;
            try {
                const tasks = await this.hub.tasks();
                if (version !== this.version) return;
                const habits = tasks.filter((task)=>taskField(task, "repeat") === "daily");
                const today = localDay();
                stats.setText("今天已打卡 " + habits.filter((task)=>finished(task) && task.metadata.includes("✅ " + today)).length + " 次");
                showTasks(list, this.hub, habits.filter((task)=>!finished(task) && task.due <= today), false);
            } catch (error) {
                if (version === this.version) report(error);
            }
        };
        this.release = this.hub.subscribe(()=>void refresh());
        void refresh();
        create.addEventListener("click", ()=>{
            if (create.disabled) return;
            create.disabled = true;
            void this.hub.createHabit(title.value).then(()=>{
                title.value = "";
                new Notice("习惯已添加");
            }).catch(report).finally(()=>{
                create.disabled = false;
            });
        });
    }
    renderTemplates(panel) {
        const el = panel.createDiv({
            cls: "taskhub-section"
        });
        const templates = {
            "月度结账": [
                "核对本月流水",
                "确认应收应付",
                "整理结账凭证"
            ],
            "出差准备": [
                "确认行程和住宿",
                "准备会议材料",
                "整理报销凭证"
            ],
            "旅行打包": [
                "检查证件",
                "准备充电器",
                "整理衣物和洗漱用品"
            ]
        };
        const select = el.createEl("label", {
            text: "模板"
        }).createEl("select");
        addOptions(select, Object.keys(templates).map((name)=>[
                name,
                name
            ]), "月度结账");
        const title = el.createEl("label", {
            text: "任务名称"
        }).createEl("input", {
            type: "text"
        });
        const steps = el.createEl("label", {
            text: "清单步骤（每行一项）"
        }).createEl("textarea", {
            attr: {
                rows: "6"
            }
        });
        const fill = ()=>{
            title.value = select.value;
            steps.value = templates[select.value].join("\n");
        };
        select.addEventListener("change", fill);
        fill();
        const submit = el.createEl("button", {
            text: "创建清单",
            cls: "mod-cta"
        });
        submit.addEventListener("click", ()=>{
            if (submit.disabled) return;
            submit.disabled = true;
            void this.hub.createFromTemplate(title.value, steps.value.split(/\r?\n/).map((s)=>s.trim()).filter(Boolean)).then(()=>{
                new Notice("清单已创建");
                this.close();
            }).catch(report).finally(()=>{
                submit.disabled = false;
            });
        });
    }
    onClose() {
        this.version++;
        this.release?.();
        this.contentEl.empty();
    }
}
class TaskPlanning extends HubModal {
    hub;
    task;
    day;
    after;
    constructor(hub, task, day, after){
        super(hub.app), this.hub = hub, this.task = task, this.day = day, this.after = after;
    }
    onOpen() {
        this.setTitle("任务安排");
        const el = this.contentEl;
        el.addClass("taskhub-dialog");
        el.createEl("p", {
            text: this.task.title.split(/\s+/).filter((word)=>word !== this.hub.settings.tag).join(" "),
            cls: "taskhub-dialog-task"
        });
        const save = (operation)=>{
            const buttons = Array.from(el.querySelectorAll("input,select,button"));
            buttons.forEach((b)=>{
                b.disabled = true;
            });
            void operation().then(()=>{
                this.close();
                this.after?.();
            }).catch((error)=>{
                report(error);
                buttons.forEach((b)=>{
                    b.disabled = false;
                });
            });
        };
        const section = (title)=>{
            const panel = el.createDiv({
                cls: "taskhub-section"
            });
            panel.createEl("h3", {
                text: title
            });
            return panel;
        };
        const schedule = section("时间块");
        const fields = schedule.createDiv({
            cls: "taskhub-schedule-grid"
        });
        const [day, time, duration] = taskField(this.task, "block").split(" ");
        const date = fields.createEl("label", {
            text: "排期日期"
        }).createEl("input", {
            type: "date",
            value: this.day || day || localDay()
        });
        const clock = fields.createEl("label", {
            text: "开始时间"
        }).createEl("input", {
            type: "time",
            value: time || "09:00"
        });
        const length = fields.createEl("label", {
            text: "时长（分钟）"
        }).createEl("select");
        addOptions(length, [
            15,
            30,
            45,
            60,
            90,
            120
        ].map((n)=>[
                String(n),
                String(n)
            ]), duration || "30");
        const scheduleActions = schedule.createDiv({
            cls: "taskhub-actions"
        });
        if (day) scheduleActions.createEl("button", {
            text: "移除时间块"
        }).addEventListener("click", ()=>save(()=>this.hub.updateField(this.task, "block", "")));
        scheduleActions.createEl("button", {
            text: "保存时间块",
            cls: "mod-cta"
        }).addEventListener("click", ()=>save(()=>this.hub.updateField(this.task, "block", [
                    date.value,
                    clock.value,
                    length.value
                ].join(" "))));
        if (!finished(this.task) && !this.task.recurring) {
            const rule = section("重复规则");
            const repeat = rule.createEl("label", {
                text: "完成后生成下一次"
            }).createEl("select");
            const current = taskField(this.task, "repeat");
            const kind = current === "mwf" || current.startsWith("weekly:") ? "weekly" : current.startsWith("monthly:") ? "monthly" : current;
            addOptions(repeat, [
                [
                    "",
                    "不重复"
                ],
                [
                    "daily",
                    "每天"
                ],
                [
                    "weekly",
                    "每周 · 选择星期"
                ],
                [
                    "monthly",
                    "每月 · 指定日期"
                ],
                [
                    "month-end",
                    "每月最后一个工作日"
                ]
            ], kind);
            const start = new Date((this.task.due || localDay()) + "T12:00:00");
            const selected = current === "mwf" ? [
                1,
                3,
                5
            ] : current.startsWith("weekly:") ? current.slice(7).split(",").map(Number) : [
                start.getDay()
            ];
            const week = rule.createEl("fieldset", {
                cls: "taskhub-repeat-days"
            });
            week.createEl("legend", {
                text: "星期（可多选）"
            });
            const weekdays = [
                1,
                2,
                3,
                4,
                5,
                6,
                0
            ].map((day, index)=>{
                const label = week.createEl("label");
                const input = label.createEl("input", {
                    type: "checkbox"
                });
                input.checked = selected.includes(day);
                label.createEl("span", {
                    text: "周" + "一二三四五六日"[index]
                });
                return {
                    day,
                    input
                };
            });
            const month = rule.createEl("label", {
                text: "每月几号"
            });
            const monthDay = month.createEl("select");
            addOptions(monthDay, Array.from({
                length: 31
            }, (_, i)=>[
                    String(i + 1),
                    i + 1 + " 号"
                ]), current.startsWith("monthly:") ? current.slice(8) : String(start.getDate()));
            const hint = rule.createEl("p", {
                cls: "taskhub-muted"
            });
            const update = ()=>{
                week.hidden = repeat.value !== "weekly";
                month.hidden = repeat.value !== "monthly";
                hint.setText(!this.task.due ? "请先在「编辑」中为这条任务设置截止日期。" : repeat.value === "monthly" ? "没有所选日期的月份会跳过。" : "首次仍按当前截止日期，完成后按规则生成下一次。");
            };
            repeat.addEventListener("change", update);
            update();
            rule.createDiv({
                cls: "taskhub-actions"
            }).createEl("button", {
                text: "保存重复规则"
            }).addEventListener("click", ()=>{
                const days = weekdays.filter(({ input })=>input.checked).map(({ day })=>day);
                if (repeat.value === "weekly" && !days.length) {
                    new Notice("请选择至少一个星期");
                    return;
                }
                const value = repeat.value === "weekly" ? "weekly:" + days.join(",") : repeat.value === "monthly" ? "monthly:" + monthDay.value : repeat.value;
                save(()=>this.hub.updateField(this.task, "repeat", value));
            });
        }
        const subtasks = section("子任务");
        const child = subtasks.createEl("label", {
            text: "步骤内容"
        }).createEl("input", {
            type: "text",
            placeholder: "例如：准备面试材料"
        });
        subtasks.createDiv({
            cls: "taskhub-actions"
        }).createEl("button", {
            text: "添加子任务"
        }).addEventListener("click", ()=>save(()=>this.hub.addSubtask(this.task, child.value)));
        if (!finished(this.task)) {
            const doing = taskField(this.task, "board") === "进行中";
            el.createDiv({
                cls: "taskhub-actions"
            }).createEl("button", {
                text: doing ? "移回待办" : "标为进行中"
            }).addEventListener("click", ()=>save(()=>this.hub.updateField(this.task, "board", doing ? "" : "进行中")));
        }
    }
    onClose() {
        this.contentEl.empty();
    }
}
function parseCalendarEvents(text) {
    const events = JSON.parse(text);
    if (!Array.isArray(events) || events.some((event)=>!validSlot(event) || typeof event.id !== "string" || typeof event.title !== "string") || new Set(events.map((event)=>event.id)).size !== events.length) throw new Error("TaskHub 日程文件格式无效。");
    return events;
}
class TaskCalendar extends ItemView {
    hub;
    stop;
    constructor(leaf, hub){
        super(leaf), this.hub = hub;
    }
    getViewType() {
        return CALENDAR_VIEW;
    }
    getDisplayText() {
        return "TaskHub 日历";
    }
    getIcon() {
        return "calendar-days";
    }
    async onOpen() {
        this.contentEl.empty();
        this.contentEl.addClass("taskhub-calendar-pane");
        const frame = this.contentEl.createEl("iframe", {
            cls: "taskhub-calendar-frame",
            attr: {
                sandbox: "allow-scripts allow-forms",
                title: "TaskHub 日历"
            }
        });
        let tasks = [], events = [];
        let busy = false, closed = false, ready = false, dirty = false, revision = 0;
        let signature = "";
        const publish = async ()=>{
            const [nextTasks, nextEvents] = await Promise.all([
                this.hub.tasks(undefined, true),
                this.hub.calendarEvents()
            ]);
            if (closed) return;
            const nextSignature = JSON.stringify([
                nextTasks,
                nextEvents,
                this.hub.calendarAgents()
            ]);
            if (nextSignature !== signature) {
                revision++;
                signature = nextSignature;
            }
            tasks = nextTasks;
            events = nextEvents;
            const payload = tasks.flatMap((task, index)=>{
                if (finished(task)) return [];
                return [
                    {
                        id: index,
                        title: task.title.split(/\s+/).filter((word)=>word !== this.hub.settings.tag).join(" ") || task.title,
                        category: task.category,
                        project: task.project,
                        due: task.due,
                        slots: taskSlots(task)
                    }
                ];
            });
            ready = true;
            frame.contentWindow?.postMessage({
                type: "taskhub-state",
                revision,
                tasks: payload,
                events,
                agents: this.hub.calendarAgents()
            }, "*");
        };
        const refresh = async ()=>{
            if (closed) return;
            if (busy) {
                dirty = true;
                return;
            }
            if (!ready) return;
            busy = true;
            try {
                await publish();
            } catch  {
                frame.contentWindow?.postMessage({
                    type: "taskhub-refresh-error",
                    text: "日历刷新失败，请点击重新读取。"
                }, "*");
            } finally{
                busy = false;
                if (dirty) {
                    dirty = false;
                    void refresh();
                }
            }
        };
        const receive = async (event)=>{
            if (event.source !== frame.contentWindow || closed) return;
            const data = event.data;
            if (!data || data.type !== "taskhub-calendar") return;
            if (data.action === "drag-probe") {
                frame.contentWindow?.postMessage({
                    type: "taskhub-drag-state",
                    ...this.hub.taskDragState()
                }, "*");
                return;
            }
            if (busy) {
                frame.contentWindow?.postMessage({
                    type: "taskhub-error",
                    text: "日历正在更新，请稍后重试。"
                }, "*");
                return;
            }
            if (data.action === "show-updates") {
                window.open("https://marcus-same.github.io/marcus-output-library/taskhub/", "_blank", "noopener,noreferrer");
                return;
            }
            busy = true;
            try {
                if (data.action === "load") {
                    await publish();
                    return;
                }
                if (!ready) throw new Error("日历尚未加载，请重试读取。");
                if (data.revision !== revision) throw new Error("待办已更新，请重新选择日程后再操作。");
                const task = Number.isInteger(data.taskId) ? tasks[data.taskId] : undefined;
                if (data.action === "delegate") {
                    if (!task) throw new Error("找不到要委派的待办。");
                    await this.hub.delegateCalendarTask(task, data.agent);
                    frame.contentWindow?.postMessage({
                        type: "taskhub-delegate-preview"
                    }, "*");
                    return;
                }
                if (data.action === "open-source" || data.action === "agent-source") {
                    if (!task) throw new Error("待办已变更，请重开日历后重试。");
                    await this.hub.openSource(task);
                    if (data.action === "agent-source") {
                        const registry = this.app.plugins;
                        new Notice(registry?.getPlugin?.("agent-deck") ? "已打开原任务。在 Agent Deck 选 Agent 并确认发送。" : "当前库未启用 Agent Deck。启用后，可在这条原待办上委派。", 9000);
                    }
                    frame.contentWindow?.postMessage({
                        type: "taskhub-opened"
                    }, "*");
                    return;
                } else if (data.action === "schedule-dragged-task") {
                    await this.hub.scheduleDraggedTask(data.token, data.slot);
                } else if (data.action === "delete-task") {
                    if (!task) throw new Error("待办已变更。");
                    await this.hub.deleteTask(task);
                } else if (data.action === "save-task") {
                    if (!task && !tasks[data.sourceId]) throw new Error("请先在待办工作台创建任务。");
                    if (!Array.isArray(data.slots) || typeof data.title !== "string") throw new Error("待办内容无效。");
                    await this.hub.saveCalendarTask(task, task?.title ?? data.title, data.slots, tasks[data.sourceId]);
                } else if (data.action === "save-event" || data.action === "delete-event") {
                    const previous = events.find((item)=>item.id === data.id);
                    if (!previous) throw new Error("找不到已有日程。");
                    const item = data.action === "delete-event" ? previous : {
                        ...previous,
                        ...data.slot,
                        id: previous.id,
                        tone: previous.tone,
                        title: data.title
                    };
                    if (!item || typeof item.title !== "string") throw new Error("日程内容无效。");
                    await this.hub.changeCalendarEvent(item, previous, data.action === "delete-event");
                } else return;
                frame.contentWindow?.postMessage({
                    type: "taskhub-saved"
                }, "*");
                ready = false;
                try {
                    await publish();
                } catch  {
                    frame.contentWindow?.postMessage({
                        type: "taskhub-refresh-error",
                        text: "已保存，但刷新失败。请重新读取日历。"
                    }, "*");
                }
            } catch (error) {
                frame.contentWindow?.postMessage({
                    type: "taskhub-error",
                    text: error instanceof Error ? error.message : String(error)
                }, "*");
            } finally{
                busy = false;
                if (dirty) {
                    dirty = false;
                    void refresh();
                }
            }
        };
        const listener = (event)=>void receive(event);
        window.addEventListener("message", listener);
        const unsubscribe = this.hub.subscribe(()=>void refresh());
        this.stop = ()=>{
            closed = true;
            unsubscribe();
            window.removeEventListener("message", listener);
        };
        frame.srcdoc = calendarHtml;
    }
    async onClose() {
        this.stop?.();
        this.stop = undefined;
        this.contentEl.empty();
    }
}
class PlanningBoard extends HubModal {
    hub;
    generation = 0;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("任务看板");
        this.modalEl?.addClass("taskhub-modal-wide");
        void this.render();
    }
    onClose() {
        this.generation++;
        this.contentEl.empty();
    }
    async render() {
        const id = ++this.generation;
        const el = this.contentEl;
        el.setText("正在读取任务…");
        try {
            const tasks = await this.hub.tasks();
            if (id !== this.generation) return;
            el.empty();
            const board = el.createDiv({
                cls: "taskhub-board"
            });
            for (const column of [
                "待办",
                "进行中",
                "已完成"
            ]){
                const section = board.createDiv();
                section.createEl("h3", {
                    text: column
                });
                const items = tasks.filter((task)=>(finished(task) ? "已完成" : taskField(task, "board") || "待办") === column);
                for (const task of items)section.createEl("button", {
                    text: task.title
                }).addEventListener("click", ()=>new TaskPlanning(this.hub, task, undefined, ()=>void this.render()).open());
            }
        } catch (error) {
            if (id === this.generation) el.setText(String(error));
        }
    }
}
class CompletionStats extends HubModal {
    hub;
    closed = false;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("近七天完成记录");
        const el = this.contentEl;
        el.setText("正在读取任务…");
        void this.hub.tasks().then((tasks)=>{
            if (this.closed) return;
            const counts = new Map();
            for(let offset = 34; offset >= 0; offset--){
                const date = new Date();
                date.setDate(date.getDate() - offset);
                counts.set(localDay(date), 0);
            }
            for (const task of tasks){
                if (!/^[xX]$/.test(task.status)) continue;
                const date = task.metadata.match(/✅\s*(\d{4}-\d{2}-\d{2})|\[(?:done|completion)::\s*(\d{4}-\d{2}-\d{2})\s*\]/u);
                const day = date?.[1] ?? date?.[2];
                if (day && counts.has(day)) counts.set(day, (counts.get(day) ?? 0) + 1);
            }
            el.empty();
            el.createEl("p", {
                text: "近七天完成 " + [
                    ...counts.values()
                ].slice(-7).reduce((sum, value)=>sum + value, 0) + " 项"
            });
            const heatmap = el.createDiv({
                cls: "taskhub-heatmap",
                attr: {
                    "aria-label": "近 35 天完成热力图"
                }
            });
            for (const [day, count] of counts)heatmap.createEl("span", {
                text: String(count),
                attr: {
                    title: day + " · " + count + " 项",
                    "data-level": String(Math.min(3, count))
                }
            });
            const list = el.createEl("ul");
            for (const [day, count] of [
                ...counts
            ].slice(-7))list.createEl("li", {
                text: day + " · " + count + " 项"
            });
            el.createEl("p", {
                text: "仅统计有完成日期的任务。",
                cls: "taskhub-muted"
            });
        }).catch((error)=>{
            if (!this.closed) el.setText(String(error));
        });
    }
    onClose() {
        this.closed = true;
        this.contentEl.empty();
    }
}
class WeeklyReview extends HubModal {
    hub;
    step = 0;
    selected = new Map();
    renderId = 0;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("每周回顾");
        void this.render();
    }
    onClose() {
        this.renderId++;
        this.contentEl.empty();
    }
    async render() {
        const id = ++this.renderId;
        const el = this.contentEl;
        el.empty();
        el.createEl("p", {
            text: "正在读取任务…"
        });
        try {
            const tasks = await this.hub.tasks();
            if (id !== this.renderId) return;
            el.empty();
            const names = [
                "处理逾期",
                "整理未排期",
                "选出下周最重要的三件事"
            ];
            const scope = [
                "逾期",
                "未排期",
                "全部"
            ][this.step];
            const items = filterTasks(tasks, {
                scope
            }, localDay(), clockTime());
            el.createEl("h3", {
                text: this.step + 1 + " / 3 · " + names[this.step]
            });
            if (this.step < 2) {
                el.createEl("p", {
                    text: this.step === 0 ? "完成已处理的任务，或编辑仍需跟进的截止时间。" : "给值得保留的任务补上分类、项目或截止日期。",
                    cls: "taskhub-muted"
                });
                showTasks(el.createDiv({
                    cls: "taskhub-review-list"
                }), this.hub, items, false);
            } else {
                const list = el.createDiv({
                    cls: "taskhub-review-list"
                });
                const status = el.createEl("p", {
                    attr: {
                        "aria-live": "polite"
                    }
                });
                const output = el.createEl("textarea", {
                    attr: {
                        readonly: "",
                        rows: "5",
                        "aria-label": "下周重点 Markdown"
                    }
                });
                const active = new Set(items.map((t)=>t.path + ":" + t.line + ":" + t.raw));
                for (const key of this.selected.keys())if (!active.has(key)) this.selected.delete(key);
                const update = ()=>{
                    status.setText("已选 " + this.selected.size + " / 3");
                    output.value = this.selected.size ? "## 下周重点\n" + [
                        ...this.selected.values()
                    ].map((title, i)=>i + 1 + ". " + title).join("\n") : "";
                };
                for (const task of items){
                    const key = task.path + ":" + task.line + ":" + task.raw;
                    const row = list.createEl("label", {
                        cls: "taskhub-review-choice"
                    });
                    const toggle = row.createEl("input", {
                        type: "checkbox"
                    });
                    row.createEl("span", {
                        text: task.title
                    });
                    toggle.checked = this.selected.has(key);
                    toggle.addEventListener("change", ()=>{
                        if (!toggle.checked) this.selected.delete(key);
                        else if (this.selected.size < 3) this.selected.set(key, task.title);
                        else {
                            toggle.checked = false;
                            new Notice("最多选择三件事");
                        }
                        update();
                    });
                }
                update();
                el.createEl("button", {
                    text: "复制下周重点"
                }).addEventListener("click", ()=>{
                    if (!output.value) {
                        new Notice("先选择至少一项任务");
                        return;
                    }
                    void navigator.clipboard.writeText(output.value).then(()=>new Notice("已复制下周重点")).catch(report);
                });
            }
            const nav = el.createDiv({
                cls: "taskhub-review-nav"
            });
            if (this.step > 0) nav.createEl("button", {
                text: "上一步"
            }).addEventListener("click", ()=>{
                this.step--;
                void this.render();
            });
            nav.createEl("button", {
                text: "刷新本步"
            }).addEventListener("click", ()=>void this.render());
            nav.createEl("button", {
                text: this.step === 2 ? "完成回顾" : "下一步",
                cls: "mod-cta"
            }).addEventListener("click", ()=>{
                if (this.step === 2) this.close();
                else {
                    this.step++;
                    void this.render();
                }
            });
        } catch (error) {
            if (id === this.renderId) el.setText(String(error));
        }
    }
}
class QueryEditor extends HubModal {
    hub;
    selected;
    insert;
    constructor(hub, selected, insert){
        super(hub.app), this.hub = hub, this.selected = selected, this.insert = insert;
    }
    onOpen() {
        this.setTitle("插入动态任务查询");
        const { contentEl } = this;
        const scope = contentEl.createEl("label", {
            text: "视图"
        }).createEl("select");
        addOptions(scope, scopes.map((s)=>[
                s,
                s
            ]), "全部");
        const project = contentEl.createEl("label", {
            text: "项目（可选）"
        }).createEl("input", {
            type: "text",
            value: this.selected
        });
        contentEl.createEl("button", {
            text: "插入查询",
            cls: "mod-cta"
        }).addEventListener("click", ()=>{
            const value = project.value.trim().replace(/[\r\n]/g, "");
            const fence = String.fromCharCode(96).repeat(3);
            this.insert("\n\n" + fence + "taskhub\nscope: " + scope.value + (value ? "\nproject: " + value : "") + "\n" + fence + "\n\n");
            this.close();
        });
    }
    onClose() {
        this.contentEl.empty();
    }
}
class Migration extends HubModal {
    hub;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("接管旧版任务库");
        const { contentEl } = this;
        contentEl.createEl("p", {
            text: "选定旧 Markdown 目录后，先备份，再让 TaskHub 原地读取。旧笔记和 Tasks 查询继续使用原路径。"
        });
        const path = contentEl.createEl("label", {
            text: "旧任务库目录"
        }).createEl("input", {
            type: "text",
            value: defaults.folder
        });
        const status = contentEl.createEl("p", {
            attr: {
                "aria-live": "polite"
            }
        });
        const preview = contentEl.createEl("button", {
            text: "扫描"
        });
        const apply = contentEl.createEl("button", {
            text: "备份并接管",
            cls: "mod-cta"
        });
        apply.disabled = true;
        let approved = "";
        path.addEventListener("input", ()=>{
            approved = "";
            apply.disabled = true;
            status.empty();
        });
        preview.addEventListener("click", ()=>{
            try {
                const target = safePath(path.value);
                approved = "";
                apply.disabled = true;
                void this.hub.tasks(target, true).then((tasks)=>{
                    if (safePath(path.value) !== target) return;
                    status.setText(this.hub.files(target).length + " 个 Markdown 文件，识别到 " + tasks.length + " 条任务。");
                    approved = target;
                    apply.disabled = !tasks.length;
                }).catch(report);
            } catch (error) {
                report(error);
            }
        });
        apply.addEventListener("click", ()=>{
            if (!approved) return;
            apply.disabled = true;
            void this.hub.migrate(approved).then((result)=>{
                new Notice("接管 " + result.count + " 条任务 · " + result.backup, 8000);
                this.close();
            }).catch((error)=>{
                report(error);
                apply.disabled = false;
            });
        });
    }
    onClose() {
        this.contentEl.empty();
    }
}
class HubSettings extends PluginSettingTab {
    hub;
    constructor(hub){
        super(hub.app, hub), this.hub = hub;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        const draft = {
            ...this.hub.settings
        };
        new Setting(containerEl).setName("改到明天时提升普通或低优先级").setDesc("仅在 TaskHub 编辑截止日期且未同时修改优先级时，将普通或低优先级调整为中。").addToggle((t)=>t.setValue(draft.promoteTomorrow).onChange((value)=>{
                draft.promoteTomorrow = value;
            }));
        const fields = [
            [
                "folder",
                "Markdown 任务库目录"
            ],
            [
                "tag",
                "新任务的 Tasks 全局标记"
            ],
            [
                "queue",
                "外部录入队列目录"
            ],
            [
                "backups",
                "备份目录"
            ]
        ];
        for (const [field, label] of fields){
            new Setting(containerEl).setName(label).addText((t)=>t.setValue(draft[field]).onChange((v)=>{
                    draft[field] = v;
                }));
        }
        new Setting(containerEl).setName("联动已有待办目录").setDesc("每行一个库内目录；任务直接在原笔记更新，不复制。留空则只显示统一任务库。").addTextArea((t)=>t.setValue(draft.linkedFolders).onChange((v)=>{
                draft.linkedFolders = v;
            }));
        new Setting(containerEl).setName("自动导入外部录入").setDesc("启动后及每 15 秒检查队列。").addToggle((t)=>t.setValue(draft.autoImport).onChange((v)=>{
                draft.autoImport = v;
            }));
        new Setting(containerEl).addButton((b)=>b.setButtonText("保存设置").setCta().onClick(()=>{
                b.setDisabled(true);
                void this.hub.updateSettings(draft).then(()=>new Notice("TaskHub 设置已保存")).catch(report).finally(()=>b.setDisabled(false));
            }));
        new Setting(containerEl).setName("旧版迁移").addButton((b)=>b.setButtonText("扫描旧任务库").onClick(()=>new Migration(this.hub).open()));
    }
}
function showTasks(el, hub, tasks, group) {
    el.empty();
    if (!tasks.length) {
        el.createEl("p", {
            text: "没有符合条件的任务。",
            cls: "taskhub-muted"
        });
        return;
    }
    const projects = group ? [
        ...new Set(tasks.map((t)=>t.project))
    ].sort() : [
        ""
    ];
    for (const project of projects){
        if (group) el.createEl("h3", {
            text: project
        });
        const list = el.createEl("ul", {
            cls: "taskhub-list"
        });
        for (const task of group ? tasks.filter((t)=>t.project === project) : tasks){
            const row = list.createEl("li", {
                cls: "taskhub-row"
            });
            const toggle = row.createEl("input", {
                type: "checkbox",
                attr: {
                    "aria-label": "完成 " + task.title
                }
            });
            toggle.checked = finished(task);
            toggle.disabled = task.recurring || ![
                " ",
                "x",
                "X"
            ].includes(task.status) || /❌|\[cancelled::/u.test(task.metadata) || finished(task) && !!taskField(task, "repeat");
            if (toggle.disabled) toggle.title = "请在原笔记使用 Tasks 修改此状态。";
            toggle.addEventListener("change", ()=>{
                toggle.disabled = true;
                void hub.toggle(task).catch((error)=>{
                    toggle.checked = finished(task);
                    report(error);
                }).finally(()=>{
                    toggle.disabled = false;
                });
            });
            const text = row.createDiv({
                cls: "taskhub-text"
            });
            const displayTitle = task.title.split(/\s+/).filter((t)=>t !== hub.settings.tag).join(" ") || task.title;
            text.createDiv({
                text: displayTitle,
                cls: finished(task) ? "taskhub-done" : "taskhub-title"
            });
            const meta = text.createDiv({
                cls: "taskhub-meta"
            });
            for (const value of [
                task.category,
                task.project ? "项目 · " + task.project : "",
                task.priority
            ])if (value) meta.createEl("span", {
                text: value,
                cls: "taskhub-badge"
            });
            if (task.due) {
                const today = localDay();
                const late = !finished(task) && (task.due < today || task.due === today && !!task.time && task.time < clockTime());
                meta.createEl("span", {
                    text: (late ? "已逾期 · " : task.due === today ? "今天到期 · " : "截止 · ") + task.due + (task.time ? " " + task.time : ""),
                    cls: "taskhub-badge " + (late ? "taskhub-overdue" : task.due === today && !finished(task) ? "taskhub-today" : "")
                });
            }
            const completed = finished(task) ? completionStamp(task) : "";
            if (completed) meta.createEl("span", {
                text: "完成于 " + completed,
                cls: "taskhub-badge"
            });
            meta.createEl("span", {
                text: task.path,
                cls: "taskhub-source"
            });
            if (toggle.disabled) meta.createEl("span", {
                text: "循环或特殊状态 · 请在原笔记操作",
                cls: "taskhub-muted"
            });
            const actions = row.createDiv({
                cls: "taskhub-row-actions"
            });
            actions.createEl("button", {
                text: "编辑"
            }).addEventListener("click", ()=>new TaskEditor(hub, task).open());
            actions.createEl("button", {
                text: "安排"
            }).addEventListener("click", ()=>new TaskPlanning(hub, task).open());
            actions.createEl("button", {
                text: "原笔记"
            }).addEventListener("click", ()=>void hub.openSource(task).catch(report));
            if (!finished(task)) {
                const handle = row.createEl("span", {
                    text: "⠿",
                    cls: "taskhub-drag-handle",
                    attr: {
                        title: "按住拖到日历时段或日期格，松手排期"
                    }
                });
                let token = "", pointerId = 0, active = false;
                const frames = ()=>Array.from(document.querySelectorAll(".taskhub-calendar-frame"));
                const cleanup = ()=>{
                    if (!active) return;
                    active = false;
                    document.body.classList.remove("taskhub-pointer-dragging");
                    window.removeEventListener("keydown", onKey);
                };
                const cancelAll = ()=>{
                    const open = frames();
                    cleanup();
                    open.forEach((frame)=>frame.contentWindow?.postMessage({
                            type: "taskhub-pointer-drag",
                            action: "cancel"
                        }, "*"));
                    hub.endTaskDrag(token);
                };
                const onKey = (event)=>{
                    if (event.key === "Escape") cancelAll();
                };
                const begin = (event)=>{
                    if (active || event.button !== 0) return;
                    active = true;
                    pointerId = event.pointerId;
                    token = hub.beginTaskDrag(task, new DataTransfer());
                    try {
                        handle.setPointerCapture(pointerId);
                    } catch  {}
                    document.body.classList.add("taskhub-pointer-dragging");
                    window.addEventListener("keydown", onKey);
                    frames().forEach((frame)=>frame.contentWindow?.postMessage({
                            type: "taskhub-pointer-drag",
                            action: "begin",
                            token
                        }, "*"));
                    event.preventDefault();
                };
                const move = (event)=>{
                    if (!active) return;
                    for (const frame of frames()){
                        const rect = frame.getBoundingClientRect();
                        frame.contentWindow?.postMessage({
                            type: "taskhub-pointer-drag",
                            action: "move",
                            x: event.clientX - rect.left,
                            y: event.clientY - rect.top
                        }, "*");
                    }
                    event.preventDefault();
                };
                const finish = (event)=>{
                    if (!active) return;
                    const targets = frames().filter((frame)=>{
                        const rect = frame.getBoundingClientRect();
                        return event.clientX >= rect.left && event.clientX <= rect.right && event.clientY >= rect.top && event.clientY <= rect.bottom;
                    });
                    cleanup();
                    if (targets.length) {
                        for (const frame of targets){
                            const rect = frame.getBoundingClientRect();
                            frame.contentWindow?.postMessage({
                                type: "taskhub-pointer-drag",
                                action: "drop",
                                x: event.clientX - rect.left,
                                y: event.clientY - rect.top
                            }, "*");
                        }
                    } else frames().forEach((frame)=>frame.contentWindow?.postMessage({
                            type: "taskhub-pointer-drag",
                            action: "cancel"
                        }, "*"));
                    hub.endTaskDrag(token);
                };
                handle.addEventListener("pointerdown", begin);
                handle.addEventListener("pointermove", move);
                handle.addEventListener("pointerup", finish);
                handle.addEventListener("pointercancel", cancelAll);
            }
        }
    }
}
class Workbench extends ItemView {
    hub;
    query = {
        scope: "今天"
    };
    release;
    version = 0;
    tasks = [];
    sort = "due";
    constructor(leaf, hub){
        super(leaf), this.hub = hub;
    }
    getViewType() {
        return VIEW;
    }
    getDisplayText() {
        return "TaskHub";
    }
    getIcon() {
        return "list-todo";
    }
    async onOpen() {
        const el = this.contentEl;
        el.empty();
        el.addClass("taskhub");
        const header = el.createDiv({
            cls: "taskhub-header"
        });
        const heading = header.createDiv();
        heading.createEl("h2", {
            text: "任务工作台"
        });
        const subtitle = heading.createEl("p", {
            cls: "taskhub-muted"
        });
        const create = ()=>new TaskEditor(this.hub, undefined, {
                category: this.query.category ?? "",
                project: this.query.project ?? "",
                due: this.query.scope === "今天" ? localDay() : "",
                priority: this.query.priority === "none" ? "" : this.query.priority ?? ""
            }).open();
        const actions = header.createDiv({
            cls: "taskhub-header-actions"
        });
        actions.createEl("button", {
            text: "日历",
            attr: {
                title: "打开或关闭日历"
            }
        }).addEventListener("click", ()=>void this.hub.toggleCalendar().catch(report));
        actions.createEl("button", {
            text: "看板"
        }).addEventListener("click", ()=>new PlanningBoard(this.hub).open());
        const more = actions.createEl("details", {
            cls: "taskhub-more"
        });
        more.createEl("summary", {
            text: "更多"
        });
        const menu = more.createDiv({
            cls: "taskhub-more-menu"
        });
        const menuItem = (text, open)=>menu.createEl("button", {
                text
            }).addEventListener("click", ()=>{
                more.open = false;
                open();
            });
        menuItem("例行清单", ()=>new Routines(this.hub).open());
        menuItem("每周回顾", ()=>new WeeklyReview(this.hub).open());
        menuItem("完成记录", ()=>new CompletionStats(this.hub).open());
        actions.createEl("button", {
            text: "＋ 新建任务",
            cls: "mod-cta",
            attr: {
                "aria-keyshortcuts": "Q"
            }
        }).addEventListener("click", create);
        const nav = el.createDiv({
            cls: "taskhub-nav",
            attr: {
                "aria-label": "任务视图"
            }
        });
        const tabs = new Map();
        for (const scope of scopes){
            const button = nav.createEl("button", {
                text: scope
            });
            tabs.set(scope, button);
            button.addEventListener("click", ()=>{
                this.query.scope = scope;
                if (scope !== "全部") this.query.status = undefined;
                render();
            });
        }
        const toolbar = el.createDiv({
            cls: "taskhub-toolbar"
        });
        const search = toolbar.createEl("input", {
            type: "search",
            placeholder: "搜索任务、标签或项目…",
            value: this.query.search ?? "",
            attr: {
                "aria-label": "搜索任务"
            }
        });
        search.setAttribute("aria-keyshortcuts", "/");
        el.tabIndex = 0;
        this.registerDomEvent(el, "keydown", (event)=>{
            if (event.defaultPrevented || event.repeat || event.isComposing || event.altKey || event.shiftKey) return;
            if (event.key.toLowerCase() === "k" && (event.ctrlKey || event.metaKey)) {
                event.preventDefault();
                new TaskJump([
                    ...scopes.map((scope)=>[
                            scope,
                            ()=>{
                                this.query.scope = scope;
                                if (scope !== "全部") this.query.status = undefined;
                                render();
                            }
                        ]),
                    [
                        "日历",
                        ()=>void this.hub.openCalendar().catch(report)
                    ],
                    [
                        "看板",
                        ()=>new PlanningBoard(this.hub).open()
                    ],
                    [
                        "每周回顾",
                        ()=>new WeeklyReview(this.hub).open()
                    ]
                ], this.hub).open();
                return;
            }
            if (event.ctrlKey || event.metaKey) return;
            if (event.target?.closest("input,textarea,select,[contenteditable=true]")) return;
            if (event.key === "/") {
                event.preventDefault();
                search.focus();
            }
            if (event.key === "q") {
                event.preventDefault();
                create();
            }
        });
        const category = toolbar.createEl("select", {
            attr: {
                "aria-label": "分类"
            }
        });
        const project = toolbar.createEl("select", {
            attr: {
                "aria-label": "项目"
            }
        });
        const priority = toolbar.createEl("select", {
            attr: {
                "aria-label": "优先级"
            }
        });
        addOptions(priority, [
            ...priorityOptions("所有优先级"),
            [
                "none",
                "普通优先级"
            ]
        ], this.query.priority ?? "");
        const state = toolbar.createEl("select", {
            attr: {
                "aria-label": "状态"
            }
        });
        addOptions(state, [
            [
                "open",
                "未完成"
            ],
            [
                "done",
                "已完成"
            ],
            [
                "all",
                "全部状态"
            ]
        ], this.query.status ?? "open");
        const sorting = toolbar.createEl("select", {
            attr: {
                "aria-label": "排序"
            }
        });
        addOptions(sorting, [
            [
                "due",
                "默认排序"
            ],
            [
                "priority",
                "优先级优先"
            ],
            [
                "title",
                "任务名称排序"
            ]
        ], this.sort);
        const reset = toolbar.createEl("button", {
            text: "清除筛选"
        });
        const summary = el.createDiv({
            cls: "taskhub-summary"
        });
        const status = summary.createEl("p", {
            cls: "taskhub-muted",
            attr: {
                "aria-live": "polite"
            }
        });
        const retry = summary.createEl("button", {
            text: "刷新"
        });
        const list = el.createDiv();
        const clear = ()=>{
            this.query = {
                scope: this.query.scope
            };
            category.value = project.value = priority.value = search.value = "";
            state.value = "open";
            render();
        };
        let renderedSignature = "";
        reset.addEventListener("click", clear);
        const render = ()=>{
            const today = localDay();
            const overdue = filterTasks(this.tasks, {
                scope: "逾期"
            }, today, clockTime()).length;
            subtitle.setText(today + (overdue ? " · " + overdue + " 项逾期" : ""));
            for (const [scope, button] of tabs){
                button.setText(scope + " · " + filterTasks(this.tasks, {
                    scope: scope
                }, today, clockTime()).length);
                button.setAttribute("aria-pressed", String(this.query.scope === scope));
            }
            state.hidden = this.query.scope !== "全部";
            const active = this.query.scope === "全部" ? {
                ...this.query,
                status: this.query.status ?? "open"
            } : this.query;
            let result = filterTasks(this.tasks, active, today, clockTime());
            if (this.sort === "priority") {
                const rank = [
                    "🔺",
                    "⏫",
                    "🔼",
                    "",
                    "🔽",
                    "⏬"
                ];
                result = result.sort((a, b)=>rank.indexOf(a.priority) - rank.indexOf(b.priority));
            } else if (this.sort === "title") result = result.sort((a, b)=>a.title.localeCompare(b.title, "zh-CN"));
            const filtered = !!(this.query.category || this.query.project || this.query.priority || this.query.search || this.query.scope === "全部" && (this.query.status ?? "open") !== "open");
            reset.disabled = !filtered;
            status.setText((this.query.scope ?? "今天") + " · " + result.length + " 项" + (this.query.scope === "全部" && (this.query.status ?? "open") === "done" ? " · 已完成" : this.query.scope === "全部" && (this.query.status ?? "open") === "all" ? " · 全部状态" : "") + (filtered ? " · 已应用筛选" : "") + (this.query.scope === "今天" ? " · 今天到期；已过截止时间的任务也列入逾期" : ""));
            const signature = JSON.stringify([
                this.query,
                this.sort,
                today,
                clockTime(),
                result.map((task)=>[
                        task.path,
                        task.line,
                        task.raw
                    ])
            ]);
            if (signature === renderedSignature) return;
            renderedSignature = signature;
            showTasks(list, this.hub, result, this.query.scope === "项目");
            if (!result.length) {
                list.empty();
                const empty = list.createDiv({
                    cls: "taskhub-empty"
                });
                empty.createEl("h3", {
                    text: filtered ? "没有匹配的任务" : this.query.scope === "逾期" ? "当前没有逾期任务" : this.query.scope === "今天" ? "今天没有到期任务" : this.query.scope === "未排期" ? "所有待办都已排期" : "这里还没有任务"
                });
                empty.createEl("p", {
                    text: filtered ? "试试减少筛选条件，或换一个关键词。" : "可以添加任务，也可以切换到全部查看其他安排。",
                    cls: "taskhub-muted"
                });
                empty.createEl("button", {
                    text: filtered ? "清除筛选" : "添加任务",
                    cls: "mod-cta"
                }).addEventListener("click", filtered ? clear : create);
            }
        };
        const reload = async ()=>{
            const version = ++this.version;
            const tasks = await this.hub.tasks();
            if (version !== this.version) return;
            this.tasks = tasks;
            for (const [select, key, label] of [
                [
                    category,
                    "category",
                    "所有分类"
                ],
                [
                    project,
                    "project",
                    "所有项目"
                ]
            ]){
                select.empty();
                const values = [
                    ...new Set(tasks.map((t)=>t[key]).filter(Boolean))
                ].sort();
                if (this.query[key] && !values.includes(this.query[key])) values.push(this.query[key]);
                addOptions(select, [
                    [
                        "",
                        label
                    ],
                    ...values.map((s)=>[
                            s,
                            s
                        ])
                ], this.query[key] ?? "");
            }
            render();
        };
        const update = ()=>{
            this.query = {
                ...this.query,
                category: category.value,
                project: project.value,
                priority: priority.value,
                search: search.value,
                status: this.query.scope === "全部" ? state.value : undefined
            };
            this.sort = sorting.value;
            render();
        };
        toolbar.addEventListener("change", update);
        search.addEventListener("input", update);
        const refresh = ()=>void reload().catch((error)=>{
                status.setText("读取失败，点击刷新重试。当前列表可能不是最新数据。");
                report(error);
            });
        retry.addEventListener("click", refresh);
        status.setText("正在读取任务…");
        this.release = this.hub.subscribe(refresh);
        refresh();
    }
    async onClose() {
        this.version++;
        this.release?.();
    }
}
class InlineTasks extends MarkdownRenderChild {
    hub;
    source;
    version = 0;
    release;
    constructor(el, hub, source){
        super(el), this.hub = hub, this.source = source;
    }
    onload() {
        this.containerEl.addClass("taskhub");
        let query;
        try {
            query = parseQuery(this.source);
        } catch (error) {
            this.containerEl.setText(String(error));
            return;
        }
        const refresh = async ()=>{
            const version = ++this.version;
            try {
                const tasks = await this.hub.tasks();
                if (version === this.version) showTasks(this.containerEl, this.hub, filterTasks(tasks, query, localDay(), clockTime()), query.scope === "项目");
            } catch (error) {
                if (version === this.version) this.containerEl.setText(String(error));
            }
        };
        this.release = this.hub.subscribe(()=>void refresh());
        void refresh();
    }
    onunload() {
        this.version++;
        this.release?.();
    }
}
module.exports = TaskHub;
