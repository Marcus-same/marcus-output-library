﻿param([string]$Vault,[string]$Queue='00-任务中枢/TaskHub-录入队列',[switch]$SelfTest)
$ErrorActionPreference='Stop'

function Write-Capture([string]$Root,[string]$Relative,[hashtable]$Task) {
    $Task.title = ([string]$Task.title).Trim()
    if (-not $Task.title -or $Task.title.Length -gt 1000 -or $Task.title -match '[\r\n\x00]') { throw '请输入 1–1000 字的单行任务。' }
    foreach ($key in @('category','project')) {
        $value = ([string]$Task[$key]).Trim() -replace ' +','_'
        if ($value -and ($value.Length -gt 100 -or $value -notmatch '^[\p{L}\p{M}\p{N}_-]+(?:/[\p{L}\p{M}\p{N}_-]+)*$' -or $value -notmatch '[\p{L}_-]')) {
            throw '分类和项目需使用有效的标签名称，支持中文、字母和下划线。'
        }
        $Task[$key] = $value
    }
    if ($Task.due) { [void][DateTime]::ParseExact($Task.due,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture) }
    if (-not (Test-Path -LiteralPath (Join-Path $Root '.obsidian') -PathType Container)) {
        throw '请选择包含 .obsidian 目录的 Vault。'
    }
    $relativePath = $Relative.Trim().Replace('\','/').TrimEnd('/')
    if (!$relativePath -or ($relativePath.Split('/') | Where-Object { !$_ -or $_.StartsWith('.') -or $_ -match '[:*?"<>|\x00-\x1f]|[. ]$' })) {
        throw '请输入 Vault 内的相对队列目录。'
    }
    $folder = $Root
    foreach ($part in $relativePath.Split('/')) {
        $folder = Join-Path $folder $part
        [void][IO.Directory]::CreateDirectory($folder)
        if ((Get-Item -LiteralPath $folder -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
            throw '队列路径不能经过符号链接或目录联接。'
        }
    }
    $id = [Guid]::NewGuid().ToString()
    $entry = @{version=1;id=$id;source='windows';task=$Task} | ConvertTo-Json -Depth 4 -Compress
    $tmp = Join-Path $folder ($id+'.tmp')
    $dest = Join-Path $folder ($id+'.taskhub.json')
    [IO.File]::WriteAllText($tmp,$entry,[Text.UTF8Encoding]::new($false))
    [IO.File]::Move($tmp,$dest)
    return $dest
}

if ($SelfTest) {
    if (!$Vault) { throw 'SelfTest requires a temporary test vault.' }
    $task=@{title='验证中文录入';category='招聘';project='FDE';priority='⏫';due='2026-11-12'}
    Write-Capture $Vault $Queue $task
    return
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$cfgDir = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'TaskHub'
$cfgFile = Join-Path $cfgDir 'capture.json'
$hadQueue = $PSBoundParameters.ContainsKey('Queue')
if (!$Vault -and (Test-Path -LiteralPath $cfgFile)) {
    try {
        $cfg = Get-Content -LiteralPath $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json
        $Vault = $cfg.vault
        if (!$hadQueue -and $cfg.queue) { $Queue = $cfg.queue }
    } catch {}
}
$form = [Windows.Forms.Form]::new()
$form.Text = 'TaskHub 快捷录入'
$form.ClientSize = [Drawing.Size]::new(560,306)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = [Drawing.Font]::new('Microsoft YaHei UI',10)
function Add-Field($Name,[int]$Y,[int]$Width=410) {
    $label=[Windows.Forms.Label]::new()
    $label.Text=$Name
    $label.SetBounds(16,$Y+4,104,28)
    $form.Controls.Add($label)
    $field=[Windows.Forms.TextBox]::new()
    $field.SetBounds(124,$Y,$Width,28)
    $form.Controls.Add($field)
    return $field
}
$titleBox=Add-Field '任务内容' 16
$categoryBox=Add-Field '分类' 52
$projectBox=Add-Field '项目' 88
$dueBox=Add-Field '截止日期' 124
$dueBox.AccessibleDescription='YYYY-MM-DD'
$priorityLabel=[Windows.Forms.Label]::new()
$priorityLabel.Text='优先级'
$priorityLabel.SetBounds(16,164,104,28)
$form.Controls.Add($priorityLabel)
$priorityBox=[Windows.Forms.ComboBox]::new()
$priorityBox.SetBounds(124,160,410,28)
$priorityBox.DropDownStyle='DropDownList'
[void]$priorityBox.Items.AddRange(@('普通','最高','高','中','低','最低'))
$priorityBox.SelectedIndex=0
$form.Controls.Add($priorityBox)
$vaultBox=Add-Field 'Vault 路径' 196 337
$vaultBox.Text=$Vault
$choose=[Windows.Forms.Button]::new()
$choose.Text='选择…'
$choose.SetBounds(466,196,68,28)
$choose.Add_Click({
    $picker=[Windows.Forms.FolderBrowserDialog]::new()
    try {if ($picker.ShowDialog() -eq 'OK') {$vaultBox.Text=$picker.SelectedPath}} finally {$picker.Dispose()}
})
$form.Controls.Add($choose)
$queueBox=Add-Field '队列目录' 232
$queueBox.Text=$Queue
$save=[Windows.Forms.Button]::new()
$save.Text='保存到录入队列'
$save.SetBounds(366,267,168,30)
$form.Controls.Add($save)
$form.AcceptButton=$save
$save.Add_Click({
    $save.Enabled=$false
    try {
        $root=(Resolve-Path -LiteralPath $vaultBox.Text.Trim()).ProviderPath
        $task=@{title=$titleBox.Text;category=$categoryBox.Text;project=$projectBox.Text;due=$dueBox.Text.Trim();
            priority=@('','🔺','⏫','🔼','🔽','⏬')[$priorityBox.SelectedIndex]}
        [void](Write-Capture $root $queueBox.Text $task)
        try {
            [void][IO.Directory]::CreateDirectory($cfgDir)
            @{vault=$root;queue=$queueBox.Text} | ConvertTo-Json -Compress | Set-Content -LiteralPath $cfgFile -Encoding UTF8
        } catch { [void][Windows.Forms.MessageBox]::Show('任务已入队。本次未能保存下次启动的默认路径。','TaskHub') }
        $form.Close()
    } catch {
        [void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'TaskHub')
    } finally {$save.Enabled=$true}
})
$form.Add_Shown({$titleBox.Focus()})
[void]$form.ShowDialog()
$form.Dispose()

