param([switch]$SelfTest)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -Path (Join-Path $PSScriptRoot 'TaskHub-Wake.cs') -ReferencedAssemblies 'System.Windows.Forms.dll','System.Drawing.dll','System.dll'
if ($SelfTest) { [TaskHubWake]::SelfTest(); return }
try { [TaskHubWake]::Run() }
catch {
    [void][Windows.Forms.MessageBox]::Show($_.Exception.GetBaseException().Message,'TaskHub')
    exit 1
}

