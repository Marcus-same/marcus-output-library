@echo off
start "" powershell.exe -NoProfile -STA -WindowStyle Hidden -File "%~dp0TaskHub-Wake.ps1"

