TaskHub 1.12.5 本地补丁修复版
基于用户确认的 1.12.3 本地补丁版构建。
修复加载期间遗漏任务更新，以及刷新后旧编辑/删除确认窗口残留。
刷新后清理内部拖拽、指针拖拽及高亮状态。
28 项插件回归测试通过，主程序与日历脚本语法检查通过。
未完成真实 Obsidian 界面、跨窗拖拽、移动端端到端验证。
本次在本地补丁包 main.js 上应用可审查的小范围补丁，尚未将本地全部改动还原到 TypeScript 源码。
更新前备份插件目录，退出 Obsidian，替换 main.js、manifest.json、styles.css，保留 data.json。
测试：进入 taskhub 目录运行 node --test tests/plugin.test.cjs。
