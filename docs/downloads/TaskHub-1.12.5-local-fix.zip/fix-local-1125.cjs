const fs = require('node:fs');
const path = require('node:path');
const source = path.resolve('work/compare-local-patch');
const target = path.resolve('outputs/package-1.12.5-local/taskhub');
fs.mkdirSync(target, {recursive:true});
for (const file of ['main.js','styles.css','manifest.json','TaskHub-Wake.exe']) {
  fs.copyFileSync(path.join(source,file),path.join(target,file));
}
let main = fs.readFileSync(path.join(source,'main.js'),'utf8');
function replaceOnce(text,before,after) {
  if(text.split(before).length !== 2) throw Error('Patch target must occur exactly once: '+before);
  return text.replace(before,after);
}
main = replaceOnce(main,
  'if (closed || !ready) return;\n            if (busy) {\n                dirty = true;\n                return;\n            }',
  'if (closed) return;\n            if (busy) {\n                dirty = true;\n                return;\n            }\n            if (!ready) return;');
const lines = main.split('\n');
const calendarLine = lines[1];
let html = JSON.parse(calendarLine.slice(calendarLine.indexOf('=')+1).trim().slice(0,-1));
html = replaceOnce(html,
  "if(revision!==data.revision&&$('editor').open&&!waiting){",
  "if(revision!==data.revision){\n      dragging=null;pointerDrag=null;clearExternalDrag();\n      document.querySelectorAll('.target').forEach(el=>el.classList.remove('target'));\n    }\n    if(revision!==data.revision&&$('editor').open){");
new Function(html.split('<script>')[1].split('</script>')[0]);
lines[1] = 'const calendarHtml = '+JSON.stringify(html)+';';
fs.writeFileSync(path.join(target,'main.js'),lines.join('\n'));
const manifest = JSON.parse(fs.readFileSync(path.join(source,'manifest.json'),'utf8'));
manifest.version = '1.12.5';
fs.writeFileSync(path.join(target,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
fs.writeFileSync(path.join(target,'calendar.html'),html);
console.log(target);
