---
name: boss-hiring-assistant
description: 面向 BOSS 直聘招聘流程的中文 skill。在本招聘工作区中主要由 recruit-daily 调用，负责推荐池扩池、卡片初筛、右侧文字复筛和入选候选人的在线简历截图深判；站内沟通和约面仍由工作区原流程控制。
---

# Boss Hiring Assistant

## Marcus recruiting skill 集成边界（本工作区最高优先级）

当本 skill 由 `skills/recruit-daily/SKILL.md` 调用时，只执行 BOSS 推荐池的
`recommended_feed` 寻访与筛选，并先完整读取
`../recruit-daily/references/boss-recommend-integration.md`。该集成文档在本场景中优先于本 skill
后续关于画像存储、自动打招呼、聊天和约面的说明。

- 招聘标准只取工作区 `CONTEXT.md` 与 `01-jd/_internal/<role>.md`；不要读取或采用本 skill
  自带的 `company-policy.yaml`、`approval-policy.yaml`、`data/profile.json` 或历史候选人数据。
- 只做扩池、卡片初筛、在线简历深筛和结果回传；不发送招呼、不发消息、不约面，
  不点击平台的“不合适”。所有对外动作仍按 `recruit-daily` 的确认规则执行。
- 用户已明确要求：卡片初筛入选者先读取右侧文字，只有复筛后仍具潜力者才进一步截图深判。
  该授权只覆盖这些候选人的深筛截图，不覆盖全池截图、OCR 扫描或其他页面截图。
- 台账、去重、日报和关键词迭代仍由 `recruit-daily` 负责，本 skill 不另建事实源。
- 回传结果直接使用 `recruit-daily` 台账状态：`初筛通过 / 待确认 / 初筛不合适 / 已排除`，
  不再输出“强匹配／待人工确认／不匹配”等第二套同义分类。在线简历截图路径回传给
  `recruit-daily`，由其写入台账的 `简历路径` 列。
- 当 `CONTEXT.md` 能唯一确定一个本轮目标岗位且当前 BOSS 岗位不同，允许在复用的现有 BOSS tab
  内自动切岗；只有目标有歧义时才询问。切岗后必须核对可见岗位名与 `jobId`。对工作区事实源中
  已确认且能无歧义映射的筛选条件，按集成文档自动设置并校验；不得读取或回写本 skill 自带的
  `data/profile.json`，不得自行放宽条件或应用来源不明的历史筛选。

## 执行优先级

龙虾执行本 skill 时，必须按下面的优先级理解规则：

1. 阻断式前置条件
2. 浏览器路由硬规则
3. 当前服务文档
4. 发送 recipe
5. 其他补充文档

如果低优先级内容与高优先级内容冲突，一律以高优先级内容为准。

## 目标

这个 skill 只做三类服务，并且三类服务必须分开理解、分开执行：

1. `boss-screening`
只负责画像校对、读取岗位、读取候选人、按画像筛选、分类、汇报。
**首次执行 / 换岗位时必须先做画像校对**（询问岗位名称 + 9 个画像字段），
画像未确认前不得开始筛选。规格见 [profile-calibration.md](./references/profile-calibration.md)。
2. `boss-chat`
只负责 BOSS 站内沟通。
3. `boss-scheduling`
只负责候选人已确认时间后的企微约面。

如果用户没有明确指定服务类型，默认先进入 `boss-screening`。
不要把三类服务混在同一轮里自由串行。

## 入口意图识别（2026-09-19 重构）

> ⛔ **原「标准模式 / 快速打招呼模式」的二分已废除。只剩一条统一流程。**

原因：原「快速打招呼模式」的两个特征都已被其他规则吸收，保留它只会造成规则冲突——
它的前提「用户已设好筛选条件」= 现在的**线1 读面板**；它的「不暂停汇报」= 现在的**每三轮复核 + 复核通过自动继续**。

用户的一句话（例如「打20个安卓岗的招呼」）只需解析出**两件事**：

| 解析项 | 说明 | 缺失时 |
|--------|------|--------|
| **岗位** | 当前 BOSS 页面选中的岗位（`.job-selecter-wrap .ui-dropmenu-label`） | 读页面；读不到再问用户 |
| **目标人数** | 本轮要打多少个招呼 | **必须追问**，不得套用 `config.json` 的 `daily_target` |

其余信息（筛选条件从哪来、单轮上限、复核节奏）都是**执行细节**，按下面的固定流程走，
不需要用户每次交代。

**常见触发词**（仅作意图识别，不再切换流程）：
「帮我筛选候选人」「开始简历筛选」「打xx个xx岗招呼」「帮我打招呼」「联系xx个候选人」

### 筛选条件从哪来（唯一的分支点）

解析完岗位+目标人数后，先做一次**只读探针**判断筛选条件是否已配置好
（读 `筛选·N` 条件计数与分页请求参数，若全为默认值/计数为 0 → 未配置），然后分两条线：

```
入口：解析「岗位 + 目标人数」
   ↓
只读探针：筛选条件是否已配置好？
   ├─ 线1 用户已设好 ──→ 读面板 → 回读给用户确认 → 落库 profile.json
   └─ 线2 需要配置 ──┬─ 2a 首次配置 / 修改岗位筛选条件 → 用户口述 9 项 → 落库 → 代设面板
                     └─ 2b 复用已存 → 用 profile.json 代设面板
                                    ↓
                     进入「统一主干」
```

- **线1**（用户已设好）：**不代设、不改动面板任何选项**，直接以面板当前条件为画像来源；
  但仍要「读 → 回读确认 → 落库」，因为**轮次复核需要一个对照基准**。
- **线2a**（首次配置 / 用户要改）：需要用户**口述 9 项**。
  **用户口述只在首次配置或用户明确说要改的时候才发生，不是每次打招呼都要口述。**
- **线2b**（复用已存）：用 `data/profile.json` 里该岗位已确认的画像去设面板，不必再问一遍。

规格见 [profile-calibration.md](./references/profile-calibration.md)。

### 统一主干（六步）

```
① 校验面板条件已生效（筛选·N 计数 + 分页参数 + 预期计数比对）
② 扩池取样（推荐 + 最新两个 tab，浅→深，⛔ 不 reload）
③ 卡片初筛（岗位相关性过滤）
④ 详情精筛（读 .resume-right-side → 画像逐项核对 → 匹配 / 待定 / 不匹配）
⑤ 打招呼（单轮上限 5 人）
⑥ 闸门检查 ─┬─ 连续扫描 60 人仍 0 匹配 → 暂停 + 分析 + 汇报
            └─ 每满 3 轮做一次「轮次复核」
                 ├─ 全部符合 → 汇报本轮 → 自动继续下一轮
                 └─ 有不符合 → 立即停止 → 检查筛选条件 → 修正并经用户确认 → 继续
```

### 滚动加载最低人数（硬规则，2026-09-15 修订）

**不得在取样到 200 人之前断言或汇报「候选池已耗尽」。**

- 计数口径：`iframe.contentDocument.querySelectorAll('.candidate-card-wrap').length`
- 执行方式：`node scripts/human-scroll.mjs <targetId> <maxRounds> --min=200`
- 退出码：`0` = 已达最小人数或正常到底；`2` = 确认池底但仍未达最小人数
- 只有滚动到确认池底（连续 3 轮卡片数无增长）且仍不足 200 时，才可如实汇报实际数量

**关于「先滚还是先筛」（本次修订要点）：**

- 200 人规则的目的是**防止误判池子耗尽**，**不是**要求"必须滚满 200 才能开始筛选"
- **允许边滚边筛**：可以在滚动扩池的同时，对已加载的浅页批次开始筛选与打招呼
- **筛选顺序必须是浅→深**——推荐页相关性随翻页深度骤降（实测同一 Android 岗：
  排序第 1 页批次命中率 94%，第 11 页只剩 8%），详见
  [boss-recommend-read-recipe.md](./references/boss-recommend-read-recipe.md)「相关性随翻页深度衰减」章节
- **禁止**为了"回到浅页重新取样"而 reload 页面（会清空用户筛选条件，见上方 1.3）

硬性红线只有一条：**没取样到 200 人之前，不能说"池子耗尽"**。

**D1（2026-09-19 补充）：池子明显偏小时直接全量取。**

- 若滚动到确认池底（连续 3 轮无增长）后卡片总数不足 200，说明该画像下池子本身就小，
  **此时按全量取对待**，不纠结 200 门槛，如实汇报实际数量继续往下走
- 实测案例：Android 岗在「年龄22-29 + 第一学历985/211/双一流 + 近14天没看过」画像下，
  推荐/最新两个 tab 各只有 15 人（滚动 20 轮无增长），此时按 15 人全量处理

原因：BOSS 推荐页候选池远大于首屏，且 DOM 窗口会随滚动回收与批次轮换。只看首屏十几张就下结论会严重低估可筛范围（实测从 15 张可加载到 360 张）。

## 全岗位统一流程（硬规则）

无论当前操作哪个岗位，打招呼之前**必须**先完成筛选。统一流程如下：

```
读取当前岗位 → 筛选条件来源判定（线1读面板 / 线2配置） → 画像确认落库
  → 校验面板生效 → 扩池取样（浅→深） → 逐个筛选候选人（按画像逐项核对）
  → 标记分类 → 对「匹配」的候选人打招呼（单轮≤5人）
  → 闸门检查（连续60人0匹配则暂停） → **每满3轮做一次轮次复核** → 符合则自动继续 / 不符合则查筛选条件
```

> 完整分支图见上方「入口意图识别」章节。

具体规则：

1. **读取当前岗位**：识别当前 BOSS 页面选中的是哪个岗位（`.job-selecter-wrap .ui-dropmenu-label`）
2. **确定筛选条件来源（阻断式步骤）**：按「入口意图识别」章节的只读探针判定，走两条线之一：
   - **线1 · 用户已设好筛选条件**：用户明确说「**设置好了筛选条件**」时，
     **跳过面板设置环节**——不代设、不改动面板任何选项，直接以面板当前条件为画像来源。
     仍须做**只读**校验（读 `筛选·N` 条件计数 / 分页请求参数）确认条件已生效，
     **回读给用户确认后写入 `data/profile.json`**（线1 也要落库，因为轮次复核需要对照基准）。
   - **线2a · 首次配置 / 修改岗位筛选条件**：**必须询问用户**岗位名称 + 9 个画像字段
     （年龄、活跃度、院校含"是否为第一学历"、近期没有看过、性别、是否与同事交换简历、
     经验要求、学历要求），经确认后落库，再代设面板。
   - **线2b · 复用已存**：`data/profile.json` 已有该岗位画像且在有效期内 → 直接用它代设面板，不必再问。
   - **画像未确认前，禁止开始筛选或打招呼**
   - 完整规格见 [profile-calibration.md](./references/profile-calibration.md)
3. **校验面板条件已生效（C3，硬规则）**：开跑前必须比对
   「**预期条件计数** vs 面板实际计数」：

   ```
   预期计数 = Σ(各维度已选中的选项数) + (只看第一学历 ? 1 : 0)
   ```

   实测印证：年龄1 + 活跃度1 + 院校3 + 只看第一学历1 + 近期1 + 交换1 + 经验3 + 学历3 = **14**，
   按钮显示即「筛选·14」。

   - 计数不一致 → **暂停并通知用户**，不要带着错误条件往下筛
   - 目的：「只看第一学历」是最容易静默丢失的一项，丢了会导致双非第一学历的人被误放行
   - **★2026-09-19 实测更正**：该开关**确实会进入 URL 参数**，键名 `firstDegree`，
     勾选值为 `999`（实测 `firstDegree=999`）。
     此前文档写「不进 URL 参数」是**错的**。现在两种校验方式都可用：
     ① 分页参数 `firstDegree=999`
     ② 按钮计数「筛选·N」（13 不勾 → 14 勾上）
   - 局限：计数法只能判断"有没有勾"，判断不了勾的是哪项；参数法更直接，两者互为正交验证

4. **加载 policy 作为补充**：从 `company-policy.yaml` 按 `job.title` / `title_aliases` 匹配。
   **只用于画像未覆盖的维度**（如专项经验累计口径、JD 特有技能栈）；与画像冲突时**以画像为准**
5. **两步筛选（一人一事闭环）**：每张候选人卡片走两步：
   - 第一步「卡片初筛」：**工作经历岗位是主判断依据**。
     卡片上展示的工作经历岗位，必须与**当前筛选岗位**有明确关联，才开详情。
     「最近关注 / 期望」里的岗位名只是**求职意向标签，不等于有该方向的工作经验**。
     **若工作经历与当前筛选岗位的相关程度很低**（例如当前招 Android，而经历全是前端/后端/算法/测试/运维等），
     即使「最近关注」写着 Android，也**直接叉掉，不点开详情**。
     再用卡片可读的画像维度（年龄 / 学历 / 经验 / 院校 / 活跃度）过一遍
   - 第二步「详情精筛」：打开候选人在线简历（右侧面板），按画像**逐项核对**（卡片读不到的维度：性别、第一学历细节、经历累计），再按 policy 补充判定
     - 硬性维度（年龄/性别/学历/经验/院校）任一不满足 → `不匹配`
     - 软性维度（活跃度/近期没有看过/是否与同事交换简历）任一不满足 → `待定`（本次不打招呼，不淘汰）
   - **硬规则：处理完每位候选人后，必须先关闭详情面板，再进入下一位。不关闭面板会阻塞页面滚动，导致无法加载新卡片**
6. **只对「匹配」的候选人打招呼**：`不匹配` 与 `待定` 都不得打招呼
7. **单轮上限**：每轮打招呼达到上限后（默认 5 人）停止本轮，**自动进入下一轮**
   （A1，2026-09-19 用户确认：不需要每轮等用户确认）。

   > **轮次复核（硬规则，2026-09-19 用户规定）**
   >
   > **每满 3 轮做一次复核**（不是每轮）。周期内每轮打完**自动继续**，不打断用户。
   >
   > 复核时按顺序做三件事，不得跳过：
   >
   > 1. 列出本轮次（最近 3 轮）已打招呼的候选人
   > 2. **逐个复核是否符合当前画像**（按画像 9 维度逐项核对；卡片信息不足时开面板读完整履历），
   >    并产出**对照表 + 是否存在「系统性偏差」的结论**（判定阈值见
   >    [boss-greet-recipe.md](./references/boss-greet-recipe.md) 轮次复核章节：
   >    同一维度 ≥2 人不符，或占本轮次 ≥40%）
   > 3. 按复核结果分支：
   >    - **全部符合** → 输出简短汇报 → **自动继续下一轮**（不打断用户）
   >    - **有任何不符合 或 判定存在系统性偏差** → **立即停止打招呼**，回头检查筛选条件
   >      （画像取值 / 面板条件是否失效或与实际不符），
   >      修正并经用户确认后，才能继续打招呼
   >
   > **禁止**在「已打招呼的候选人存在不符合画像」或「存在系统性偏差」的情况下继续下一轮。
   > **禁止**为了凑人数而降低画像标准。

8. **B1 闸门：连续 60 人 0 匹配 → 暂停汇报**

   > 自**上次成功打招呼**起，累计扫描（含卡片初筛判不匹配 + 详情精筛判不匹配）达到 **60 人**
   > 仍无一人「匹配」时：
   > 1. **立即暂停**打招呼
   > 2. 做一次原因分析（按轮次复核的「检查筛选条件时查什么」四步排查）
   > 3. **通知并汇报给用户**（含 claw bot 推送提示，见「失败处理」章节）
   >
   > 60 人闸门与「权益耗尽检测」的"连续 50 张无 pass"是两个不同信号：
   > 前者判**筛选条件过窄**，后者判**权益/池子问题**，两者触发时都要暂停并汇报。
9. **启动前断点恢复**：每次启动打招呼前，必须先读取 `data/` 目录：
   - `candidates.json` → 跳过已处理候选人（**按 `job` 字段区分岗位**）
   - `progress.json` → **按岗位分片读取**：`jobs[current_job_title].current_greeted_count`
     继续计数（不从零开始）；顶层 `active_job` 指出上次在跑哪个岗位
   - **断线探针（B3）**：读文件前先探测 CDP 可用性
     （`curl -s -m 6 http://localhost:3456/targets`）；
     无响应 → 直接进入暂停态，通知用户重开 Chrome 并登录，**不要自行重试或换方案**
   - `config.json` → 确认当前岗位和目标数
   - `profile.json` → 确认当前岗位的画像已校对且在有效期内；缺失或过期则先补做画像校对
   - 如果 `quota_exhausted: true` 且未过 24 小时，先告知用户权益耗尽状态
10. **持续执行**：在达到目标数量之前，持续滚动加载→筛选→打招呼。到底部有"刷新"按钮时点击刷新继续加载。**不要因为当前批次质量差就停止**，目标未完成就一直滚

**禁止跳过的步骤**：

- ❌ 不允许不做筛选就直接打招呼
- ❌ 不允许按单一关键词（如"Android"）做粗筛代替画像校对
- ❌ 不允许跳过画像确认——**BOSS 页面上设好的筛选条件正是画像的来源，必须显式记录成画像并经用户确认**，
  不能停留在"页面上设了就算"的隐性状态。**线1（读面板）同样必须落库**
- ❌ 不允许用"用户说了打xx个招呼"来绕过筛选（该二分模式已废除，见「入口意图识别」）

**多岗位场景**：

- `data/profile.json` 与 `company-policy.yaml` 都支持多岗位配置
- **切换岗位时必须重新做画像校对**，不能沿用上一个岗位的画像
- 如果当前岗位在 profile / policy 中都没有配置，先走画像校对（必做），
  再基于 JD 生成默认 policy 作为补充，两者都经用户确认后再开始
- 不同岗位的候选人不能混在同一轮打招呼
- **状态按岗位隔离（C1，2026-09-19 新增）**：
  - `progress.json` 用 `jobs{ <岗位名>: {...} }` 分片存计数与已打名单，
    顶层 `active_job` 标识当前在跑的岗位；**切换岗位就是切换分片，不要手工清零**
  - `candidates.json` / `actions.json` 每条记录都带 `job` 字段，
    同一位候选人在不同岗位下是两条独立记录（`candidate_id` 含岗位关键词）
  - 并行跑 Java / Android / AI全栈 三个岗时，计数、已打名单、单轮序号**互不干扰**

## 首次安装后的介绍

用户首次安装这个 skill 后，必须先用中文向用户做一个简短介绍，再进入任何具体执行。

介绍内容至少包含：

1. 这个 skill 分成三类独立服务：
   - `boss-screening`：简历筛选和周期汇报
   - `boss-chat`：BOSS 站内沟通
   - `boss-scheduling`：企微约面
2. 推荐用户先从 `boss-screening` 开始
3. 后两类服务按需启动，不必首次安装时一起配置
4. 在任何浏览器接管开始前，必须先让用户在 Chrome 或 Chromium 浏览器里打开并登录 BOSS 直聘招聘者页面
5. `boss-screening` 覆盖三类候选人来源（主动聊天未读、推荐页、搜索页），核心按**画像校对 + 用户当次告知的目标人数**驱动，详见 screening 服务文档
6. 启动方式：
   - 用户说"先帮我做简历筛选"时进入 `boss-screening`
   - 用户说"帮我联系这些候选人"时进入 `boss-chat`
   - 用户说"帮我给这些候选人约面"时进入 `boss-scheduling`

如果用户没有明确选择，默认建议先从 `boss-screening` 开始。

在这一步没有完成前，不要：

- 直接进入 Boss 页面读取
- 直接开始筛选
- 直接开始发消息
- 直接开始企微约面

## 顶层硬规则

### 1. 浏览器访问只允许走 web-access

BOSS 页面上的所有读取、点击、切换线程、打开详情、发送消息，都必须先遵守：

- [browser-routing.md](./references/browser-routing.md)

这是一条硬规则，不是建议。

对于 `web-access` 的 eval 能力，必须先做最小探针验证请求写法正确，再执行复杂逻辑。
不要在 eval 传参方式未确认时直接跑复杂脚本。

对于 Boss 聊天页中的在线简历读取，默认优先走"左侧点击候选人卡片 + 右侧简历面板提取"的路径，不要先假设会跳转到独立 URL。

在 Boss 任务中，默认只允许操作用户当前已经登录的 Boss tab。
不要为了进入招聘后台或职位管理而新建 tab、新建窗口或新建浏览器上下文。

如果当前已登录 tab 存在，就必须复用它的 `targetId` 和同一 `browserContextId`。
不要通过 `web-access /new` 直接新开 Boss 页面再尝试进入后台。

如果 `targetId` 变化，不要立即要求用户确认登录状态。
必须先按 [browser-routing.md](./references/browser-routing.md) 中的规则自动重新绑定 Boss target，并做低成本登录态探针。

### 1.1 截图默认彻底禁止

在 BOSS 页面读取中，截图、OCR、图像理解默认彻底禁止。

如果 `web-access` 读取失败：

1. 允许在同一路径内最多再尝试 `2` 次
2. 如果仍失败，不允许自动切换到截图路径
3. 必须先向用户说明：
   - `web-access` 已尝试失败
   - 现在可以改走截图等异常方案
   - 这些方案可能增加 token 消耗，也可能提高 BOSS 风控或网页登录强退风险
   - 默认更建议继续坚持 `web-access`
4. 只有用户明确同意后，才允许临时启用截图等异常方案

### 1.2 三个高频致命坑（2026-09-14 实测，硬规则）

执行前先看这三条，踩中任意一条都会导致整轮空转。

**坑 1：iframe 内点击必须用 `/clickAtFrame`，不是 `/clickAt` + `::iframe::` 前缀**

web-access proxy 新版本已移除该前缀支持，旧写法会报
`SyntaxError: Failed to execute 'querySelector' ... is not a valid selector`。

```bash
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" \
  -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":"[data-workbuddy-greet-target=\"c1\"]"}'
```

`scripts/*.mjs` 已内置翻译层，脚本侧不用改；手工 curl 必须用新接口。

**坑 2：中文只能「文件进、JSON 出」**

- eval 脚本里写中文字面量 → 整个脚本挂掉，返回 `{"error":"Uncaught"}`，必须用
  `String.fromCharCode(...)`
- Windows 下 `node script.mjs "张三,李四"` 的 argv 中文会被破坏 → 姓名匹配失败
  （表现为 `NOT_FOUND_IN_DOM`），必须用 `--names-file=<UTF-8文件>`
- 给元素打的临时标记值一律用 **ASCII**（`c1` / `g1`）

**坑 3：推荐页相关性随翻页深度衰减，别一路滚到底**

实测同一 Android 岗：排序第 1 页批次命中率 94%（197/210），滚到第 11 页只剩 8%（16/240）。
正确节奏是「**在当前页按浅→深逐步取样**：浅页先筛先打 → 再逐步深滚扩池」。

⚠️ **不要靠 reload 推荐页来回到首屏**：reload 会把用户在页面上手动设置的
**平台侧筛选条件全部清零**（年龄/经验/学历/求职意向/薪资等）。
确需重载时必须先问用户，并在重载前记录当前请求参数以便恢复。

另外**切 tab 也会重置列表冲掉候选池**，不要随手切。

⚠️ **由此推出一条操作原则：筛完即打，不要「先筛一大批、再分批打」。**

2026-09-21 真实损失：先把 165 张批次筛出 31 位达标候选人，只打了 14 位就切 tab 去挖新池，
**切 tab 把整批换出，剩下 6 位已筛中但未打的候选人再也找不回来**（连换 3 个批次 + 最新 tab 均未复现）。
正确做法是**一批筛完立刻打掉**，把「已筛中未打」的窗口压到最小。

**坑 4：跑着的 proxy 可能不是这一份（端口被别的环境抢占）**

`web-access` 在多个环境各有一份副本（WorkBuddy 在 `~/.workbuddy/skills/web-access/`，
Claude Code / Codex 在 `~/.codex/skills/web-access/`）。**proxy 是长驻进程，
谁先占了 3456 就一直是谁**——端口只有一个。

2026-09-21 实测：`~/.codex` 那份（5 月旧版）占着端口，导致 `/clickAtFrame` 直接返回
`未知端点`，所有 iframe 内点击全废。排查与修复：

```bash
# 1) 看跑的是哪一份 —— ⚠️ 下面这条 PowerShell 写法在 WorkBuddy 环境**不可用**（见下方说明）
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='node.exe'\" | Where-Object { \$_.CommandLine -like '*cdp-proxy*' } | Select-Object ProcessId, CommandLine"

# 2) 停掉旧 proxy，再从正确路径重启
#    停：Stop-Process -Id <PID> -Force   （注意 Git Bash 里 taskkill //PID 会被吃掉参数）
#    启：node ~/.workbuddy/skills/web-access/scripts/check-deps.mjs

# 3) 验证端点存在（返回 attach 错误 = 端点存在；返回"未知端点" = 版本不对）
curl -s -X POST "http://localhost:3456/clickAtFrame?target=probe" \
  -H "Content-Type: application/json" --data-raw '{"frame":"x","selector":"x"}'
```

**⚠️ 环境限制（2026-09-21 实测，WorkBuddy 下必读）**：上面第 1 步的 PowerShell 探针**在本环境拿不到结果**：

| 手段 | 结果 |
|------|------|
| PowerShell 工具 | 只回显 `powershell.EXE` 路径，**无命令输出** |
| 从 Bash 调 `powershell -Command` | 被安全策略拦截（"Invoking PowerShell from Bash bypasses PowerShell security checks"） |
| `wmic process get CommandLine` | 系统级工具**已被禁用** |
| `tasklist /FO CSV \| grep -i node` | ✅ **可用**，但**只有 PID，没有命令行** |

**可用替代（按有效性排序）**：

```bash
# A) 看 proxy 启动日志 + 它的修改时间 —— 最有效：能判断"当前这份是什么时候起的"
tail -20 "$TEMP/cdp-proxy.log"; ls -la "$TEMP/cdp-proxy.log"

# B) 问 proxy 自己
curl -s http://localhost:3456/health
#    → {"status":"ok","connected":true,"browser":{...},"sessions":1,"chromePort":9222}
#    只能证明"有一个健康的 proxy"，**不能区分是哪一份**

# C) 列 node 进程（只有 PID）
tasklist /FO CSV | grep -i node
```

**判读要点**：`cdp-proxy.log` 里出现成片的「连接断开」「non-101 status code」
**多半是启动期的正常噪声**（浏览器发现重试），**不能据此判定 B3 断线**——
2026-09-21 就因此误判过一次（把启动期噪声当成连接抖动，写了暂停态）。
**要判"页面是否真的不稳"，必须用「静默观察法」**：

```bash
# 纯读、不写、多采样点，连续 4~5 次，每次间隔 4~5s
curl -s -X POST "http://localhost:3456/eval?target=$T" -H "Content-Type: text/plain" --data-raw '
var d=document.querySelector("iframe[src*=recommend]").contentDocument;
JSON.stringify({st:Math.round(d.documentElement.scrollTop), h:d.documentElement.scrollHeight,
 cards:d.querySelectorAll(".candidate-card-wrap").length});'
```

5 次读数**完全一致** → 页面稳定，问题在别处；**持续自走** → 才考虑连接/页面异常。
（★ 注意：自己刚写过 `scrollTop` 时不要立刻观察——平滑滚动动画会让读数"自己走"，
那是**自己写的**，不是页面不稳。）

**出现 `未知端点` 时的第一反应应该是查 proxy 来源路径，而不是改脚本。**

**坑 5：读不到「只看第一学历」≠ 面板没有它（条件渲染）**

`.first-degree-wrap`「只看第一学历」是**条件渲染**的：**只有当院校组选中了具体院校（非「不限」）
时才出现在 DOM 里**。院校未选中时读不到它，是**假阴性**，不是面板不支持。

2026-09-21 因此误判过「BOSS 已移除只看第一学历」（当时同一时刻还压着
「是否应用上次的筛选条件？ 取消 / 应用」横幅，一度把归因放在横幅上——**横幅不是原因**，
二者只是恰好同时出现）。判定顺序应为：

1. 读到 `.first-degree-wrap` → 支持
2. 读不到 + 院校组**未**选中具体院校 → **无法判定**，按「支持」计（设置流程里院校会先被选中）
3. 读不到 + 院校组**已**选中具体院校 → 判定为不支持

`apply-profile-filters.mjs` 的 `deduceFdSupport()` 已按此实现。

**另一条仍然成立的独立规则**：横幅（「是否应用上次的筛选条件?」）存在时面板确实尚未渲染完整，
**探查面板结构前应先点掉它（取消）**。脚本已内置这一步，手工 curl 探查时容易漏。

**坑 6：`clickAtFrame` 报「iframe target unavailable or obscured」= 元素在视口外，不是网络问题**

2026-09-21 实测：`round-execute.mjs` 在第 1 位候选人就崩，报
`clickAtFrame 失败: {"error":"iframe target unavailable or obscured"}`。
排查发现目标卡片在 `y=-13294`（视口外 1.3 万像素）——页面已滚到列表另一端，
而脚本只写了一次 `scrollTop`、睡 300~700ms 就点，**元素坐标还是陈旧的**。

**根因**：iframe 内是平滑滚动 + 一次修正量不够 + 布局未落定 → 点击坐标不可信。
**不是** CDP 断线、**不是** proxy 版本问题（对照坑 4：那种情况返回的是 `未知端点`）。

**修复**：`round-execute.mjs` 新增 `waitInView()` —— 打上标记后**轮询**
「读 `getBoundingClientRect().top` → 不在视口内就再修正 → 再读」，最多 8 轮，
到位才点；始终不到位就**放弃该人**（宁可跳过，也不能在坐标不可信时点击——会点到别人）。

**判别口诀**：`未知端点` → 查 proxy 来源；`unavailable or obscured` → 查元素是否在视口内。

**坑 7：eval 突然返回 `Uncaught` → 第一件事查 `location.href`，多半是风控验证页**

**症状**：之前正常的 eval 突然全部返回 `{"error":"Uncaught"}`，
连 `iframe[src*=recommend]` 都说 `has:false`。

**真因（2026-09-21 实测）**：页面被 BOSS 替换成了风控安全验证页——

```
url   : https://www.zhipin.com/web/passport/zp/verify.html?...&code=36
title : 安全验证 - BOSS直聘
正文  : 您的账号可能存在异常访问行为，完成验证后即可正常使用。点击按钮进行验证
iframes: []          ← recommend iframe 整个消失
```

iframe 没了 → 所有取 `contentDocument` 的表达式全部抛异常 → 表现为 `Uncaught`。
**若只盯着 `Uncaught` 去改脚本，会白排很久。**

**规则**：

1. 见到 `Uncaught` **先跑** `location.href` 与 `document.title`（不碰 iframe，必成功）
2. 命中 `passport/zp/verify.html` → **立即停止整轮**，进入风控暂停态，交用户手动过验证
3. **绝不可**尝试自动过验证、也不可重试点击（会加重风控）
4. 恢复后必须先做「静默观察」确认 recommend iframe 回来了、`筛选·N` 仍在，
   再按 C3 重新校验面板

**触发前的预兆**：本轮在**连续打开 3 位候选人详情面板**（演练模式，未打招呼）后即被拦截。
即"开面板"这个动作本身也在累积风控，不要把它当成零成本的只读操作。

**坑 8：`--dry` 不是只读演练（只跳过"打招呼"那一次点击）**

`round-execute.mjs` 里 `DRY` 只出现两次：定义 + **唯一一处使用**：

```js
if (decision === 'pass' && !DRY) { await greet(...); }   // ← 全脚本仅此一处
```

即**滚动、切 tab、为每个候选人开详情面板（真实 CDP 点击）全部照跑**。
dry 的交互足迹 ≈ 实跑减一次点击，**不能当"零风险只读"**。
（2026-09-21 我正是误当成安全操作，崩溃后连跑两次 dry，白白叠了一轮真实交互量。）

**控制交互量要用只读探针，不要用 dry**：C3 校验优先计数法
（`apply-profile-filters.mjs --check-only`，纯读）；参数法要"滚到底触发分页"，代价高得多。

**坑 9：Chrome 窗口宽度必须 ≥1040px，否则右侧按钮（筛选 / 打招呼）根本点不到**

**症状**：`clickAtFrame` 返回 `{"error":"iframe target outside viewport"}`。

**真因**：BOSS 聊天页布局宽度约 1040px。窗口比这窄时，
`iframe` 自身会横向溢出视口，**位于右端的「筛选」按钮落在视口之外**，真实鼠标点不到。

2026-09-21 实测：窗口 `outerWidth=800 / innerWidth=786`（屏幕 1280），
「筛选」按钮绝对坐标 `x=951` > 786 → 点不到；而**上午同一页面窗口宽 1048 时一切正常**。

**量测（纯读，1 次 eval）**：

```bash
curl -s -X POST "http://localhost:3456/eval?target=$T" -H "Content-Type: text/plain" --data-raw '
var f=document.querySelector("iframe[src*=recommend]"), fb=f.getBoundingClientRect(), d=f.contentDocument;
var b=d.querySelector(".fl.recommend-filter").getBoundingClientRect();
JSON.stringify({win:{w:innerWidth,h:innerHeight,outer:outerWidth},
  need:document.documentElement.scrollWidth, have:document.documentElement.clientWidth,
  btnAbsX:Math.round(fb.x+b.x+b.width/2), overflow:Math.round(fb.x+fb.width)-innerWidth});'
```

判据：`btnAbsX > innerWidth`（实测 `951 > 786`）或 `overflow > 0` → **窗口太窄，需用户最大化**。

**⛔ 不要用这两种"技巧"绕**：

| 绕法 | 为什么不行 |
|------|-----------|
| 设 `window.scrollX` 横向滚动 | 按钮能点到，但**左侧卡片被推出视口**，后续卡片点击全废 |
| 改用 DOM `element.click()` | 违反主路径要求；且风控刚触发时更不该用非鼠标事件 |

**正确处置**：**请用户把 Chrome 窗口最大化**（或宽度 ≥1100px），然后重测。这是环境前提，
不是脚本问题——**不要改脚本去适配窄窗口**。

**两个易混报错的区分**：

| 报错 | 含义 | 查什么 |
|------|------|--------|
| `iframe target outside viewport` | **iframe 自身**超出浏览器视口（窗口太窄/太小） | `innerWidth/outerWidth` vs 元素绝对坐标 |
| `iframe target unavailable or obscured` | 元素在 **iframe 内部滚动区域**之外（视口外/被遮挡） | 元素在 iframe 内的 `getBoundingClientRect().top`（见坑 6） |

详见 [execution-lessons-summary.md](./execution-lessons-summary.md) 第 12、12.1、14、19、20、21、22 节。

### 1.3 ⛔ 禁止刷新 / 重载 Boss 页面（用户明确要求，最高优先级）

**用户会自行在 Boss 页面上设置好筛选条件。龙虾任何时候都不得刷新或重载页面。**

禁止的动作（包括但不限于）：

- `POST /navigate` 到 `https://www.zhipin.com/web/chat/recommend` 或任何 Boss 页面
- 任何等价于浏览器 F5 / `location.reload()` 的操作
- 为了「拿排序第 1 页高相关批次」而重载推荐页
- 为了「重置列表 / 扩池」而重载推荐页

原因：重载会把用户在页面上手动设置的全部平台侧筛选条件清零
（年龄、活跃度、院校、性别、跳槽频率、专业、牛人关键词、经验要求、学历要求、
求职状态、薪资待遇），实测请求参数会回落成
`age=16,-1&experience=0&degree=0&gender=0&intention=0&salary=0`。

**正确做法：**

1. **在当前页面上继续滚动 / 翻页取样**，靠"浅→深逐步取样"控制相关性，不要重载
2. 页面上没有更多卡片时：优先滚动到底触发 `刷新 / 换一批` 按钮，
   或在三个 tab（推荐 / 精选 / 最新）之间切换取样
3. 确实认为需要重载时：**必须先停下来问用户**，得到明确同意才能执行

补充事实：

- 推荐页筛选条件**不写入 localStorage**，reload 后无法从存储找回
- Boss 自带恢复入口：打开筛选面板后顶部会出现
  「是否应用上次的筛选条件？ [取消][应用]」，其中 **应用 = `div.recover`**；
  但点击它同样属于改动用户设置的动作，**必须先经用户同意**
- 切换 tab 也会重置列表、冲掉已滚动加载的候选池，不要随手切

2026-09-15 发生过一次真实事故：龙虾为重载导致用户筛选条件全部丢失。

### 1.4 同事是否沟通过，不影响打招呼（2026-09-19 用户规定）

**详情面板里的「合作专享 · 同事沟通进度」区块，只作为信息参考，不作为跳过或判「待定」的依据。**

用户原话：**「同事是否沟通过不影响你打招呼」**。

- `同事沟通进度` 会列出同事（如同事A、同事B、同事C）向该候选人**发起沟通**的日期
- **即使同事在近一个月内、甚至昨天刚发起过沟通，也照常打招呼**
- 该区块的唯一用途：了解**竞争态势**（例如发现同事正在密集联系同一批候选人时，
  可以在汇报里提示用户「池子被同事先占了」），但**不改变判定结果**
- ⚠️ 注意区分两个不同信号：
  - 画像维度 **`是否与同事交换简历 = 近一个月没有`** —— 这是 **BOSS 平台侧的筛选条件**，
    由面板参数 `exchangeResumeWithColleague=1301` 控制，**仍然生效**
  - 面板里的 **`同事沟通进度`** —— 这是**信息展示**，不是筛选条件，**不参与判定**
- 平台把「交换简历」和「发起沟通」当作两个不同动作，所以**同事沟通过的人仍会出现在池子里**——
  这是正常现象，**不要因此判待定或叉掉**

### 2. BOSS 站内发消息必须走固定 recipe

只要进入 BOSS 站内消息发送，必须先读取并执行：

- [boss-send-recipe.md](./references/boss-send-recipe.md)

不要把该文档当参考说明。
不要再自行重新设计 DOM 路径、前端事件路径、子代理方案。

如果候选人线程都没有成功打开，就不得继续做输入框查找和发送动作。
但在暂停前，必须先把"自动打开候选人线程"的标准路径和有限备用路径走完。
不要一失败就要求用户代为点击候选人。

如果标准路径失败，下一步必须优先走低 token 的分层自动诊断，而不是直接进入长时间试错或大段脚本探索。

发送 Boss 站内消息时，必须做候选人身份校验，避免把给 A 的消息发给 B。

发送按钮点击路径也必须受控：

- 默认优先使用 `web-access clickAt`
- 其次才是底层 CDP 鼠标事件
- DOM `btn.click()` 只允许作为一次性兜底，不得作为默认主路径

特别是在批量打招呼时，不允许把 DOM click 当成标准实现。

对于"索要附件简历"类消息，发送后还必须继续跟进：

- 候选人是否已发送简历
- 是否出现"同意/接收"按钮
- 是否已点击完成接收

如果是批量打招呼或批量推进消息，还必须额外遵守：

- 小批量分轮发送
- 相邻发送之间加入短暂停顿
- 每发送 2 到 3 人做一次轻量状态校验
- 触发验证码、异常验证、登录态波动、页面异常跳转时立即停止整轮发送

如果首条打招呼发生在推荐页，还必须额外遵守：

- 禁止用 XPath 或 DOM 序号点击"第 N 个按钮"
- 必须先绑定稳定候选人标识，再点该候选人卡片内按钮
- 如果没有唯一 ID，必须先用 eval 给目标按钮临时写入 `data-*` 标记，再用 CSS selector 调 `clickAt` 或 `click`
- 必须按"一人一事务"执行，不要先识别一批人再回头批量点按钮
- 优先在当前推荐页完成成功确认，不要每打一人就默认跳聊天页确认
- 如果前几个候选人成功、后续连续失败，必须优先判断当日推荐牛人沟通权益是否耗尽
- 如果疑似权益耗尽，进入 `paused_for_boss_contact_quota_exhausted`，保留已筛选候选人，等待权益恢复或用户开通更多权益

### 2.1 默认不要把 Boss 浏览器控制下放给子代理

Boss 相关浏览器控制默认应由主执行流完成。

不要为了普通页面读取、进入后台、读取 JD、读取候选人列表、发送标准消息，而默认启动子代理接管浏览器。

只有在用户明确要求，或主执行流已经卡在非页面业务逻辑问题时，才允许考虑子代理。

### 3. 服务按入口执行

简历筛选：

- [boss-screening-service.md](./references/boss-screening-service.md)

站内沟通：

- [boss-chat-service.md](./references/boss-chat-service.md)

企微约面：

- [boss-scheduling-service.md](./references/boss-scheduling-service.md)

## 阻断式前置条件

在介绍完三类服务之后，再告诉用户该服务对应的强制前置条件。

所有服务共用的强制前置条件：

1. 由龙虾代为禁用或移除会抢占浏览器访问的 skill，包括但不限于 `browser-use`。
2. 由龙虾代为安装 `web-access`。
   - GitHub 链接：`https://github.com/eze-is/web-access`
3. 先要求用户在真实 Chrome 或 Chromium 浏览器里打开并登录 BOSS 直聘招聘者页面。
4. 把当前任务切换到 `web-access`。
5. 验证 `web-access` 已经接管当前 BOSS 任务。
6. 确认当前 Chrome / Chromium 中确实存在已登录的 Boss tab。
7. **每轮开始前的断线探针（B3，硬规则）**：先探 CDP 是否可用：

   ```bash
   curl -s -m 6 http://localhost:3456/targets
   ```

   - **无响应 / 连接断开循环** → 进入暂停态，通知用户：
     重开 Chrome 并登录 BOSS 招聘者页；若日志出现 `non-101 status code`，
     提示用户到 `chrome://inspect/#remote-debugging` 重新勾选远程调试授权
   - **不要**自行反复重试、不要新开 tab、不要改用截图或其它浏览器方案
   - 恢复后重新绑定 Boss target（targetId 会变化），再做一次低成本登录态探针

此外，对于 `boss-screening`，还有两个额外阻断条件：

8. **必须先完成画像确认**：按「入口意图识别」的两条线之一取得画像——
   - 线1（用户已设好条件）：**只读**读出面板条件 → **回读给用户确认** → 写入 `data/profile.json`
   - 线2a（首次 / 要改）：询问用户岗位名称 + 9 个画像字段
     （年龄、活跃度、院校及是否第一学历、近期没有看过、性别、是否与同事交换简历、
     经验要求、学历要求），经用户确认后写入 `data/profile.json`
   - 线2b（复用已存）：直接读取 `data/profile.json` 中该岗位仍在有效期内的画像

   详见 [profile-calibration.md](./references/profile-calibration.md)
9. **必须由用户告知本轮目标人数。**

   > **目标人数来源（硬规则，2026-09-19 用户规定）**
   > 目标人数**每次由用户当场告知**，不要默认套用 `config.json` 里的日目标。
   > `config.json` 中的 `daily_target` 只作为历史记录保留，不作为默认值。
   > **用户未告知目标人数时，先问，不要自行取数。**

**画像确认与目标人数任一未确认，禁止开始筛选。**

如果这些通用前置条件没有完成，禁止继续：

- 读取在线岗位
- 读取 JD
- 查看候选人
- 发站内消息
- 创建企微日程

如果用户还没有先在 Chrome 中登录 Boss 招聘者页面，也禁止开始"接管浏览器"这一步。

如果 `boss-screening` 的**本轮目标人数**（由用户告知）未明确，也禁止开始筛选。

不要自行搜索 `web-access` 的安装来源。
默认由龙虾先尝试代为安装；只有代装失败、权限不足或环境阻塞时，才让用户手动安装，并直接提供上面的 GitHub 链接。

对于 `browser-use` 等浏览器 skill，也默认由龙虾先代为禁用或移除。
不要先反问用户"是否已经禁用"。
完成后直接向用户汇报"已禁用/已移除"，只有在代办失败时才再向用户说明阻塞原因。

服务专属前置条件必须按需引导，不要一次性全部抛给用户：

- `boss-screening`：只需要通用前置条件
- `boss-chat`：需要通用前置条件，以及用户已明确批准哪些候选人进入沟通
- `boss-scheduling`：需要通用前置条件，以及用户已选择候选人进入约面；企微日程的配置只在第一次真实创建日程时再引导

不要跳过这些条件自行脑补默认答案。

## policy / 画像缺失时的默认处理

**筛选标准的第一来源是「画像校对」，不是 JD，也不是 policy。**

正确顺序必须是：

1. **先做画像校对**：按 [profile-calibration.md](./references/profile-calibration.md)
   询问用户 9 个画像字段（首次 / 换岗 / 过期时必须问，不得脑补默认值）
2. 画像确认落库后，再读取当前在线岗位和 JD
3. 基于 JD 生成一版默认 policy，**只用于画像未覆盖的维度**（专项经验口径、特有技能栈）
4. 向用户确认 policy 里与画像不一致或画像未涉及的部分

如果 `company-policy.yaml` / `approval-policy.yaml` 缺失，不要直接反问用户"筛选标准是什么"，
先问画像字段；画像里已经覆盖的维度不需要再问一遍。

默认标准的第二来源是 JD。
用户补充的是：

- 公司特有的人才观
- 硬性淘汰条件
- 审批边界
- 必须人工复核的情况

## 筛选服务核心规则（摘要）

`boss-screening` 的核心是**按画像校对候选人 + 按用户当次告知的目标人数推进**，
而非机械按时间节奏运行。

- **必须先完成「画像确认」**：线1（用户已设好条件）读面板并回读落库；
  线2a（首次 / 要改）询问岗位名称 + 9 个画像字段；线2b（复用已存）读取已有画像。
  画像未确认时禁止开始筛选
- 其次确认**本轮目标人数（用户当次告知）**；目标未明确时禁止开始筛选，
  不得套用 `config.json` 的 `daily_target`
- 新一轮默认只处理"未读/未处理候选人"，不重扫已完成旧候选人
- 不同来源判断依据不同：`inbound_chat` 以页面未读信号为主，`recommended_feed` 和 `search_results` 以任务记忆为主
- 时间窗口和汇报节奏是辅助规则，未指定时默认周一至周五 09:00-17:00，每 60 分钟汇报

详细规则见 [boss-screening-service.md](./references/boss-screening-service.md)。

## 企微边界

企微约面**优先走本 skill 自带的 [wecom-meeting-creator](./wecom-meeting-creator/SKILL.md)**，
它封装了"用 wecom-cli 建面试日程 + PDF 简历挂附件"的完整流程。

底层能力来自连接器 `connector-wecom` 提供的 `wecomcli-*` 系列 skill。

> ⚠️ **不存在名为 `wecomcli-schedule` 的 skill**（2026-09-15 核查）。
> 实际可用的是下面这些：`wecomcli-calendar`、`wecomcli-meeting`、`wecomcli-contact`、
> `wecomcli-message`、`wecomcli-email`、`wecomcli-doc`、`wecomcli-sheet`、
> `wecomcli-disk`、`wecomcli-todo`、`wecomcli-media`、`wecomcli-shared` 等。
> **创建日程用 `wecomcli-calendar`。**

命名区分：

- **CLI 命令**是 `wecom-cli`（带连字符），例如 `wecom-cli calendar schedules create ...`
- **skill 名**是 `wecomcli-*`（无连字符）

用户负责：

- 确保企微 CLI（`wecom-cli`）已安装并授权
- 确认企微日历权限已开通

龙虾负责：

- 调用 `wecomcli-calendar` 创建面试日程
- 添加参会人（候选人 + 面试官）
- 设置日程时间、地点、备注

**前置检查（硬规则）**：任何 `wecomcli-*` 调用前必须**先过 `wecomcli-shared` 的前置检查**：

1. CLI 版本 ≥ 1.1.0
2. `wecom-cli auth show --status` 返回 `authorized`

已知坑：机器人日程权限会过期（`errcode 850003`），需用户在企微中重新点授权链接。

第一次真的要创建企微日程时，才去确认 wecom-cli 是否已配置、授权是否已完成。

## 失败处理

所有强约束动作失败后，都必须进入"可恢复暂停态"，而不是继续长时间试错。

暂停时必须告诉用户：

1. 失败的是哪一步
2. 已经按最小快路径尝试过
3. 最可能原因
4. 用户现在最小需要做什么
5. 用户做完后如何恢复

不得把"继续试试看"当成默认策略。

### 暂停通知（2026-09-19 用户规定）

所有暂停共用一个出口，通知内容固定四段：**暂停原因 / 卡在哪一步 / 最小恢复动作 / 如何恢复**。

**触发暂停的场景**：断线(B3)、连续 60 人 0 匹配(B1)、面板计数校验不一致(C3)、
风控验证（验证码 / 安全验证页）、权益耗尽、画像未确认。

**推送渠道**：默认**只在对话里告知用户**。若要推送到微信，由**使用者自行连接
WorkBuddy 的 claw bot**——skill 不自行实现推送。

在每次暂停提示的末尾附一句：

> 如需微信推送，请连接 WorkBuddy 的 claw bot

`config.json` 中的配置位（默认关闭）：

```json
"notify": {
  "channel": "none",
  "note": "要推送到微信，请连接 WorkBuddy 的 claw bot 并在此处配置"
}
```

**实现状态**：推送路径当前**只留占位**，未实现具体发送。

## 脚本索引（scripts/）

> **岗位适配很重要**：下面两个脚本**只适配 Java 岗**，用错岗位会全员误判。

| 脚本 | 用途 | 岗位适配 |
|------|------|---------|
| `human-scroll.mjs` | 滚动加载候选池到 ≥200 人（拟人化分步滚动 + 回弹触底） | **通用** |
| `batch-read-resume.mjs` | 按姓名批量读在线简历（详情精筛），支持 `--names-file=` | **通用** |
| `greet-from-recommend.mjs` | 推荐页「一人一事务」打招呼闭环，含成功确认（含 `success_unconfirmed` 备用判据）与风控停顿 | **通用** |
| `apply-profile-filters.mjs` | 把 `profile.json` 的画像落到 BOSS 筛选面板（Vue 赋值设年龄滑块 + `/clickAtFrame` 点选项，含「只看第一学历」勾选与计数校验） | **通用** |
| `round-scan.mjs` | 批次轮换 + 卡片初筛 | ⚠️ **仅 Java 岗**（硬编码 985 + 北京 + Java） |
| `round-execute.mjs` | 轮换扫描 → 卡片初筛 → 详情精筛 → 打招呼 全流水线 | ⚠️ **仅 Java 岗**（硬编码 985 + 北京 + Java + 专职≥24月） |

**非 Java 岗（Android / AI全栈 / 大模型等）推荐组合**：

```bash
# 1) 扩池（不要 reload，见 1.3）
node scripts/human-scroll.mjs <targetId> 20 --min=200

# 2) 详情精筛（中文名单必须走 UTF-8 文件）
node scripts/batch-read-resume.mjs <targetId> --names-file=names.txt --chars=1200

# 3) 打招呼（单轮默认上限 5 人）
node scripts/greet-from-recommend.mjs <targetId> --names-file=names.txt --max=5
# 先加 --dry 演练，确认绑定无误再实打
```

脚本通用约定：

- 中文一律**文件进、JSON 出**（`--names-file` / `String.fromCharCode`），不要走 argv
- iframe 内点击一律走 `/clickAtFrame`，脚本内已封装 `clickAt()` 兼容层
- 所有间隔为随机值，不要改成固定 sleep

## 阅读顺序

1. 先读 [profile-calibration.md](./references/profile-calibration.md)（画像校对是筛选的起点）
2. 再读 [browser-routing.md](./references/browser-routing.md)
3. 再按当前服务读取：
   - [boss-screening-service.md](./references/boss-screening-service.md)
   - [boss-chat-service.md](./references/boss-chat-service.md)
   - [boss-scheduling-service.md](./references/boss-scheduling-service.md)
4. 如需发 BOSS 站内消息，再读 [boss-send-recipe.md](./references/boss-send-recipe.md)
5. 如需读取推荐页，再读 [boss-recommend-read-recipe.md](./references/boss-recommend-read-recipe.md)
6. 如需发送首条打招呼，再读 [boss-greet-recipe.md](./references/boss-greet-recipe.md)
7. 其他补充文档：
   - [policy-schema.md](./references/policy-schema.md)
   - [task-memory.md](./references/task-memory.md)
   - [trial-run.md](./references/trial-run.md)
