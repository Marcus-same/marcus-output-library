#!/usr/bin/env node
/**
 * round-execute.mjs — 一轮完整执行：轮换扫描 → 卡片初筛 → 详情精筛 → 打招呼
 *
 * ⚠️⚠️ 本脚本**只适配 Java 岗**（高级java研发工程师 / 中·高级java开发工程师）⚠️⚠️
 *
 *   判定逻辑里写死了 Java 岗 policy：
 *     - 卡片初筛要求「985 院校标签 + 期望含北京 + 工作经历含 Java」
 *     - 详情判定用 `javaMonths()` 正则解析「Java … N年M个月」
 *     - 技能判定要求后端技术栈关键词（Spring/MySQL/Redis/…）
 *
 *   **其他岗位（Android / AI全栈 / 大模型 等）不要用本脚本**，否则会全员误判
 *   （例如 Android 岗候选人在 `javaMonths()` 下一律得 0 个月而被全部 reject）。
 *
 *   Android 岗等非 Java 岗的正确工具链：
 *     1) human-scroll.mjs    —— 滚动加载候选池到 ≥200
 *     2) batch-read-resume.mjs --names-file=... —— 按姓名批量读简历做详情精筛
 *     3) greet-from-recommend.mjs --names-file=... —— 对通过的候选人打招呼
 *
 * 设计依据（skill 硬规则）：
 *   - 一人一事务闭环：命中候选人必须在其卡片仍在 DOM 时立刻开详情、判定、动作
 *     （批次轮换后卡片会被回收，事后按姓名回找命中率极低）
 *   - 每轮取样 ≥200 人（--min 由 human-scroll 负责；本脚本负责"边扫边办"）
 *   - 间隔随机：同候选人动作之间 2~5s，批次之间停顿随机
 *
 * 判定规则（Java 岗 policy 的可自动化部分）：
 *   1) 卡片：985 院校标签 + 期望城市含北京 + 工作经历段含 Java
 *   2) 详情：Java 专职经历累计 ≥ 24 个月（从面板文本 "岗位 起止 时长" 中解析）
 *   3) 技能：卡片标签至少命中一个后端技术栈关键词（Spring/MySQL/Redis/微服务/Kafka/MyBatis/JVM）
 *   满足 1+2+3 且不命中"继续沟通"（已沟通）→ 打招呼
 *
 * 用法：
 *   node round-execute.mjs <targetId> <batches> [--skip=names.txt] [--dry] [--max-greet=5] [--min-months=24]
 *   --dry  只判定不打招呼（演练）
 *
 * 输出：每行一条决策记录；结束打印汇总
 */

const BASE = process.env.WEB_ACCESS_BASE || 'http://localhost:3456';
const TARGET = process.argv[2];
const BATCHES = parseInt(process.argv[3] || '12', 10);
const skipArg = process.argv.find((a) => a.startsWith('--skip='));
const SKIP_FILE = skipArg ? skipArg.split('=')[1] : null;
const DRY = process.argv.includes('--dry');
const mmArg = process.argv.find((a) => a.startsWith('--min-months='));
const MIN_MONTHS = mmArg ? parseInt(mmArg.split('=')[1], 10) : 24;
const mgArg = process.argv.find((a) => a.startsWith('--max-greet='));
// 单轮打招呼上限：默认 5，遵循 approval-policy 的 max_batch_greet
// 2026-09-10 教训：未设上限连续打 15 人后 BOSS 触发安全验证页
const MAX_GREET = mgArg ? parseInt(mgArg.split('=')[1], 10) : 5;

if (!TARGET) {
  console.error('用法: node round-execute.mjs <targetId> <batches> [--skip=names.txt] [--dry]');
  process.exit(1);
}

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ts = () => new Date().toTimeString().slice(0, 8);

const TAB_REC = String.fromCharCode(25512, 33616); // 推荐
const TAB_LATEST = String.fromCharCode(26368, 26032); // 最新
const K_CONTINUE = String.fromCharCode(32487, 32493, 27807, 36890); // 继续沟通
const K_BEIJING = String.fromCharCode(21271, 20140); // 北京
const K_EXPECT = String.fromCharCode(26399, 26395); // 期望
const K_JAVA_YEAR = String.fromCharCode(24180); // 年
const K_JAVA_MONTH = String.fromCharCode(20010, 26376); // 个月

async function ev(js) {
  const res = await fetch(`${BASE}/eval?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: js,
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error);
  return JSON.parse(json.value);
}

// 兼容层：新 proxy（2026-09 起）用 POST /clickAtFrame + JSON body，
// 旧写法 `::iframe::xxx` 前缀在此内部自动翻译，调用点无需改。
const IFRAME_SEL = 'iframe[src*=recommend]';
async function clickAt(selector) {
  if (typeof selector === 'string' && selector.startsWith('::iframe::')) {
    const inner = selector.slice('::iframe::'.length);
    const r = await fetch(`${BASE}/clickAtFrame?target=${TARGET}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frame: IFRAME_SEL, selector: inner }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.clicked) throw new Error('clickAtFrame 失败: ' + JSON.stringify(j).slice(0, 200));
    return j;
  }
  await fetch(`${BASE}/clickAt?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: selector,
  });
}

const STATE_JS = `var d=document.querySelector('iframe').contentDocument;
JSON.stringify({cards:d.querySelectorAll('.candidate-card-wrap').length,
top:Math.round(d.documentElement.scrollTop),
h:d.documentElement.scrollHeight,
view:d.documentElement.clientHeight})`;

const SET_TOP = (y) => `var d=document.querySelector('iframe').contentDocument;
d.documentElement.scrollTop=${Math.max(0, Math.round(y))};
Math.round(d.documentElement.scrollTop)`;

const CLOSE_ALL = `var d=document.querySelector('iframe').contentDocument;
d.querySelectorAll('.dialog-wrap').forEach(function(w){w.remove()});JSON.stringify({closed:true})`;

/** 卡片初筛：返回本批命中候选人的 姓名 + 卡片标签 */
const FILTER_JS = `var BJ=${JSON.stringify(K_BEIJING)},QW=${JSON.stringify(K_EXPECT)},JX=${JSON.stringify(K_CONTINUE)};
var d=document.querySelector('iframe').contentDocument;
var out=[];
d.querySelectorAll('.candidate-card-wrap').forEach(function(c){
  var btn=c.querySelector('button');
  if(btn&&btn.innerText.indexOf(JX)>=0) return;
  var tags=Array.from(c.querySelectorAll('.tag-item')).map(function(e){return e.innerText.trim()});
  if(tags.join(',').indexOf('985')<0) return;
  var txt=c.innerText.split('\\n').map(function(s){return s.trim()}).filter(Boolean).join('|');
  var qi=txt.indexOf(QW);
  if(qi<0||txt.slice(qi).indexOf(BJ)<0) return;
  var leaves=[];
  c.querySelectorAll('*').forEach(function(e){if(e.children.length===0&&e.innerText&&e.innerText.trim())leaves.push(e)});
  var lt=-1;
  leaves.forEach(function(e,k){if(e.classList.contains('tag-item'))lt=k});
  var exp=leaves.slice(lt+1).map(function(e){return e.innerText.trim().replace(/\\s+/g,'')}).join('|');
  if(exp.indexOf('Java')<0) return;
  out.push({name:(c.querySelector('.name')||{}).innerText||'',tags:tags,exp:exp.slice(0,140)});
});
JSON.stringify(out)`;

const READ_PANEL = (chars) => `var d=document.querySelector('iframe').contentDocument;
var p=d.querySelector('.lib-standard-resume,.dialog-lib-resume');
JSON.stringify(p ? p.innerText.replace(/\\s+/g,' ').slice(0,${chars}) : 'NO_PANEL')`;

async function stepScrollToBottom() {
  for (let i = 0; i < 60; i++) {
    const s = await ev(STATE_JS);
    const maxTop = s.h - s.view;
    if (s.top >= maxTop - 50) return i;
    await ev(SET_TOP(Math.min(s.top + rand(400, 900), maxTop)));
    await sleep(rand(250, 700));
  }
  return 60;
}

async function bounceNudge() {
  const s = await ev(STATE_JS);
  const maxTop = s.h - s.view;
  await ev(SET_TOP(maxTop - rand(600, 1200)));
  await sleep(rand(250, 550));
  await ev(SET_TOP(maxTop));
}

async function switchTab(label) {
  const json = JSON.stringify(label);
  await ev(`var d=document.querySelector('iframe').contentDocument;
d.querySelectorAll('.tab-item').forEach(function(e){e.removeAttribute('data-lobster-tab')});
var tgt=null;
d.querySelectorAll('.tab-item').forEach(function(e){ if(e.innerText.trim()===${json}) tgt=e; });
if(tgt) tgt.setAttribute('data-lobster-tab','go');
JSON.stringify({marked:!!tgt})`);
  await sleep(rand(400, 900));
  await clickAt('::iframe::[data-lobster-tab="go"]');
  await sleep(rand(2500, 4000));
}

/** 解析面板文本中的 Java 专职时长（月） */
function javaMonths(panel) {
  const re = new RegExp('Java[^0-9]{0,6}(\\d+)\\s*' + K_JAVA_YEAR + '(?:\\s*(\\d+)\\s*' + K_JAVA_MONTH + ')?', 'g');
  let total = 0;
  let m;
  while ((m = re.exec(panel)) !== null) {
    total += parseInt(m[1], 10) * 12 + (m[2] ? parseInt(m[2], 10) : 0);
  }
  return total;
}

/**
 * 滚动到位轮询：打上 data-lobster-open 之后，必须等元素**真正进入视口**再点。
 *
 * 2026-09-21 实测事故：单次写 scrollTop 后立刻点击，元素坐标是陈旧的
 * （目标卡片在 `y=-13294`，视口外 1.3 万像素），clickAtFrame 直接返回
 * `{"error":"iframe target unavailable or obscured"}`，导致整轮在第 1 个人就崩掉。
 *
 * 根因不是网络/连接，而是**写入后没等布局与滚动动画落定**：
 *   - iframe 内是平滑滚动，写入后仍在动画中
 *   - 目标可能远在列表另一端，一次修正量不够
 * 故改为「读 rect → 若不在视口就修正 → 再读」，最多 tries 轮；仍未到位就放弃该人
 * （宁可跳过，也不要在坐标不可信的情况下点击——可能点到别的候选人）。
 */
async function waitInView(tries = 8) {
  for (let i = 0; i < tries; i++) {
    const r = await ev(`var d=document.querySelector('iframe').contentDocument;
var el=d.querySelector('.candidate-card-wrap[data-lobster-open="s"] .name');
if(!el){JSON.stringify({gone:true});}else{
  var b=el.getBoundingClientRect(), v=d.documentElement.clientHeight;
  if(b.top>=0 && b.top<=v-140){JSON.stringify({ok:true,top:Math.round(b.top)});}else{
    d.documentElement.scrollTop=d.documentElement.scrollTop+b.top-200;
    JSON.stringify({ok:false,top:Math.round(b.top)});}
}`);
    if (r && r.gone) return null;
    if (r && r.ok) return r.top;
    await sleep(rand(180, 340));
  }
  return null;
}

/** 打开指定候选人详情，返回面板文本 */
async function openDetail(name) {
  const json = JSON.stringify(name);
  // 同名唯一性校验：命中必须唯一，否则宁可放弃也不要冒险给错人打招呼
  const meta = await ev(`var d=document.querySelector('iframe').contentDocument;
var cs=d.querySelectorAll('.candidate-card-wrap');
cs.forEach(function(c){c.removeAttribute('data-lobster-open')});
var hit=null, n=0;
cs.forEach(function(c){var e=c.querySelector('.name');if(e&&e.innerText.trim()===${json}){n++;hit=c;}});
if(n!==1){JSON.stringify({ok:false,matched:n});}else{
  hit.setAttribute('data-lobster-open','s');
  var r=hit.getBoundingClientRect();
  d.documentElement.scrollTop=d.documentElement.scrollTop+r.top-200;
  JSON.stringify({ok:true,matched:n});
}`);
  if (!meta.ok) {
    if (meta.matched > 1) console.log(`[${ts()}] ⚠️ ${name} 同名 ${meta.matched} 人，已跳过（避免误触达）`);
    return null;
  }
  // ★ 必须等到真正进入视口再点，否则报 iframe target unavailable or obscured
  const inView = await waitInView();
  if (inView === null) {
    console.log(`[${ts()}] ⚠️ ${name} 卡片未能滚入视口，跳过（坐标不可信时不点击）`);
    return null;
  }
  await sleep(rand(200, 450));
  await clickAt('::iframe::.candidate-card-wrap[data-lobster-open="s"] .name');
  await sleep(rand(1200, 2200));
  // 面板文本读 1600 字符：需要覆盖位于面板末尾的「同事沟通进度」区块
  let text = await ev(READ_PANEL(1600));
  if (text === 'NO_PANEL') {
    await sleep(rand(800, 1500));
    if (await waitInView(4) === null) return null;
    await clickAt('::iframe::.candidate-card-wrap[data-lobster-open="s"] .name');
    await sleep(rand(1200, 2000));
    text = await ev(READ_PANEL(1600));
  }
  return text === 'NO_PANEL' ? null : text;
}

/** 打招呼：点击详情面板内的打招呼按钮，并验证成功 */
async function greet(name) {
  const ok = await ev(`var d=document.querySelector('iframe').contentDocument;
var b=d.querySelector('.btn-sure-v2.btn-greet');
if(b) b.setAttribute('data-lobster-greet','g');
JSON.stringify({marked:!!b})`);
  if (!ok.marked) return { ok: false, reason: 'no_greet_button' };

  await sleep(rand(2000, 5000)); // 风控：随机停顿
  await clickAt('::iframe::[data-lobster-greet="g"]');
  await sleep(rand(2200, 3200));

  const json = JSON.stringify(name);
  const res = await ev(`var d=document.querySelector('iframe').contentDocument;
var b=d.querySelector('[data-lobster-greet="g"]');
var cs=d.querySelectorAll('.candidate-card-wrap');
var hit=null;
cs.forEach(function(c){var n=c.querySelector('.name');if(n&&n.innerText.trim()===${json})hit=c;});
var cb=hit?hit.querySelector('button'):null;
JSON.stringify({panel:b?b.innerText.trim():'gone',card:cb?cb.innerText.trim():'none'})`);
  const v = res;
  const success = v.panel === 'gone' || v.card.indexOf(K_CONTINUE) >= 0;
  return { ok: success, detail: v };
}

(async () => {
  const skip = new Set();
  if (SKIP_FILE) {
    const fs = await import('node:fs');
    if (fs.existsSync(SKIP_FILE)) {
      fs.readFileSync(SKIP_FILE, 'utf8').split('\n').map((s) => s.trim()).filter(Boolean).forEach((n) => skip.add(n));
      console.log(`[${ts()}] 跳过名单：${skip.size} 人`);
    }
  }

  const done = new Set(skip);
  const greeted = [];
  const rejected = [];
  const tabs = [TAB_REC, TAB_LATEST];

  for (let b = 1; b <= BATCHES; b++) {
    await stepScrollToBottom();
    const nudges = rand(1, 3);
    for (let n = 0; n < nudges; n++) {
      await bounceNudge();
      await sleep(rand(1200, 2600));
    }

    if (greeted.length >= MAX_GREET) {
      console.log(`[${ts()}] 已达单轮打招呼上限 ${MAX_GREET} 人，暂停本轮（分轮执行以降低风控风险）`);
      break;
    }

    const hits = await ev(FILTER_JS);
    const todo = hits.filter((h) => h.name && !done.has(h.name));
    const st = await ev(STATE_JS);
    console.log(`[${ts()}] batch ${b}: 本批 ${st.cards} 张 | 卡片命中 ${hits.length} | 待办 ${todo.length}`);

    for (const h of todo) {
      const bonusTag = /Spring|MySQL|Redis|微服务|Kafka|MyBatis|JVM/i.test(h.tags.join(','));
      const panel = await openDetail(h.name);
      if (!panel) {
        console.log(`${h.name}|跳过|详情未打开`);
        done.add(h.name);
        continue;
      }
      const months = javaMonths(panel);
      // 2026-09-10 用户确认标准：第一学历985 + 期望北京 + Java专职累计>=MIN_MONTHS
      // 技术栈标签（bonusTag）只作为加分项记录，不作为阻断条件
      const decision = months >= MIN_MONTHS ? 'pass' : 'reject';
      const why =
        months >= MIN_MONTHS
          ? bonusTag
            ? '满足 hard_pass（含技能标签加分）'
            : '满足 hard_pass（技能标签缺失，记加分项待复核）'
          : `Java 累计 ${months} 个月（<${MIN_MONTHS}）`;

      if (greeted.length >= MAX_GREET) {
        console.log(`[${ts()}] 已达单轮上限 ${MAX_GREET} 人，跳过剩余候选人`);
        break;
      }

      if (decision === 'pass' && !DRY) {
        const g = await greet(h.name);
        if (g.ok) {
          greeted.push(h.name);
          console.log(`[${ts()}] ${h.name}|打招呼成功|Java ${months}个月|标签 ${h.tags.join(',')}`);
        } else {
          rejected.push(h.name);
          console.log(`[${ts()}] ${h.name}|打招呼失败|${JSON.stringify(g.detail || g.reason)}`);
        }
      } else {
        rejected.push(h.name);
        console.log(`[${ts()}] ${h.name}|${decision}|${why}|Java ${months}个月|标签 ${h.tags.join(',')}`);
      }
      done.add(h.name);

      await ev(CLOSE_ALL);
      await sleep(rand(1500, 3500));
    }

    await switchTab(tabs[b % tabs.length]);
  }

  console.log('--- 汇总 ---');
  console.log(`打招呼成功 ${greeted.length} 人: ${greeted.join(', ') || '无'}`);
  console.log(`未打招呼 ${rejected.length} 人`);
  const fs = await import('node:fs');
  fs.writeFileSync(
    'C:/Users/Administrator/AppData/Local/Temp/round-greeted.txt',
    greeted.join('\n'),
    'utf8'
  );
  process.exit(0);
})().catch((e) => {
  console.error('执行失败:', e.message);
  process.exit(1);
});
