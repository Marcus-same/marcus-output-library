#!/usr/bin/env node
/**
 * human-scroll.mjs — BOSS 推荐页拟人化滚动加载（v3）
 *
 * 用途：以随机步长、随机间隔分步滚动 iframe 内候选人列表，触发懒加载；
 *       在单标签停滞时通过标签轮换继续累积候选人，直到达到最小人数或确认池底。
 *
 * 用法：
 *   node human-scroll.mjs <targetId> [maxRounds] [--min=200] [--rotate] [--out=names.txt]
 *
 * 硬规则：BOSS 招聘任务中，每轮筛选前必须把候选人取样到至少 200 人（--min=200）。
 *
 * 关键机制：
 *   1) 触底后只设同一个 scrollTop 不会产生 scroll 事件 → 加载器不唤醒；
 *      必须"回弹式触底"：先回退几百像素，再滑到底。
 *   2) 单标签被日限额卡住时（DOM 只保留 15 张且滚动不增长），
 *      用 --rotate 在「推荐 / 最新」之间轮换，每次轮换会拿到一批新候选人。
 *
 * 退出码：
 *   0 = 达到最小人数
 *   2 = 已尽力（含标签轮换）仍未达最小人数
 *   1 = 参数或连接错误
 */

const BASE = process.env.WEB_ACCESS_BASE || 'http://localhost:3456';
const TARGET = process.argv[2];
const MAX_ROUNDS = parseInt(process.argv[3] || '20', 10);
const minArg = process.argv.find((a) => a.startsWith('--min='));
const MIN_CARDS = minArg ? parseInt(minArg.split('=')[1], 10) : 0;
const ROTATE = process.argv.includes('--rotate');
const outArg = process.argv.find((a) => a.startsWith('--out='));
const OUT = outArg ? outArg.split('=')[1] : null;

if (!TARGET) {
  console.error('用法: node human-scroll.mjs <targetId> [maxRounds] [--min=200] [--rotate] [--out=names.txt]');
  process.exit(1);
}

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ts = () => new Date().toTimeString().slice(0, 8);

// 「推荐」「最新」的字符编码，避免 shell 传参时中文被破坏
const TAB_REC = String.fromCharCode(25512, 33616); // 推荐
const TAB_LATEST = String.fromCharCode(26368, 26032); // 最新

async function ev(js) {
  const res = await fetch(`${BASE}/eval?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: js,
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error);
  return JSON.parse(json.value);
}

// 兼容层：新 proxy（2026-09 起）用 POST /clickAtFrame + JSON body，
// 旧写法 `::iframe::xxx` 前缀在此内部自动翻译，调用点无需改。
const IFRAME_SEL = 'iframe[src*=recommend]';
async function clickAt(selector) {
  if (typeof selector === 'string' && selector.startsWith('::iframe::')) {
    const inner = selector.slice('::iframe::'.length);
    const r = await fetch(`${BASE}/clickAtFrame?target=${TARGET}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frame: IFRAME_SEL, selector: inner }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.clicked) throw new Error('clickAtFrame 失败: ' + JSON.stringify(j).slice(0, 200));
    return j;
  }
  await fetch(`${BASE}/clickAt?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: selector,
  });
}

const STATE_JS = `var d=document.querySelector('iframe').contentDocument;
JSON.stringify({
  cards: d.querySelectorAll('.candidate-card-wrap').length,
  top: Math.round(d.documentElement.scrollTop),
  h: d.documentElement.scrollHeight,
  view: d.documentElement.clientHeight,
  tab: (d.querySelector('.tab-item.curr')||{}).innerText || ''
})`;

const NAMES_JS = `var d=document.querySelector('iframe').contentDocument;
var ns=[];d.querySelectorAll('.candidate-card-wrap').forEach(function(c){
  var n=c.querySelector('.name'); if(n && n.innerText.trim()) ns.push(n.innerText.trim());
});
JSON.stringify(ns)`;

const SET_TOP = (y) => `var d=document.querySelector('iframe').contentDocument;
d.documentElement.scrollTop=${Math.max(0, Math.round(y))};
Math.round(d.documentElement.scrollTop)`;

async function stepScrollToBottom() {
  let steps = 0;
  for (;;) {
    const s = await ev(STATE_JS);
    const maxTop = s.h - s.view;
    if (s.top >= maxTop - 50) break;
    await ev(SET_TOP(Math.min(s.top + rand(400, 900), maxTop)));
    steps++;
    await sleep(rand(250, 700));
    if (steps > 60) break;
  }
  return steps;
}

async function bounceNudge() {
  const s = await ev(STATE_JS);
  const maxTop = s.h - s.view;
  await ev(SET_TOP(maxTop - rand(600, 1200)));
  await sleep(rand(250, 550));
  await ev(SET_TOP(maxTop));
}

/** 切换到目标标签（返回是否成功切换） */
async function switchTab(label) {
  const json = JSON.stringify(label);
  await ev(`var d=document.querySelector('iframe').contentDocument;
d.querySelectorAll('.tab-item').forEach(function(e){e.removeAttribute('data-lobster-tab')});
var tgt=null;
d.querySelectorAll('.tab-item').forEach(function(e){ if(e.innerText.trim()===${json}) tgt=e; });
if(tgt) tgt.setAttribute('data-lobster-tab','go');
JSON.stringify({marked: !!tgt})`);
  await sleep(rand(400, 900));
  await clickAt('::iframe::[data-lobster-tab="go"]');
  await sleep(rand(2500, 4000));
}

(async () => {
  const seen = new Set();
  let switchesWithoutNew = 0;
  const tabCycle = [TAB_REC, TAB_LATEST];
  let cycleIdx = 0;

  // 续跑：若 --out 文件已存在，先读入已有名单，避免重复计数
  if (OUT) {
    const fs = await import('node:fs');
    if (fs.existsSync(OUT)) {
      fs.readFileSync(OUT, 'utf8')
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean)
        .forEach((n) => seen.add(n));
      console.log(`[${ts()}] 续跑模式：已载入历史名单 ${seen.size} 人`);
    }
  }

  for (let round = 1; round <= MAX_ROUNDS; round++) {
    const before = await ev(STATE_JS);
    const steps = await stepScrollToBottom();
    const nudges = rand(1, 3);
    for (let n = 0; n < nudges; n++) {
      await bounceNudge();
      await sleep(rand(1500, 3500));
    }
    const after = await ev(STATE_JS);

    const names = await ev(NAMES_JS);
    let fresh = 0;
    names.forEach((n) => {
      if (!seen.has(n)) {
        seen.add(n);
        fresh++;
      }
    });

    console.log(
      `[${ts()}] round ${round}: 分步 ${steps} 段 + 回弹 ${nudges} 次 | 本批 ${after.cards} 张 (新增 ${fresh}) | 累计去重 ${seen.size} 人 | 高度 ${after.h}`
    );

    if (MIN_CARDS > 0 && seen.size >= MIN_CARDS) {
      console.log(`[${ts()}] 已达到最小取样人数（${seen.size} >= ${MIN_CARDS}），可以开始筛选`);
      break;
    }

    // 单标签停滞：若开启轮换，切换标签拿新批次
    if (after.cards === before.cards && fresh === 0) {
      if (ROTATE) {
        if (fresh === 0) switchesWithoutNew++;
        cycleIdx = (cycleIdx + 1) % tabCycle.length;
        const target = tabCycle[cycleIdx];
        console.log(`[${ts()}] 本标签停滞，轮换到「${target}」拉取新批次`);
        await switchTab(target);
        if (switchesWithoutNew >= 8) {
          console.log(`[${ts()}] 连续 8 次轮换无新增，判定已无更多可取样候选人（累计 ${seen.size} 人）`);
          break;
        }
      } else {
        console.log(`[${ts()}] 本标签无增长（未开启 --rotate），当前累计 ${seen.size} 人`);
        break;
      }
    } else {
      switchesWithoutNew = 0;
    }
  }

  if (OUT) {
    const fs = await import('node:fs');
    fs.writeFileSync(OUT, [...seen].join('\n'), 'utf8');
    console.log(`[${ts()}] 已写出候选人名单：${OUT}（${seen.size} 人）`);
  }

  console.log(`[${ts()}] 本轮取样结束，累计去重候选人 ${seen.size} 人`);
  process.exit(MIN_CARDS > 0 && seen.size < MIN_CARDS ? 2 : 0);
})().catch((e) => {
  console.error('执行失败:', e.message);
  process.exit(1);
});
