#!/usr/bin/env node
/**
 * apply-profile-filters.mjs — 按画像校对结果设置 BOSS 筛选面板
 *
 * ★ 2026-09-21 重构为「画像驱动 + 动态定位」：
 *   1) 面板维度值全部来自 data/profile.json，脚本内不再硬编码任何画像值
 *   2) 分组按**标题**定位（院校/活跃度/经验要求…），不再依赖组序号
 *      —— 实测面板组顺序会随岗位变化：Android 岗是 1=活跃度 2=院校 9=经验 10=学历，
 *         Java 岗是 1=院校 2=活跃度 9=学历 10=经验，且 Java 岗多出「牛人关键词」组。
 *         用序号会静默点错组。
 *   3) 选项按**文案**匹配（中文只出现在 eval 的「返回」方向，安全；传入方向仍用序号标记）
 *   4) 画像按**页面当前岗位名**选取（旧版取「最近一条」，多岗位时会拿错岗位的画像 → 真 bug）
 *
 * 用法：
 *   node apply-profile-filters.mjs <targetId> [--dry] [--expect=N] [--job=岗位名]
 *     [--profile-file=绝对路径] [--no-writeback]
 *   node apply-profile-filters.mjs <targetId> --check-only      # 只读校验，不改面板
 *
 * 退出码：0 正常 | 1 参数/连接错误 | 2 面板未打开 | 3 C3 校验不一致（应暂停）
 */

import fs from 'fs';
import path from 'path';

const BASE = process.env.WEB_ACCESS_BASE || 'http://localhost:3456';
const TARGET = process.argv[2];
const DRY = process.argv.includes('--dry');
const CHECK_ONLY = process.argv.includes('--check-only');
const NO_WRITEBACK = process.argv.includes('--no-writeback');
const FRAME = 'iframe[src*=recommend]';

const expectArg = (process.argv.find((a) => a.startsWith('--expect=')) || '').split('=')[1];
const jobArg = (process.argv.find((a) => a.startsWith('--job=')) || '').split('=')[1];
const profileFileArg = (process.argv.find((a) => a.startsWith('--profile-file=')) || '').split('=').slice(1).join('=');

if (!TARGET) {
  console.error('用法: node apply-profile-filters.mjs <targetId> [--dry] [--expect=N] [--job=岗位名] [--check-only] [--profile-file=绝对路径] [--no-writeback]');
  process.exit(1);
}

/** 画像维度 → 面板分组标题 */
const DIM_MAP = [
  { key: 'activation', group: '活跃度' },
  { key: 'school', group: '院校' },
  { key: 'recent_not_viewed', group: '近期没有看过' },
  { key: 'gender', group: '性别' },
  { key: 'exchange_resume_with_colleague', group: '是否与同事交换简历' },
  { key: 'experience', group: '经验要求' },
  { key: 'degree', group: '学历要求' },
];

const rand = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ts = () => new Date().toTimeString().slice(0, 8);
const normTitle = (t) => String(t || '').replace(/\[[^\]]*\]/g, '').replace(/\s+/g, '').trim();
const normText = (t) => String(t || '').replace(/\s+/g, '').trim();

/** 画像值 → 面板文案数组；'不限' / 空 一律视为「不设」 */
function toTexts(v) {
  if (!v) return [];
  const arr = Array.isArray(v) ? v : [v];
  return arr.map((s) => String(s).trim()).filter((s) => s && s !== '不限');
}

const SKILL_DIR = path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1'));
const PROFILE_FILE = profileFileArg
  ? path.resolve(profileFileArg)
  : path.join(SKILL_DIR, '..', 'data', 'profile.json');

function loadProfiles() {
  try {
    return JSON.parse(fs.readFileSync(PROFILE_FILE, 'utf8')).profiles || [];
  } catch {
    return null;
  }
}

function pickProfile(list, jobTitle) {
  if (!list || !list.length) return null;
  if (jobTitle) {
    let p = list.find((x) => normTitle(x.job_title) === normTitle(jobTitle));
    if (p) return p;
    p = list.find(
      (x) => normTitle(x.job_title).includes(normTitle(jobTitle)) ||
             normTitle(jobTitle).includes(normTitle(x.job_title))
    );
    if (p) return p;
  }
  return null;
}

async function ev(js) {
  const res = await fetch(`${BASE}/eval?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: js,
  });
  const j = await res.json();
  if (j.error) throw new Error(j.error);
  return j.value;
}

async function clickAtFrame(selector) {
  const res = await fetch(`${BASE}/clickAtFrame?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ frame: FRAME, selector }),
  });
  const j = await res.json().catch(() => ({}));
  if (res.ok && j.clicked) return j;

  // Codex bundled web-access versions before iframe-input support expose
  // /eval but return "unknown endpoint" for /clickAtFrame. Filter controls
  // are reversible page settings, so use the control's own click handler as
  // a compatibility fallback. Never reuse this fallback for greet/message
  // actions, which require a real CDP mouse event and success confirmation.
  if (j && j.error === String.fromCharCode(26410,30693,31471,28857)) {
    const raw = await ev(`var f=document.querySelector('${FRAME}');
var d=f&&f.contentDocument;var e=d&&d.querySelector(${JSON.stringify(selector)});
if(!e){JSON.stringify({clicked:false,error:'selector not found'});}else{
var r=e.getBoundingClientRect();var cs=d.defaultView.getComputedStyle(e);
if(r.width<=0||r.height<=0||cs.display==='none'||cs.visibility==='hidden'){
JSON.stringify({clicked:false,error:'selector not visible'});
}else{e.click();JSON.stringify({clicked:true,fallback:'dom-control-click'});}}`);
    const fallback = JSON.parse(raw);
    if (fallback.clicked) return fallback;
  }
  throw new Error('clickAtFrame 失败: ' + JSON.stringify(j).slice(0, 160));
}

/** 读页面当前岗位名（去掉「 _ 北京 30-50K」后缀） */
async function getCurrentJobTitle() {
  const raw = await ev(`var f=document.querySelector('iframe[src*=recommend]');
if(!f||!f.contentDocument){JSON.stringify({t:null});}else{
var d=f.contentDocument;
var el=d.querySelector('.job-selecter-wrap .ui-dropmenu-label');
JSON.stringify({t: el? el.innerText.replace(/\\s+/g,' ').trim() : null});}`);
  const t = (JSON.parse(raw).t || '').trim();
  return t ? t.replace(/\s*_\s*.*$/, '').trim() : '';
}

/** 读面板结构：分组标题 + 各选项文案与选中态 + 只看第一学历开关 */
async function readPanelStructure() {
  const raw = await ev(`var f=document.querySelector('iframe[src*=recommend]');
if(!f||!f.contentDocument){JSON.stringify({open:false, why:'no_iframe'});}else{
var d=f.contentDocument;
var p=d.querySelector('.filter-panel');
if(!p){JSON.stringify({open:false, why:'no_panel'});}else{
  var groups=[];
  var items=p.querySelectorAll('.filter-item');
  for(var g=0;g<items.length;g++){
    var nm=items[g].querySelector('.name');
    var opts=[];
    items[g].querySelectorAll('.option').forEach(function(e){
      var c=(e.className||'').toString();
      opts.push({t:(e.innerText||'').trim(), on:(c.indexOf('active')>=0)});
    });
    groups.push({g:g, title: nm? nm.innerText.trim():'', opts:opts});
  }
  var fw=d.querySelector('.first-degree-wrap');
  var fdOn=false;
  if(fw){
    var cb=fw.querySelector('.check-box');
    var cc=cb? (cb.className||'').toString() : '';
    fdOn = cc.indexOf('checked')>=0 || cc.indexOf('active')>=0;
  }
  JSON.stringify({open:true, groups:groups, hasFirstDegree:!!fw, firstDegreeOn:fdOn});
}}`);
  return JSON.parse(raw);
}

/** 读筛选按钮上的条件计数（「筛选·14」→ 14；无计数时返回 0） */
async function readFilterCount() {
  const raw = await ev(`var f=document.querySelector('iframe[src*=recommend]');
if(!f || !f.contentDocument){JSON.stringify({found:false, why:'no_iframe'});}else{
var d=f.contentDocument;
var target=null;
d.querySelectorAll('div,span,a,button').forEach(function(e){
  var t=(e.innerText||'').trim();
  if(t && t.length<14 && t.indexOf(String.fromCharCode(31579,36873))===0 && e.children.length<=2) target=e;
});
if(!target){JSON.stringify({found:false, why:'no_button'});}else{
  var t=target.innerText.trim();
  var m=t.match(/(\\d+)/);
  JSON.stringify({found:true, text:t, count:m?parseInt(m[1],10):0});
}}`);
  return JSON.parse(raw);
}

/**
 * ★ 读页面 Vue 的 `checkedFilters` —— 当前最权威、且**零点击零滚动**的面板条件校验法。
 *
 * 2026-09-21 新增。相比另两种：
 *   - 计数法「筛选·N」：对「同维度只计 1 项」的改动**不敏感**
 *     （年龄 22-29 → 22-34，计数仍是 14，看不出改没改）
 *   - 参数法（读 rec/geek/list 的 age=）：必须**先触发一次分页请求**（要滚动），
 *     而且 proxy 清过 buffer 后经常读到 n=0
 *   - **本法**：直接读推荐页 Vue 实例上的 `checkedFilters` 对象，逐维可见，
 *     面板开或关都能读（它就是应用侧的真实状态）
 *
 * 实测样例：{"age":[22,34],"activation":2504,"school":[1104,1103,1102],
 *           "recentNotView":2301,"gender":0,"exchangeResumeWithColleague":1301,
 *           "experience":[104,105,106],"degree":[203,204,205],...}
 */
async function readCheckedFilters() {
  const raw = await ev(`var f=document.querySelector('iframe[src*=recommend]');
if(!f||!f.contentWindow){JSON.stringify({ok:false,why:'no_iframe'});}else{
var d=f.contentWindow.document; var res=null;
function scan(vm,depth){
  if(!vm||depth>4||res) return;
  try{
    var data=vm._data||vm.$data||{};
    Object.keys(data).forEach(function(k){
      if(k==='checkedFilters' && data[k] && typeof data[k]==='object') res=data[k];
    });
  }catch(e){}
  try{ (vm.$children||[]).forEach(function(c){scan(c,depth+1);}); }catch(e){}
}
var vms=[];
d.querySelectorAll('*').forEach(function(e){ if(e.__vue__ && vms.length<3) vms.push(e.__vue__); });
vms.forEach(function(v){scan(v,0);});
if(!res){JSON.stringify({ok:false,why:'checkedFilters_not_found'});}
else{JSON.stringify({ok:true, filters:res, fd:res.firstDegree});}
}`);
  return JSON.parse(raw);
}

/** 用 Vue checkedFilters 核对画像（重点核**年龄区间**——计数法对它不敏感）。
 *  返回 {bad, filters}；读不到时返回 null（不阻断，只提示）。 */
async function verifyCheckedFilters(prof) {
  const cf = await readCheckedFilters();
  if (!cf || !cf.ok) {
    console.log(`  ℹ️ 未读到 Vue checkedFilters（${(cf && cf.why) || 'unknown'}）→ 本项校验跳过`);
    return null;
  }
  const d = prof.dimensions || {};
  console.log(`  面板实际条件（Vue checkedFilters）：${JSON.stringify(cf.filters)}`);
  let bad = 0;
  const ageM = String(d.age_range || '').match(/(\d+)\s*[-~—]\s*(\d+)/);
  if (ageM) {
    const exp = `[${ageM[1]},${ageM[2]}]`;
    const act = JSON.stringify(cf.filters.age || null);
    const one = act === exp;
    if (!one) bad++;
    console.log(`  ${one ? '✅' : '❌'} age：期望 ${exp} / 实际 ${act}`);
  }
  // 顺带核对几个关键维度（码值取自 BOSS 面板口径，实测稳定）
  const checks = [
    ['activation', d.activation === '本周活跃' ? 2504 : null],
    ['exchangeResumeWithColleague',
      d.exchange_resume_with_colleague && d.exchange_resume_with_colleague !== '不限' ? 1301 : null],
    ['recentNotView',
      d.recent_not_viewed && d.recent_not_viewed !== '不限' ? 2301 : null],
  ];
  for (const [k, exp] of checks) {
    if (exp === null) continue;
    const act = cf.filters[k];
    const one = act === exp;
    if (!one) bad++;
    console.log(`  ${one ? '✅' : '❌'} ${k}：期望 ${exp} / 实际 ${act}`);
  }
  if (!bad) console.log('  ✅ Vue 维度核对通过（含计数法查不出的年龄区间）');
  return { bad, filters: cf.filters };
}

const markOption = (g, n) => `var d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.querySelectorAll('[data-wb-opt]').forEach(function(e){e.removeAttribute('data-wb-opt')});
var p=d.querySelector('.filter-panel');
if(!p){JSON.stringify({ok:false,why:'no_panel'});}else{
  var items=p.querySelectorAll('.filter-item');
  if(!items[${g}]){JSON.stringify({ok:false,why:'no_group'});}else{
    var opts=items[${g}].querySelectorAll('.option');
    if(!opts[${n}]){JSON.stringify({ok:false,why:'no_option'});}else{
      opts[${n}].setAttribute('data-wb-opt','v');
      JSON.stringify({ok:true,txt:opts[${n}].innerText.trim()});
    }
  }
}`;

/** 设置某一组里的一个选项（每次重新读结构 → 按文案定位 → 标记 → 点击 → 复验） */
async function setOption(groupTitle, wantText) {
  const st = await readPanelStructure();
  if (!st.open) throw new Error('筛选面板未打开');
  const g = st.groups.find((x) => normTitle(x.title) === normTitle(groupTitle));
  if (!g) {
    console.log(`  ⚠️ 未找到分组「${groupTitle}」，跳过`);
    return false;
  }
  const idx = g.opts.findIndex((o) => normText(o.t) === normText(wantText));
  if (idx < 0) {
    console.log(`  ⚠️「${groupTitle}」未找到选项「${wantText}」（可选：${g.opts.map((o) => o.t).join('/')}）`);
    return false;
  }
  if (g.opts[idx].on) {
    console.log(`  ${groupTitle}：「${wantText}」已是选中态，跳过`);
    return true;
  }
  if (DRY) {
    console.log(`  [dry] ${groupTitle} → 「${wantText}」(组${g.g} 选项${idx})`);
    return true;
  }
  const m = JSON.parse(await ev(markOption(g.g, idx)));
  if (!m.ok) throw new Error(`标记失败 g=${g.g} n=${idx} ${m.why || ''}`);
  await clickAtFrame('[data-wb-opt="v"]');
  await sleep(rand(240, 460)); // Vue 重渲染间隔
  const after = await readPanelStructure();
  const g2 = after.groups.find((x) => normTitle(x.title) === normTitle(groupTitle));
  const ok = !!g2 && g2.opts.some((o) => normText(o.t) === normText(wantText) && o.on);
  const cur = g2 ? g2.opts.filter((o) => o.on).map((o) => o.t).join(',') : '?';
  console.log(`  ${groupTitle}：点「${wantText}」→ ${ok ? '✅ 已选中' : '❌ 未生效'}（当前 [${cur}]）`);
  return ok;
}

/** 把某组重置回「不限」（画像值为「不限」时用，保证结果确定而非依赖残留状态） */
async function resetGroup(groupTitle) {
  const st = await readPanelStructure();
  if (!st.open) throw new Error('筛选面板未打开');
  const g = st.groups.find((x) => normTitle(x.title) === normTitle(groupTitle));
  if (!g) return;
  const anyOn = g.opts.filter((o) => o.on).map((o) => o.t);
  const offNonDefault = anyOn.filter((t) => normText(t) !== '不限');
  if (!offNonDefault.length) {
    console.log(`  ${groupTitle}：已是「不限」，跳过`);
    return;
  }
  const idx = g.opts.findIndex((o) => normText(o.t) === '不限');
  if (idx < 0) {
    console.log(`  ⚠️「${groupTitle}」无「不限」选项，无法重置（当前选中：${offNonDefault.join(',')}）`);
    return;
  }
  if (DRY) {
    console.log(`  [dry] 重置 ${groupTitle} → 「不限」（当前 [${anyOn.join(',')}]）`);
    return;
  }
  await ev(markOption(g.g, idx));
  await clickAtFrame('[data-wb-opt="v"]');
  await sleep(rand(240, 460));
  console.log(`  ${groupTitle}：已重置为「不限」（原 [${anyOn.join(',')}]）`);
}

/** 年龄滑块：Vue 赋值（CDP 拖拽会超时）。按标题定位年龄组。 */
async function setAgeSlider(rangeText) {
  const m = String(rangeText || '').match(/(\d+)\s*[-~—]\s*(\d+)/);
  if (!m) {
    console.log(`  年龄：画像为「${rangeText}」，非区间 → 跳过滑块`);
    return;
  }
  const lo = parseInt(m[1], 10);
  const hi = parseInt(m[2], 10);
  const res = await ev(`var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var p=d.querySelector('.filter-panel');
var items=p.querySelectorAll('.filter-item');
var el=null;
for(var i=0;i<items.length;i++){
  var nm=items[i].querySelector('.name');
  if(nm && nm.innerText.replace(/\\s+/g,'').indexOf(String.fromCharCode(24180,40836))===0){el=items[i];break;}
}
if(!el){el=p.querySelector('.filter-item.age');}
var out={found:false};
var cands=[];
if(el){
  el.querySelectorAll('*').forEach(function(e){
    if(e.__vue__ && Array.isArray(e.__vue__.value)) cands.push(e);
    if(e.__vue__ && e.__vue__.$children) e.__vue__.$children.forEach(function(c){
      if(c && Array.isArray(c.value)) cands.push(e);
    });
  });
}
var target=cands.length? cands[0] : null;
if(!target){
  var sl=p.querySelector('.vue-slider');
  if(sl && sl.__vue__) target=sl;
  if(!target && sl && sl.parentElement && sl.parentElement.__vue__) target=sl.parentElement;
}
if(!target){JSON.stringify({found:false, why:'no_vue_slider'});}else{
  var before=JSON.stringify(target.__vue__.value||null);
  ${DRY ? '' : `
  target.__vue__.value=[${lo},${hi}];
  if(target.__vue__.$emit) target.__vue__.$emit('change',[${lo},${hi}]);
  try{ if(target.__vue__.$parent && target.__vue__.$parent.setValue) target.__vue__.$parent.setValue([${lo},${hi}]); }catch(e){}
  `}
  JSON.stringify({found:true, before:before, after:JSON.stringify(target.__vue__.value||null)});
}`);
  const r = JSON.parse(res);
  if (!r.found) {
    console.log(`  ⚠️ 年龄滑块未找到（${r.why || ''}）`);
    return;
  }
  if (DRY) console.log(`  [dry] 年龄滑块 ${r.before} → [${lo},${hi}]`);
  else console.log(`  年龄滑块：${r.before} → ${r.after}（目标 [${lo},${hi}]）`);
}

/**
 * 判断面板是否支持「只看第一学历」。
 *
 * ★ 关键事实（2026-09-21 实测更正）：`.first-degree-wrap` 是**条件渲染**的 ——
 *   只有当院校组选中了具体院校（非「不限」）时才出现在 DOM 里。
 *   所以「读不到它」≠「面板不支持它」；在院校未选中时读到的 false 是**假阴性**。
 *   （此前把 read 不到归因为「横幅遮挡」是错的归因；横幅只是恰好同时存在。）
 *
 * 判定：
 *   - 读到 .first-degree-wrap            → 支持
 *   - 读不到，且院校组当前未选中具体院校   → 无法判定，按「支持」计（设置流程里院校会先被选中）
 *   - 读不到，且院校组已选中具体院校       → 判定为不支持
 */
function deduceFdSupport(st) {
  if (!st || !st.open) return false;
  if (st.hasFirstDegree) return true;
  const sg = (st.groups || []).find((g) => normTitle(g.title) === '院校');
  const picked = sg ? sg.opts.some((o) => o.on && normText(o.t) !== '不限') : false;
  return !picked;
}

function expectedCount(prof, supportsFirstDegree) {
  const d = prof.dimensions || {};
  let n = 0;
  if (d.age_range && d.age_range !== '不限') n += 1;
  for (const mm of DIM_MAP) n += toTexts(d[mm.key]).length;
  if (supportsFirstDegree && d.school_first_degree_only) n += 1;
  return n;
}

(async () => {
  const jobTitle = jobArg || (await getCurrentJobTitle());
  const list = loadProfiles();
  if (list === null) {
    console.log('❌ 读不到 data/profile.json');
    process.exit(1);
  }
  const prof = pickProfile(list, jobTitle);
  console.log(`[${ts()}] 页面岗位：${jobTitle || '(未读到)'}`);
  if (!prof) {
    console.log(`❌ profile.json 中没有该岗位的画像（现有：${list.map((x) => x.job_title).join(' / ') || '无'}）`);
    console.log('   → 需先做画像校对（references/profile-calibration.md），或用 --job= 指定');
    process.exit(1);
  }
  console.log(`  匹配画像：${prof.job_title}（校对 ${prof.calibrated_at}，来源 ${prof.source}）`);

  // check-only 的典型场景是面板**已关闭**（条件已应用），此时读不到面板结构，
  // 只能读到筛选按钮上的计数。故面板未开时不算错误，只是无法探测第一学历开关。
  const st0 = await readPanelStructure();
  if (!st0.open && !CHECK_ONLY) {
    console.log(`❌ 筛选面板未打开（${st0.why || ''}）→ 先打开筛选面板再运行`);
    process.exit(2);
  }

  // ★ .first-degree-wrap 是**条件渲染**的：只有当院校组选中了具体院校（非「不限」）时才会出现。
  //   所以「读不到它」≠「面板不支持它」。院校未选中时读到的 hasFirstDegree=false 是假阴性。
  const wantFd = !!(prof.dimensions || {}).school_first_degree_only;
  let fdSupported;
  if (st0.open) {
    fdSupported = deduceFdSupport(st0);
    if (wantFd && !st0.hasFirstDegree) {
      console.log(`  ℹ️ 当前 DOM 里没有「只看第一学历」开关 → 按「面板${fdSupported ? '支持' : '不支持'}」计入预期计数`);
      console.log('     （该开关仅在院校组选中具体院校后才渲染，未选中时缺失属正常）');
    }
  } else {
    // 面板未打开：无法探测，按「画像里要求的维度都应支持」乐观计算
    fdSupported = true;
    console.log('  ℹ️ 筛选面板未打开 → 无法探测「只看第一学历」开关，按画像完整值计算预期计数');
  }

  // ---- check-only：只读校验 ----
  if (CHECK_ONLY) {
    const info = await readFilterCount();
    const expN = expectArg ? parseInt(expectArg, 10) : expectedCount(prof, fdSupported);
    console.log(`  面板条件计数：${info.found ? info.text : '(未找到筛选按钮)'}`);
    console.log(`  预期计数：${expN}（来源：${prof.job_title}${fdSupported ? '' : '，已扣掉面板不支持的只看第一学历'}）`);
    // ★ check-only 也必须做「年龄区间」核对：计数法对年龄改动不敏感，只看计数会漏
    const cfOnly = await verifyCheckedFilters(prof);
    if (cfOnly && cfOnly.bad) {
      console.log('  ❌ 面板实际条件与画像不符（见上方 ❌ 行）→ 暂停');
      process.exit(3);
    }
    if (info.found && info.count === expN) {
      console.log('  ✅ C3 校验通过');
      process.exit(0);
    }
    console.log('  ❌ C3 校验不一致 → 暂停（不要带错误条件去筛）');
    process.exit(3);
  }

  console.log(`[${ts()}] 开始设置筛选面板${DRY ? '（演练，不实际点击）' : ''}`);

  // 1) 「是否应用上次的筛选条件？」横幅 → 点「取消」。
  //    注意：横幅存在时 .first-degree-wrap 等元素尚未渲染，必须先清掉再读结构。
  const cancelSel = await ev(`var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var c=d.querySelector('div.cancel');
if(c && c.getBoundingClientRect().width>0){c.setAttribute('data-wb-x','c');JSON.stringify({found:true});}
else{JSON.stringify({found:false});}`);
  if (JSON.parse(cancelSel).found) {
    console.log('  检测到「应用上次筛选条件?」横幅 → 点「取消」');
    if (!DRY) {
      await clickAtFrame('[data-wb-x="c"]');
      await sleep(rand(600, 1000));
    }
    // 横幅消失后结构才完整，重读一次
    const st1 = await readPanelStructure();
    console.log(`  重读面板：${st1.groups.length} 组，只看第一学历开关 ${st1.hasFirstDegree ? '存在' : '不存在'}`);
  } else {
    console.log('  无「应用上次筛选条件」横幅');
  }

  const st2 = await readPanelStructure();
  if (!st2.open) throw new Error('筛选面板未打开，无法继续');
  console.log(`  面板已就绪：${st2.groups.length} 组`);

  // 2) 逐维度设置（按标题定位；画像为「不限」的维度重置回「不限」）
  console.log(`[${ts()}] 设置各维度：`);
  const dims = prof.dimensions || {};
  const results = [];
  for (const mm of DIM_MAP) {
    const texts = toTexts(dims[mm.key]);
    if (!texts.length) {
      await resetGroup(mm.group);
    } else {
      for (const t of texts) results.push(await setOption(mm.group, t));
    }
  }

  // 3) 只看第一学历
  if (wantFd) {
    const stf = await readPanelStructure();
    if (!stf.hasFirstDegree) {
      console.log('  只看第一学历：面板无此开关，跳过（改由详情精筛核）');
    } else if (stf.firstDegreeOn) {
      console.log('  只看第一学历：已勾选，无需操作');
    } else if (DRY) {
      console.log('  [dry] 将勾选「只看第一学历」');
    } else {
      await ev(`var d=document.querySelector('iframe[src*=recommend]').contentDocument;
d.querySelectorAll('[data-wb-fd]').forEach(function(e){e.removeAttribute('data-wb-fd')});
var fw=d.querySelector('.first-degree-wrap');
if(fw) fw.setAttribute('data-wb-fd','1');
JSON.stringify({ok:!!fw})`);
      await clickAtFrame('[data-wb-fd="1"]');
      await sleep(rand(300, 600));
      const stv = await readPanelStructure();
      console.log(`  只看第一学历：${stv.firstDegreeOn ? '✅ 已勾选' : '❌ 勾选失败'}`);
      if (!stv.firstDegreeOn) throw new Error('「只看第一学历」勾选未生效');
    }
  }

  // 4) 年龄滑块
  await setAgeSlider(dims.age_range);

  if (DRY) {
    console.log(`[${ts()}] 演练结束（未点「确定」）`);
    process.exit(0);
  }

  // 5) 点「确定」
  //    ★ 实测（2026-09-21）：CDP 真实鼠标事件点这个按钮**不生效**——
  //      坐标正确（iframe 偏移 + 内部坐标）、主文档层无遮挡、iframe 内 hit-test 命中的也是它，
  //      但 Vue 就是不响应，面板不关、列表不刷新。改用**合成 el.click()** 才生效。
  //      注意这与「打招呼」按钮相反：打招呼必须用 CDP 真实事件，合成事件无效。
  //      故这里做两级兜底：先 CDP，验证面板是否关闭；没关再合成 click。
  const okSel = await ev(`var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var p=d.querySelector('.filter-panel');
var hit=null;
p.querySelectorAll('button,div,a').forEach(function(e){
  var t=(e.innerText||'').trim();
  if(t==='\\u786e\\u5b9a' && (e.className||'').toString().indexOf('btn')>=0) hit=e;
});
if(!hit){JSON.stringify({found:false});}else{hit.setAttribute('data-wb-ok','1');
 JSON.stringify({found:true, cls:(hit.className||'').toString()});}`);
  if (!JSON.parse(okSel).found) throw new Error('未找到「确定」按钮');

  /** 面板是否已关闭（关闭 = 条件已应用） */
  const panelClosed = async () => {
    const r = await ev(`var f=document.querySelector('iframe[src*=recommend]');
JSON.stringify({closed: (f&&f.contentDocument)? !f.contentDocument.querySelector('.filter-panel') : true})`);
    return JSON.parse(r).closed;
  };

  await clickAtFrame('[data-wb-ok="1"]');
  await sleep(2500);
  if (await panelClosed()) {
    console.log(`[${ts()}] 已点「确定」（CDP 真实事件生效）`);
  } else {
    console.log(`[${ts()}] ⚠️ CDP 点击「确定」未生效 → 改用合成 click 兜底`);
    const clicked = await ev(`var f=document.querySelector('iframe[src*=recommend]');
var el=f.contentDocument.querySelector('[data-wb-ok="1"]');
if(!el){JSON.stringify({ok:false,why:'marker_lost'});}else{el.click();JSON.stringify({ok:true});}`);
    console.log(`  合成 click：${clicked}`);
    await sleep(3000);
    console.log(`  面板已关闭：${(await panelClosed()) ? '是 ✅' : '否 ❌'}`);
  }
  await sleep(rand(1500, 2500));

  // 6) 校验参数：buffer 可能残留旧请求（尤其切过岗位/清过筛选时），先清空再触发一次分页请求。
  //    注意顺序：清空必须在**点确定之后、读参数之前**，否则会读到旧条件或读不到（n=0）。
  await ev(`var w=document.querySelector('iframe[src*=recommend]').contentWindow;
w.performance.clearResourceTimings(); "cleared"`);
  await ev(`var d=document.querySelector('iframe[src*=recommend]').contentDocument;
var cs=d.querySelectorAll('.candidate-card-wrap');
if(cs.length>3){cs[3].scrollIntoView({block:'center'});} "scrolled"`);
  await sleep(4500);
  const verify = await ev(`var w=document.querySelector('iframe[src*=recommend]').contentWindow;
var es=w.performance.getEntriesByType('resource').map(function(e){return e.name})
  .filter(function(n){return /rec\\/geek\\/list/.test(n)});
var last=es.length?es[es.length-1]:'';
var q=last.slice(last.indexOf('?')+1);
var o={};
q.split('&').forEach(function(kv){var a=kv.split('=');if(a[0])o[a[0]]=a[1];});
var d=document.querySelector('iframe[src*=recommend]').contentDocument;
JSON.stringify({n:es.length, params:o, jobId:o.jobId, cards:d.querySelectorAll('.candidate-card-wrap').length,
  panelOpen: !!d.querySelector('.filter-panel')})`);
  console.log(`[${ts()}] 校验结果：${verify}`);

  // 7) C3 计数校验
  //    ⚠️ 2026-09-21 修复：此处**不能**重新探测「只看第一学历」的渲染状态。
  //    因为第 5 步已经点过「确定」，面板此刻是**关闭**的（实测 panelOpen:false），
  //    而 .first-degree-wrap 是条件渲染的 → 面板一关必然读不到
  //    → deduceFdSupport({open:false}) 恒为 false → 预期计数凭空少 1 → **假警报**。
  //    （当天实测：面板真实 14、脚本却按 13 比对，报「C3 校验不一致」并 exit 3。）
  //    正确做法：面板还开着就用现场探测值；已关闭则沿用设置阶段（面板打开时）得到的 fdSupported。
  const stEnd = await readPanelStructure();
  const fdFinal = stEnd.open ? deduceFdSupport(stEnd) : fdSupported;
  if (!stEnd.open && fdSupported !== undefined) {
    console.log('  ℹ️ 面板已关闭（「确定」已提交）→ 沿用设置阶段的只看第一学历判定，不再重探');
  }
  const info = await readFilterCount();
  const expN = expectArg ? parseInt(expectArg, 10) : expectedCount(prof, fdFinal);
  console.log(`[${ts()}] 面板条件计数：${info.found ? info.text : '(未找到筛选按钮)'}`);
  console.log(`  预期计数：${expN}（来源：${prof.job_title}${fdFinal ? '' : '，已扣掉面板不支持的只看第一学历'}）`);
  const failed = results.filter((r) => r === false).length;
  if (failed) console.log(`  ⚠️ 有 ${failed} 个选项未生效，请核对上方日志`);

  // 7b) ★ 首选校验法：直接读页面 Vue 的 checkedFilters（零点击、零滚动、最权威）
  //     计数法对「年龄区间」这种"同维度只计 1 项"的改动**不敏感**
  //     （22-29 → 22-34 计数不变），参数法又要先触发一次分页请求。
  //     读 Vue 状态既免费又能逐维核对，是三者里最好的。
  const cfRes = await verifyCheckedFilters(prof);

  // 写入 panel 落库信息
  if (info.found && info.count === expN) {
    console.log('  ✅ C3 校验通过');
    try {
      if (NO_WRITEBACK) {
        console.log('  ℹ️ --no-writeback：不回写画像文件');
        return;
      }
      const raw = JSON.parse(fs.readFileSync(PROFILE_FILE, 'utf8'));
      const tgt = raw.profiles.find((x) => x.job_title === prof.job_title);
      if (tgt) {
        tgt.panel_applied = true;
        tgt.panel_applied_at = new Date().toISOString().replace('Z', '+00:00');
        tgt.panel_conditions_count = info.count;
        tgt.panel_params = JSON.parse(verify).params || {};
        tgt.panel_apply_method = 'scripts/apply-profile-filters.mjs（画像驱动 + 按标题动态定位）';
        tgt.panel_first_degree_supported = fdFinal;
        fs.writeFileSync(PROFILE_FILE, JSON.stringify(raw, null, 2) + '\n', 'utf8');
        console.log('  ✓ 已把面板落地信息写回 profile.json');
      }
    } catch (e) {
      console.log('  ⚠️ 写回 profile.json 失败：' + e.message);
    }
    process.exit(0);
  }
  console.log('  ❌ C3 校验不一致 → 应暂停并通知用户（不要把错误条件带下去筛）');
  process.exit(3);
})();
