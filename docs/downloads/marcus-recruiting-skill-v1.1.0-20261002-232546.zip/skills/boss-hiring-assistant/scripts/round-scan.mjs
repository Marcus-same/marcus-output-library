#!/usr/bin/env node
/**
 * round-scan.mjs — 一轮扫描：批次轮换 + 卡片初筛
 *
 * ⚠️⚠️ 本脚本**只适配 Java 岗**（高级java研发工程师 / 中·高级java开发工程师）⚠️⚠️
 *
 *   卡片初筛条件写死了 Java 岗 policy：
 *     - `.tag-item.highlight` 必须含 `985`
 *     - 期望段必须含「北京」
 *     - 工作经历段必须含 `Java`
 *
 *   **其他岗位（Android / AI全栈 / 大模型 等）不要用本脚本**：
 *     - Android 岗不要求 985，用它会把绝大多数合格候选人误过滤
 *     - 「工作经历含 Java」对 Android 岗本身就是错误条件
 *
 *   非 Java 岗请改用：human-scroll.mjs（扩池）+ batch-read-resume.mjs（精筛）
 *                   + greet-from-recommend.mjs（打招呼）
 *
 * 流程：在「推荐 / 最新」标签间轮换，每批对当前 DOM 内的候选人执行卡片初筛
 *       （985 院校 + 期望城市北京 + 工作经历含 Java 岗位），
 *       跳过已处理名单，输出待精筛候选人。
 *
 * 用法：
 *   node round-scan.mjs <targetId> <batches> [--skip=processed-names.txt]
 *
 * 输出：每行 "name|tags|exp"
 */

const BASE = process.env.WEB_ACCESS_BASE || 'http://localhost:3456';
const TARGET = process.argv[2];
const BATCHES = parseInt(process.argv[3] || '14', 10);
const skipArg = process.argv.find((a) => a.startsWith('--skip='));
const SKIP_FILE = skipArg ? skipArg.split('=')[1] : null;

if (!TARGET) {
  console.error('用法: node round-scan.mjs <targetId> <batches> [--skip=names.txt]');
  process.exit(1);
}

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const ts = () => new Date().toTimeString().slice(0, 8);

const TAB_REC = String.fromCharCode(25512, 33616); // 推荐
const TAB_LATEST = String.fromCharCode(26368, 26032); // 最新

async function ev(js) {
  const res = await fetch(`${BASE}/eval?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: js,
  });
  const json = await res.json();
  if (json.error) throw new Error(json.error);
  return JSON.parse(json.value);
}

// 兼容层：新 proxy（2026-09 起）用 POST /clickAtFrame + JSON body，
// 旧写法 `::iframe::xxx` 前缀在此内部自动翻译，调用点无需改。
const IFRAME_SEL = 'iframe[src*=recommend]';
async function clickAt(selector) {
  if (typeof selector === 'string' && selector.startsWith('::iframe::')) {
    const inner = selector.slice('::iframe::'.length);
    const r = await fetch(`${BASE}/clickAtFrame?target=${TARGET}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frame: IFRAME_SEL, selector: inner }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.clicked) throw new Error('clickAtFrame 失败: ' + JSON.stringify(j).slice(0, 200));
    return j;
  }
  await fetch(`${BASE}/clickAt?target=${TARGET}`, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain' },
    body: selector,
  });
}

const STATE_JS = `var d=document.querySelector('iframe').contentDocument;
JSON.stringify({cards:d.querySelectorAll('.candidate-card-wrap').length,
top:Math.round(d.documentElement.scrollTop),
h:d.documentElement.scrollHeight,
view:d.documentElement.clientHeight})`;

const SET_TOP = (y) => `var d=document.querySelector('iframe').contentDocument;
d.documentElement.scrollTop=${Math.max(0, Math.round(y))};
Math.round(d.documentElement.scrollTop)`;

/** 卡片初筛：985 标签 + 期望含北京 + 工作经历段含 Java，排除已沟通 */
const FILTER_JS = `var BJ=String.fromCharCode(21271,20140),QW=String.fromCharCode(26399,26395),JX=String.fromCharCode(32487,32493);
var d=document.querySelector('iframe').contentDocument;
var out=[];
d.querySelectorAll('.candidate-card-wrap').forEach(function(c){
  var btn=c.querySelector('button');
  if(btn&&btn.innerText.indexOf(JX)>=0) return;
  var hl=Array.from(c.querySelectorAll('.tag-item.highlight')).map(function(e){return e.innerText.trim()}).join(',');
  if(hl.indexOf('985')<0) return;
  var txt=c.innerText.split('\\n').map(function(s){return s.trim()}).filter(Boolean).join('|');
  var qi=txt.indexOf(QW);
  if(qi<0||txt.slice(qi).indexOf(BJ)<0) return;
  var leaves=[];
  c.querySelectorAll('*').forEach(function(e){if(e.children.length===0&&e.innerText&&e.innerText.trim())leaves.push(e)});
  var lt=-1;
  leaves.forEach(function(e,k){if(e.classList.contains('tag-item'))lt=k});
  var exp=leaves.slice(lt+1).map(function(e){return e.innerText.trim().replace(/\\s+/g,'')}).join('|');
  if(exp.indexOf('Java')<0) return;
  out.push(((c.querySelector('.name')||{}).innerText||'')+'|'+hl+'|'+exp.slice(0,140));
});
JSON.stringify(out)`;

async function stepScrollToBottom() {
  for (let i = 0; i < 60; i++) {
    const s = await ev(STATE_JS);
    const maxTop = s.h - s.view;
    if (s.top >= maxTop - 50) return i;
    await ev(SET_TOP(Math.min(s.top + rand(400, 900), maxTop)));
    await sleep(rand(250, 700));
  }
  return 60;
}

async function bounceNudge() {
  const s = await ev(STATE_JS);
  const maxTop = s.h - s.view;
  await ev(SET_TOP(maxTop - rand(600, 1200)));
  await sleep(rand(250, 550));
  await ev(SET_TOP(maxTop));
}

async function switchTab(label) {
  const json = JSON.stringify(label);
  await ev(`var d=document.querySelector('iframe').contentDocument;
d.querySelectorAll('.tab-item').forEach(function(e){e.removeAttribute('data-lobster-tab')});
var tgt=null;
d.querySelectorAll('.tab-item').forEach(function(e){ if(e.innerText.trim()===${json}) tgt=e; });
if(tgt) tgt.setAttribute('data-lobster-tab','go');
JSON.stringify({marked:!!tgt})`);
  await sleep(rand(400, 900));
  await clickAt('::iframe::[data-lobster-tab="go"]');
  await sleep(rand(2500, 4000));
}

(async () => {
  const skip = new Set();
  if (SKIP_FILE) {
    const fs = await import('node:fs');
    if (fs.existsSync(SKIP_FILE)) {
      fs.readFileSync(SKIP_FILE, 'utf8')
        .split('\n')
        .map((s) => s.trim())
        .filter(Boolean)
        .forEach((n) => skip.add(n));
      console.log(`[${ts()}] 跳过名单已载入：${skip.size} 人`);
    }
  }

  const found = new Map();
  const tabs = [TAB_REC, TAB_LATEST];

  for (let b = 1; b <= BATCHES; b++) {
    await stepScrollToBottom();
    const nudges = rand(1, 3);
    for (let n = 0; n < nudges; n++) {
      await bounceNudge();
      await sleep(rand(1200, 2600));
    }

    const list = await ev(FILTER_JS);
    let fresh = 0;
    list.forEach((line) => {
      const name = line.split('|')[0];
      if (!name || skip.has(name) || found.has(name)) return;
      found.set(name, line);
      fresh++;
    });
    const st = await ev(STATE_JS);
    console.log(
      `[${ts()}] batch ${b}: 本批 ${st.cards} 张 | 初筛命中 ${list.length} | 新增待精筛 ${fresh} | 累计 ${found.size}`
    );

    const next = tabs[b % tabs.length];
    await switchTab(next);
  }

  console.log('--- 待精筛候选人 ---');
  [...found.values()].forEach((line) => console.log(line));
  const fs = await import('node:fs');
  fs.writeFileSync('C:/Users/Administrator/AppData/Local/Temp/round-passers.txt', [...found.keys()].join('\n'), 'utf8');
  console.log(`待精筛 ${found.size} 人，名单已写入 round-passers.txt`);
  process.exit(0);
})().catch((e) => {
  console.error('执行失败:', e.message);
  process.exit(1);
});
