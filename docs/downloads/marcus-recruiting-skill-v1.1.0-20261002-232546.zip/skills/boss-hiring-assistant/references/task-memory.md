# 任务记忆模型

## 目的

Boss 招聘流程是长流程任务，不能只依赖龙虾通用记忆，所以需要单独维护任务记忆。

## 存储位置

默认存储路径（WorkBuddy 环境）：

```
~/.workbuddy/skills/boss-hiring-assistant/data/
```

（Claude Code 环境下对应 `~/.claude/skills/boss-hiring-assistant/data/`）

文件结构：

```
data/
├── candidates.json      # 候选人记录（主表）
├── actions.json         # 动作历史记录
├── progress.json        # 进度与汇报状态（按岗位分片）
├── profile.json         # 画像校对结果（按岗位一条）—— 筛选的主标准
└── config.json          # 运行配置（历史目标数、时间窗口、通知配置等）
```

> **`profile.json` 属于「配置」性质**：打包导出时会清成 `{"profiles": []}`，
> 使用方首次运行时由画像校对流程引导自行设置（画像校对本身就会问 9 项，
> 不需要预置字段模板）。**不要把某个环境的实际画像（年龄区间、院校名单等）打包发出去。**

- 首次运行时自动创建 `data/` 目录和初始空文件
- 候选人记录按 `candidate_id` 去重，状态更新时覆盖原记录
- 动作记录按时间追加，不清理（用于审计和复盘）
- `progress.json` 每次汇报后更新

用户不需要手动管理这些文件。龙虾负责读写和维护。

## ⚠️ 字段名以 boss-greet-recipe.md 为准（2026-09-15 修正）

本文件描述的是**任务记忆的概念模型**（要记住哪些维度）。

**`data/*.json` 的实际字段名与结构，一律以
[boss-greet-recipe.md](./boss-greet-recipe.md) 的「状态持久化」章节为准。**

此前两个文档各写了一套字段名，互相冲突。实测在跑的任务读写的字段如下：

| 文件 | 实际结构 | 关键字段 |
|------|---------|---------|
| `candidates.json` | **JSON 数组**（不是按 id 为键的对象） | `candidate_id` / `name` / **`job`** / `source` / `card_scan_result` / `detail_decision` / `greeted` / `greet_result` / `city` / `past_position` / `experience_years` / `reject_reason` / **`pending_reasons`** / **`review_after`** / `processed_at` |
| `actions.json` | JSON 数组，按时间追加 | `action_type` / `candidate_id` / `candidate_name` / **`job`** / `result` / `timestamp` |
| `progress.json` | JSON 对象，**按岗位分片** | 顶层 `active_job` / `last_updated`；岗位分片在 **`jobs{}`** 下，每片含 `target_greeted_count` / `current_greeted_count` / `total_cards_scanned` / `round_index` / `max_batch_greet` / `greeted_names[]` / `last_greeted_at` / `paused` / `pause_reason` / `quota_exhausted` / `pool_status` |
| `profile.json` | JSON 对象 | `profiles[]`，每项含 `job_title` / `job_id` / `calibrated_at` / `source` / `dimensions{}` / `panel_applied` / `panel_params{}` / `panel_conditions_count` |
| `config.json` | JSON 对象 | `jd_targets{}`（每个岗位含 `daily_target` / `city_filter` / `title_aliases`）/ `current_job_title` / `reporting_window` / `summary_interval_minutes` / **`notify{}`** / **`java_job_line{}`**（2026-09-21 新增：页面上多个同岗位名视为同一条岗位线，各 jobId 分列，推荐池仍需分别筛） |

**C1 · 岗位隔离（2026-09-19 新增，硬规则）**

并行跑 Java / Android / AI全栈 三个岗时，状态必须互不干扰：

- `progress.json`：**每个岗位一份独立分片**（`jobs[岗位名]`），计数、已打名单、单轮序号都隔离。
  **切换岗位 = 切换分片，不要手工清零**，也不要让两个岗位的计数互相污染
- `candidates.json` / `actions.json`：每条记录都带 **`job` 字段**；
  同一位候选人在不同岗位下是**两条独立记录**（`candidate_id` 已含岗位关键词）
- 读取时一律先按 `job` 过滤，再按 `candidate_id` 去重

去重规则：`candidates.json` 是数组，**按 `candidate_id` 字段去重**（不是按对象键）。
`candidate_id` 生成规则：`姓名_岗位关键词_hash`，例如 `张三_Android_a1b2c3`；
若 BOSS 卡片有 `data-id`，优先用 `data-id`。

**三分类 ↔ JSON 取值（固定对应，不要自造同义词）：**

| 语义 | JSON 取值 | 触发条件 |
|------|-----------|---------|
| **匹配** | `pass` | 硬性 + 软性维度全部满足 |
| **待定** | `manual_review` | 软性维度（活跃度 / 近期没看过 / 是否与同事交换简历）不满足 |
| **不匹配** | `reject` | 硬性维度（年龄 / 性别 / 学历 / 经验 / 院校）不满足 |

待定记录必须带 `pending_reasons`（列出具体维度）+ `review_after`（最早可复议日）；
不匹配记录必须带 `reject_reason`。

本节下方给出的 JSON 示例是**概念示意**，字段名可能与实际不同，请以上表为准。

## 存储要求

龙虾应维护一个轻量本地结构化存储，可以是：

- 本地 SQLite
- 本地 JSON
- 其他等价的本地结构化存储

用户不需要手动安装或管理数据库。

## 最小候选人记录

```json
{
  "candidate_id": "boss_xxx",
  "source_type": "recommended_feed",
  "process_state": "card_scanned",
  "decision": "pending",
  "last_snapshot_at": "2026-04-02T12:00:00+08:00",
  "payload": {
    "name": "张三",
    "title": "高级后端工程师",
    "city": "Shanghai",
    "profile": {}
  }
}
```

## 最小动作记录

```json
{
  "candidate_id": "boss_xxx",
  "action_type": "classification",
  "created_at": "2026-04-02T12:05:00+08:00",
  "payload": {
    "decision": "pass_to_chat",
    "next_action": "request_attachment_resume"
  }
}
```

## 必须记住的维度

- 候选人来源
- 当前流程状态
- 上次决策
- 动作历史
- 上次是否已经进入本轮进度汇报
- 是否等待用户确认下一步沟通
- 是否等待用户确认进入约面
- 是否已请求附件简历
- 是否已收到附件简历
- 是否已确认面试意向
- 是否已确认面试时间
- 是否已生成企微建会请求
- 是否本轮发现为未读候选人
- 是否本轮已成功更新简历
- 是否本轮仍待补齐
- 本轮未补齐原因

## 建议增加的候选人状态

建议至少记录：

- `unread_discovered`
- `resume_read`
- `classification_updated`
- `has_unread_message`
- `replied_by_candidate`
- `pending_user_confirmation`
- `resume_read_failed`
- `needs_rescan`
- `attachment_requested`
- `attachment_sent_by_candidate`
- `attachment_receive_pending`
- `attachment_received`
- `wrong_candidate_thread_detected`
- `paused_for_boss_contact_quota_exhausted`

## 来源相关判断建议

任务记忆不仅用于防止重复触达，也用于区分不同来源下"哪些候选人本轮应该处理"：

- 对 `inbound_chat`，页面未读信号优先，本地记忆负责去重与补漏
- 对 `recommended_feed`，本地记忆优先，页面信号只做辅助
- 对 `search_results`，本地记忆优先，页面信号只做辅助

不要把推荐页和搜索页误当成自带稳定"已读/已处理"标记的页面。

## 汇报与目标状态

还应保存进度与汇报状态，例如：

```json
{
  "reporting_window": {
    "start_hour_local": 9,
    "end_hour_local": 17
  },
  "summary_interval_minutes": 60,
  "daily_target_count": 10,
  "current_qualified_count": 6,
  "current_unread_discovered_count": 12,
  "current_unread_updated_count": 9,
  "current_unread_missing_count": 3,
  "last_scan_at": "2026-04-02T10:00:00+08:00",
  "last_summary_at": "2026-04-02T10:00:00+08:00"
}
```

这样可以避免重复汇报、漏汇报，以及人数口径混乱。

> **目标人数字段口径（2026-09-19）**：`daily_target_count` 仅作**历史记录**。
> 本轮实际目标由**用户当次告知**，写入 `progress.json` 的
> `jobs[当前岗位].target_greeted_count`。用户没说时先追问，不要取历史值。

## 保留原则

保留足够多的状态，防止重复触达和状态丢失；  
但不要把这部分扩展成通用 CRM。
