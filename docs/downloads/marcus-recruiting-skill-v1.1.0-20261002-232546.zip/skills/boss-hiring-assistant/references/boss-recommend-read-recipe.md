# BOSS 推荐页读取固定方案

## 定位

这个文档用于 `recommended_feed`。
目标不是"判断页面是不是神秘地还没加载完"，而是以最低 token 成本确认：

1. 当前是否已经进入推荐页
2. 当前页是否已经存在可读取的候选人卡片
3. 当前卡片里哪些候选人属于本轮未处理对象

## 与两步筛选法的关系

推荐页读取是**第一步「卡片初筛」**的数据来源。

读取到的候选人卡片信息（姓名、过往岗位、期望岗位、标签等）用于：
1. 判断是否与当前岗位 JD 有关联
2. 有关联的 → 打开在线简历详情做第二步精筛
3. 无关的 → 叉掉，继续下一张卡片

读取本身不决定是否打招呼。决定权在两步筛选之后。

## 读取原则

只要推荐页上已经稳定显示候选人卡片，就视为页面可读取。

此时必须：

1. 直接读取 DOM
2. 直接提取候选人卡片文本和稳定标识
3. 结合本地任务记忆判断哪些候选人属于本轮未处理

不要默认：

- 等待 30 秒
- 让用户确认"页面是否加载完成"
- 让用户描述页面内容
- 默认退回截图快照分析
- 用"可能需要手动触发加载"作为第一判断

## iframe 结构（硬规则）

BOSS 推荐页的候选人内容在 **iframe** 内，不在主文档中。

**访问方式**：
```javascript
var iframe = document.querySelector("iframe");
var doc = iframe.contentDocument;
var cards = doc.querySelectorAll(".candidate-card-wrap");
```

**所有 DOM 查询必须在 iframe.contentDocument 上执行**，不要在主文档上查询。

## 字符编码（硬规则）

在 eval 脚本中使用中文字符串时，**必须使用 `String.fromCharCode()`**，不能直接用中文字面量。

原因：curl 传输时中文字符可能编码损坏。

**正确写法**：
```javascript
var beijing = String.fromCharCode(21271, 20140); // 北京
var nian = String.fromCharCode(24180); // 年
if (text.indexOf(beijing) >= 0) { ... }
```

**错误写法**：
```javascript
if (text.indexOf("北京") >= 0) { ... } // ❌ 可能匹配失败
```

**常用字符编码**：
- 北京：`String.fromCharCode(21271, 20140)`
- 年：`String.fromCharCode(24180)`
- 本科：`String.fromCharCode(26412, 31185)`
- 硕士：`String.fromCharCode(30805, 22763)`

## 固定主路径

1. 确认当前 target 已在 Boss 推荐页
2. **进入 iframe**：`var doc = document.querySelector("iframe").contentDocument`
3. 用短 selector 检查候选人卡片容器是否存在：`doc.querySelectorAll(".candidate-card-wrap")`
4. 用短 eval 统计：
   - 卡片数量
   - 每张卡片的姓名 / 职位 / 期望 / 标签等可见文本
   - 是否存在"加载更多"或继续滚动信号
5. 若卡片数量大于 0：
   - 直接进入候选人卡片提取
   - 基于本地记忆过滤本轮未处理候选人
6. 若卡片数量等于 0：
   - 再做一次低成本 DOM 分层探针
   - 只检查容器、iframe、懒加载占位、空列表文案、登录失效信号
7. 只有两轮 DOM 探针都无法确认页面状态时，才允许暂停并告诉用户当前卡在推荐页读取

## 低成本 DOM 探针

探针顺序固定为：

1. 页面标题和 URL 是否符合推荐页
2. 主内容容器是否存在
3. 候选人卡片节点数量是否大于 0
4. 是否存在"暂无结果 / 没有更多 / 加载中 / 请登录 / 风控验证"之类文案
5. 是否存在 iframe，且候选人内容是否实际在 iframe 内

探针输出必须优先结构化，例如：

- `is_recommend_page=true`
- `card_count=12`
- `has_load_more=false`
- `empty_state=false`
- `risk_prompt=false`

不要输出一大段泛化推测。

## 增量读取规则

只有在页面明确存在下面信号之一时，才继续增量读取：

- "加载更多"按钮
- 继续滚动后出现新增卡片
- 容器滚动高度继续增长
- **列表底部出现"刷新"按钮**（意味着当前批次已读完，需要刷新加载新一批）

如果没有这些明确信号，就把当前已显示卡片视为本轮可直接处理集合。

**刷新按钮处理**：
当滚动到列表底部且出现"刷新"按钮时，点击刷新以加载新一批候选人。刷新后重新从第一步卡片初筛开始处理新候选人。这是达到打招呼目标之前的常规操作，不是异常。

## 加载更多的真实机制（2026-09-10 实测，硬规则）

**结论：推荐页的候选池远大于首屏，且必须用"轮询"方式加载，不能一次性跳到底部。**

### 错误做法（会导致误判"池子耗尽"）

```javascript
// ❌ 一次性把 scrollTop 设成 scrollHeight
d.documentElement.scrollTop = d.documentElement.scrollHeight;
// 如果这一次就已经到底，后续再设同样的值不会产生新的 scroll 事件，
// 加载器不会被唤醒 → 看起来"没有更多了"，实际是没触发加载
```

### 正确做法：拟人化分步滚动 → 等待 → 对比卡片数

**禁止**一次性 `scrollTop = scrollHeight` 跳到底部，原因有两个：

1. 功能原因：一步到底后再设同值不产生新的 scroll 事件，加载器不唤醒（见上节）
2. 风控原因：瞬间位移到列表底部不是人类行为

**正确做法**：分步滚动，且**步长与停顿都必须随机**

- 单步位移：随机 `400 ~ 900px`
- 步间停顿：随机 `250 ~ 700ms`
- 每轮到底后停顿：随机 `1500 ~ 3500ms`
- 连续 **3 轮**卡片数无增长才判定到池底
- 安全阀：单轮分步不超过 40 次

```javascript
// 每一轮都重新读取状态（高度会变），分步滚到底，再对比 .candidate-card-wrap 数量
var d = document.querySelector('iframe').contentDocument;
d.documentElement.scrollTop = 当前值 + 随机(400~900);   // 分步，不要一步到底
JSON.stringify({ c: d.querySelectorAll('.candidate-card-wrap').length });
```

执行要点：

1. 单次加载增量实测为 **15 张/轮**
2. 每轮到底后等待不少于 **1.5 秒**，建议随机 1.5~3.5 秒
3. 不要因为一两轮没变化就下"池子耗尽"的结论
4. 实测容量参考：Java 岗 `推荐` 标签从 15 张增长到 **360 张**后到底

### 取样下限 200 人（硬规则，2026-09-15 修订）

**不得在取样到 200 人之前断言或汇报「候选池已耗尽」。**

注意：这条规则的目的是**防止误判池子耗尽**，**不是**要求「必须滚满 200 才能开始筛选」。允许**边滚边筛**——可以在滚动扩池的同时，对已加载的浅页批次开始筛选与打招呼；但**筛选顺序必须是浅→深**（见下节「相关性随翻页深度衰减」）。硬性红线只有一条：没取样到 200 人之前，不能说「池子耗尽」。

- 未达 200 人**不得汇报**"池子耗尽"；但可以开始初筛（浅页优先）
- 计数口径：`iframe.contentDocument.querySelectorAll('.candidate-card-wrap').length`
- 批次会随滚动回收/轮换，DOM 里只保留约 15 张窗口 —— 因此**索引定位不可用，必须按姓名定位**
- 若滚到确认池底仍不足 200 人，才可如实汇报实际数量

#### D1：池子明显偏小时直接全量取（2026-09-19 新增）

- 滚动到**确认池底**（连续 3 轮卡片数无增长）后总数仍不足 200 → 说明该画像下池子本身就小，
  **按全量取对待**，不纠结 200 门槛，如实汇报实际数量后继续往下走
- **实测案例**：Android 岗在「年龄 22-29 + 第一学历 985/211/双一流 + 只看第一学历 +
  近14天没看过 + 近一个月未交换简历」这组画像下，推荐 / 最新两个 tab **各只有 15 人**，
  滚动 20 轮无增长（`exit 2` 确认见底）。此时按 15 人全量处理，不要反复滚动空耗

#### B1 闸门：连续 60 人 0 匹配 → 暂停（2026-09-19 新增）

自**上次成功打招呼**起，累计扫描（含卡片初筛叉掉 + 详情精筛不匹配）达到 **60 人**
仍无一人「匹配」时：

1. **立即暂停**筛选与打招呼
2. 按「检查筛选条件时查什么」四步做原因分析
3. **通知并汇报给用户**（附 claw bot 推送提示）

> 与「连续滚动 3 轮无增长」的区别：后者判**池子是否见底**，
> 60 人闸门判**筛选条件是否过窄导致选不出人**。两者都要求暂停并汇报，
> 但分析方向完全不同——池子见底要扩池或放宽画像，条件过窄要查面板条件是否失效。

### 触底唤醒机制（关键）

触底后若只是把 `scrollTop` 设成同一个值，**不会产生新的 scroll 事件，加载器不会被唤醒**。必须用"回弹式触底"：

```javascript
var d = document.querySelector('iframe').contentDocument;
var maxTop = d.documentElement.scrollHeight - d.documentElement.clientHeight;
d.documentElement.scrollTop = maxTop - 随机(600~1200);  // 先回退
// 停顿随机 250~550ms
d.documentElement.scrollTop = maxTop;                    // 再到底 → 产生真实位移
```

现成脚本（已内置随机步长、随机间隔、回弹触底与最小人数控制）：

```bash
# WorkBuddy 环境
node ~/.workbuddy/skills/boss-hiring-assistant/scripts/human-scroll.mjs <targetId> 20 --min=200
# Claude Code 环境
node ~/.claude/skills/boss-hiring-assistant/scripts/human-scroll.mjs <targetId> 20 --min=200
```

退出码：`0` = 已达 200 人或正常到底；`2` = 确认池底但仍不足 200。

输出示例（每轮实际步数、回弹次数与卡片增量都可见）：

```
[18:55:02] round 1: 分步 41 段 + 回弹 2 次 | 卡片 15 -> 60 (+45) | 高度 12256
[18:55:31] round 2: 分步 38 段 + 回弹 1 次 | 卡片 60 -> 105 (+45) | 高度 21132
```

### 打招呼间隔同样必须随机

打招呼之间的停顿**不允许**用固定值，范围固定为：

```
Math.random() * 3000 + 2000   // 2000ms ~ 5000ms
```

每发送 2 到 3 人后，额外随机等待 5~10 秒做一次轻量状态校验。

**执行提醒**：实测中发现执行时很容易退化成写死的 `sleep 1` / `sleep 3`。实现时必须显式生成随机数，不要偷懒用常量。

### 滚动容器与锁的判断

- 真正滚动的是 `<html>`（`iframe.contentDocument.documentElement`），不是 `body`
- `body` 常带 `boss-layer__lock-scroll` class，这是 BOSS 的常态标记，**不代表滚动被锁死**；判定标准是 `documentElement.scrollTop` 能否被成功赋值
- 全页找不到 `.loadmore` 元素也不代表没有更多数据；`最新` 标签的 `.loadmore` 到底时会带 `finished-wrap` class，`推荐` 标签则完全没有该元素

### 三个标签的池子互相独立

`推荐` / `精选` / `最新` 三个 tab 是独立数据源，切换 tab 是扩池的重要入口：

- `最新`：长列表，滚动到底出现 `loadmore finished-wrap`
- `推荐`：长列表，可持续增长，无 loadmore 元素
- `精选`：需「搜索畅聊卡」付费权益，无卡时卡片不渲染（badge 显示人数但列表为空）

**禁止**在池子仍有增长空间时向用户汇报"候选池已耗尽"。

## 相关性随翻页深度衰减（2026-09-14 实测，硬规则）

**结论：推荐页排序的相关性会随翻页深度迅速衰减，绝不能一路滚到底再筛选。**

同一 Android 岗位实测数据：

| 取样位置 | 卡片数 | 工作经历含 Android/移动端 | 命中率 |
|---------|-------|------------------------|-------|
| 排序第 1 页批次 | 210 | 197 | 94% |
| 滚到第 11 页批次 | 240 | 16~19 | 8% |

深页批次里混入大量 Java / 算法 / 前端 / 测试候选人，与当前岗位无关。

### 正确取样节奏

1. **在当前页按浅→深逐步取样筛选**（推荐页 DOM 会累积已加载卡片，浅页批次天然排在前面）
2. **在浅页（前 1~3 批）完成筛选与打招呼**
3. 浅页打完了，**再逐步深滚扩池**

不要反过来：先滚到 200+ 再筛，会拿到大量低相关候选人，既浪费 token 又拉低命中率。

### ⛔ reload 推荐页会清空用户筛选条件（硬规则，2026-09-15 修正）

> **禁止在未经用户明确同意的情况下 navigate / reload 推荐页。**

`navigate` 回 `https://www.zhipin.com/web/chat/recommend` 虽然能回到排序第 1 页，
但**会把用户在页面上手动设置的全部平台侧筛选条件清零**（年龄、经验、学历、性别、
求职意向、薪资、院校等），实测请求参数会回落成全零：

```
age=16,-1&activation=0&school=0&recentNotView=0&gender=0&exchangeResumeWithColleague=0
&switchJobFrequency=0&major=0&keyword1=-1&experience=0&degree=0&intention=0&salary=0
```

2026-09-15 实际事故：龙虾为了拿"高相关首屏"直接 reload，用户已设置好的筛选条件全部丢失。

**正确做法**：

1. 优先**在当前页继续滚动 / 翻页**取样，不要 reload
2. 确实需要回到排序第 1 页时，**先问用户**：
   "重载推荐页会清空你在页面上设置的筛选条件，要重载吗？还是我继续往下滚？"
3. 用户同意重载时，**在重载前先把当前筛选条件读出来存好**，重载后按需恢复
4. 重载前最好先记录一次当前请求参数（见下节 `jobId` 探针写法），便于比对恢复

**岗位选择会保留**（`.job-selecter-wrap` 仍是原岗位），但平台侧筛选条件不会。

### 恢复筛选条件（首选：BOSS 自带的「应用上次筛选条件」）

**实测（2026-09-15）：推荐页平台侧筛选条件不会写入 localStorage，reload 后无法从存储里找回。**

但 BOSS 自己提供了恢复入口。打开筛选面板（点右上 `.filter-label`）后，面板内会出现一行提示：

```
是否应用上次的筛选条件？   [取消]  [应用]
```

对应 DOM：

- 应用：`div.recover`（可视时 `y≈118`，宽约 56px）
- 取消：`div.cancel`

```bash
# 打开筛选面板
curl -s -X POST "http://localhost:3456/eval?target=XXX" -H "Content-Type: text/plain" \
  --data-raw 'var d=document.querySelector("iframe[src*=recommend]").contentDocument;
var b=null;d.querySelectorAll("div,span,button").forEach(function(e){
  if((e.innerText||"").trim()===String.fromCharCode(31579,36873)&&e.children.length<=2)b=e;});
if(!b){JSON.stringify({ok:false});}else{b.setAttribute("data-wb-filter","f");JSON.stringify({ok:true});}'

# 点开面板
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" \
  -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":"[data-wb-filter=\"f\"]"}'

# 点「应用」恢复上次筛选条件
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" \
  -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":"div.recover"}'
```

⚠️ **仍属改动用户设置的动作，必须先征得用户同意再点。**

筛选面板结构（用于核对/重建筛选条件）：

| 区块 | 可选项 |
|------|--------|
| 年龄 | 数值区间（滑块，需 Vue 赋值） |
| 活跃度[单选] | 不限 / 刚刚活跃 / 今日活跃 / 3日内活跃 / 本周活跃 / 本月活跃 |
| 院校 | 不限 / 985 / 211 / 双一流院校 / 留学 / 国内外名校 / 公办本科 |
| 近期没有看过 | 不限 / 近14天没有 |
| 性别 | 不限 / 男 / 女 |
| 是否与同事交换简历 | 不限 / 近一个月没有 |
| 跳槽频率[单选] | 不限 / 5年少于3份 / 平均每份工作大于1年 |
| 专业 | 不限 / 电力电气类 / 电子信息类 / 机械类 / 计算机类 / 自动化类 / 修改筛选专业 |
| 牛人关键词 | JAVA / C++ / 性能优化 / KOTLIN / 多线程 / 设计模式 / 架构设计 / 数据结构 / 网络编程 |
| 经验要求 | 不限 / 在校·应届 / 26年毕业 / 27年毕业 / 27年后毕业 / 1年以内 / 1-3年 / 3-5年 / 5-10年 / 10年以上 |
| 学历要求 | 不限 / 初中及以下 / 中专中技 / 高中 / 大专 / 本科 / 硕士 / 博士 |
| 求职状态 | 不限 / 离职-随时到岗 / 在职-暂不考虑 / 在职-考虑机会 / 在职-月内到岗 |
| 薪资待遇[单选] | 不限 / 3K以下 / 3-5K / 5-10K / 10-20K / 20-50K / 50K以上 |

面板底部：`清除` / `确定`（两个 `.btn`，可视时 `y≈480`）。

### 手动重建筛选条件（若「应用」恢复不到）

筛选面板受 Vue 控制，必须用 Vue 实例赋值，不能靠鼠标拖拽：

- **年龄滑块**：`slider.__vue__.value = [22, 28]` 然后 `slider.__vue__.$emit('change', [22, 28])`
  （CDP 拖拽会超时，不可用）
- **checkbox 类**：每次点击后 Vue 会重渲染，**必须重新 `querySelector` 获取最新节点**，
  相邻点击加 200ms 间隔
- 恢复后回到推荐页核对请求参数里的 `age` / `experience` / `degree` 等字段是否生效

### 切 tab 有破坏性（重要）

- 点击 `.tab-item`（推荐/精选/最新）会**重置 iframe 列表**，把已滚动加载的候选池全部冲掉
- 因此 `batch-read-resume.mjs` 的「找不到姓名就轮换 tab 重试」已改为**默认关闭**，
  需显式加 `--allow-tab-switch` 才启用
- 想扩池时优先用「reload 推荐页」或「继续滚动」，不要随手切 tab

### 验证池子是否按岗位过滤

分页请求参数里带 `jobId`，可用它确认当前池是不是目标岗位：

```bash
curl -s -X POST "http://localhost:3456/eval?target=XXX" -H "Content-Type: text/plain" \
  --data-raw 'var w=document.querySelector("iframe").contentWindow;
var es=w.performance.getEntriesByType("resource").map(function(e){return e.name})
  .filter(function(n){return /rec.f1.card|rec.geek.list/.test(n)});
var ids={};
es.forEach(function(u){var m=u.match(/jobId=([a-zA-Z0-9]+)/);if(m)ids[m[1]]=(ids[m[1]]||0)+1;});
JSON.stringify(ids)'
```

注意：iframe 的 `src` 属性会显示 `jobid=null`，这是初始值，**不代表筛选失效**，
要以分页请求里的 `jobId` 为准。

## 暂停条件

只有在下面任一情况出现时，才允许暂停并请求用户帮助：

1. 推荐页 DOM 两轮探针后仍无法判断页面状态
2. 明确出现登录失效、验证码、风控验证
3. 明确出现空列表，但与用户实际页面明显矛盾
4. **CDP 不可用**（B3：`/targets` 无响应，或 proxy 反复「连接断开」/`non-101`）
5. **连续扫描 60 人 0 匹配**（B1 闸门）
6. **面板条件计数校验不一致**（C3：实际 `筛选·N` ≠ 预期计数）

> 暂停一律走统一出口，通知固定四段：**暂停原因 / 卡在哪一步 / 最小恢复动作 / 如何恢复**。
> 并附一句：「如需微信推送，请连接 WorkBuddy 的 claw bot」。

暂停时要告诉用户的是：

- 当前停在"推荐页 DOM 无法确认"
- 已完成的探针结果是什么
- 下一步最小恢复动作是什么

不要要求用户重新描述完整页面内容。
