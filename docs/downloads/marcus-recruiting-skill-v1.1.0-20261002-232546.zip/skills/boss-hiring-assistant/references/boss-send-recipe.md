# BOSS 站内消息发送固定方案

## 定位

这个文档不是"建议方案"，而是 BOSS 站内消息发送的唯一主路径。
当页面结构没有明显变化时，不得重新设计发送实现。

## 固定元素

线程确认：

- 候选人线程节点：`#_{candidate_id}`
- 也可以用 `.geek-item[data-id]` 获取 `candidate_id`

输入框：

- 首选 selector：`[contenteditable]`
- 更稳妥 selector：`.chat-container-private [contenteditable]`

发送按钮：

- selector：`.submit`
- 更稳妥 selector：`.chat-container-private .submit`

点击方式优先级：

1. `web-access clickAt`
2. `web-access` 底层 CDP `Input.dispatchMouseEvent`
3. DOM `element.click()` 仅作一次性兜底，不得作为默认主路径

## 唯一主路径

1. 先尝试点击 `#_{candidate_id}` 打开目标候选人线程
2. 先确认聊天线程确实已打开，并且当前线程身份与目标候选人一致
3. 等待输入框出现
4. 在写入消息前，再做一次候选人身份校验
5. 对 `.chat-container-private [contenteditable]` 写入消息文本
6. 在点击发送前，第三次确认当前线程仍是目标候选人
7. 点击 `.chat-container-private .submit`
8. 做一级成功校验：输入框内容清空
9. 做二级成功校验：最后一条消息或会话预览出现"送达"标记

其中第 7 步的默认实现必须是：

- 优先对发送按钮使用 `clickAt`
- 若 `clickAt` 在当前节点无效，再退到 CDP `Input.dispatchMouseEvent`
- 只有这两条都失败，才允许对同一按钮节点补一次 DOM `element.click()`

不要把 DOM `btn.click()` 当成默认发送实现。

## 候选人身份校验规则

为了避免把给候选人 A 的消息发给候选人 B，发送动作必须做三次身份校验：

1. 切线程后校验一次
2. 写入消息前校验一次
3. 点击发送前校验一次

校验信号优先级：

1. 当前选中的候选人卡片 `candidate_id`
2. 右侧面板中的候选人姓名或身份信息
3. 线程标题或当前会话头部信息

如果任意一次校验发现当前线程身份与目标候选人不一致：

- 不得继续发送
- 应立即进入 `paused_for_wrong_candidate_thread`
- 告诉用户当前线程可能已串人，已停止发送，避免误发

## 线程打开的硬前置条件

"发送消息"不等于"能点开候选人线程"。

在进入输入框和发送按钮逻辑前，必须先确认下面至少一项成立：

1. 右侧聊天/简历面板已切换到目标候选人
2. 当前页面已出现该候选人的聊天输入区
3. 当前线程标题或候选人信息已更新为目标候选人

如果上述条件都不成立，就视为"线程未成功打开"，不得继续进入发送动作。

## 发送动作的风控规则

Boss 对"批量打招呼"这类重复发送动作更敏感。

因此发送动作必须额外遵守：

1. 默认不要把 DOM `btn.click()` 当主路径
2. 主路径优先使用 `clickAt` 或 CDP 鼠标事件，模拟更接近真实用户点击
3. 每次发送后必须等待一次短暂停顿，不允许毫秒级连续触发
4. 同一轮批量发送必须设置上限，到达上限后先暂停并汇报
5. 如果页面出现验证码、异常弹窗、登录态波动、明显卡顿或发送失败率升高，立即停止该轮发送

也就是说，发送逻辑要优先"像真实点击"，而不是优先"最省实现代码"。

## 自动打开候选人线程的标准路径

"打开候选人线程"本身必须当成一个独立动作来做，而不是只靠一次 click 撞运气。

标准顺序应当是：

1. 先定位目标候选人卡片，优先使用稳定标识：
   - `#_{candidate_id}`
   - 或带 `data-id` 的候选人卡片节点
2. 先把该卡片滚动到可见区域中央
3. 等待列表稳定，再执行一次主 click
4. 检查线程是否已切换：
   - 右侧面板候选人信息是否变化
   - 线程标题是否变化
   - 输入区是否出现
5. 若未切换，再对同一卡片执行一次有限的备用点击路径

## 打开线程的有限备用路径

如果主 click 没有切换成功，只允许按下面顺序补试：

1. 对同一个候选人卡片的可点击子节点再点击一次
2. 若卡片本身在虚拟列表中位置不稳定，先重新滚动定位，再点击一次

最多只允许：

- 1 次主路径
- 2 次有限备用路径

总计不超过 3 次"线程打开尝试"。

## 线程打开失败时的处理

如果上述标准路径和有限备用路径都失败：

1. 不要继续递归遍历 DOM 乱点
2. 不要继续用 `elementFromPoint` 长时间坐标试错
3. 不要直接把问题归因于输入框 selector
4. 应进入 `paused_for_switch_thread`

暂停时应告诉用户：

- 当前候选人线程自动切换失败
- 已按标准路径和有限备用路径尝试
- 最可能原因是页面拦截、虚拟列表状态异常或当前卡片不可交互
- 需要用户确认页面当前是否正常，但不要要求用户代替龙虾完成常规点击工作

也就是说，用户只负责确认页面状态，不负责代点线程。

## 最保底的低 token 自动诊断路径

如果线程切换或发送动作失败，默认不要继续做大段复杂脚本试错。
应先走一条低 token 的分层诊断路径。

诊断顺序固定为：

1. `diagnose_candidate_presence`
   - 目标候选人卡片是否存在
2. `diagnose_candidate_visibility`
   - 目标卡片当前是否可见、是否已滚动到位
3. `diagnose_thread_switch`
   - 点击后右侧面板或线程标题是否变化
4. `diagnose_input_presence`
   - 输入框是否出现
5. `diagnose_input_editable`
   - 输入框是否可编辑
6. `diagnose_send_confirmation`
   - 发送后输入框是否清空、是否有"送达"标记

## 诊断的 token 经济性要求

每一层诊断都必须优先用最便宜的方式完成：

1. 优先读已有 DOM 节点和已有状态
2. 优先做短 selector 检查
3. 优先做单一布尔判断
4. 不要一上来提交大段复杂 eval
5. 不要在诊断阶段做多轮长链重试

也就是说，诊断目标是"快速定位故障层级"，不是"顺便重新实现一遍动作"。

## 诊断输出要求

诊断完成后，优先输出结构化结论，例如：

- `candidate_found=true`
- `candidate_visible=true`
- `thread_switched=false`
- `input_found=false`
- `send_not_attempted=true`

然后再决定：

- 是否还能再走一次主路径
- 是否需要暂停
- 是否需要进入异常兜底

## 截图在诊断中的边界

截图仍然不能作为正常读取 Boss 页面和正常发送消息的主路径。

但如果：

1. 标准路径失败
2. 有限备用路径失败
3. 低 token 分层诊断仍无法定位故障层级

则可以在用户明确同意后，把截图作为**最终故障定位手段**使用一次。

这里的截图只用于定位问题，不用于继续主流程读取和发送。

## 唯一备用路径

如果点击 `.submit` 无效，只允许一次备用路径：

- 先补一次 `clickAt` 或 CDP 鼠标事件
- 若发送按钮层仍无效，再在同一个输入框节点上派发一次 Enter

不允许继续扩展出更多发送变体。

## 优化要求

发送动作要优先遵守这些低 token 规则：

1. 少 eval，多合并
2. selector 尽量短
3. 成功验证优先看输入框是否清空
4. 优先点击候选人打开线程，不要优先走 URL 导航
5. 发送按钮优先走 `clickAt` / CDP 鼠标事件，不要默认走 DOM click
6. 批量发送时优先复用已确认有效的发送路径，不要每个候选人重新试一遍多种点击方案

## 禁止项

以下行为不允许作为常规发送路径：

- 研究 Vue 事件系统
- 起子代理处理普通发送
- 连续尝试多套前端实现
- 默认走截图/OCR
- 发送失败后长时间试错
- 把 DOM `btn.click()` 当作默认发送实现
- 在线程未打开的情况下继续尝试输入框或发送按钮
- 在线程打开失败后继续坐标点击或递归点击很多轮
- 未先滚动定位和验证卡片可见性，就反复盲点候选人

## 失败后的处理

如果主路径和唯一备用路径都失败，立即进入 `paused_for_send_message`，并告诉用户：

1. 当前线程是否已打开
2. 输入框是否可编辑
3. 已经试过主路径和 Enter 备用路径
4. 用户现在需要做什么才能恢复

如果是"候选人身份不一致"导致停止，则要明确说明：

- 当前线程身份与目标候选人不一致
- 为避免误发，消息未发送

## eval 代码参考

以下 eval 代码可直接用于 `web-access` eval 请求。使用 `Content-Type: text/plain` + `--data-raw` 传参。

**注意**：selector 为推断性写法，首次使用必须先做最小探针验证实际 class 名称。

### 候选人身份校验（发送前三次校验共用）

```js
(() => {
  // 1. 当前选中线程的候选人 ID
  const activeItem = document.querySelector('.geek-item.active, [class*="chat-item"].active, [class*="thread"].active');
  const activeId = activeItem?.getAttribute('data-id') || activeItem?.id?.replace(/^#?_/, '') || '';

  // 2. 右侧面板候选人姓名
  const panelNameEl = document.querySelector('.chat-header .name, .resume-panel .name, [class*="header"] [class*="name"]');
  const panelName = panelNameEl?.textContent?.trim() || '';

  // 3. 输入框状态
  const inputEl = document.querySelector('.chat-container-private [contenteditable], [contenteditable]');
  const inputEditable = inputEl?.isContentEditable || false;
  const inputText = inputEl?.textContent?.trim() || '';

  return JSON.stringify({
    activeId: activeId,
    panelName: panelName,
    inputEditable: inputEditable,
    inputText: inputText.slice(0, 50),
    hasInput: !!inputEl
  });
})()
```

### 分层诊断（线程切换失败时按序执行）

```js
// diagnose_candidate_presence: 目标候选人卡片是否存在
((targetId) => {
  const el = document.querySelector('#_' + targetId) || document.querySelector('[data-id="' + targetId + '"]');
  return JSON.stringify({ candidate_found: !!el });
})('/* 替换为 candidate_id */')
```

```js
// diagnose_candidate_visibility: 卡片是否在视口内
((targetId) => {
  const el = document.querySelector('#_' + targetId) || document.querySelector('[data-id="' + targetId + '"]');
  if (!el) return JSON.stringify({ candidate_visible: false, reason: 'not_found' });
  const rect = el.getBoundingClientRect();
  const inView = rect.top >= 0 && rect.bottom <= window.innerHeight;
  return JSON.stringify({ candidate_visible: inView, rect: { top: rect.top, height: rect.height } });
})('/* 替换为 candidate_id */')
```

```js
// diagnose_thread_switch: 线程是否已切换
((targetId) => {
  const activeItem = document.querySelector('.geek-item.active, [class*="chat-item"].active');
  const switchedId = activeItem?.getAttribute('data-id') || '';
  const headerEl = document.querySelector('.chat-header, [class*="chat-header"]');
  const headerText = headerEl?.textContent?.trim()?.slice(0, 50) || '';
  return JSON.stringify({
    thread_switched: switchedId === targetId,
    activeId: switchedId,
    headerText: headerText
  });
})('/* 替换为 candidate_id */')
```

```js
// diagnose_input_presence + diagnose_input_editable
(() => {
  const input = document.querySelector('.chat-container-private [contenteditable], [contenteditable]');
  return JSON.stringify({
    input_found: !!input,
    input_editable: input?.isContentEditable || false
  });
})()
```

```js
// diagnose_send_confirmation: 发送后输入框是否清空
(() => {
  const input = document.querySelector('.chat-container-private [contenteditable], [contenteditable]');
  const text = input?.textContent?.trim() || '';
  // 检查最后一条消息是否包含刚发送的内容
  const lastMsg = document.querySelector('.message-item:last-child, [class*="msg"]:last-child, [class*="message"]:last-child');
  const lastMsgText = lastMsg?.textContent?.trim()?.slice(0, 50) || '';
  return JSON.stringify({
    input_cleared: text.length === 0,
    inputRemaining: text.slice(0, 30),
    lastMessage: lastMsgText
  });
})()
```
