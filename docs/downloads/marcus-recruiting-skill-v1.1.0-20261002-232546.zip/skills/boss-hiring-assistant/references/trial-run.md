# Trial Run 试运行指南

## 目的

在正式执行招聘任务前，先做一次低风险试运行，验证：

1. `web-access` 连接正常
2. Boss 登录态有效
3. 页面读取路径可用
4. eval 传参方式正确
5. policy 已就位

## 试运行顺序

### 第一步：连接验证

1. 调用 `web-access /targets`，确认能列出浏览器 tabs
2. 在结果中找到 Boss target（URL 包含 `zhipin.com`）
3. 记录 `targetId`

**通过条件**：能找到已登录的 Boss target。

### 第二步：登录态探针

对已找到的 Boss target 做一次短 eval：

```js
document.title
```

**通过条件**：title 包含"招聘"或"BOSS直聘"或类似关键词，不包含"登录"。

### 第三步：eval 传参验证

对 Boss target 做一次最小 eval 请求，验证传参方式：

```
Content-Type: text/plain
--data-raw: document.querySelectorAll('.job-card').length
```

**通过条件**：返回数字或可解析结果，不报编码错误。

如果失败，先检查请求体编码和 `Content-Type`，不要直接跑复杂脚本。

### 第四步：JD 读取验证

1. 导航到职位管理页（优先 iframe 地址 `https://www.zhipin.com/web/frame/job/list-new`）
2. 读取岗位列表
3. 提取至少一个 JD

**通过条件**：能提取出岗位名称和 JD 内容。

### 第五步：候选人页面验证

1. 进入推荐牛人页或聊天页
2. 做一次短 DOM 读取，确认候选人卡片或聊天列表存在
3. 不执行任何发送动作

**通过条件**：能读取到至少 1 个候选人卡片或聊天线程。

### 第六步：Policy 确认

1. 检查 `company-policy.yaml` 是否存在
2. 如果存在，读取并确认关键字段（job title、hard_pass），并向用户确认**本轮目标人数**（不要用 daily_target 当默认）
3. 如果不存在，基于第五步读到的 JD 生成一版默认 policy，让用户确认

**通过条件**：policy 就位且用户已确认。

## 试运行结果汇报

试运行完成后，向用户汇报：

| 检查项 | 状态 | 说明 |
|--------|------|------|
| web-access 连接 | ✅/❌ | |
| Boss 登录态 | ✅/❌ | |
| eval 传参 | ✅/❌ | |
| JD 读取 | ✅/❌ | |
| 候选人页面读取 | ✅/❌ | |
| Policy 就位 | ✅/❌ | |

全部 ✅ → 可以开始正式筛选。
任一 ❌ → 先解决对应问题再开始。

## 注意事项

- 试运行阶段不做任何发送动作
- 不切换到截图模式
- 不起子代理
- 每步失败时按失败处理规则进入暂停，不长时间试错
- 整个试运行应在 5 分钟内完成
