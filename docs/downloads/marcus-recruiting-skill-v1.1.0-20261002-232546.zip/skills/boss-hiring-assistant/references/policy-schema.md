# Policy Schema

## 目的

定义 `company-policy.yaml` 和 `approval-policy.yaml` 的结构规范。

> ⚠️ **筛选标准的第一来源是「画像校对」（`data/profile.json`），不是本文件。**
> 画像覆盖的维度（年龄 / 活跃度 / 院校 / 近期没有看过 / 性别 / 是否与同事交换简历 /
> 经验要求 / 学历要求）一律以画像为准；`company-policy.yaml` 只用于**画像未覆盖的维度**
> （如专项经验累计口径、JD 特有技能栈）。画像规格见
> [profile-calibration.md](./profile-calibration.md)。

当 skill 基于 JD 自动生成默认 policy 时，必须符合此 schema。

## company-policy.yaml 结构

`company-policy.yaml` 是一个 YAML 数组，每个元素代表一个岗位的筛选标准。
支持多岗位配置，按 `job.title` 或 `job.title_aliases` 匹配当前操作岗位。

每个 position 块结构如下：

```yaml
- job:
    title: string          # 岗位名称，必填（用于匹配 BOSS 页面上的岗位）
    title_aliases:         # 可选，同一岗位在 BOSS 上的不同写法
      - "别名1"
      - "别名2"
    company: string        # 公司名称，必填
    type: string           # "社招全职" | "校招" | "实习"，必填
    salary: string         # 薪资范围，如 "30-50K"，必填
    daily_target: number   # 历史参考值（不是默认目标）。实际目标人数每次由用户告知

  hard_pass:
    education: string      # 学历要求，如 "本科及以上"
    experience: string     # 经验要求，如 "3年及以上 Android 开发经验"
    core_skills:           # 核心技能要求（数组）
      - "技能描述1"
      - "技能描述2"
    nice_to_have:          # 加分项（数组）
      - "加分项1"
      - "加分项2"
    # 以下字段按需使用，未涉及的维度不必出现
    # 注意：Java 岗实际使用了 city（期望城市）与 bonus_skills（加分技能，非阻断）
    city: string           # 期望城市，如 "北京"
    bonus_skills:          # 加分项技能（数组），**不作为阻断条件**
      - "加分技能1"
    gender: string
    age: string
    backend: string
    frontend: string
    ai_agent: string
    ai_skills: string
    database: string
```

## manual_review

类型：字符串数组。

列出需要人工复核的候选人画像，例如：

```yaml
manual_review:
  - "学历非211但5年以上经验且Agent经验突出"
  - "经验1-3年但有大厂背景或优秀Agent项目"
```

## direct_reject

类型：字符串数组。

列出直接淘汰条件，例如：

```yaml
direct_reject:
  - "无Agent相关经验"
  - "纯前端或纯后端无全栈能力"
  - "经验不足1年"
```

## schedule

```yaml
schedule:
  workdays: string             # 如 "周一至周五"
  time_window: string          # 如 "09:00-17:00"
  report_interval_minutes: number  # 汇报间隔，默认 60
```

## approval-policy.yaml 结构

用于审批或进阶筛选场景。结构与 `company-policy.yaml` 类似，额外支持：

```yaml
approval:
  auto_pass: boolean           # 是否允许自动推进到沟通阶段
  auto_request_resume: boolean # 是否允许自动索要附件简历
  max_batch_greet: number      # 单轮最大批量打招呼数，默认 5
  require_user_confirm_before: # 哪些动作需要用户确认
    - "pass_to_chat"
    - "pass_to_scheduling"
```

## 自动生成规则

当 skill 基于 JD 自动生成 policy 时：

1. `job` 部分直接从 JD 提取
2. `hard_pass` 从 JD 中的硬性要求提取
3. `manual_review` 和 `direct_reject` 根据 JD 要求合理推断
4. `schedule` 使用默认值
5. `daily_target` 仅作历史记录；**实际目标人数每次由用户当场告知**，不要拿它当默认值

生成后必须让用户确认差异项，不要直接开始执行。
