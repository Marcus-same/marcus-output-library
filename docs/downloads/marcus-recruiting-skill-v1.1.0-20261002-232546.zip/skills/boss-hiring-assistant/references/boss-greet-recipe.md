# BOSS 推荐页打招呼固定方案

## 定位

这个文档只处理"在推荐牛人页对已筛选通过的候选人发送首条打招呼"。

目标是保持路径短、定位准、确认快。
不要把它扩展成通用浏览器调试、事件系统研究或前台鼠标控制方案。

## 执行流程（统一，2026-09-19 重构）

> ⛔ 原「模式1 标准筛选 / 模式2 快速打招呼」二分已废除，只剩下面这一条流程。
> 入口只需解析「岗位 + 目标人数」；筛选条件来源按线1 / 线2 判定（见 SKILL.md「入口意图识别」）。

```javascript
var targetCount = <用户当次告知>;   // 不要用 config.daily_target
var greetedCount = 0;              // 从 progress.jobs[job].current_greeted_count 续算
var scannedSinceLastGreet = 0;     // B1 闸门计数器：自上次成功打招呼起扫了多少人
var roundIndex = <progress.jobs[job].round_index>;

while (greetedCount < targetCount) {
  // ① 断线探针（B3）——失败即暂停并通知用户，不自行重试
  if (!probeCdp()) { pauseAndNotify("CDP 不可用"); break; }
  // ①b 面板条件校验（C3）——计数不一致即暂停
  if (filterCount() !== expectedCount()) { pauseAndNotify("面板条件不一致"); break; }

  var cards = getVisibleCards();
  for (var card of cards) {
    if (greetedCount >= targetCount) break;
    if (roundGreetedThisRound >= 5) break;      // 单轮上限 5 人
    if (isAlreadyProcessed(card)) continue;     // 含本次任务内已判「待定」的（B4）
    scannedSinceLastGreet++;

    // ② 卡片初筛：工作经历与当前岗位相关性低 → 直接叉掉，不开详情
    if (cardScreening(card) !== "pass") { recordAction(card, "reject"); continue; }

    // ③ 详情精筛：只读 .resume-right-side，画像逐项核对
    openDetailPanel(card);
    var r = detailScreening(card);              // pass | manual_review | reject
    closeDetailPanel();                         // 必关；不点「不合适」(A3)

    if (r === "pass") {
      if (greetCandidate(card)) { greetedCount++; roundGreetedThisRound++; scannedSinceLastGreet = 0; }
    } else {
      recordAction(card, r);
    }

    wait(rand(2000, 5000));                     // 风控：随机间隔
    if (greetedCount % 2 === 0) wait(rand(5000, 10000));  // 轻量状态校验停顿

    // ④ B1 闸门：连续 60 人 0 匹配 → 暂停 + 分析 + 汇报
    if (scannedSinceLastGreet >= 60) { pauseAndNotify("连续60人0匹配"); return; }
  }

  // ⑤ 本轮收尾
  roundIndex++;
  persist();                                    // 写 progress / candidates / actions

  // ⑥ 每满 3 轮做一次轮次复核（B5）；周期内自动继续，不打断用户
  if (roundIndex % 3 === 0) {
    var audit = roundAudit();                   // 产出对照表 + 系统性偏差结论
    if (audit.allMatched && !audit.systemicBias) {
      report(roundIndex);                       // 简短汇报
      continue;                                 // A1：自动进入下一轮
    } else {
      pauseAndNotify("轮次复核发现不符合 / 系统性偏差");  // 停止打招呼
      break;                                    // 回头查筛选条件，修正并经用户确认
    }
  }
  // 非复核轮次：直接进入下一轮（A1 自动继续）

  if (!scrollDown()) { pauseAndNotify("池子已见底"); break; }
}
reportFinal();
```

**注意事项：**

- 两步筛选**不可跳过**，只对「匹配」的候选人打招呼
- 风控要求必须遵守：随机延迟、每 2 人轻量校验、异常立即停整轮
- 每处理完一位候选人**必须关闭详情面板**再进入下一位
- 连续失败 5 次 → 优先判断权益是否耗尽
- 出现验证码 / 登录失效 / 安全验证页 → 立即停止整轮并汇报
- **不要因为当前批次质量差就停止**，目标未完成就继续滚；
  但触发 60 人闸门（B1）时必须暂停并汇报

## 技术实现细节（硬规则）

### iframe 结构

推荐页内容在 iframe 内，所有 DOM 查询必须在 iframe 内执行：

```javascript
var iframe = document.querySelector("iframe");
var doc = iframe.contentDocument;
var cards = doc.querySelectorAll(".candidate-card-wrap");
```

### 卡片结构

- **卡片容器**：`.candidate-card-wrap`
- **姓名元素**：`[class*=name]` 或 `span.name`
- **打招呼按钮**：`button.btn-greet`
- **已打招呼状态**：按钮消失（`button.btn-greet` 不存在）

### 详情面板

- **打开方式**：先用 eval 按姓名给卡片打 ASCII 标记，再用 `/clickAtFrame` 点该卡片的姓名元素
  ```bash
  # 1. 按姓名定位并打标记（中文用 \uXXXX 或 charCode，标记值用 ASCII）
  curl -s -X POST "http://localhost:3456/eval?target=XXX" -H "Content-Type: text/plain" \
    --data-raw 'var d=document.querySelector("iframe").contentDocument;
  var cs=d.querySelectorAll(".candidate-card-wrap"),hit=null;
  cs.forEach(function(c){var n=c.querySelector(".name");
    if(n&&n.innerText.trim()==="\u59ec\u7f8e\u6668")hit=c;});
  cs.forEach(function(c){c.removeAttribute("data-wb-open")});
  if(!hit){JSON.stringify({ok:false});}else{
    hit.setAttribute("data-wb-open","s");
    var r=hit.getBoundingClientRect();
    d.documentElement.scrollTop=d.documentElement.scrollTop+r.top-200;
    JSON.stringify({ok:true,name:hit.querySelector(".name").innerText});}'

  # 2. 点姓名开面板
  curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" \
    -H "Content-Type: application/json" \
    --data-raw '{"frame":"iframe[src*=recommend]","selector":".candidate-card-wrap[data-wb-open=\"s\"] .name"}'
  ```
- **禁止**用 `:first-child` / `nth-child` / 索引定位（虚拟滚动后会失真，可能点到别人）
- **面板选择器**：`.dialog-lib-resume` 或 `.boss-popup__wrapper`
- **关闭方式（硬规则）**：优先使用 `/clickAt` 点击关闭按钮

**关闭面板的标准流程**：

```bash
# 最可靠：直接 remove()（推荐，2026-09-09 确认）
curl -s -X POST "http://localhost:3456/eval?target=XXX" -H "Content-Type: text/plain" \
  --data-raw 'var d=document.querySelector("iframe").contentDocument;
d.querySelectorAll(".dialog-wrap").forEach(function(w){w.remove()});"closed"'

# 备选：/clickAtFrame 点关闭按钮（需先给按钮打 ASCII 标记）
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" \
  -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":".dialog-lib-resume .close-btn"}'

# 验证面板是否关闭（等待1秒后执行）
curl -X POST "http://localhost:3456/eval?target=XXX" -H "Content-Type: text/plain" -d 'var iframe = document.querySelector("iframe"); var panels = iframe.contentDocument.querySelectorAll(".dialog-lib-resume, .boss-popup__wrapper"); var visible = 0; panels.forEach(function(p) { if (p.offsetWidth > 0) visible++; }); JSON.stringify({total: panels.length, visible: visible})'
# 期望结果：{"total":0,"visible":0} 或 visible === 0
```

**备选关闭方法**（如果方法1失败）：

```javascript
// 方法2：使用 eval 移除面板（~80%可靠）
var iframe = document.querySelector("iframe");
var doc = iframe.contentDocument;
doc.querySelectorAll(".dialog-wrap, .dialog-lib-resume, .boss-popup__wrapper").forEach(function(el) {
  el.remove();
});

// 方法3：使用 eval 设置 display:none（~60%可靠，Vue可能恢复）
var panel = doc.querySelector(".dialog-lib-resume");
if (panel) {
  panel.style.display = "none";
}
```

**重要**：
- 每次处理完候选人后，**必须**关闭详情面板再进入下一位
- 不关闭面板会导致页面滚动被阻塞，无法加载更多卡片
- 关闭后必须验证（检查 `visible === 0`），确认面板已消失

### 字符编码

eval 脚本中的中文字符串必须用 `String.fromCharCode()`：

```javascript
var beijing = String.fromCharCode(21271, 20140); // 北京
var nian = String.fromCharCode(24180); // 年
if (text.indexOf(beijing) >= 0) { ... }
```

### 滚动加载

推荐页使用虚拟滚动，候选人卡片在 DOM 中但可能不在视口内。

**正确的滚动方式**：

```javascript
// 滚动到顶部
var iframe = document.querySelector("iframe");
iframe.contentDocument.documentElement.scrollTop = 0;

// 滚动到底部（加载更多）
iframe.contentDocument.documentElement.scrollTop = iframe.contentDocument.documentElement.scrollHeight;

// 滚动到指定卡片位置
var card = iframe.contentDocument.querySelectorAll(".candidate-card-wrap")[targetIdx];
var rect = card.getBoundingClientRect();
var currentScroll = iframe.contentDocument.documentElement.scrollTop;
iframe.contentDocument.documentElement.scrollTop = currentScroll + rect.top - 200;
```

**检查卡片是否在视口内**：

```javascript
var card = iframe.contentDocument.querySelectorAll(".candidate-card-wrap")[idx];
var rect = card.getBoundingClientRect();
var inViewport = (rect.top >= 0 && rect.top < 1000);
// inViewport === false 时，需要先滚动到该卡片
```

**虚拟滚动处理**：
- 如果 `rect.top < 0`，说明卡片在视口上方，需要向上滚动
- 如果 `rect.top > 1000`，说明卡片在视口下方，需要向下滚动
- 滚动后等待 1 秒，让页面完成渲染

### 刷新按钮查找

当推荐池用尽或需要加载新一批候选人时，需要找到页面上的"刷新"或"换一批"按钮。

**查找刷新按钮**：

```javascript
var iframe = document.querySelector("iframe");
var doc = iframe.contentDocument;
var buttons = doc.querySelectorAll("button");
var refreshBtn = null;

for (var i = 0; i < buttons.length; i++) {
  var btn = buttons[i];
  var text = btn.textContent.trim();
  var cls = btn.className;
  
  // 匹配刷新按钮的关键词
  if (text.indexOf("刷新") >= 0 || 
      text.indexOf("换一批") >= 0 || 
      text.indexOf("查看更多") >= 0 ||
      text.indexOf("加载更多") >= 0 ||
      cls.indexOf("refresh") >= 0 ||
      cls.indexOf("load-more") >= 0) {
    refreshBtn = btn;
    break;
  }
}

if (refreshBtn) {
  // 使用 /clickAtFrame 点击刷新按钮
  // curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" -H "Content-Type: application/json" --data-raw '{"frame":"iframe[src*=recommend]","selector":".refresh-btn"}'
  return "refresh button found: " + refreshBtn.textContent.trim();
} else {
  return "no refresh button found";
}
```

**点击刷新按钮**：

```bash
# 如果找到了刷新按钮，使用 /clickAtFrame 点击
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":"button.refresh-btn"}'

# 或者使用通用选择器（根据实际 class 调整；注意必须唯一命中）
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":"[class*=refresh]"}'
```

**刷新后的处理**：
1. 等待 2-3 秒，让新候选人加载完成
2. 重新扫描候选人卡片
3. 继续从第一步（卡片初筛）开始处理新候选人

### 打招呼确认

打招呼成功后，卡片的 `button.btn-greet` 会消失：

```javascript
var btn = card.querySelector("button.btn-greet");
if (!btn) { /* 已打招呼 */ }
```

### 批量打招呼

使用 setTimeout 实现延迟，避免触发风控：

```javascript
function clickOne(k) {
  if (k >= count) return;
  // ... click logic ...
  setTimeout(function() { clickOne(k+1); }, 2500);
}
clickOne(0);
```

## 打招呼前必须先完成两步筛选

打招呼不是看到卡片就打。必须按下面两步走完，只有**精筛通过**的候选人才进入打招呼环节。

### 第一步：卡片初筛（硬过滤）

在推荐页候选人卡片上，只凭卡片可见信息做快速判断。

**卡片文本结构（必须区分区域）：**

卡片文本包含以下区域，每个区域的"Android"含义不同：
- **"期望 X" / "最近关注 X"** → 求职意向标签，**不等于**有该方向工作经验
- **"优势"区域** → 候选人自述技能，需看是否包含 Android 相关技术
- **工作经历标题**（卡片右侧展示的公司+岗位） → **主判断依据**，这里出现 Android 才是实际经验

**必须检查的字段（任何一项不满足直接叉掉，不开详情）：**

1. **工作经历岗位**（主判断）→ 卡片上展示的工作经历岗位，必须与**当前筛选岗位**有明确关联。
   **若工作经历与当前筛选岗位的相关程度很低 → 直接叉掉，不点开详情**，
   **即使"最近关注"或"期望"里写着当前岗位也不开详情**。
   - 例（当前招 Android）：经历全是 前端 / 后端 / 算法 / 测试 / 运维 / C++ / Golang → 叉掉
   - 例（当前招 Java）：经历全是 Android / 前端 / 算法 → 叉掉
   - 判据是**岗位相关性**，不是某个固定关键词；换岗位时判据跟着换
2. **期望城市 / 最近关注城市** → 必须包含当前岗位所在城市（如北京）。不在目标城市的直接叉掉
   > ⚠️ **这条要求的来源要清楚（2026-09-21 澄清）**：它来自
   > `config.json` 的 `jd_targets[岗].city_filter` + 本规则，
   > **既不在于画像（profile.json）的 9 项里，也不在 `company-policy.yaml` 的
   > `hard_pass` / `direct_reject` 里**。所以当推荐池打尽时，
   > 「城市」往往是那个真正的绑定约束——排查池子时应优先量化它：
   > 把批次按「Android 且期望北京」vs「Android 但期望外地」拆开统计，
   > 若前者为 0 而后者上百，就说明卡的是城市，需要用户裁决是否放开。
3. **经验年限** → 必须满足当前岗位画像 / policy 的经验要求

**评估优先级：工作经历岗位 >>> 优势描述 > 期望岗位 / 最近关注岗位**

**错误示例（之前犯的错）：**
- 汪广瑞卡片："最近关注 北京 Android" + 工作经历全是"前端开发工程师" → Android 只在求职意向标签里 → ❌ 不开详情
- 张涛卡片：卡片提到 Android → 但工作经历是"前端开发工程师 3年3个月" → ❌ 不开详情

**正确做法：**
- 先提取卡片上的**工作经历岗位标题**（如"Android开发工程师""前端开发工程师""Java后端"）
- 工作经历岗位与当前筛选岗位**有明确关联** → 才进入第二步（详情精筛）
- 工作经历岗位与当前筛选岗位**相关程度很低** → 直接叉掉，不管"最近关注"里写了什么

> **硬规则（2026-09-19 用户口径）**：这一条是**省 token 的关键闸门**——
> 相关性低就叉掉、**不点开详情**是刻意的取舍，用于把明确无关的人挡在精筛之外。
> 已知代价：极少数「早期有相关经历、但卡片只显示最近 1-2 段」的人会被误杀。
> 兜底：这类人仍按卡片信息记入 `candidates.json` 并写明 `reject_reason`，
> 便于事后抽查，但**不额外开详情**。

### 第二步：详情精筛

对卡片初筛认为"可能匹配"的候选人，点开其在线简历详情（右侧面板），完整阅读后对照画像做最终分类。

> **B4 · 同任务内不重复开详情（硬规则）**：滚动再遇到**本次任务内已判为「待定」**的候选人时，
> **直接跳过，不重复开面板**（避免每轮重复开详情白烧 token）。
> 复议时机见 `data/candidates.json` 的 `review_after` 字段（见 2.5）。

#### 2.1 详情面板的真实结构（2026-09-19 实测，硬事实）

> ⚠️ **本节 2026-09-19 全面重写。原版本说「必须滚动 `.resume-detail-wrap` 读取完整简历」——这条是错的，已删除。**

详情面板是**左右两栏**（根容器 class 带 `wasm-res`）：

```
.dialog-wrap
└ .lib-standard-resume / .dialog-lib-resume     ← 面板根
   ├ .resume-center-side     宽 762px           ← 左侧：完整简历
   │   └ .resume-detail-wrap
   │       └ iframe[src="/web/frame/c-resume/?source=recommend"]   ← 嵌套 iframe
   │           └ #resume > canvas#resume  (762×381)   ← 简历正文【纯图形，无文本节点】
   └ .resume-right-side      宽 350px           ← 右侧：「经历概览」文字
```

**关键结论：**

1. **左侧是真的存在的**，而且装了**完整简历**——但它是 **WASM 渲染在 `canvas` 上的图形**。
2. `canvas` 里**没有任何文本节点**：`innerText` 恒为 `0`，
   且 `.resume-detail-wrap` 与内层 iframe 的 `scrollHeight === clientHeight`，
   **根本不可滚动**。滚动它拿不到任何新文字。
3. `.resume-detail-wrap` 只是**包着 iframe 的一层壳 div**，不是简历内容容器。
4. 想读左侧内容**只有截图 + 视觉识别一条路**——而这条路**默认禁止**（见下）。

**左侧 canvas 的处置（2026-09-19 用户决定：选项 A）**

| 选项 | 做法 | 结论 |
|------|------|------|
| **A · 不启用** | 只用右区文本筛（方向 + 年限 + 学历 + 重复联系） | ✅ **采用** |
| B · 对少数人启用 | 只对通过初筛的人截左区补技能栈 | ❌ 否决 |
| C · 混合 | 最终打招呼前截图复核一次 | ❌ 否决 |

理由：当前判定链（岗位相关性 + 画像 9 维度）所需要的信息，
右区**已经完整提供**；技能栈/项目细节并不参与判定。
且截图会明显增加 token，并可能提高 BOSS 风控与登录强退风险。

> **因此：精筛一律只读 `.resume-right-side`，不对左侧 canvas 做截图 / OCR / 图像理解。**
> 若将来确需启用，必须先按 SKILL.md 1.1 向用户说明风险并取得明确同意。

#### 2.2 读取右区（唯一的文本来源）

```javascript
var d = document.querySelector('iframe[src*=recommend]').contentDocument;
var right = d.querySelector('.resume-right-side');
var text = right ? right.innerText.replace(/\s+/g, ' ').trim() : 'NO_PANEL';
```

**注意：必须读 `.resume-right-side`，不要再用 `.lib-standard-resume` 整体读**——
整体读虽然也能拿到右区文字（左区贡献 0 字符），但一旦 BOSS 改版、
左区出现任何文字节点，就会把 canvas 之外的内容混进来，语义不清晰。

**右区实际能拿到的字段（实测样本，约 220 字）：**

```
[操作区] 收藏 | 转发 | 举报 | 不合适 | 打招呼 | 帮我联系
[经历概览]
  广东九联科技股份有限公司  2023.07-至今      语音/视频/图形开发  3年2个月
  中国移动机顶盒分省项目    2024.06-2026.08   音视频软件开发      2年2个月
  海思电信集采              2024.01-2024.06   软件开发            5个月
[教育]
  南昌大学 2019-2023 软件工程 · 本科
[尾部]
  合作专享 · 同事沟通进度 …
```

**读取顺序（固定）：**

1. **经历概览（最重要）**：每段「公司 + 起止 + 岗位 + 时长」——
   **岗位名 → 判定方向相关性；时长 → 累加算经验年限**
2. **教育背景**：学校 / 专业 / 学历 / 起止（**注意区分本科与硕士，判断第一学历**）
3. **同事沟通进度**（在面板**末尾**）：**仅作信息参考**（了解竞争态势），
   **不作为判定依据**——同事是否沟通过**不影响打招呼**（见 SKILL.md 1.4）
4. 操作区按钮状态：确认「打招呼」按钮是否还在

**拿不到的**（都在左侧 canvas 里，按选项 A 不读）：
技能栈、职责描述、项目细节、自我评价。

**读取长度建议：** 右区整体约 200~400 字，`--chars` 给 1200~1600 足够；
**不要再靠"读更长"或"滚动"来获取更多信息**——右区就这么多，左侧是图形。

#### 2.3 对照画像 / policy 逐条检查

读取完简历后，**先按画像逐项核对（画像为主标准），再用 policy 补充画像未覆盖的维度**。

画像来自 `data/profile.json`，其 9 个字段（年龄 / 活跃度 / 院校及是否第一学历 /
近期没有看过 / 性别 / 是否与同事交换简历 / 经验要求 / 学历要求）的判定细则见
[profile-calibration.md](./profile-calibration.md)。

- **硬性维度**（年龄 / 性别 / 学历 / 经验 / 院校）任一不满足 → `不匹配`
- **软性维度**（活跃度 / 近期没有看过 / 是否与同事交换简历）任一不满足 → `待定`

> ⚠️ **画像与 policy 都必须按「当前岗位」取值，不要套用其他岗位的标准。**
> 各岗位门槛差异很大——Java 岗要求「第一学历 985」，而 Android 岗只要求「本科及以上」，
> 套错岗位的标准会把合格候选人整批误杀。
> **判定依据一律取 `company-policy.yaml` 中匹配当前岗位的那个 position 块**
> （按 `job.title` 或 `job.title_aliases` 匹配）。

**hard_pass 检查（全部满足才能 pass）——具体检查项由 policy 决定：**

| 检查项 | 检查方法 | 数据来源 |
|--------|----------|----------|
| 学历 | 对照 policy 的 `hard_pass.education`（Java 岗=第一学历全日制本科且985；Android 岗=本科及以上） | 教育背景 |
| 经验 | 对照 policy 的 `hard_pass.experience`，按**该岗位主业方向**累计时长 | 工作经历（岗位名 + 时长累加） |
| 城市 | 若 policy 有城市要求（`city` / `city_filter`），核对期望城市 | 期望信息 |
| 核心技能 | 对照 policy 的 `core_skills`；若该岗位已把技能降级为 `bonus_skills`，则**不作为阻断条件** | 技能标签 + 工作经历描述 |

**经验年限计算规则（通用形式）：**

- 只累计**与该岗位主业方向相关**的经历时长
  - Java 岗 → 岗位名含 Java 的段
  - Android 岗 → 岗位名含 Android / 安卓 / 移动端 / 客户端 的段
- 多段相关经历**累加**计算
- 实习经历减半计入（或按 policy 说明）
- 主业完全无关的岗位（如 Java 岗里的"后端开发""全栈工程师"即使涉及 Java）按 policy 判定是否计入

**院校判断规则（仅当该岗位 policy 有院校要求时才执行）：**

- 页面标注"985院校" → 直接通过
- 页面标注"QS前100院校"或"双一流" → 需确认具体学校名，再判断是否满足 policy
- 页面无院校标签 → 按学校名称判断，不确定时归入 manual_review
- **Android / AI全栈等不要求院校的岗位跳过本节**

**direct_reject 检查（命中任一条直接 reject）：**

逐条比对 policy 中 `direct_reject` 列表，例如：
- 第一学历非 985 → reject
- 非全日制本科 → reject
- 经验不足要求年限 → reject
- 无 Java 开发经验 → reject
- 期望城市不含目标城市 → reject

**manual_review 检查（不完全满足 hard_pass 但有补偿项）：**

逐条比对 policy 中 `manual_review` 列表，例如：
- 中上游 211 院校 + 技术栈匹配 → manual_review
- 经验达标但项目质量一般 → manual_review

#### 2.4 分类决策

三分类（语义与 JSON 取值的对应关系固定，不要混用）：

| 语义 | JSON 取值 | 含义 | 动作 |
|------|-----------|------|------|
| **匹配** | `pass` | 硬性 + 软性维度全部满足 | 打招呼 |
| **待定** | `manual_review` | 软性维度不满足（活跃度 / 近期没看过 / 是否与同事交换简历） | 记录 + 关闭面板，**不招待、不叉掉** |
| **不匹配** | `reject` | 硬性维度不满足（年龄 / 性别 / 学历 / 经验 / 院校） | 记录理由 + 关闭面板 |

> **A3（2026-09-19 用户规定）：判「不匹配」时只关闭面板，不要点击「不合适」。**
>
> - 面板操作区有「不合适」按钮，但**我们不点它**——它是否会消耗权益、是否影响推荐排序均未经验证
> - 正确动作：`querySelectorAll('.dialog-wrap').forEach(w => w.remove())`
>   （关闭方法见下方「关闭面板标准流程」）
> - **文档里任何"点击不合适或关闭详情"的旧表述一律以本条为准**

**信息不足以判断** → 先按现状给一个保守分类（倾向 `manual_review`），
在 `reject_reason` / `pending_reasons` 里写明缺什么信息，**不要为补信息反复纠缠**。
按 2.1 的结论，右区信息就这么多，**不存在"再滚动一下就能看到更多"的路径**。

#### 2.5 记录结果

每位候选人处理后，必须更新 `data/candidates.json`：

```json
{
  "candidate_id": "张三_Android_a1b2c3",
  "name": "张三",
  "job": "高级安卓开发工程师（学习机/教育平板）",
  "source": "recommended_feed",
  "card_scan_result": "pass|reject|skip",
  "detail_decision": "pass|manual_review|reject",
  "education": "哈尔滨工业大学 本科 985",
  "past_position": "百度Android 3年",
  "city": "北京",
  "experience_years": 5,
  "reject_reason": "期望城市不含北京",
  "pending_reasons": ["活跃度仅本月活跃"],
  "review_after": "2026-09-20",
  "greeted": true,
  "greet_result": "success|failed|skipped|success_unconfirmed",
  "processed_at": "2026-09-19T18:00:00+08:00"
}
```

**必填字段说明：**

- **`job`**（C1，2026-09-19 新增）：候选人归属的岗位。同一位候选人在不同岗位下是两条独立记录
- **`reject_reason`**：判 `reject` 时必填，便于复盘与人工抽查
- **`pending_reasons`**（B4）：判 `manual_review` 时必填，列出**具体哪个软性维度**不满足
- **`review_after`**（B4）：最早可复议日期，按时长推算：

  | 待定原因 | 复议时间 |
  |---------|---------|
  | 活跃度不足 | 次日 |
  | 近期没有看过 = 近14天没有 | 被看过那天 + 14 天 |
  | 与同事交换简历 = 近一个月没有 | + 30 天 |

**待定名单的三条配套规则（B4）：**

1. **同任务内不重复开详情**——已判待定的，滚动再遇到直接跳过（见第二步开头）
2. **复议时机**——每次开跑时，先挑 `review_after <= 今天` 的待定名单优先复核
3. **容量**——只保留 90 天，超期归档，不要让待定名单无限膨胀

**`greet_result` 的 `success_unconfirmed`（D2）**：
卡片被虚拟滚动回收、取不到卡片按钮文案时，用备用判据（操作区变化 + toast 提示），
都取不到则记 `success_unconfirmed` **待复核**，
**不硬判失败、也不重复补发**，在汇报里单独列出。

**每位候选人的一人一事闭环（硬规则）：**

```
打开卡片详情 → 阅读在线简历 → 对照 policy 分类 →
  pass → 打招呼 → 确认成功 → 【关闭详情面板】 → 下一位
  reject → 【关闭详情面板】 → 下一位
  manual_review → 【关闭详情面板】 → 标记 → 下一位
```

**不关闭详情面板的后果：**
- 页面滚动被阻塞，无法加载更多卡片
- 下次点击卡片可能点不到目标候选人
- 滚动到底部后无法触发刷新按钮

### 关闭面板标准流程（硬规则，每位候选人处理后必须执行）

**关键事实：**
1. 页面可能同时存在多个 `.dialog-wrap`（实测最多 7 个叠加），必须用 `querySelectorAll` 处理全部
2. **`display:none` 完全无效** — Vue 响应式系统会在下一帧恢复为 `display:flex`，面板依然可见
3. **唯一可靠方法：`element.remove()` 从 DOM 中彻底删除**
4. 验证必须在**单独的 eval 调用**中执行，且等待至少 1 秒让 Vue 完成渲染

#### 关闭（一步到位）

```javascript
var iframe = document.querySelector("iframe");
var doc = iframe.contentDocument;
doc.querySelectorAll(".dialog-wrap").forEach(function(dw) {
  dw.remove();
});
```

#### 验证（必须单独 eval + 等待）

```javascript
// 必须在关闭操作之后的下一个独立 eval 调用中执行，中间至少 sleep 1 秒
var iframe = document.querySelector("iframe");
var doc = iframe.contentDocument;
var wraps = doc.querySelectorAll(".dialog-wrap");
var visible = 0;
wraps.forEach(function(dw) {
  if (dw.offsetWidth > 0) visible++;
});
// wraps.length === 0 → 关闭成功
// visible > 0 → 还有面板没关掉
```

#### 打开下一位

```javascript
// remove() 后不需要重置，直接打开
doc.querySelectorAll(".candidate-card-wrap")[nextIdx].querySelector("[class*=name]").click();
```

#### 完整的一次「分析→关闭→打开下一位」循环

```javascript
// 1. 分析完 → 删除所有面板
var iframe = document.querySelector("iframe");
var doc = iframe.contentDocument;
doc.querySelectorAll(".dialog-wrap").forEach(function(dw) { dw.remove(); });

// 2. 等待 Vue 渲染（sleep 1 秒）

// 3. 验证（单独 eval）
var wraps = doc.querySelectorAll(".dialog-wrap");
// wraps.length === 0 即成功

// 4. 打开下一位（不需要重置，直接点击）
doc.querySelectorAll(".candidate-card-wrap")[nextIdx].querySelector("[class*=name]").click();
```

**禁止**：
- ❌ 用 `display:none`（Vue 秒恢复，完全无效）
- ❌ 用 `querySelector`（只取第一个，会漏掉其他面板）
- ❌ 在同一个 eval 里关闭+验证（Vue 还没恢复，验证结果是假的）
- ❌ 跳过关闭直接打开下一位

### 筛选示例

以"高级安卓开发工程师"岗位为例：

**卡片初筛通过 → 进入详情的情况：**
- 卡片显示"Android 开发工程师"、"移动端开发"、"鸿蒙/Android"等 → 打开详情
- 卡片显示"Java 后端"但有"Android 相关经验" → 打开详情
- 卡片显示"全栈工程师"且有移动端标签 → 打开详情

**卡片初筛直接叉掉的情况：**
- 卡片显示过往岗位是"产品经理"、"机械工程师"、"项目经理" → 与 Android 无关
- 卡片显示期望岗位是"大模型算法"、"数据分析师" → 与 Android 无关
- 卡片显示纯嵌入式、纯前端（非移动）、纯运营 → 与 Android 无关

**详情精筛后 pass 的标准（参考 Android 岗位 policy）：**
- 本科及以上 + 3 年及以上 Android 开发经验
- 精通 Kotlin/Java + 熟悉 Android SDK + 主流架构
- 熟悉 Jetpack 组件、网络请求等

**详情精筛后 reject 的标准：**
- 无 Android 原生开发经验
- 纯后端/纯前端/纯嵌入式，无移动端经历
- 经验不足 2 年且无突出补偿项

## 实测补充：打招呼按钮的实际位置（2026-09-10 验证）

**打招呼按钮在详情面板内，不在卡片上。**

打开候选人详情面板后，面板顶部操作区有可见按钮：

- 选择器：`.btn-sure-v2.btn-greet`（class 全称 `btn-v2 btn-v2-new btn-sure-v2 btn-greet`）
- 位置：面板内可见区域，实测 y≈98（**标记值必须用 ASCII**）
- 点击方式：先用 eval 打临时标记，再 `/clickAtFrame`

```bash
# 1. 标记
curl -s -X POST "http://localhost:3456/eval?target=XXX" -H "Content-Type: text/plain" \
  --data-raw 'var d=document.querySelector("iframe").contentDocument;
var b=d.querySelector(".btn-sure-v2.btn-greet");
if(!b){JSON.stringify({ok:false});}else{
  b.setAttribute("data-workbuddy-greet-target","c1");
  JSON.stringify({ok:true,txt:b.innerText.trim()});}'
# 2. 点击
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" \
  -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":"[data-workbuddy-greet-target=\"c1\"]"}'
```

**成功确认（一次 eval 同时看三处）**：

```bash
curl -s -X POST "http://localhost:3456/eval?target=XXX" -H "Content-Type: text/plain" \
  --data-raw 'var d=document.querySelector("iframe").contentDocument;
var left=d.querySelectorAll("[data-workbuddy-greet-target]").length;
var panelBtn=d.querySelector(".btn-sure-v2.btn-greet")?1:0;
JSON.stringify({markerLeft:left,panelGreetBtnStill:panelBtn})'
# markerLeft=0 且 panelGreetBtnStill=0 → 成功（再核对卡片按钮是否已变「继续沟通」）
```

**成功判定（实测可靠）**：点击后面板内该按钮从 DOM 消失（`gone`），同时该候选人卡片按钮文案由「打招呼」变为「继续沟通」。

注意：卡片上旧位置的 `button.btn.btn-greet` y 坐标为负数（在不可见区域），不要点那些。

## 实测补充：三个 tab 是独立候选池（2026-09-10 验证）

推荐页顶部有三个 tab，**池子互相独立**，是扩池的关键入口：

- `推荐` / `精选` / `最新`，选择器 `.tab-item`，当前激活的带 `curr` class
- 切换方式：给目标 `.tab-item` 打标记后 `clickAt`
- 实测容量（Java 岗）：`最新` 66 人、`推荐` 15 人、`精选` 有 badge 数字但**需「搜索畅聊卡」才能开聊**（付费权益，无卡时卡片不渲染）
- 池子到底信号：底部 `.loadmore` 元素 class 为 `loadmore finished-wrap`，且全页找不到「刷新 / 换一批」按钮

## 实测补充：卡片定位与虚拟滚动（2026-09-10 验证）

- 卡片索引会被虚拟滚动回收：按索引拿到的卡片可能已不在 DOM
- 稳定做法：**按姓名查找卡片 → 打唯一 `data-*` 标记 → 滚动到视口（`top≈200`）→ clickAt**
- 标记值必须唯一（如姓名），不要复用同一个值；上一轮残留的标记会导致 `querySelector` 命中错误卡片
- 中文匹配的 `String.fromCharCode` 编码必须核对（例：琪 = `29738`，不是 `29734`），写错会静默匹配失败
- 姓名找不到时先列出 `cards[k].querySelector('.name').innerText` 核对实际文本，再定位

## 重要事实：权益优先

推荐牛人页打招呼可能受账号当日沟通权益限制。

真实测试发现：当账号当天只剩 3 次推荐牛人沟通权益时，前 3 位候选人可以成功，后续候选人无论自动点击还是用户手动点击都没有反应。

因此，出现"前几个成功、后续连续失败"时，第一优先级不是怀疑 selector、Vue 事件或 click 方式，而是先判断：

- 当日推荐牛人沟通权益是否已耗尽
- 页面是否存在剩余次数、权益、沟通额度、开通权益、升级套餐等提示
- 手动点击是否同样无反应

如果用户手动点击也无反应，或页面有明确权益/额度限制信号，应进入：

- `paused_for_boss_contact_quota_exhausted`

并记录：

- 已成功打招呼人数
- 本轮剩余未打招呼候选人
- 预计可在明日权益恢复或购买/开通权益后继续

不要继续测试更多 click 方式。

## 前置条件

开始打招呼前，必须同时满足：

1. 候选人已经通过筛选，或已获用户批准进入沟通
2. 当前 Boss 登录态稳定
3. 当前任务正在使用 `web-access`
4. 当前推荐页候选人卡片已稳定显示
5. 当前话术已经准备好，不在页面里边想边写

## 固定主路径

1. 在当前推荐页定位目标候选人卡片
2. 用稳定标识绑定"候选人卡片"和"该卡片内的打招呼按钮"
3. 做候选人身份确认
4. 点击该候选人卡片内已绑定的打招呼按钮
5. 在当前页面完成成功确认
6. 成功后记录发送结果和发送时间
7. 再进入下一位候选人

这是一条"一人一事务"路径。
不要先识别一批候选人，再回头按按钮序号批量点击。

## 稳定定位规则

推荐页打招呼时，默认禁止使用纯位置索引定位，例如：

- XPath 第 `N` 个按钮
- 第 `N` 张卡片里的按钮
- `button[4]`
- "当前列表第 2 个/第 4 个按钮"

必须优先使用：

1. 候选人唯一 ID
2. 卡片节点上的稳定属性，例如 `data-id`、`href`、业务主键
3. 候选人姓名 + 职位 + 当前卡片文本上下文的组合绑定
4. 如果页面没有唯一 ID，则用 eval 给目标卡片或目标按钮临时写入唯一 `data-*` 标记

也就是说，先锁定"这是哪位候选人"，再锁定"这个按钮属于这位候选人"。
不要倒过来先点按钮，再猜它属于谁。

## 无唯一 ID 时的临时标记方案

推荐页卡片可能没有稳定唯一 ID，但卡片内部通常包含候选人姓名和打招呼按钮。

这种情况下，不要退回 XPath、nth-child 或"第 N 个按钮"。
必须使用"先按文本找到卡片，再给卡片内按钮临时打标"的方式。

固定步骤：

1. 用 eval 在当前 DOM 中查找包含目标候选人姓名和必要上下文的卡片
2. 在该卡片内部查找打招呼按钮
3. 给该按钮写入临时属性，例如：
   - `data-lobster-greet-target="candidate_name_or_hash"`
4. 再用 CSS selector 调用 `web-access`：
   - `[data-lobster-greet-target="candidate_name_or_hash"]`
5. 点击完成后清理或覆盖该临时标记

这样做的目的：

- 仍然让 `/clickAt` 或 `/click` 使用 CSS selector
- 避免 `querySelector` 不支持 `:contains`
- 避免 XPath / nth-child 在虚拟滚动后失真
- 避免误点到其他候选人的打招呼按钮

如果候选人同名，必须加入职位、年龄、学校、期望岗位等卡片上下文共同匹配。
如果仍无法唯一匹配，则进入 `paused_for_candidate_binding`，不要继续点按钮。

## eval 代码参考

以下 eval 代码可直接用于 `web-access` eval 请求。使用 `Content-Type: text/plain` + `--data-raw` 传参。

### 读取推荐页全部候选人卡片

```js
(() => {
  const cards = document.querySelectorAll('.recommend-card-wrap, .card-inner, [class*="geek-card"]');
  const result = [];
  cards.forEach(card => {
    const nameEl = card.querySelector('.name, .geek-name, [class*="name"]');
    const infoEl = card.querySelector('.info, .geek-desc, [class*="info"]');
    const btnEl = card.querySelector('button, .btn, [class*="btn"]:not([style*="display: none"])');
    if (!nameEl) return;
    result.push({
      name: nameEl.textContent.trim(),
      info: (infoEl || {}).textContent?.trim() || '',
      btnText: btnEl?.textContent?.trim() || '',
      btnDisabled: btnEl?.disabled || btnEl?.classList?.contains('disabled') || false,
      href: card.querySelector('a')?.href || '',
      cardId: card.getAttribute('data-id') || card.getAttribute('data-geek-id') || ''
    });
  });
  return JSON.stringify({ count: result.length, cards: result });
})()
```

返回示例：`{"count":10,"cards":[{"name":"张三","info":"5年·硕士·北京大学","btnText":"立即沟通","btnDisabled":false,"href":"...","cardId":"12345"}]}`

**注意**：以上 selector 是推断性的，首次使用时必须先用最小探针验证页面实际 class 名称。如果 selector 不匹配，先做一次 class 探测：

```js
(() => {
  const containers = document.querySelectorAll('[class*="recommend"], [class*="geek"], [class*="card"]');
  return JSON.stringify(Array.from(containers).slice(0, 10).map(el => ({
    tag: el.tagName,
    cls: el.className,
    childCount: el.children.length,
    text: el.textContent.trim().slice(0, 80)
  })));
})()
```

### 按姓名找到卡片并写入临时标记

```js
((targetName) => {
  const cards = document.querySelectorAll('.recommend-card-wrap, .card-inner, [class*="geek-card"]');
  let found = 0;
  cards.forEach(card => {
    const nameEl = card.querySelector('.name, .geek-name, [class*="name"]');
    if (!nameEl || nameEl.textContent.trim() !== targetName) return;
    found++;
    const btn = card.querySelector('button, .btn, [class*="btn"]');
    if (btn) {
      btn.setAttribute('data-lobster-greet-target', encodeURIComponent(targetName));
    }
  });
  return JSON.stringify({ matched: found, selector: '[data-lobster-greet-target="' + encodeURIComponent(targetName) + '"]' });
})(/* 替换为目标姓名 */'张三')
```

**同名候选人**：如果 `matched > 1`，必须加上更多上下文（职位、年龄等）来唯一确定，否则进入 `paused_for_candidate_binding`。

### 成功确认 eval

点击打招呼按钮后，用这个 eval 检查目标卡片状态是否变化：

```js
((targetName) => {
  const key = encodeURIComponent(targetName);
  const btn = document.querySelector('[data-lobster-greet-target="' + key + '"]');
  if (!btn) return JSON.stringify({ found: false, reason: '临时标记不存在，卡片可能已滚出视口' });
  const card = btn.closest('[class*="card"], [class*="recommend"]');
  const nameEl = card?.querySelector('.name, .geek-name, [class*="name"]');
  return JSON.stringify({
    found: true,
    btnText: btn.textContent.trim(),
    btnDisabled: btn.disabled || false,
    cardStatus: card?.querySelector('[class*="status"]')?.textContent?.trim() || '',
    name: nameEl?.textContent?.trim() || ''
  });
})(/* 替换为目标姓名 */'张三')
```

**判断成功**：
- `btnText` 从"立即沟通"变为"继续沟通"/"已沟通" → 成功
- `btnDisabled` 变为 `true` → 成功
- `cardStatus` 出现"已联系"/"已沟通" → 成功
- 以上均无变化 → 可能失败，先检查权益是否耗尽

## 点击路径

推荐页打招呼按钮默认只允许按下面顺序尝试：

1. `web-access /clickAtFrame`，body 为 JSON `{frame, selector}`（BOSS 推荐页内容在 iframe 内，**唯一正确路径**）
2. `web-access /clickAt`，不加前缀（仅当按钮在主文档中时）
3. `web-access /click`，使用目标按钮 CSS selector
4. 单次 DOM `element.click()` 兜底

### `/clickAtFrame` 用法（硬规则，2026-09-14 更新）

> ⚠️ **web-access proxy 新版本（2026-09 起）已移除 `/clickAt` 的 `::iframe::` 前缀支持。**
> 继续用旧写法会被当成普通 CSS selector，报
> `SyntaxError: Failed to execute 'querySelector' ... is not a valid selector`。

```bash
# BOSS 推荐页内容在 iframe 内，必须用 /clickAtFrame
curl -s -X POST "http://localhost:3456/clickAtFrame?target=XXX" \
  -H "Content-Type: application/json" \
  --data-raw '{"frame":"iframe[src*=recommend]","selector":"[data-workbuddy-greet-target=\"c1\"]"}'
```

参数说明：

- `frame`：主文档中的 iframe 选择器，BOSS 推荐页固定用 `iframe[src*=recommend]`
- `selector`：iframe **内部**的选择器，必须**唯一命中 1 个元素**，禁止 `nth-child`
- 成功返回：`{"clicked":true,"x":1103.5,"y":158,"tag":"BUTTON","inIframe":true}`
- 失败返回 `{"error":"..."}`，此时不要盲试其他 selector，先按错误信息排查

原理：proxy 在 iframe 内用 `querySelector` 定位元素，计算 **iframe 偏移 + 元素偏移** 的绝对坐标，
再用 CDP `Input.dispatchMouseEvent` 发到浏览器级坐标，实现真实鼠标点击穿透 iframe。

**脚本侧兼容层**：`scripts/*.mjs` 里的 `clickAt()` 已内置翻译，
调用点仍写 `::iframe::xxx` 也能正常工作；但**手工 curl 必须用 `/clickAtFrame`**。

**注意区分按钮**：推荐页存在多个 `button.btn-greet`，卡片上的旧按钮被推到不可见区域（y > 1000）。
必须点击面板内可见的 `.btn-sure-v2.btn-greet`（实测 y≈98），而非卡片上的 `button.btn.btn-greet`。

任何一步成功后都要立即停止继续试其他点击变体。

不要引入：

- 截图坐标点击
- browser-use
- 额外 RPA 工具
- 长链 Vue 事件研究

如果这三类点击都没有让当前卡片状态变化，先进入"权益耗尽优先诊断"，不要继续扩展点击方式。

## 成功确认

成功确认优先级固定为：

1. 当前候选人卡片内按钮文案是否变化
   - 例如从"立即沟通 / 打招呼"变成"继续沟通 / 已沟通"
2. 当前候选人卡片操作区是否变化
   - 例如按钮消失、按钮禁用、按钮样式变化、操作区被替换
3. 当前候选人卡片主状态文案是否变化
   - 例如新增"已联系""已沟通""继续沟通"
4. 页面是否出现短时成功提示
   - 例如 toast、轻提示、顶部提示条
5. 当页或全局打招呼计数是否增加

不要只因为"点击 API 返回成功"就当作发送成功。
也不要只因为"全局计数增加"就确认目标候选人成功，必须优先看目标卡片自身状态。

## 权益耗尽优先诊断

如果出现下面模式，应优先判断为权益耗尽或账号权益限制：

1. 前 1 到 3 个候选人打招呼成功
2. 后续多个候选人连续点击无效
3. 目标候选人绑定准确
4. 页面没有明显技术错误
5. 用户手动点击也无反应，或页面存在权益/额度提示

此时进入：

- `paused_for_boss_contact_quota_exhausted`

并停止本轮推荐页打招呼。

暂停汇报应包含：

- 今日已成功沟通人数
- 当前疑似权益上限
- 尚未触达但已筛选通过的候选人名单
- 建议明日权益恢复后继续，或让用户开通/购买更多沟通权益

不要把这类情况误判为：

- selector 失效
- Vue 事件失败
- web-access 不可用
- 需要前台鼠标点击

## 外部确认的边界

推荐页打招呼默认不跳聊天页确认。

只有当前页没有足够成功信号，且没有权益耗尽迹象时，才允许做一次外部确认。

如果必须离开推荐页做外部确认：

1. 只允许做一次
2. 确认完成后，如果还要继续处理下一位候选人，必须重新回到推荐页重新定位
3. 回到推荐页后，禁止复用上一轮的 XPath 索引、按钮序号、卡片序号

## 滚动刷新与持续执行规则

打招呼目标是完成用户指定的数量（如 20 个）。在达到目标之前，必须持续执行：

1. **持续下滑**：每次处理完当前批次候选人后，继续向下滚动加载更多
2. **刷新按钮**：当滚动到列表底部时，页面最后一行通常会出现"刷新"按钮。点击刷新以加载新一批候选人
3. **循环执行**：刷新后继续从第一步卡片初筛开始，对新加载的候选人走两步筛选流程
4. **终止条件**：只有当打招呼数量达到用户设定的目标时才停止

**禁止在未达到目标时主动停止**。不要因为"当前这批候选人质量差"就停下来等用户指示，应继续滚动和刷新。

### 关键：关闭详情面板（硬规则）

每处理完一位候选人（无论打招呼还是叉掉），**必须先关闭右侧详情面板**，再进入下一位。

不关闭详情面板会导致：
- 页面滚动被阻塞，无法加载更多卡片
- 下次点击卡片可能点不到目标候选人
- 滚动到底部后无法触发刷新按钮

**关闭面板的方法（按可靠性排序）：**

1. **PointerEvent 在 close-btn 上**（~90% 可靠，首选）：
```js
const rp = doc.querySelector(".lib-standard-resume, .dialog-lib-resume");
const closeBtn = rp.querySelector(".close-btn");
const r = closeBtn.getBoundingClientRect();
const cx = r.left + r.width/2, cy = r.top + r.height/2;
closeBtn.dispatchEvent(new PointerEvent("pointerdown",{bubbles:true,cancelable:true,view:iframe.contentWindow,clientX:cx,clientY:cy,pointerId:1,pointerType:"mouse"}));
closeBtn.dispatchEvent(new PointerEvent("pointerup",{bubbles:true,cancelable:true,view:iframe.contentWindow,clientX:cx,clientY:cy,pointerId:1,pointerType:"mouse"}));
closeBtn.dispatchEvent(new PointerEvent("click",{bubbles:true,cancelable:true,view:iframe.contentWindow,clientX:cx,clientY:cy,pointerId:1,pointerType:"mouse"}));
```

2. **MouseEvent 在 Vue 根元素上**（~70% 可靠）：
```js
rp.dispatchEvent(new MouseEvent("click",{bubbles:true,cancelable:true,view:iframe.contentWindow,clientX:cx,clientY:cy}));
const wrapper = rp.closest(".boss-popup__wrapper");
if (wrapper) wrapper.dispatchEvent(new MouseEvent("click",{bubbles:true,cancelable:true,view:iframe.contentWindow,clientX:cx,clientY:cy}));
```

3. **elementFromPoint + DOM 遍历 + MouseEvent**（~60% 可靠）

4. **Document 空白处点击**（~50% 可靠）

**禁止**：navigate 离开推荐页（会清除用户设置的筛选条件）
```js
const rp = doc.querySelector(".lib-standard-resume, .dialog-lib-resume");
const closeBtn = rp.querySelector(".close-btn");
const r = closeBtn.getBoundingClientRect();
const cx = r.left + r.width/2;
const cy = r.top + r.height/2;
// 方法A：在 rp 上 dispatch
rp.dispatchEvent(new MouseEvent("click",{bubbles:true,cancelable:true,view:iframe.contentWindow,clientX:cx,clientY:cy}));
// 方法B（如果A失效）：在 .boss-popup__wrapper 上 dispatch
const wrapper = rp.closest(".boss-popup__wrapper, .boss-dialog");
if (wrapper) wrapper.dispatchEvent(new MouseEvent("click",{bubbles:true,cancelable:true,view:iframe.contentWindow,clientX:cx,clientY:cy}));
// 方法C（如果AB都失效）：elementFromPoint + 向上遍历
const el = doc.elementFromPoint(cx, cy);
let target = el;
while (target && !target.classList?.contains("close-btn")) { target = target.parentElement; }
if (target) target.dispatchEvent(new MouseEvent("click",{bubbles:true,view:iframe.contentWindow}));
```
**原理**：Vue 的 click 监听器绑定在 `.lib-standard-resume` 或 `.boss-popup__wrapper` 上（有 `__vue__` 实例），不在 `.close-btn` 上。三种方法覆盖不同情况下 Vue 事件绑定的父元素。

2. `elementFromPoint` + 向上遍历 + 鼠标事件（~70% 可靠）：
```js
const rp = doc.querySelector(".lib-standard-resume, .dialog-lib-resume");
const closeBtn = rp ? rp.querySelector(".close-btn") : null;
if (closeBtn) {
  const r = closeBtn.getBoundingClientRect();
  const el = doc.elementFromPoint(r.left + r.width/2, r.top + r.height/2);
  // elementFromPoint 可能返回 SVG <path>，必须向上遍历找到 .close-btn
  let target = el;
  while (target && !target.classList?.contains("close-btn")) { target = target.parentElement; }
  if (target) {
    target.dispatchEvent(new MouseEvent("click", {bubbles:true, view:iframe.contentWindow}));
  }
}
```

3. ~~导航重置（navigate 回推荐页）~~ **禁止使用**：
   navigate 会清空用户在页面上设置的**全部平台侧筛选条件**，
   属于 SKILL.md 1.3 明令禁止的动作。详见
   [boss-recommend-read-recipe.md](./boss-recommend-read-recipe.md) 的
   「reload 推荐页会清空用户筛选条件」章节。

3. `elementFromPoint` + 向上遍历（~60% 可靠）：
```js
const el = doc.elementFromPoint(r.left + r.width/2, r.top + r.height/2);
let target = el;
while (target && !target.classList?.contains("close-btn")) { target = target.parentElement; }
if (target) target.dispatchEvent(new MouseEvent("click",{bubbles:true,view:iframe.contentWindow}));
```

4. **Document 空白处点击**（~50% 可靠）：
```js
doc.dispatchEvent(new MouseEvent("click",{bubbles:true,cancelable:true,clientX:50,clientY:50}));
```

**实际执行策略**：四种方法依次尝试，任一成功即停止。四种都失败时暂停并报告。

### 打招呼间隔（风控要求）

相邻两次打招呼之间必须加入**随机**短暂停顿，不能固定间隔：

```
每位候选人处理完后：
  关闭面板 → 等待随机 2-5 秒 → 再开下一位
```

随机间隔范围：`Math.random() * 3000 + 2000`（2000ms 到 5000ms）

**禁止使用固定 sleep 值**（如固定 sleep 1 或 sleep 2），固定间隔容易被 BOSS 风控识别为机器行为。

### 实测风控事故（2026-09-10，必须引以为戒）

当晚实际执行时**只做了随机间隔，却没有限制单轮人数**，结果：

- 一轮内 5 分钟内连续打招呼 **15 人**（另有一轮 9 人）
- 20:33 页面被强制跳转到安全验证页：
  `https://www.zhipin.com/web/passport/zp/verify.html?callbackUrl=.../web/chat/recommend`
- 会话中断，需用户手动完成验证才能恢复

**结论：随机间隔不足以规避风控，必须同时限制单轮人数。**

硬性要求：

1. 单轮打招呼上限 **5 人**（`approval-policy.yaml` 的 `max_batch_greet`），达到即暂停汇报
2. 跨轮之间也要留足间隔，不要一轮结束立刻开下一轮
3. 检测到页面跳转 `verify.html` / 出现验证码 / 出现"安全验证"字样 → **立即停止整轮**，写入 `progress.json`：
   ```json
   { "paused": true, "pause_reason": "boss_security_verification", "paused_at": "..." }
   ```
   并告知用户需手动完成验证后再恢复

脚本侧对应参数：`round-execute.mjs --max-greet=5`（默认即为 5）。

每发送 2 到 3 人后，额外等待 5-10 秒做轻量状态校验。

## 单轮发送上限

打招呼默认必须分轮执行。

单轮内必须遵守：

1. 小批量发送
2. 相邻发送之间加入随机短暂停顿
3. 每发送 2 到 3 人，做一次轻量状态校验
4. 单轮达到权益上限、用户设定上限或异常上限后结束本轮

**本轮结束后（A1，2026-09-19 用户确认）：**

- **自动进入下一轮**，不需要每轮等用户确认
- 只有两种情况会打断：**每满 3 轮的轮次复核发现不符合**，或**其他闸门触发**
  （60 人 0 匹配 / 断线 / 风控 / 权益耗尽）

不要因为同一套路径刚刚成功，就无限连续发送。

## 轮次复核（硬规则，2026-09-19 用户规定）

**每满 3 轮做一次复核**（不是每轮）。周期内的每轮打完**自动继续**，不打断用户。

> 为什么是"每三轮"而不是"每轮"：打招呼前刚刚按画像筛过，每轮再逐个复核等于自己查自己，
> 成本高、收益低。复核的真正价值在于**发现系统性偏差**——例如连续 3 人都是双非本科，
> 说明院校筛选压根没生效。所以把复核周期拉长到 3 轮，让它有足够样本看出模式。

### 步骤

1. **列出本轮次（最近 3 轮）已打招呼的候选人**
   - 对照 `data/candidates.json` 中 `greeted: true` 且 `job` = 当前岗位、
     `processed_at` 落在最近 3 轮时间窗内的记录

2. **逐个复核是否符合当前画像**，并按维度产出**对照表**：

   ```
   | 候选人 | 年龄 | 活跃度 | 院校(第一学历) | 近期没看过 | 性别 | 未交换简历 | 经验 | 学历 | 结论 |
   |--------|------|--------|---------------|-----------|------|-----------|------|------|------|
   | 张三   | ✓    | ✓      | ✓             | ✓         | ✓    | ✓         | ✓    | ✓    | 符合 |
   | 李四   | ✓    | ✗      | ✓             | ✓         | ✓    | ✓         | ✓    | ✓    | 不符合（活跃度） |
   ```

   - 卡片信息不足的维度（性别、第一学历细节、完整经历）→ 开详情面板读完整履历
   - **按维度统计不符人数**，得出「是否存在系统性偏差」结论

3. **系统性偏差判定阈值（B5）**

   满足任一条件即判定为**存在系统性偏差**：

   - **同一维度有 ≥2 人不符合**，或
   - **同一维度不符人数占本轮次已打人数的 ≥40%**

   判定的意义：单个人不符可能是个案（BOSS 数据滞后、候选人刚更新活跃度），
   但「同一个维度反复不符」几乎一定是**筛选条件本身没生效或取错了**。

4. **按结果分支**

   | 复核结果 | 动作 |
   |---------|------|
   | 全部符合 **且** 无系统性偏差 | 输出简短汇报 → **自动进入下一轮**（A1，不打断用户） |
   | 有任一不符合 **或** 判定有系统性偏差 | **立即停止打招呼** → 回头检查筛选条件 → 修正并经用户确认 → 才能继续 |

### 检查筛选条件时查什么

有不符合时，按下面顺序排查，**找到根因再动手**：

1. **画像取值是否与实际不符**：`data/profile.json` 与实际约定是否一致
2. **面板条件是否失效**：读 `筛选·N` 条件计数与分页请求参数
   （`age` / `activation` / `school` / `experience` / `degree` / `recentNotView` /
   `exchangeResumeWithColleague`）核对是否仍是约定值
3. **是否是 BOSS 侧过滤的固有偏差**：例如「只看第一学历」未勾选时院校按任意学历生效；
   近期没有看过 / 是否与同事交换简历这类排除型条件可能被平台放宽
4. **是否是我方判定逻辑的问题**：独立学院被误判成母体名校、卡片摘要不足导致方向误判等

**禁止**在「已打招呼的候选人存在不符合画像」的情况下继续下一轮。
**禁止**为了凑人数而降低画像标准。

## token 经济性要求

推荐页打招呼默认要优先节省 token：

1. 优先在单个 eval 中提取"候选人标识 + 卡片文本 + 按钮状态"
2. 优先在当前页完成成功确认，减少 `navigate`
3. 不要为每位候选人重复跑整页深度分析
4. 每位候选人只允许一次快速补试
5. 失败后输出结构化结果，不输出长篇泛化原因分析
6. 连续失败时优先进入权益耗尽诊断，不继续发散 click 方案

## 禁止项

以下行为不允许作为默认打招呼路径：

- 一边看页面一边临时生成长话术
- 起子代理研究 Vue 或前端事件
- 反复切换 DOM click / 坐标点击 / 截图方案
- 发送失败后长时间停在同一候选人页面试错
- 要求用户手动帮忙点击候选人或手动发送
- 用 XPath / DOM 序号把"第 N 个按钮"当成目标候选人按钮
- 每打一位候选人就默认切到聊天页确认，再回推荐页继续用旧索引
- 使用额外本机控制路径作为默认或兜底路径
- **点击面板上的「不合适」按钮**（A3：判不匹配只关面板，不点「不合适」）
- **对左侧 canvas 截图 / OCR / 图像理解**（2026-09-19 用户选 A，左侧简历是图形，不读）
- **reload / navigate Boss 页面**（见 SKILL.md 1.3，会清空用户筛选条件）

## 权益耗尽检测（#7）

批量打招呼过程中必须监控以下信号：

1. **连续失败计数**：连续 N 次（默认 5 次）打招呼按钮点击后文案未变为"继续沟通" → 疑似权益耗尽
2. **页面异常信号**：出现验证码、登录失效页、异常弹窗 → 立即停止
3. **推荐池质量骤降**：连续扫描 M 张卡片（默认 50 张）无一个 pass 候选人 → 可能推荐池耗尽或岗位不匹配

> **与 B1 闸门的区别（2026-09-19 新增）**
>
> | 信号 | 阈值 | 判定为 |
> |------|------|--------|
> | 权益耗尽检测（本节） | 连续 50 张无 pass | **权益 / 池子问题** |
> | B1 闸门 | 自上次成功打招呼起连续 **60 人** 0 匹配 | **筛选条件过窄** |
>
> 两者都会暂停并汇报，但**分析方向不同**：前者查权益是否耗尽、池子是否枯竭；
> 后者按「检查筛选条件时查什么」四步排查画像/面板条件。
> 实际执行时若两个信号同时满足，**优先按权益耗尽处理并一并汇报**。

触发权益耗尽时：
- 设置 `progress.json` 中 `quota_exhausted: true`，记录 `quota_exhausted_at` 时间戳
- 停止本轮发送
- 向用户汇报：已打招呼人数、连续失败次数、疑似原因
- 等待用户指示（开通权益/换岗位/明天继续）

**不要因为连续失败就降低筛选标准**。权益耗尽和候选人质量差是两个不同的问题。

## 状态持久化（#4）

每次执行动作后，必须更新 `data/` 目录下的 JSON 文件：

### candidates.json
每位候选人处理后追加或更新：
```json
{
  "candidate_id": "name_position_hash",
  "name": "张三",
  "source": "recommended_feed",
  "card_scan_result": "pass|reject|skip",
  "detail_decision": "pass|manual_review|reject",
  "greeted": true|false,
  "greet_result": "success|failed|skipped",
  "city": "北京",
  "past_position": "Android开发",
  "experience_years": 5,
  "processed_at": "2026-09-05T15:00:00+08:00"
}
```

### progress.json（C1：按岗位分片，2026-09-19 重构）

顶层只放全局信息，**每个岗位一份独立计数**：

```json
{
  "active_job": "高级安卓开发工程师（学习机/教育平板）",
  "last_updated": "2026-09-19T18:00:00+08:00",
  "jobs": {
    "高级安卓开发工程师（学习机/教育平板）": {
      "target_greeted_count": 20,
      "current_greeted_count": 0,
      "total_cards_scanned": 0,
      "round_index": 1,
      "max_batch_greet": 5,
      "greeted_names": [],
      "last_greeted_at": null,
      "paused": false,
      "pause_reason": null,
      "paused_at": null,
      "quota_exhausted": false,
      "quota_exhausted_at": null,
      "pool_status": {}
    }
  }
}
```

- **每轮结束后**更新 `jobs[当前岗位]` 下的计数，**不要动其他岗位的分片**
- `current_greeted_count`：该岗位本轮已成功打招呼人数
- `target_greeted_count`：**用户当次告知**的目标（不是 `config.daily_target`）
- `round_index`：该岗位的单轮序号，用于**每满 3 轮**的复核判定
- **切换岗位 = 切换到对应分片**，不要手工清零，也不要让两个岗位的计数互相污染
- 顶层 `active_job` 记录上次在跑哪个岗位，便于断点恢复

### actions.json
每个动作追加一条：
```json
{
  "action_type": "card_scan|detail_open|greet_success|greet_fail|reject|skip|panel_close|scroll",
  "candidate_id": "xxx",
  "candidate_name": "张三",
  "result": "pass|reject|success|failed",
  "timestamp": "2026-09-05T15:00:00+08:00"
}
```

## 断点续跑（#9）

每次启动打招呼流程前，必须先读取 `data/` 文件：

0. **断线探针（B3）**：先探 CDP 是否可用
   （`curl -s -m 6 http://localhost:3456/targets`）；无响应即暂停并通知用户重开 Chrome，
   不要自行重试
1. 读取 `candidates.json`，获取已处理候选人列表（**按 `job` 过滤当前岗位**）
2. 读取 `progress.json`，**取 `jobs[当前岗位]` 分片**获取进度（已打招呼数、已扫描数、轮次序号）
3. 读取 `config.json`，获取目标岗位（**目标人数以用户当次告知为准，不要用 `daily_target`**）
4. 读取 `profile.json`，确认该岗位画像在有效期内；缺失或过期先补做画像确认
5. 跳过 `candidates.json` 中该岗位已处理过的候选人（按 `candidate_id` 去重）；
   **本次任务内已判「待定」的也跳过**（B4，不重复开详情）
6. 从 `jobs[当前岗位].current_greeted_count` 继续计数，而非从零开始
7. 若 `jobs[当前岗位].quota_exhausted` 为 true 且未过 24 小时，先告知用户权益耗尽状态

**candidate_id 生成规则**：`姓名_岗位关键词_hash`，例如 `张三_Android_a1b2c3`。
如果 BOSS 卡片有 `data-id` 属性，优先使用 `data-id` 作为 candidate_id。

**重启恢复场景**：
- 会话中断后重启 → 读取 data/ 文件 → 从上次进度继续
- 换岗位 → 更新 `config.json` 中 `current_job_title` → 重置计数但保留历史候选人记录
