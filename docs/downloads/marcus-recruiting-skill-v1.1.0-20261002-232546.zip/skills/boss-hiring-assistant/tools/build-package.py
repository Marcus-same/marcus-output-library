#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build-package.py — 把 boss-hiring-assistant skill 打包成可分发 zip

⚠️ **本脚本不会修改本机 data/ 里的任何文件。**
清空操作只作用于写进 zip 的那份副本（在内存里替换内容），
所以打包完你本地正在跑的任务进度、已打名单、画像都原样保留。

打包约定（与历史包一致，2026-09-19 增补 C2）：

  * 保留：SKILL.md / references/ / scripts/ / agents/ / wecom-meeting-creator/ /
          tools/ / *.yaml / execution-lessons-summary.md / CHANGELOG.md

  * **清空状态类数据**（接收方从零开始）：
      - data/candidates.json -> []
      - data/actions.json    -> []
      - data/progress.json   -> 模板（schema v2，计数归零、jobs 分片清空）

  * **C2：画像属于「配置」，取值必须清空**：
      - data/profile.json    -> {"profiles": []}
      画像校对流程本身会问 9 项，不需要预置字段模板；
      否则会把本环境的实际画像（年龄区间、院校名单等）直接发给别人。

  * **保留**：data/config.json（岗位名 / title_aliases 等结构性配置，不含个人信息），
              但其中 notify.channel 在包内强制重置为 "none"

  * 排除：data/_backup/、__pycache__、.DS_Store、*.pyc

  * **正文姓名自检（2026-09-21 新增）**：`data/` 白名单能挡住「报告目录」，
    但挡不住**写进 .md / .yaml 正文里的真实人名** —— 09-21 实测发现
    SKILL.md / execution-lessons-summary.md / CHANGELOG.md 里散落着 3 名同事 + 7 名候选人的真名。
    故新增：打包前扫描所有文本文件的正文，命中 `tools/redact-blocklist.txt`
    里的词条即 **exit 2**（该名单文件本身不进包）。
    确需放行时加 `--allow-names`（会在输出里标红提示）。

用法：
  python tools/build-package.py                  # 输出到桌面，版本号取今天
  python tools/build-package.py --out D:/x.zip   # 指定输出路径
  python tools/build-package.py --dry            # 只打印清单，不写 zip
  python tools/build-package.py --allow-names    # 跳过正文姓名自检（慎用）
"""

import argparse
import io
import json
import os
import sys
import zipfile
from datetime import datetime

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKILL_NAME = os.path.basename(SKILL_DIR)

INCLUDE_TOP_FILES = {
    'SKILL.md',
    'CHANGELOG.md',
    'execution-lessons-summary.md',
    'company-policy.yaml',
    'approval-policy.yaml',
}
INCLUDE_DIRS = {'references', 'scripts', 'agents', 'wecom-meeting-creator', 'tools', 'data'}

# data/ 采用**白名单**：只收根目录下这几个文件，**绝不收 data/ 的任何子目录**。
# 原因：data/reports/ 里的筛选报告含真实候选人姓名、同事姓名、公司名；
#      data/_backup/ 是本地备份。这些一旦顺手打进包，就等于把用户数据分享出去了。
#      （2026-09-19 真实发生过一次：报告被一起打包，已修复。）
DATA_ALLOWLIST = {
    'candidates.json', 'actions.json', 'progress.json', 'profile.json', 'config.json',
}
EXCLUDE_PATTERNS = ('__pycache__', '.DS_Store', '.pyc', '.git', 'redact-blocklist')

# 正文姓名自检：扫描这些扩展名的**文本内容**（不是文件名）
TEXT_EXTS = ('.md', '.yaml', '.yml', '.json', '.mjs', '.js', '.txt', '.py')
BLOCKLIST_FILE = os.path.join('tools', 'redact-blocklist.txt')

PROGRESS_TEMPLATE = {
    '_schema': 'progress v2（2026-09-19）：按岗位分片。每岗位一份独立计数与已打名单，'
               '切岗=切分片，不要手工清零。',
    '_see': 'references/task-memory.md',
    'schema_version': 2,
    'active_job': None,
    'last_updated': None,
    'jobs': {},
}

PROFILE_TEMPLATE = {
    '_schema': "画像校对结果，按岗位存一条；字段值用 BOSS 筛选面板原名，'不限' 统一写 \"不限\"",
    '_see': 'references/profile-calibration.md',
    '_note': '本文件在打包时被清空——画像属于配置，由使用方首次运行时通过画像校对自行设置',
    'profiles': [],
}


def dumps(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2) + '\n'


def build_overrides(data_dir):
    """构造「包内版本」：清空状态与画像；config 保留结构但 notify=none。
    返回 {arcname: 文本内容}。本机文件一律不动。"""
    overrides = {}
    clear = {
        'candidates.json': dumps([]),
        'actions.json': dumps([]),
        'progress.json': dumps(PROGRESS_TEMPLATE),
        'profile.json': dumps(PROFILE_TEMPLATE),
    }
    for fn, content in clear.items():
        overrides[f'{SKILL_NAME}/data/{fn}'] = content

    cp = os.path.join(data_dir, 'config.json')
    if os.path.exists(cp):
        with io.open(cp, encoding='utf-8') as f:
            cfg = json.load(f)
        cfg.setdefault('notify', {})
        cfg['notify']['channel'] = 'none'
        cfg['notify']['note'] = ('要推送到微信，请连接 WorkBuddy 的 claw bot 并在此处配置。'
                                 '默认 none 表示只在对话里提示。')
        overrides[f'{SKILL_NAME}/data/config.json'] = dumps(cfg)
    return overrides


def collect_files():
    """返回 (abs_path, arcname) 列表；**所有条目统一放在 `SKILL_NAME/` 目录下**"""
    out = []
    for root, dirs, files in os.walk(SKILL_DIR):
        dirs[:] = [d for d in dirs
                   if not any(p in d for p in EXCLUDE_PATTERNS) and d != '_backup']
        rel_root = os.path.relpath(root, SKILL_DIR)
        if rel_root == '.':
            for fn in files:
                if fn in INCLUDE_TOP_FILES:
                    out.append((os.path.join(root, fn), f'{SKILL_NAME}/{fn}'))
            continue
        top = rel_root.split(os.sep)[0]
        if top not in INCLUDE_DIRS:
            continue
        # data/ 只收白名单里的根级文件，跳过一切子目录（reports/ 、_backup/ 等）
        if top == 'data' and rel_root != 'data':
            continue
        for fn in files:
            if any(p in fn for p in EXCLUDE_PATTERNS):
                continue
            if top == 'data' and fn not in DATA_ALLOWLIST:
                continue
            ap = os.path.join(root, fn)
            arc = os.path.join(SKILL_NAME, rel_root, fn).replace('\\', '/')
            out.append((ap, arc))
    return sorted(out, key=lambda x: x[1])


def load_blocklist():
    """读 tools/redact-blocklist.txt（每行一个词条，# 开头为注释）。
    该文件本身被 EXCLUDE_PATTERNS 排除，不会进包。"""
    p = os.path.join(SKILL_DIR, BLOCKLIST_FILE)
    if not os.path.exists(p):
        return []
    terms = []
    with io.open(p, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                terms.append(line)
    return terms


def scan_names(files, overrides, terms):
    """扫描**包内实际生效的文本内容**，返回 [(arcname, 行号, 词条, 行内容)]。

    ⚠️ 只扫「进包后真正长这样」的内容，不扫磁盘原文：
       - 清空/重置类文件（candidates / actions / progress / profile）以 overrides 的模板为准
         → 否则会把本机候选人数据当泄露报出来（假阳性）
       - config.json 这类「读盘内容 + 局部改写」的文件以 overrides 为准
         → 否则反过来会漏报（它的磁盘内容确实进包）
    """
    hits = []
    for src, arc in files:
        if not arc.lower().endswith(TEXT_EXTS):
            continue
        if arc in overrides:
            text = overrides[arc]
        else:
            try:
                with io.open(src, encoding='utf-8', errors='ignore') as f:
                    text = f.read()
            except OSError:
                continue
        for i, line in enumerate(text.splitlines(), 1):
            for t in terms:
                if t in line:
                    hits.append((arc, i, t, line.strip()[:90]))
    return hits


def verify_overrides_are_scanned(files, overrides):
    """自检：清空规则必须作用在真正入包的文件上，且扫描器确实会读 overrides。
    否则「包内已清空」只是打在屏幕上好看，实际扫了磁盘原文。"""
    arcs = {arc for _, arc in files}
    for arc in ('data/candidates.json', 'data/actions.json',
                'data/progress.json', 'data/profile.json', 'data/config.json'):
        full = f'{SKILL_NAME}/{arc}'
        if full not in arcs:
            continue
        if full not in overrides:
            raise SystemExit(f'❌ {arc} 会按磁盘原文入包，但没有清空/重置规则')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--out', default=None, help='输出 zip 路径')
    ap.add_argument('--dry', action='store_true', help='只打印清单，不写文件')
    ap.add_argument('--allow-names', action='store_true',
                    help='跳过正文姓名自检（慎用；会把真实人名发给接收方）')
    args = ap.parse_args()

    stamp = datetime.now().strftime('%Y%m%d')
    out = args.out or os.path.join(
        os.path.expanduser('~'), 'Desktop', f'{SKILL_NAME}-{stamp}.zip')

    data_dir = os.path.join(SKILL_DIR, 'data')
    overrides = build_overrides(data_dir)

    files = collect_files()
    arcs = {arc for _, arc in files}

    # 一致性自检：清空规则必须作用到实际入包的文件上，否则会被静默丢弃
    orphan = sorted(set(overrides) - arcs)
    if orphan:
        print('❌ 以下数据文件不在待打包清单里，清空规则会失效：')
        for a in orphan:
            print('   ' + a)
        print('   请检查 INCLUDE_DIRS / collect_files()')
        sys.exit(2)

    # 隐私自检：data/ 下除白名单外的任何内容都不得入包（reports/ 含真实候选人数据）
    for _, arc in files:
        parts = arc.split('/')
        # 形如 boss-hiring-assistant/data/<sub>/<file> → 子目录内容，一律拒绝
        if len(parts) >= 4 and parts[1] == 'data':
            print(f'❌ 检测到 data/ 子目录文件混入打包清单：{arc}')
            print('   data/reports/ 等目录含真实候选人数据，不得分发。')
            sys.exit(2)
        # 形如 boss-hiring-assistant/data/<file> → 必须在白名单内
        if len(parts) == 3 and parts[1] == 'data' and parts[2] not in DATA_ALLOWLIST:
            print(f'❌ 检测到 data/ 非白名单文件混入：{arc}')
            sys.exit(2)

    # 正文姓名自检：名单文件本身若混进清单，等于把要脱敏的名字发出去
    for _, arc in files:
        if 'redact-blocklist' in arc:
            print(f'❌ 脱敏名单文件混入打包清单：{arc}（它记录了要脱敏的真实姓名）')
            sys.exit(2)

    terms = load_blocklist()
    verify_overrides_are_scanned(files, overrides)
    if not terms:
        print('ℹ️ 未找到 tools/redact-blocklist.txt 或名单为空 → 跳过正文姓名自检')
    elif args.allow_names:
        hits = scan_names(files, overrides, terms)
        print(f'⚠️ --allow-names：已跳过正文姓名自检'
              f'（名单 {len(terms)} 词条，本该命中 {len(hits)} 处）')
    else:
        hits = scan_names(files, overrides, terms)
        if hits:
            print(f'❌ 包内正文发现 {len(hits)} 处待脱敏姓名/词条（名单来自 {BLOCKLIST_FILE}）')
            for arc, ln, term, text in hits[:20]:
                print(f'   {arc}:{ln}  「{term}」  {text}')
            if len(hits) > 20:
                print(f'   ... 另有 {len(hits) - 20} 处')
            print('   → 请把这些真名替换为「同事A/B/C」「某位候选人」等占位符。')
            print('   → 确需放行：加 --allow-names')
            sys.exit(2)
        print(f'✅ 正文姓名自检通过（按包内内容扫描 {len(terms)} 个词条，0 命中）')

    print(f'=== 待打包 {len(files)} 个文件（本机 data/ 不会被修改）===')
    for _, arc in files:
        mark = '  [包内已清空/重置]' if arc in overrides else ''
        print(f'  {arc}{mark}')

    print('\n=== 包内数据文件的处理 ===')
    for arc in sorted(overrides):
        print(f'  {arc}  ->  {overrides[arc].strip()[:64]} ...')

    if args.dry:
        print('\n[dry] 未写出 zip')
        return

    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        for src, arc in files:
            if arc in overrides:
                z.writestr(arc, overrides[arc].encode('utf-8'))
            else:
                z.write(src, arc)

    size = os.path.getsize(out)
    print(f'\n✅ 已生成：{out}  ({len(files)} 文件, {size/1024:.1f} KB)')


if __name__ == '__main__':
    sys.exit(main())
