# 约面与企微服务

## 目标

在候选人已确认时间后，通过企微创建面试日程/会议，并附上候选人简历 PDF。

不负责：

- 筛选简历
- 自由聊天

## 进入条件

1. 用户明确同意该候选人进入约面
2. 候选人已经确认可面试时间

## 前置条件

1. `wecom-cli` 已安装并授权
2. 企微邮件权限已授权（「工作台 → 智能机器人」→ 授权邮件权限）
3. 已确认面试官 userid（`wecom-cli contact users search --keywords "姓名"`）

## 创建面试日程/会议

通过 `wecom-cli mail send --schedule` 创建，PDF 简历直接挂在日程附件上。

### 线上面试（日程 + 腾讯会议 + PDF 附件）

```bash
wecom-cli mail send \
  --subject "{候选人姓名}—{岗位}—{轮次}" \
  --to '{"userids":["面试官userid"]}' \
  --schedule '{"begin_time":"YYYY-MM-DD HH:mm:ss","end_time":"YYYY-MM-DD HH:mm:ss"}' \
  --meeting '{}' \
  --attachments '[{"file_path":"D:/简历路径/简历.pdf"}]'
```

### 线下面试（日程 + PDF 附件）

```bash
wecom-cli mail send \
  --subject "{候选人姓名}—{岗位}—{轮次}" \
  --to '{"userids":["面试官userid"]}' \
  --schedule '{"begin_time":"YYYY-MM-DD HH:mm:ss","end_time":"YYYY-MM-DD HH:mm:ss"}' \
  --attachments '[{"file_path":"D:/简历路径/简历.pdf"}]'
```

### 注意事项

- 路径用正斜杠 `/`，不用反斜杠
- `--to` 填面试官 userid
- 不需要 `--content`，不发描述
- 企微 `calendar schedules create` 不支持附件，必须走 `mail send --schedule`

## 其他日程操作

```bash
# 查询日程
wecom-cli calendar schedules list --begin-time "..." --end-time "..."

# 查询闲忙
wecom-cli calendar schedules free list --check-user-list '["userid"]' --begin-time "..." --end-time "..."

# 取消日程
wecom-cli calendar schedules cancel --schedule-id "SCHEDULE_ID"
```

## 失败处理

创建失败时，先判断是否是权限问题，告诉用户去企微工作台补授权。
