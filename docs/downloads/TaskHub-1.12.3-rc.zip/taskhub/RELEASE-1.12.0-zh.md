# TaskHub 1.12.0

在同一 Obsidian 库安装并启用 Agent Deck（上游 MatsuriMW/obsidian-agent-deck，依据 1.9.0 源码）及可用的 Agent。重开日历或点刷新，右侧将显示启用的 Agent。拖入待办或打开任务卡片选择 Agent，核对 Agent Deck 原生确认窗口后发送。WorkBuddy 仍按 Agent Deck 的方式交接。TaskHub 不运行另一套 Agent，也不代替上游会话管理。

本版依赖上游内部委派入口，升级 Agent Deck 后需重新验证。37 项自动化测试通过，真实会话需实机验收。退出 Obsidian 后备份并覆盖四个运行文件，保留 data.json。
