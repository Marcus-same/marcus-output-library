# TaskHub 1.11.2 RC

日历在 Obsidian 右侧视图打开，可折叠或拖到主区。设置、帮助和删除确认使用显式关闭按钮。新建从工作台进入，待办排期颜色跟随任务分类，旧独立日程可改期或删除。Agent Deck 入口跳转原任务，实际发送由 Agent Deck 完成。

36 项自动化测试通过。尚未完成真实 Obsidian 窗口验收。退出 Obsidian 后备份并覆盖四个运行文件，保留 data.json。
