# TaskHub 1.0.5

修复 Windows 全局助手依赖 window.require 导致可能静默跳过启动的问题，改用插件 CommonJS require。新增“TaskHub：查看全局快捷键状态”命令；报告启动、双击 Ctrl、启动失败及旧助手占用。

安装：退出 Obsidian，备份插件目录，将 taskhub 目录下四个文件复制至仓库 .obsidian/plugins/taskhub，保留 data.json。启动 Obsidian 并启用插件。无需手动启动 exe，插件管理其生命周期。

测试：18 项自动化测试通过，包含模拟 Windows 启动和错误诊断；C# 编译及手势自测通过。未验证真实 Obsidian 后台键盘钩子端到端效果，未执行完整 TypeScript 类型检查。

验证：切换到浏览器，快速按两次 Ctrl。失败时在 Obsidian 命令面板运行“TaskHub：查看全局快捷键状态”，提供显示内容。READY 表示钩子安装成功；KEY 表示收到双击。
