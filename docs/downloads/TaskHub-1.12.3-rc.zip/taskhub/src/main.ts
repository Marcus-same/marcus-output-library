import {ItemView, MarkdownRenderChild, Modal, Notice, Plugin, PluginSettingTab, Setting, TFile, TFolder, WorkspaceLeaf} from "obsidian";
import {appendLine, completionLine, completionStamp, draftOf, filterTasks, finished, isDuplicate, localDay, parseCapture, parseQuickTitle,
  parseNote, parseQuery, priorities, renderLine, replaceLine, safePath, scopes, validateDraft,
  nextRepeatDate, validRepeatRule, taskField, setTaskField, validDate, emailSubject, deleteTaskLine, validSlot, taskSlots, withTaskSlots} from "./core.ts";
import type {Draft, Query, Task, CalendarSlot} from "./core.ts";
declare const calendarHtml:string;
declare const require: ((name:string)=>any) | undefined;

const VIEW="taskhub-workbench";
const CALENDAR_VIEW="taskhub-calendar";
const TASK_DRAG="application/x-taskhub-task";
const DECK_AGENTS=[{id:"codex",name:"Codex"},{id:"claude",name:"Claude Code"},
  {id:"workbuddy",name:"WorkBuddy"},{id:"dsh",name:"DeepSeek Harness"},{id:"antigravity",name:"Antigravity"}];
type DeckBridge={agentEnabled?:(id:string)=>boolean;delegateDrop:(id:string,item:{path:string;line:number;lineText:string},anchor:null)=>Promise<void>};
const defaults={folder:"00-任务中枢/待办库",tag:"#task",queue:"00-任务中枢/TaskHub-录入队列",
  backups:"00-任务中枢/TaskHub-备份", autoImport:false, linkedFolders:"01-Daily\n06-工作", reminders:false, promoteTomorrow:false};
const priorityLabels=["普通","最高","高","中","低","最低"];
type Settings=typeof defaults;
function report(error: unknown) {
  new Notice("TaskHub · "+(error instanceof Error ? error.message : String(error)),7000);
}
function addOptions(select: HTMLSelectElement, values: [string,string][], value: string) {
  for (const [id,label] of values) select.createEl("option",{value:id,text:label});
  select.value=value;
}
function priorityOptions(normal: string): [string,string][] {
  return priorities.map((p,i)=>[p,i===0 ? normal : p+" "+priorityLabels[i]]);
}
function clockTime(d=new Date()) {return String(d.getHours()).padStart(2,"0")+":"+String(d.getMinutes()).padStart(2,"0");}
function under(path: string, folder: string) {
  return path.startsWith(folder+"/");
}

class TaskHub extends Plugin {
  settings:Settings={...defaults};
  private changes=new Set<()=>void>();
  private pending:Promise<unknown>=Promise.resolve();
  private timer:number|undefined;
  private day=localDay();
  private reminderKeys=new Set<string>();
  private checkingReminders=false;
  private alive=true;
  private hotkeyStatus="全局快捷键尚未启动";

  async onload() {
    const saved=await this.loadData();
    if (saved) {
      for (const key of ["folder","queue","backups","tag","linkedFolders"] as const)
        if (typeof saved[key]==="string") this.settings[key]=saved[key];
      this.settings.autoImport=saved.autoImport===true;
      this.settings.reminders=saved.reminders===true;
      this.settings.promoteTomorrow=saved.promoteTomorrow===true;
    }
    this.registerView(VIEW,leaf=>new Workbench(leaf,this));
    this.registerView(CALENDAR_VIEW,leaf=>new TaskCalendar(leaf,this));
    this.addRibbonIcon("list-todo","打开 TaskHub",()=>void this.openView().catch(report));
    this.addCommand({id:"capture",name:"快捷录入任务",
      callback:()=>new TaskEditor(this).open()});
    this.registerDoubleControl();
    this.startWindowsHotkey();
    this.addCommand({id:"global-hotkey-status",name:"查看全局快捷键状态",callback:()=>new Notice(this.hotkeyStatus,10000)});
    this.addCommand({id:"calendar",name:"打开任务日历",callback:()=>void this.openCalendar().catch(report)});
    this.registerObsidianProtocolHandler("taskhub-capture",()=>{
      if (!document.querySelector(".modal-container")) new TaskEditor(this).open();
    });
    this.registerObsidianProtocolHandler("taskhub-web",params=>{
      if (document.querySelector(".modal-container")) return;
      try {
        const url=new URL(params.url??"");
        if(!["https:","http:"].includes(url.protocol)||url.username||url.password||url.href.length>700) return;
        const title=(params.title??"").replace(/[\r\n\0]/g," ").trim().slice(0,220);
        new TaskEditor(this,undefined,{title:(title||"阅读网页")+" "+url.href}).open();
      } catch {new Notice("网页地址无效");}
    });
    this.addCommand({id:"workbench",name:"打开任务工作台",callback:()=>void this.openView().catch(report)});
    this.addCommand({id:"weekly-review",name:"开始每周回顾",callback:()=>new WeeklyReview(this).open()});
    this.addCommand({id:"import-email",name:"从邮件文件录入任务",callback:()=>new EmailCapture(this).open()});
    this.addCommand({id:"toggle-reminders",name:"切换到期提醒",callback:()=>void this.updateSettings({...this.settings,reminders:!this.settings.reminders})
      .then(()=>new Notice(this.settings.reminders?"到期提醒已开启":"到期提醒已关闭")).catch(report)});
    this.addCommand({id:"backup",name:"创建任务库备份",callback:()=>void this.backup().then(p=>new Notice("备份已保存 · "+p)).catch(report)});
    this.addCommand({id:"migrate",name:"接管旧版任务库",callback:()=>new Migration(this).open()});
    this.addCommand({id:"import-captures",name:"导入外部录入队列",callback:()=>void this.importQueue(true).catch(report)});
    this.addCommand({id:"insert-query",name:"插入动态任务查询",editorCallback:editor=>{
      const selected=editor.getSelection().trim();
      new QueryEditor(this,selected,block=>editor.replaceRange(block,editor.getCursor("to"))).open();
    }});
    this.registerMarkdownCodeBlockProcessor("taskhub",(source,el,ctx)=>ctx.addChild(new InlineTasks(el,this,source)));
    this.addSettingTab(new HubSettings(this));
    for (const event of ["create","modify","delete"] as const) {
      this.registerEvent(this.app.vault.on(event,file=>{
        if (this.includesTaskPath(file.path)) this.changed();
      }));
    }
    this.registerEvent(this.app.vault.on("rename",(file,old)=>{
      if ([file.path,old].some(path=>this.includesTaskPath(path) || this.taskFolders().includes(path)))
        this.changed();
    }));
    this.registerInterval(window.setInterval(()=>{
      const now=localDay();
      if(this.day!==now) this.reminderKeys.clear();
      this.day=now; this.changed();
      if (this.settings.autoImport) this.autoImport();
      if (this.settings.reminders) void this.checkReminders().catch(report);
    },15000));
    this.app.workspace.onLayoutReady(()=>{
      if (this.alive && this.settings.autoImport) this.autoImport();
    });
  }
  async checkReminders(now=new Date()) {
    if (!this.settings.reminders || this.checkingReminders) return;
    this.checkingReminders=true;
    try {
      const today=localDay(now);
      const tasks=await this.tasks();
      if (!this.alive || !this.settings.reminders) return;
      for (const task of tasks) {
        if (finished(task) || !task.time || task.due!==today) continue;
        const elapsed=now.getTime()-new Date(task.due+"T"+task.time+":00").getTime();
        const key=JSON.stringify([task.path,task.title,task.due,task.time]);
        if (!(elapsed>=0 && elapsed<300000) || this.reminderKeys.has(key)) continue;
        this.reminderKeys.add(key);
        new Notice("任务到期 · "+task.time+" · "+task.title,12000);
      }
    } finally {this.checkingReminders=false;}
  }
  onunload() {
    this.alive=false;
    window.clearTimeout(this.timer);
    this.changes.clear();
    this.app.workspace.detachLeavesOfType(VIEW);
    this.app.workspace.detachLeavesOfType(CALENDAR_VIEW);
  }
  private registerDoubleControl() {
    let pressedAt: number | undefined;
    let lastTap: number | undefined;
    const reset=()=>{pressedAt=undefined;lastTap=undefined;};
    this.registerDomEvent(window,"blur",reset);
    this.registerDomEvent(window,"pointerdown",reset,true);
    this.registerDomEvent(window,"keydown",event=>{
      if (event.key!=="Control" || event.altKey || event.shiftKey || event.metaKey) {
        reset();
        return;
      }
      if (!event.repeat) {
        if (pressedAt!==undefined) reset();
        else pressedAt=Date.now();
      }
    },true);
    this.registerDomEvent(window,"keyup",event=>{
      if (event.key!=="Control") return;
      const now=Date.now();
      if (pressedAt===undefined || now-pressedAt>300 || event.ctrlKey) {
        reset();
        return;
      }
      pressedAt=undefined;
      if (lastTap!==undefined && now-lastTap<=400) {
        reset();
        if (!document.querySelector(".modal-container")) new TaskEditor(this).open();
      } else lastTap=now;
    },true);
  }
  private startWindowsHotkey() {
    try {
      if (typeof require!=="function") return;
      const runtime=require("process");
      if (runtime.platform!=="win32") return;
      const adapter=this.app.vault.adapter as unknown as {getBasePath?:()=>string};
      const base=adapter.getBasePath?.();
      if (!base || !this.manifest.dir) throw new Error("无法定位全局快捷键组件。");
      const path=require("path");
      const args=["--parent",String(runtime.pid)];
      const vault=this.app.vault.getName?.();
      if(vault)args.push("--vault",vault);
      const child=require("child_process").spawn(
        path.join(base,this.manifest.dir,"TaskHub-Wake.exe"),
        args,
        {windowsHide:true,stdio:["ignore","pipe","pipe"]}
      );
      this.hotkeyStatus="正在启动 Windows 全局快捷键";
      child.stdout.on("data",(data:{toString:()=>string})=>{
        this.hotkeyStatus=data.toString().trim();
        if (this.hotkeyStatus.includes("READY")) new Notice("TaskHub 全局双击 Ctrl 已启动");
      });
      child.stderr.on("data",(data:{toString:()=>string})=>{this.hotkeyStatus=data.toString().trim();});
      child.on("error",(error:Error)=>{
        this.hotkeyStatus="全局快捷键启动失败："+error.message;
        report(new Error(this.hotkeyStatus));
      });
      child.on("exit",(code:number|null)=>{
        if (!this.alive) return;
        this.hotkeyStatus=code===2 ? "旧版 TaskHub 助手仍在运行，请退出托盘中的助手，再重新启用插件。" : "全局快捷键进程已退出，退出码："+code+"。"+this.hotkeyStatus;
        new Notice(this.hotkeyStatus,12000);
      });
      this.register(()=>{if (child.exitCode===null) child.kill();});
    } catch(error) {this.hotkeyStatus=String(error);report(error);}
  }
  private importing=false;
  private autoImport() {
    if (this.importing) return;
    this.importing=true;
    void this.importQueue(false).catch(report).finally(()=>{this.importing=false;});
  }
  subscribe(callback:()=>void) { this.changes.add(callback); return ()=>this.changes.delete(callback); }
  changed() {
    window.clearTimeout(this.timer);
    this.timer=window.setTimeout(()=>this.changes.forEach(callback=>callback()),120);
  }
  private serial<T>(operation:()=>Promise<T>):Promise<T> {
    const current=this.pending.then(operation);
    this.pending=current.catch(()=>{});
    return current;
  }
  async openView() {
    let leaf=this.app.workspace.getLeavesOfType(VIEW)[0];
    if (!leaf) {
      leaf=this.app.workspace.getLeaf("tab");
      await leaf.setViewState({type:VIEW,active:true});
    }
    await this.app.workspace.revealLeaf(leaf);
  }
  async openCalendar(){
    const workspace=this.app.workspace;
    let leaf=workspace.getLeavesOfType(CALENDAR_VIEW)[0];
    if(!leaf){
      leaf=workspace.getRightLeaf(true)??workspace.getLeaf("tab");
      await leaf.setViewState({type:CALENDAR_VIEW,active:true});
    }
    await workspace.revealLeaf(leaf);
  }
  private calendarToggling=false;
  async toggleCalendar(){
    if(this.calendarToggling)return;
    this.calendarToggling=true;
    try {
      const existing=this.app.workspace.getLeavesOfType(CALENDAR_VIEW);
      if(existing.length)existing.forEach(leaf=>leaf.detach());
      else await this.openCalendar();
    } finally {this.calendarToggling=false;}
  }
  private draggedTask?:{token:string;task:Task};
  beginTaskDrag(task:Task,transfer:DataTransfer){
    const token=Date.now().toString(36)+Math.random().toString(36).slice(2);
    this.draggedTask={token,task};
    transfer.setData(TASK_DRAG,token);
    transfer.effectAllowed="linkMove";
    return token;
  }
  endTaskDrag(token:string){
    // The embedded calendar delivers the drop asynchronously, after dragend.
    window.setTimeout(()=>{
      if(this.draggedTask?.token===token)this.draggedTask=undefined;
    },1500);
  }
  scheduleDraggedTask(token:string,slot:CalendarSlot){
    const drag=this.draggedTask;
    if(!drag||drag.token!==token)throw new Error("请重新拖动待办。");
    this.draggedTask=undefined;
    const task=drag.task;
    if(!validSlot(slot))throw new Error("请拖到有效的日期和时间。");
    const slots=taskSlots(task);
    if(slots.some(item=>item.date===slot.date&&item.start===slot.start&&item.length===slot.length))return Promise.resolve();
    return this.saveCalendarTask(task,task.title,[...slots,slot]);
  }
  private getAgentDeck():DeckBridge|undefined {
    const registry=(this.app as unknown as {plugins?:{getPlugin?:(id:string)=>Partial<DeckBridge>}}).plugins;
    const deck=registry?.getPlugin?.("agent-deck");
    return deck&&typeof deck.delegateDrop==="function"?deck as DeckBridge:undefined;
  }
  calendarAgents(){
    const deck=this.getAgentDeck();
    return deck?DECK_AGENTS.filter(agent=>deck.agentEnabled?.(agent.id)!==false):[];
  }
  async delegateCalendarTask(task:Task,agent:string){
    const deck=this.getAgentDeck();
    if(!deck)throw new Error("请安装并启用有兼容委派入口的 Agent Deck。");
    if(!this.calendarAgents().some(item=>item.id===agent))throw new Error("该 Agent 当前不可用。");
    const file=this.app.vault.getAbstractFileByPath(task.path);
    if(!(file instanceof TFile)||!this.includesTaskPath(task.path))throw new Error("原任务文件已移动。");
    const matches=parseNote(await this.app.vault.read(file),task.path).filter(item=>item.raw===task.raw);
    if(matches.length!==1||finished(matches[0]))throw new Error("任务已变更，请刷新日历后重试。");
    await deck.delegateDrop(agent,{path:task.path,line:matches[0].line,lineText:matches[0].raw},null);
  }
  async calendarEvents():Promise<CalendarEvent[]> {
    const file=this.app.vault.getAbstractFileByPath(this.settings.folder+"/TaskHub-calendar.json");
    return file instanceof TFile?parseCalendarEvents(await this.app.vault.read(file)):[];
  }
  changeCalendarEvent(event:CalendarEvent,previous?:CalendarEvent,remove=false) {
    return this.serial(async()=>{
      if(!validSlot(event)||!event.title.trim()||event.title.length>120) throw new Error("日程内容或时间无效。");
      const vault=this.app.vault,path=this.settings.folder+"/TaskHub-calendar.json";
      await this.makeFolders(this.settings.folder);
      const file=vault.getAbstractFileByPath(path);
      const update=(text:string)=>{
        const events=parseCalendarEvents(text),index=events.findIndex(item=>item.id===event.id);
        if(previous){
          if(index<0||JSON.stringify(events[index])!==JSON.stringify(previous)) throw new Error("日程已变更，请刷新后重试。");
          if(remove) events.splice(index,1); else events[index]=event;
        } else {if(index>=0) throw new Error("日程已存在。");events.push(event);}
        return JSON.stringify(events,null,2)+"\n";
      };
      if(file instanceof TFile) await vault.process(file,update);
      else if(!file) await vault.create(path,update("[]"));
      else throw new Error("日程文件路径被占用。");
      this.changed();
    });
  }
  saveCalendarTask(task:Task|undefined,title:string,slots:CalendarSlot[],source?:Task) {
    return this.serial(async()=>{
      const draft=validateDraft({...draftOf(task??source),title});
      if (!task){ await this.add(draft,undefined,[],false,slots); return; }
      const raw=renderLine(draft,this.settings.tag,task);
      if(raw!==task.raw&&!finished(task)&&isDuplicate(await this.tasks(undefined,true),draft,this.settings.tag,task))
        throw new Error("编辑后会与另一条未完成任务重复。");
      await this.writeTask(task,withTaskSlots({...task,raw},slots));
    });
  }
  files(folder=this.settings.folder) {
    return this.app.vault.getMarkdownFiles().filter(file=>under(file.path,folder));
  }
  taskFolders() {return [...new Set([this.settings.folder,...this.settings.linkedFolders.split(/\r?\n/).map(s=>s.trim()).filter(Boolean)])];}
  includesTaskPath(path:string) {return this.taskFolders().some(folder=>under(path,folder)) && ![this.settings.backups,this.settings.queue].some(folder=>under(path,folder));}
  async tasks(folder?:string, fresh=false) {
    const vault=this.app.vault;
    const files=folder?this.files(folder):vault.getMarkdownFiles().filter(file=>this.includesTaskPath(file.path));
    const groups=await Promise.all(files.map(async f=>parseNote(await (fresh?vault.read(f):vault.cachedRead(f)),f.path)));
    return groups.flat();
  }
  async updateSettings(next:Settings) {
    return this.serial(()=>this.applySettings(next));
  }
  private async applySettings(next:Settings) {
    const setting={...next,folder:safePath(next.folder),queue:safePath(next.queue),backups:safePath(next.backups)};
    setting.tag=setting.tag.trim();
    if (setting.tag && !/^#[\p{L}\p{M}\p{N}_/-]+$/u.test(setting.tag)) throw new Error("全局任务标记需为单个 #标签。");
    const dirs=[setting.folder,setting.queue,setting.backups];
    if (dirs.some((a,i)=>dirs.some((b,j)=>j!==i && (a.toLowerCase()===b.toLowerCase()||under(a,b)))))
      throw new Error("任务库、录入队列和备份需要各自独立的目录。");
    setting.linkedFolders=setting.linkedFolders.split(/\r?\n/).map(s=>s.trim()).filter(Boolean).map(safePath).join("\n");
    if (setting.linkedFolders.split("\n").filter(Boolean).some(p=>[setting.backups,setting.queue].some(q=>p===q||under(p,q)||under(q,p))))
      throw new Error("联动目录不能包含备份或录入队列目录。");
    await this.saveData(setting);
    this.settings=setting;
    this.changed();
  }
  private async makeFolders(path:string) {
    const vault=this.app.vault;
    let parent="";
    for (const part of safePath(path).split("/")) {
      parent=parent ? parent+"/"+part : part;
      const current=vault.getAbstractFileByPath(parent);
      if (current && !(current instanceof TFolder)) throw new Error("文件占用了目录 · "+parent);
      if (!current) await vault.createFolder(parent);
    }
  }
  private async add(draft:Draft,id?:string,steps:string[]=[],daily=false,slots:CalendarSlot[]=[]) {
    const d=validateDraft(draft);
    const {folder,tag}=this.settings;
    const tasks=await this.tasks(undefined,true);
    if (id) {
      const received=tasks.filter(t=>t.ids.includes(id));
      if (received.length>1) throw new Error("多个任务使用同一外部录入 ID，请先检查原笔记。");
      if (received.length===1) return false;
    }
    if (isDuplicate(tasks,d,tag)) {
      if (id) throw new Error("任务重复，外部录入已保留以便核对。");
      throw new Error("已有同内容、分类、项目和截止日的未完成任务。");
    }
    const month=localDay().slice(0,7);
    const [year,number]=month.split("-");
    const legacyMonth=new RegExp("(^|[^0-9])"+year+"(?:[-_年]?)0?"+Number(number)+"(?:月)?([^0-9]|$)");
    const monthly=this.files(folder).filter(file=>legacyMonth.test(file.basename));
    const standard=folder+"/"+month+".md";
    const preferred=monthly.find(file=>file.path===standard);
    if (!preferred && monthly.length>1) throw new Error("找到多份本月任务笔记，请保留唯一月度文件或使用 "+month+".md 作为录入目标。");
    const path=preferred?.path??monthly[0]?.path??standard;
    const vault=this.app.vault;
    const raw=renderLine(d,tag,undefined,id)+(daily?" [taskhub-repeat:: daily]":"");
    const line=slots.length?withTaskSlots(parseNote(raw,path)[0],slots):raw;
    const childLines=steps.map(title=>"    "+renderLine({...d,title,due:"",time:"",priority:""},tag,undefined,
      Date.now().toString(36)+"-"+Math.random().toString(36).slice(2)));
    const insert=(text:string)=>{
      const lines=[line,...childLines];
      const next=appendLine(text,lines.join(text.includes("\r\n")?"\r\n":"\n"));
      const offset=next.split(/\r?\n/).length-1-lines.length;
      const parsed=parseNote(next,path);
      if(lines.some((raw,index)=>!parsed.some(task=>task.line===offset+index&&task.raw===raw)))
        throw new Error("月度笔记末尾无法写入任务，请检查代码块或注释是否关闭。");
      return next;
    };
    await this.makeFolders(folder);
    const target=vault.getAbstractFileByPath(path);
    if (target instanceof TFile) {
      await vault.process(target,text=>{
        if (isDuplicate(parseNote(text,path),d,tag)) throw new Error("目标文件已有重复任务。");
        return insert(text);
      });
    } else if (!target) {
      await vault.create(path,insert("# "+month+" 任务\n"));
    } else {
      throw new Error("月度文件路径已被占用 · "+path);
    }
    this.changed();
    return true;
  }
  createFromTemplate(title:string,steps:string[]) {
    return this.serial(async()=>{
      if(!steps.length||steps.length>30) throw new Error("请填写 1–30 条步骤");
      await this.add({title,category:"",project:"",due:"",priority:""},undefined,steps);
    });
  }
  createHabit(title:string) {
    return this.serial(async()=>{await this.add({title,category:"",project:"",due:localDay(),priority:""},undefined,[],true);});
  }
  save(draft:Draft,task?:Task) {
    return this.serial(async()=>{
      if (!task) { await this.add(draft); return; }
      const d=validateDraft(draft);
      const existing=await this.tasks(undefined,true);
      const matches=existing.filter(t=>t.path===task.path && t.raw===task.raw);
      if (matches.length!==1) throw new Error("任务已变更或有相同记录，请刷新后重试。");
      const current=matches[0];
      const tomorrow=new Date();tomorrow.setDate(tomorrow.getDate()+1);
      if(this.settings.promoteTomorrow && !finished(current) && current.due!==d.due && d.due===localDay(tomorrow)
          && ["","🔽","⏬"].includes(d.priority) && d.priority===current.priority) d.priority="🔼";
      const replacement=renderLine(d,this.settings.tag,current);
      if (replacement===current.raw) return;
      if (!finished(current) && isDuplicate(existing,d,this.settings.tag,current)) throw new Error("编辑后会与另一条未完成任务重复。");
      await this.writeTask(current,replacement);
    });
  }
  toggle(task:Task) {
    return this.serial(async()=>{
      const now=new Date();
      const today=localDay(now);
      const replacement=completionLine(task,today,clockTime(now));
      const rule=taskField(task,"repeat");
      if (!rule) {await this.writeTask(task,replacement);return;}
      if (finished(task)) throw new Error("此重复任务已生成下一次，请在原笔记中处理历史记录");
      const due=nextRepeatDate(rule,task.due>today?task.due:today);
      const raw=renderLine({...draftOf(task),due},this.settings.tag);
      const successor=raw+" [taskhub-repeat:: "+rule+"]";
      await this.writeGroup(task,text=>{
        const updated=replaceLine(text,task,replacement);
        const next=appendLine(updated,successor);
        if (!parseNote(next,task.path).some(row=>row.raw===successor&&row.line===next.split(/\r?\n/).length-2))
          throw new Error("原笔记末尾无法插入下一次重复任务");
        return next;
      });
    });
  }
  updateField(task:Task,key:"repeat"|"block"|"board",value:string) {
    return this.serial(async()=>{
      if(key==="repeat" && value && (!validRepeatRule(value)||!task.due||task.recurring||finished(task)))
        throw new Error("请为未完成的普通任务设置截止日期后再添加重复规则");
      if(key==="board" && !["","进行中"].includes(value)) throw new Error("看板状态无效");
      if(key==="block" && value){
        const match=value.match(/^(\d{4}-\d{2}-\d{2}) ((?:[01]\d|2[0-3]):[0-5]\d) (15|30|45|60|90|120)$/);
        if(!match || !validDate(match[1])) throw new Error("请选择有效的排期日期、时间和时长");
        const [hour,minute]=match[2].split(":").map(Number);
        if(hour*60+minute+Number(match[3])>1440) throw new Error("时间块不能跨午夜");
      }
      const raw=setTaskField(task,key,value);
      if(raw!==task.raw) await this.writeTask(task,raw);
    });
  }
  addSubtask(task:Task,title:string) {
    return this.serial(()=>{
      const draft=validateDraft({title,category:"",project:"",due:"",priority:""});
      const indent=task.raw.match(/^\s*/)?.[0]??"";
      const child=indent+"    "+renderLine(draft,this.settings.tag);
      return this.writeGroup(task,text=>replaceLine(text,task,task.raw+(text.includes("\r\n")?"\r\n":"\n")+child));
    });
  }
  private async writeGroup(task:Task,transform:(text:string)=>string) {
    const vault=this.app.vault;
    const file=vault.getAbstractFileByPath(task.path);
    if (!this.includesTaskPath(task.path)||!(file instanceof TFile)) throw new Error("任务文件已移动。");
    await vault.process(file,transform);
    this.changed();
  }
  deleteTask(task:Task) {
    return this.serial(()=>this.writeGroup(task,text=>deleteTaskLine(text,task)));
  }
  private async writeTask(task:Task,replacement:string) {
    const vault=this.app.vault;
    const file=vault.getAbstractFileByPath(task.path);
    if (!this.includesTaskPath(task.path)||!(file instanceof TFile)) throw new Error("任务文件已移动。");
    await vault.process(file,text=>replaceLine(text,task,replacement));
    this.changed();
  }
  async openSource(task:Task) {
    const file=this.app.vault.getAbstractFileByPath(task.path);
    if (!(file instanceof TFile)) throw new Error("原笔记已移动。");
    const leaf=this.app.workspace.getLeaf("tab");
    await leaf.openFile(file,{eState:{line:task.line}});
  }
  private async createBackup(folder?:string) {
    const files=folder?this.files(folder):this.app.vault.getMarkdownFiles().filter(file=>this.includesTaskPath(file.path));
    const timestamp=new Date().toISOString().replace(/[:.]/g,"-");
    const path=this.settings.backups+"/"+timestamp+"-"+Math.random().toString(36).slice(2,8)+".json";
    const notes=await Promise.all(files.map(async f=>({path:f.path,content:await this.app.vault.read(f)})));
    const calendarPath=this.settings.folder+"/TaskHub-calendar.json";
    const calendarFile=this.app.vault.getAbstractFileByPath(calendarPath);
    const calendar=calendarFile instanceof TFile?{path:calendarPath,content:await this.app.vault.read(calendarFile)}:undefined;
    await this.makeFolders(this.settings.backups);
    await this.app.vault.create(path,JSON.stringify({version:1,createdAt:new Date().toISOString(),
      settings:{...this.settings},sourceFolder:folder,notes,calendar},null,2));
    return path;
  }
  backup() { return this.serial(()=>this.createBackup()); }
  migrate(folder:string) {
    return this.serial(async()=>{
      const path=safePath(folder);
      if (!this.files(path).length) throw new Error("目录内没有 Markdown 笔记，请检查旧任务库路径。");
      if ([this.settings.backups,this.settings.queue].some(p=>under(p,path)||under(path,p)||path.toLowerCase()===p.toLowerCase()))
        throw new Error("旧任务目录与队列或备份目录重叠。");
      const tasks=await this.tasks(path,true);
      if (!tasks.length) throw new Error("目录内没有可识别的 Markdown 任务。");
      const backup=await this.createBackup(path);
      await this.applySettings({...this.settings,folder:path});
      return {count:tasks.length,backup};
    });
  }
  importQueue(manual:boolean) {
    return this.serial(async()=>{
      const {queue}=this.settings;
      const vault=this.app.vault;
      if (!await vault.adapter.exists(queue)) {
        if (manual) new Notice("录入队列为空");
        return;
      }
      const paths=(await vault.adapter.list(queue)).files.filter(p=>under(p,queue)&&p.endsWith(".taskhub.json")).sort();
      let added=0, removed=0;
      const errors:string[]=[];
      for (const path of paths) {
        try {
          const original=await vault.adapter.read(path);
          const entry=parseCapture(original);
          if (await this.add(entry.task,entry.id)) added++;
          if (await vault.adapter.read(path)!==original) throw new Error("队列文件在导入过程中发生变化，已保留以便重试。");
          await vault.adapter.remove(path);
          removed++;
        } catch (error) {
          errors.push(path.split("/").at(-1)+" · "+(error instanceof Error?error.message:String(error)));
        }
      }
      if (manual || removed) new Notice("TaskHub · 新增 "+added+" 条，确认 "+removed+" 份队列文件，待处理 "+errors.length+" 份。");
      if (manual && errors.length) new Notice(errors.slice(0,5).join("\n"),10000);
    });
  }
}
class HubModal extends Modal {
  setTitle(title:string) {
    super.setTitle(title);
    this.modalEl?.addClass("taskhub-modal");
    this.contentEl.addClass("taskhub-dialog");
  }
}
class TaskEditor extends HubModal {
  constructor(private hub:TaskHub,private task?:Task,private preset:Partial<Draft>={}) { super(hub.app); }
  onOpen() {
    const {contentEl}=this;
    this.setTitle(this.task ? "编辑任务" : "新建任务");
    const form=contentEl.createEl("form",{cls:"taskhub-form"});
    const draft={...draftOf(this.task),...(!this.task?this.preset:{})};
    const input=(parent:HTMLElement,label:string,type:string,key:"title"|"category"|"project"|"due"|"time")=>{
      const row=parent.createEl("label",{text:label});
      const el=row.createEl("input",{type,value:draft[key]??""});
      el.addEventListener("input",()=>{draft[key]=el.value;});
      return el;
    };
    const title=input(form,"要做什么？","text","title");
    title.required=true; title.maxLength=1000; title.placeholder="例如：联系候选人，确认周五面试时间";
    form.createEl("p",{text:"只写内容即可保存；分类、项目与日期可以稍后补充。",cls:"taskhub-muted"});
    const fields=form.createDiv({cls:"taskhub-fields"});
    const category=input(fields,"分类","text","category");
    category.placeholder="例如：招聘、个人";
    const project=input(fields,"项目","text","project");
    project.placeholder="例如：FDE 招聘";
    const due=input(fields,"截止日期","date","due");
    const time=input(fields,"截止时间（可选）","time","time");
    time.step="60";
    const suggestion=this.task?undefined:form.createDiv({cls:"taskhub-quick-suggestion"});
    if (suggestion) {
      const preview=()=>{
        suggestion.empty();
        const parsed=parseQuickTitle(title.value);
        if (!parsed) return;
        suggestion.createEl("span",{text:"识别到 "+parsed.due+(parsed.time?" "+parsed.time:"")});
        suggestion.createEl("button",{text:"应用日期时间",attr:{type:"button"}}).addEventListener("click",()=>{
          title.value=draft.title=parsed.title;
          due.value=draft.due=parsed.due;
          time.value=draft.time=parsed.time;
          suggestion.empty();title.focus();
        });
      };
      title.addEventListener("input",preview);
    }
    due.addEventListener("input",()=>{if(!due.value){draft.time="";time.value="";}});
    const priority=fields.createEl("label",{text:"优先级"}).createEl("select");
    addOptions(priority,priorityOptions("普通"),draft.priority);
    priority.addEventListener("change",()=>{draft.priority=priority.value;});
    const dates=form.createDiv({cls:"taskhub-date-shortcuts"});
    for (const [label,offset] of [["今天",0],["明天",1],["一周后",7],["不设日期",-1]] as const) {
      dates.createEl("button",{text:label,attr:{type:"button"}}).addEventListener("click",()=>{
        const date=new Date(); date.setDate(date.getDate()+Math.max(0,offset));
        due.value=draft.due=offset<0?"":localDay(date);
        if(offset<0){draft.time="";time.value="";}
      });
    }
    void this.hub.tasks().then(tasks=>{
      for (const [el,key] of [[category,"category"],[project,"project"]] as const) {
        if (!el.isConnected) return;
        const list=form.createEl("datalist"); list.id="taskhub-"+key+"-"+Math.random().toString(36).slice(2);
        el.setAttribute("list",list.id);
        for (const value of new Set(tasks.map(t=>t[key]).filter(Boolean))) list.createEl("option",{value});
      }
    }).catch(report);
    const status=form.createDiv({cls:"taskhub-form-status",attr:{"aria-live":"polite"}});
    const footer=form.createDiv({cls:"taskhub-editor-footer"});
    let keep:HTMLInputElement|undefined;
    if (!this.task) {
      const label=footer.createEl("label",{cls:"taskhub-keep"});
      keep=label.createEl("input",{type:"checkbox"});
      label.createEl("span",{text:"保存后继续添加"});
    }
    const submit=footer.createEl("button",{text:this.task?"保存修改":"添加任务",cls:"mod-cta",attr:{type:"submit"}});
    const task=this.task;
    if(task){
      const remove=footer.createEl("button",{text:"删除任务",cls:"taskhub-danger",attr:{type:"button"}});
      const confirm=form.createDiv({cls:"taskhub-confirm"});
      confirm.hidden=true;
      confirm.createEl("p",{text:"确认从原笔记删除这条任务？"});
      const actions=confirm.createDiv({cls:"taskhub-actions"});
      const cancel=actions.createEl("button",{text:"取消",attr:{type:"button"}});
      const accept=actions.createEl("button",{text:"确认删除",cls:"mod-warning",attr:{type:"button"}});
      remove.addEventListener("click",()=>{confirm.hidden=false;submit.disabled=true;remove.disabled=true;cancel.focus();});
      cancel.addEventListener("click",()=>{confirm.hidden=true;submit.disabled=false;remove.disabled=false;remove.focus();});
      accept.addEventListener("click",()=>{
        if(accept.disabled)return;
        accept.disabled=cancel.disabled=true;
        void this.hub.deleteTask(task).then(()=>{new Notice("任务已删除");this.close();})
          .catch(error=>{status.setText(error instanceof Error?error.message:String(error));})
          .finally(()=>{accept.disabled=cancel.disabled=false;});
      });
    }
    form.addEventListener("submit",event=>{
      event.preventDefault();
      if (submit.disabled) return;
      submit.disabled=true; submit.setText("正在保存…"); status.setText("");
      const next={...draft};
      // Prevent edits during a pending save from being silently lost on close/reset.
      const controls=Array.from(form.querySelectorAll<HTMLInputElement|HTMLSelectElement|HTMLButtonElement>("input,select,button"));
      controls.forEach(control=>{control.disabled=true;});
      void this.hub.save(next,this.task).then(()=>{
        if (keep?.checked) {
          draft.title=""; title.value=""; suggestion?.empty(); status.setText("已添加。分类、项目和日期已保留，可继续录入。");
        } else {new Notice(this.task?"修改已保存":"任务已添加");this.close();}
      }).catch(error=>{status.setText(error instanceof Error?error.message:String(error));})
        .finally(()=>{controls.forEach(control=>{control.disabled=false;});submit.setText(this.task?"保存修改":"添加任务");title.focus();});
    });
    title.focus();
  }
  onClose() {this.contentEl.empty();}
}

class EmailCapture extends HubModal {
  private generation=0;
  constructor(private hub:TaskHub){super(hub.app);}
  onOpen(){
    this.setTitle("邮件转任务");
    const el=this.contentEl;
    el.createEl("p",{text:"选择导出的 .eml 邮件。插件在本地读取主题，生成可编辑的录入预览。"});
    const input=el.createEl("input",{type:"file",attr:{accept:".eml,message/rfc822","aria-label":"选择邮件文件"}});
    const status=el.createEl("p",{attr:{"aria-live":"polite"}});
    const preview=el.createEl("button",{text:"打开录入预览",cls:"mod-cta"});
    preview.disabled=true;
    let title="";
    input.addEventListener("change",()=>{
      const id=++this.generation,file=input.files?.[0];
      title="";preview.disabled=true;status.setText("");
      if(!file)return;
      void file.slice(0,65536).text().then(text=>{
        if(id!==this.generation)return;
        title=emailSubject(text);status.setText("邮件主题 · "+title);preview.disabled=false;
      }).catch(error=>{if(id===this.generation)status.setText(error instanceof Error?error.message:String(error));});
    });
    preview.addEventListener("click",()=>{if(title){this.close();new TaskEditor(this.hub,undefined,{title:"处理邮件："+title}).open();}});
  }
  onClose(){this.generation++;this.contentEl.empty();}
}
class TaskJump extends HubModal {
  constructor(private destinations:[string,()=>void][],hub:TaskHub){super(hub.app);}
  onOpen(){
    this.setTitle("跳转到");
    const input=this.contentEl.createEl("input",{type:"search",placeholder:"搜索视图",attr:{"aria-label":"搜索视图"}});
    const list=this.contentEl.createDiv({cls:"taskhub-review-nav"});
    const matches=()=>this.destinations.filter(([name])=>name.includes(input.value.trim()));
    const choose=(action:()=>void)=>{this.close();action();};
    const render=()=>{
      list.empty();
      for(const [name,action] of matches()) list.createEl("button",{text:name}).addEventListener("click",()=>choose(action));
    };
    input.addEventListener("input",render);
    input.addEventListener("keydown",event=>{const first=matches()[0];if(event.key==="Enter"&&!event.isComposing&&first){event.preventDefault();choose(first[1]);}});
    render();input.focus();
  }
  onClose(){this.contentEl.empty();}
}
class Routines extends HubModal {
  private version=0;
  private release?:()=>void;
  constructor(private hub:TaskHub){super(hub.app);}
  onOpen(){
    this.setTitle("例行清单");
    const el=this.contentEl;el.addClass("taskhub-dialog");
    const tabs=el.createDiv({cls:"taskhub-nav"});
    const template=tabs.createEl("button",{text:"清单模板"});
    const habit=tabs.createEl("button",{text:"每日习惯"});
    const panel=el.createDiv();
    const switchTo=(daily:boolean)=>{
      this.version++;this.release?.();this.release=undefined;panel.empty();
      template.setAttribute("aria-pressed",String(!daily));habit.setAttribute("aria-pressed",String(daily));
      if(daily)this.renderHabits(panel);else this.renderTemplates(panel);
    };
    template.addEventListener("click",()=>switchTo(false));habit.addEventListener("click",()=>switchTo(true));
    switchTo(false);
  }
  private renderHabits(el:HTMLElement){
    const form=el.createDiv({cls:"taskhub-section"});
    const title=form.createEl("label",{text:"新习惯"}).createEl("input",{type:"text",placeholder:"例如：每天整理收集箱"});
    const create=form.createEl("button",{text:"添加每日习惯",cls:"mod-cta"});
    const stats=el.createEl("p",{cls:"taskhub-muted"});
    const list=el.createDiv();
    const refresh=async()=>{
      const version=++this.version;
      try {
        const tasks=await this.hub.tasks();if(version!==this.version)return;
        const habits=tasks.filter(task=>taskField(task,"repeat")==="daily");
        const today=localDay();
        stats.setText("今天已打卡 "+habits.filter(task=>finished(task)&&task.metadata.includes("✅ "+today)).length+" 次");
        showTasks(list,this.hub,habits.filter(task=>!finished(task)&&task.due<=today),false);
      } catch(error){if(version===this.version)report(error);}
    };
    this.release=this.hub.subscribe(()=>void refresh());void refresh();
    create.addEventListener("click",()=>{
      if(create.disabled)return;create.disabled=true;
      void this.hub.createHabit(title.value).then(()=>{title.value="";new Notice("习惯已添加");})
        .catch(report).finally(()=>{create.disabled=false;});
    });
  }
  private renderTemplates(panel:HTMLElement){
    const el=panel.createDiv({cls:"taskhub-section"});
    const templates:Record<string,string[]>={"月度结账":["核对本月流水","确认应收应付","整理结账凭证"],"出差准备":["确认行程和住宿","准备会议材料","整理报销凭证"],"旅行打包":["检查证件","准备充电器","整理衣物和洗漱用品"]};
    const select=el.createEl("label",{text:"模板"}).createEl("select");
    addOptions(select,Object.keys(templates).map(name=>[name,name]),"月度结账");
    const title=el.createEl("label",{text:"任务名称"}).createEl("input",{type:"text"});
    const steps=el.createEl("label",{text:"清单步骤（每行一项）"}).createEl("textarea",{attr:{rows:"6"}});
    const fill=()=>{title.value=select.value;steps.value=templates[select.value].join("\n");};
    select.addEventListener("change",fill);fill();
    const submit=el.createEl("button",{text:"创建清单",cls:"mod-cta"});
    submit.addEventListener("click",()=>{
      if(submit.disabled)return;submit.disabled=true;
      void this.hub.createFromTemplate(title.value,steps.value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean))
        .then(()=>{new Notice("清单已创建");this.close();}).catch(report).finally(()=>{submit.disabled=false;});
    });
  }
  onClose(){this.version++;this.release?.();this.contentEl.empty();}
}
class TaskPlanning extends HubModal {
  constructor(private hub:TaskHub,private task:Task,private day?:string,private after?:()=>void){super(hub.app);}
  onOpen(){
    this.setTitle("任务安排");
    const el=this.contentEl;el.addClass("taskhub-dialog");
    el.createEl("p",{text:this.task.title.split(/\s+/).filter(word=>word!==this.hub.settings.tag).join(" "),cls:"taskhub-dialog-task"});
    const save=(operation:()=>Promise<void>)=>{
      const buttons=Array.from(el.querySelectorAll<HTMLInputElement|HTMLSelectElement|HTMLButtonElement>("input,select,button"));
      buttons.forEach(b=>{b.disabled=true;});
      void operation().then(()=>{this.close();this.after?.();}).catch(error=>{
        report(error);buttons.forEach(b=>{b.disabled=false;});
      });
    };
    const section=(title:string)=>{const panel=el.createDiv({cls:"taskhub-section"});panel.createEl("h3",{text:title});return panel;};
    const schedule=section("时间块");
    const fields=schedule.createDiv({cls:"taskhub-schedule-grid"});
    const [day,time,duration]=taskField(this.task,"block").split(" ");
    const date=fields.createEl("label",{text:"排期日期"}).createEl("input",{type:"date",value:this.day||day||localDay()});
    const clock=fields.createEl("label",{text:"开始时间"}).createEl("input",{type:"time",value:time||"09:00"});
    const length=fields.createEl("label",{text:"时长（分钟）"}).createEl("select");
    addOptions(length,[15,30,45,60,90,120].map(n=>[String(n),String(n)]),duration||"30");
    const scheduleActions=schedule.createDiv({cls:"taskhub-actions"});
    if(day) scheduleActions.createEl("button",{text:"移除时间块"}).addEventListener("click",()=>save(()=>this.hub.updateField(this.task,"block","")));
    scheduleActions.createEl("button",{text:"保存时间块",cls:"mod-cta"}).addEventListener("click",()=>save(()=>this.hub.updateField(this.task,"block",[date.value,clock.value,length.value].join(" "))));
    if(!finished(this.task)&&!this.task.recurring){
      const rule=section("重复规则");
      const repeat=rule.createEl("label",{text:"完成后生成下一次"}).createEl("select");
      const current=taskField(this.task,"repeat");
      const kind=current==="mwf"||current.startsWith("weekly:")?"weekly":current.startsWith("monthly:")?"monthly":current;
      addOptions(repeat,[["","不重复"],["daily","每天"],["weekly","每周 · 选择星期"],["monthly","每月 · 指定日期"],["month-end","每月最后一个工作日"]],kind);
      const start=new Date((this.task.due||localDay())+"T12:00:00");
      const selected=current==="mwf"?[1,3,5]:current.startsWith("weekly:")?current.slice(7).split(",").map(Number):[start.getDay()];
      const week=rule.createEl("fieldset",{cls:"taskhub-repeat-days"});
      week.createEl("legend",{text:"星期（可多选）"});
      const weekdays=[1,2,3,4,5,6,0].map((day,index)=>{
        const label=week.createEl("label");
        const input=label.createEl("input",{type:"checkbox"});input.checked=selected.includes(day);
        label.createEl("span",{text:"周"+"一二三四五六日"[index]});
        return {day,input};
      });
      const month=rule.createEl("label",{text:"每月几号"});
      const monthDay=month.createEl("select");
      addOptions(monthDay,Array.from({length:31},(_,i)=>[String(i+1),(i+1)+" 号"]),current.startsWith("monthly:")?current.slice(8):String(start.getDate()));
      const hint=rule.createEl("p",{cls:"taskhub-muted"});
      const update=()=>{
        week.hidden=repeat.value!=="weekly";month.hidden=repeat.value!=="monthly";
        hint.setText(!this.task.due?"请先在「编辑」中为这条任务设置截止日期。":repeat.value==="monthly"?"没有所选日期的月份会跳过。":"首次仍按当前截止日期，完成后按规则生成下一次。");
      };
      repeat.addEventListener("change",update);update();
      rule.createDiv({cls:"taskhub-actions"}).createEl("button",{text:"保存重复规则"}).addEventListener("click",()=>{
        const days=weekdays.filter(({input})=>input.checked).map(({day})=>day);
        if(repeat.value==="weekly"&&!days.length){new Notice("请选择至少一个星期");return;}
        const value=repeat.value==="weekly"?"weekly:"+days.join(","):repeat.value==="monthly"?"monthly:"+monthDay.value:repeat.value;
        save(()=>this.hub.updateField(this.task,"repeat",value));
      });
    }
    const subtasks=section("子任务");
    const child=subtasks.createEl("label",{text:"步骤内容"}).createEl("input",{type:"text",placeholder:"例如：准备面试材料"});
    subtasks.createDiv({cls:"taskhub-actions"}).createEl("button",{text:"添加子任务"}).addEventListener("click",()=>save(()=>this.hub.addSubtask(this.task,child.value)));
    if(!finished(this.task)) {
      const doing=taskField(this.task,"board")==="进行中";
      el.createDiv({cls:"taskhub-actions"}).createEl("button",{text:doing?"移回待办":"标为进行中"}).addEventListener("click",()=>save(()=>this.hub.updateField(this.task,"board",doing?"":"进行中")));
    }
  }
  onClose(){this.contentEl.empty();}
}
type CalendarEvent=CalendarSlot & {id:string;title:string};
function parseCalendarEvents(text:string):CalendarEvent[] {
  const events:unknown=JSON.parse(text);
  if(!Array.isArray(events)||events.some(event=>!validSlot(event)||typeof event.id!=="string"||typeof event.title!=="string")||
      new Set(events.map(event=>event.id)).size!==events.length) throw new Error("TaskHub 日程文件格式无效。");
  return events;
}
class TaskCalendar extends ItemView {
  private stop?:()=>void;
  constructor(leaf:WorkspaceLeaf,private hub:TaskHub){super(leaf);}
  getViewType(){return CALENDAR_VIEW;}
  getDisplayText(){return "TaskHub 日历";}
  getIcon(){return "calendar-days";}
  async onOpen(){
    this.contentEl.empty();
    this.contentEl.addClass("taskhub-calendar-pane");
    const frame=this.contentEl.createEl("iframe",{cls:"taskhub-calendar-frame",attr:{sandbox:"allow-scripts",title:"TaskHub 日历"}});
    let tasks:Task[]=[],events:CalendarEvent[]=[];
    let busy=false,closed=false,ready=false,dirty=false,revision=0;
    let signature="";
    const publish=async()=>{
      const [nextTasks,nextEvents]=await Promise.all([this.hub.tasks(),this.hub.calendarEvents()]);
      if(closed)return;
      const nextSignature=JSON.stringify([nextTasks,nextEvents,this.hub.calendarAgents()]);
      if(nextSignature!==signature){revision++;signature=nextSignature;}
      tasks=nextTasks;events=nextEvents;
      const payload=tasks.flatMap((task,index)=>{
        if(finished(task))return [];
        return [{id:index,title:task.title.split(/\s+/).filter(word=>word!==this.hub.settings.tag).join(" ")||task.title,category:task.category,project:task.project,due:task.due,slots:taskSlots(task)}];
      });
      ready=true;
      frame.contentWindow?.postMessage({type:"taskhub-state",revision,tasks:payload,events,agents:this.hub.calendarAgents()},"*");
    };
    const refresh=async()=>{
      if(closed||!ready)return;
      if(busy){dirty=true;return;}
      busy=true;
      try{await publish();}
      catch{frame.contentWindow?.postMessage({type:"taskhub-refresh-error",text:"日历刷新失败，请点击重新读取。"},"*");}
      finally{busy=false;if(dirty){dirty=false;void refresh();}}
    };
    const receive=async(event:MessageEvent)=>{
      if(event.source!==frame.contentWindow||closed)return;
      const data=event.data;
      if(!data||data.type!=="taskhub-calendar")return;
      if(busy){frame.contentWindow?.postMessage({type:"taskhub-error",text:"日历正在更新，请稍后重试。"},"*");return;}
      if(data.action==="show-updates"){
        window.open("https://marcus-same.github.io/marcus-output-library/taskhub/","_blank","noopener,noreferrer");
        return;
      }
      busy=true;
      try {
        if(data.action==="load"){await publish();return;}
        if(!ready)throw new Error("日历尚未加载，请重试读取。");
        if(data.revision!==revision)throw new Error("待办已更新，请重新选择日程后再操作。");
        const task=Number.isInteger(data.taskId)?tasks[data.taskId]:undefined;
        if(data.action==="delegate"){
          if(!task)throw new Error("找不到要委派的待办。");
          await this.hub.delegateCalendarTask(task,data.agent);
          frame.contentWindow?.postMessage({type:"taskhub-delegate-preview"},"*");
          return;
        }
        if(data.action==="open-source"||data.action==="agent-source"){
          if(!task)throw new Error("待办已变更，请重开日历后重试。");
          await this.hub.openSource(task);
          if(data.action==="agent-source"){
            const registry=(this.app as unknown as {plugins?:{getPlugin?:(id:string)=>unknown}}).plugins;
            new Notice(registry?.getPlugin?.("agent-deck")
              ?"已打开原任务。在 Agent Deck 选 Agent 并确认发送。"
              :"当前库未启用 Agent Deck。启用后，可在这条原待办上委派。",9000);
          }
          frame.contentWindow?.postMessage({type:"taskhub-opened"},"*");return;
        } else if(data.action==="schedule-dragged-task"){
          await this.hub.scheduleDraggedTask(data.token,data.slot);
        } else if(data.action==="delete-task"){
          if(!task)throw new Error("待办已变更。");
          await this.hub.deleteTask(task);
        } else if(data.action==="save-task"){
          if(!task&&!tasks[data.sourceId])throw new Error("请先在待办工作台创建任务。");
          if(!Array.isArray(data.slots)||typeof data.title!=="string")throw new Error("待办内容无效。");
          await this.hub.saveCalendarTask(task,task?.title??data.title,data.slots,tasks[data.sourceId]);
        } else if(data.action==="save-event"||data.action==="delete-event"){
          const previous=events.find(item=>item.id===data.id);
          if(!previous)throw new Error("找不到已有日程。");
          const item=data.action==="delete-event"?previous:{...previous,...data.slot,id:previous.id,tone:previous.tone,title:data.title};
          if(!item||typeof item.title!=="string")throw new Error("日程内容无效。");
          await this.hub.changeCalendarEvent(item,previous,data.action==="delete-event");
        } else return;
        frame.contentWindow?.postMessage({type:"taskhub-saved"},"*");
        ready=false;
        try {await publish();}
        catch {frame.contentWindow?.postMessage({type:"taskhub-refresh-error",text:"已保存，但刷新失败。请重新读取日历。"},"*");}
      } catch(error){frame.contentWindow?.postMessage({type:"taskhub-error",text:error instanceof Error?error.message:String(error)},"*");}
      finally{busy=false;if(dirty){dirty=false;void refresh();}}
    };
    const listener=(event:MessageEvent)=>void receive(event);
    window.addEventListener("message",listener);
    const unsubscribe=this.hub.subscribe(()=>void refresh());
    this.stop=()=>{closed=true;unsubscribe();window.removeEventListener("message",listener);};
    frame.srcdoc=calendarHtml;
  }
  async onClose(){this.stop?.();this.stop=undefined;this.contentEl.empty();}
}
class PlanningBoard extends HubModal {
  private generation=0;
  constructor(private hub:TaskHub){super(hub.app);}
  onOpen(){this.setTitle("任务看板");this.modalEl?.addClass("taskhub-modal-wide");void this.render();}
  onClose(){this.generation++;this.contentEl.empty();}
  private async render(){
    const id=++this.generation;
    const el=this.contentEl;el.setText("正在读取任务…");
    try {
      const tasks=await this.hub.tasks();if(id!==this.generation)return;
      el.empty();
      const board=el.createDiv({cls:"taskhub-board"});
      for(const column of ["待办","进行中","已完成"]){
        const section=board.createDiv();section.createEl("h3",{text:column});
        const items=tasks.filter(task=>(finished(task)?"已完成":taskField(task,"board")||"待办")===column);
        for(const task of items) section.createEl("button",{text:task.title}).addEventListener("click",()=>new TaskPlanning(this.hub,task,undefined,()=>void this.render()).open());
      }
    } catch(error){if(id===this.generation)el.setText(String(error));}
  }
}
class CompletionStats extends HubModal {
  private closed=false;
  constructor(private hub:TaskHub){super(hub.app);}
  onOpen(){
    this.setTitle("近七天完成记录");
    const el=this.contentEl;
    el.setText("正在读取任务…");
    void this.hub.tasks().then(tasks=>{
      if(this.closed) return;
      const counts=new Map<string,number>();
      for(let offset=34;offset>=0;offset--){
        const date=new Date();date.setDate(date.getDate()-offset);counts.set(localDay(date),0);
      }
      for(const task of tasks){
        if(!/^[xX]$/.test(task.status)) continue;
        const date=task.metadata.match(/✅\s*(\d{4}-\d{2}-\d{2})|\[(?:done|completion)::\s*(\d{4}-\d{2}-\d{2})\s*\]/u);
        const day=date?.[1]??date?.[2];
        if(day && counts.has(day)) counts.set(day,(counts.get(day)??0)+1);
      }
      el.empty();
      el.createEl("p",{text:"近七天完成 "+[...counts.values()].slice(-7).reduce((sum,value)=>sum+value,0)+" 项"});
      const heatmap=el.createDiv({cls:"taskhub-heatmap",attr:{"aria-label":"近 35 天完成热力图"}});
      for(const [day,count] of counts) heatmap.createEl("span",{text:String(count),attr:{title:day+" · "+count+" 项","data-level":String(Math.min(3,count))}});
      const list=el.createEl("ul");
      for(const [day,count] of [...counts].slice(-7)) list.createEl("li",{text:day+" · "+count+" 项"});
      el.createEl("p",{text:"仅统计有完成日期的任务。",cls:"taskhub-muted"});
    }).catch(error=>{if(!this.closed) el.setText(String(error));});
  }
  onClose(){this.closed=true;this.contentEl.empty();}
}
class WeeklyReview extends HubModal {
  private step=0;
  private selected=new Map<string,string>();
  private renderId=0;
  constructor(private hub:TaskHub){super(hub.app);}
  onOpen(){this.setTitle("每周回顾");void this.render();}
  onClose(){this.renderId++;this.contentEl.empty();}
  private async render(){
    const id=++this.renderId;
    const el=this.contentEl;
    el.empty();el.createEl("p",{text:"正在读取任务…"});
    try {
      const tasks=await this.hub.tasks();
      if (id!==this.renderId) return;
      el.empty();
      const names=["处理逾期","整理收集箱","选出下周最重要的三件事"];
      const scope=(["逾期","收集箱","全部"] as const)[this.step];
      const items=filterTasks(tasks,{scope},localDay(),clockTime());
      el.createEl("h3",{text:(this.step+1)+" / 3 · "+names[this.step]});
      if (this.step<2) {
        el.createEl("p",{text:this.step===0?"完成已处理的任务，或编辑仍需跟进的截止时间。":"给值得保留的任务补上分类、项目或截止日期。",cls:"taskhub-muted"});
        showTasks(el.createDiv({cls:"taskhub-review-list"}),this.hub,items,false);
      } else {
        const list=el.createDiv({cls:"taskhub-review-list"});
        const status=el.createEl("p",{attr:{"aria-live":"polite"}});
        const output=el.createEl("textarea",{attr:{readonly:"",rows:"5","aria-label":"下周重点 Markdown"}});
        const active=new Set(items.map(t=>t.path+":"+t.line+":"+t.raw));
        for (const key of this.selected.keys()) if (!active.has(key)) this.selected.delete(key);
        const update=()=>{
          status.setText("已选 "+this.selected.size+" / 3");
          output.value=this.selected.size?"## 下周重点\n"+[...this.selected.values()].map((title,i)=>(i+1)+". "+title).join("\n"):"";
        };
        for (const task of items) {
          const key=task.path+":"+task.line+":"+task.raw;
          const row=list.createEl("label",{cls:"taskhub-review-choice"});
          const toggle=row.createEl("input",{type:"checkbox"});
          row.createEl("span",{text:task.title});
          toggle.checked=this.selected.has(key);
          toggle.addEventListener("change",()=>{
            if (!toggle.checked) this.selected.delete(key);
            else if (this.selected.size<3) this.selected.set(key,task.title);
            else {toggle.checked=false;new Notice("最多选择三件事");}
            update();
          });
        }
        update();
        el.createEl("button",{text:"复制下周重点"}).addEventListener("click",()=>{
          if (!output.value) {new Notice("先选择至少一项任务");return;}
          void navigator.clipboard.writeText(output.value).then(()=>new Notice("已复制下周重点")).catch(report);
        });
      }
      const nav=el.createDiv({cls:"taskhub-review-nav"});
      if (this.step>0) nav.createEl("button",{text:"上一步"}).addEventListener("click",()=>{this.step--;void this.render();});
      nav.createEl("button",{text:"刷新本步"}).addEventListener("click",()=>void this.render());
      nav.createEl("button",{text:this.step===2?"完成回顾":"下一步",cls:"mod-cta"}).addEventListener("click",()=>{
        if (this.step===2) this.close();else {this.step++;void this.render();}
      });
    } catch(error) {if (id===this.renderId) el.setText(String(error));}
  }
}
class QueryEditor extends HubModal {
  constructor(private hub:TaskHub,private selected:string,private insert:(block:string)=>void) {super(hub.app);}
  onOpen() {
    this.setTitle("插入动态任务查询");
    const {contentEl}=this;
    const scope=contentEl.createEl("label",{text:"视图"}).createEl("select");
    addOptions(scope,scopes.map(s=>[s,s]),"全部");
    const project=contentEl.createEl("label",{text:"项目（可选）"}).createEl("input",{type:"text",value:this.selected});
    contentEl.createEl("button",{text:"插入查询",cls:"mod-cta"}).addEventListener("click",()=>{
      const value=project.value.trim().replace(/[\r\n]/g,"");
      const fence=String.fromCharCode(96).repeat(3);
      this.insert("\n\n"+fence+"taskhub\nscope: "+scope.value+(value?"\nproject: "+value:"")+"\n"+fence+"\n\n");
      this.close();
    });
  }
  onClose() {this.contentEl.empty();}
}
class Migration extends HubModal {
  constructor(private hub:TaskHub) {super(hub.app);}
  onOpen() {
    this.setTitle("接管旧版任务库");
    const {contentEl}=this;
    contentEl.createEl("p",{text:"选定旧 Markdown 目录后，先备份，再让 TaskHub 原地读取。旧笔记和 Tasks 查询继续使用原路径。"});
    const path=contentEl.createEl("label",{text:"旧任务库目录"}).createEl("input",{type:"text",value:defaults.folder});
    const status=contentEl.createEl("p",{attr:{"aria-live":"polite"}});
    const preview=contentEl.createEl("button",{text:"扫描"});
    const apply=contentEl.createEl("button",{text:"备份并接管",cls:"mod-cta"});
    apply.disabled=true;
    let approved="";
    path.addEventListener("input",()=>{approved="";apply.disabled=true;status.empty();});
    preview.addEventListener("click",()=>{
      try {
        const target=safePath(path.value);
        approved="";
        apply.disabled=true;
        void this.hub.tasks(target,true).then(tasks=>{
          if (safePath(path.value)!==target) return;
          status.setText(this.hub.files(target).length+" 个 Markdown 文件，识别到 "+tasks.length+" 条任务。");
          approved=target;
          apply.disabled=!tasks.length;
        }).catch(report);
      } catch(error) {report(error);}
    });
    apply.addEventListener("click",()=>{
      if (!approved) return;
      apply.disabled=true;
      void this.hub.migrate(approved).then(result=>{
        new Notice("接管 "+result.count+" 条任务 · "+result.backup,8000);this.close();
      }).catch(error=>{report(error);apply.disabled=false;});
    });
  }
  onClose() {this.contentEl.empty();}
}
class HubSettings extends PluginSettingTab {
  constructor(private hub:TaskHub) {super(hub.app,hub);}
  display() {
    const {containerEl}=this;
    containerEl.empty();
    const draft={...this.hub.settings};
    new Setting(containerEl).setName("改到明天时提升普通或低优先级")
      .setDesc("仅在 TaskHub 编辑截止日期且未同时修改优先级时，将普通或低优先级调整为中。")
      .addToggle(t=>t.setValue(draft.promoteTomorrow).onChange(value=>{draft.promoteTomorrow=value;}));
    const fields=[["folder","Markdown 任务库目录"],["tag","新任务的 Tasks 全局标记"],
      ["queue","外部录入队列目录"],["backups","备份目录"]] as const;
    for (const [field,label] of fields) {
      new Setting(containerEl).setName(label).addText(t=>t.setValue(draft[field]).onChange(v=>{draft[field]=v;}));
    }
    new Setting(containerEl).setName("联动已有待办目录").setDesc("每行一个库内目录；任务直接在原笔记更新，不复制。留空则只显示统一任务库。")
      .addTextArea(t=>t.setValue(draft.linkedFolders).onChange(v=>{draft.linkedFolders=v;}));
    new Setting(containerEl).setName("自动导入外部录入").setDesc("启动后及每 15 秒检查队列。")
      .addToggle(t=>t.setValue(draft.autoImport).onChange(v=>{draft.autoImport=v;}));
    new Setting(containerEl).addButton(b=>b.setButtonText("保存设置").setCta().onClick(()=>{
      b.setDisabled(true);
      void this.hub.updateSettings(draft).then(()=>new Notice("TaskHub 设置已保存")).catch(report).finally(()=>b.setDisabled(false));
    }));
    new Setting(containerEl).setName("旧版迁移").addButton(b=>b.setButtonText("扫描旧任务库").onClick(()=>new Migration(this.hub).open()));
  }
}
function showTasks(el:HTMLElement,hub:TaskHub,tasks:Task[],group:boolean) {
  el.empty();
  if (!tasks.length) {el.createEl("p",{text:"没有符合条件的任务。",cls:"taskhub-muted"});return;}
  const projects=group ? [...new Set(tasks.map(t=>t.project))].sort() : [""];
  for (const project of projects) {
    if (group) el.createEl("h3",{text:project});
    const list=el.createEl("ul",{cls:"taskhub-list"});
    for (const task of (group?tasks.filter(t=>t.project===project):tasks)) {
      const row=list.createEl("li",{cls:"taskhub-row"});
      const toggle=row.createEl("input",{type:"checkbox",attr:{"aria-label":"完成 "+task.title}});
      toggle.checked=finished(task);
      toggle.disabled=task.recurring || ![" ","x","X"].includes(task.status) || /❌|\[cancelled::/u.test(task.metadata) || (finished(task)&&!!taskField(task,"repeat"));
      if (toggle.disabled) toggle.title="请在原笔记使用 Tasks 修改此状态。";
      toggle.addEventListener("change",()=>{
        toggle.disabled=true;
        void hub.toggle(task).catch(error=>{toggle.checked=finished(task);report(error);})
          .finally(()=>{toggle.disabled=false;});
      });
      const text=row.createDiv({cls:"taskhub-text"});
      const displayTitle=task.title.split(/\s+/).filter(t=>t!==hub.settings.tag).join(" ")||task.title;
      text.createDiv({text:displayTitle,cls:finished(task)?"taskhub-done":"taskhub-title"});
      const meta=text.createDiv({cls:"taskhub-meta"});
      for (const value of [task.category,task.project?"项目 · "+task.project:"",task.priority])
        if (value) meta.createEl("span",{text:value,cls:"taskhub-badge"});
      if (task.due) {
        const today=localDay();
        const late=!finished(task)&&(task.due<today || (task.due===today && !!task.time && task.time<clockTime()));
        meta.createEl("span",{text:(late?"已逾期 · ":task.due===today?"今天到期 · ":"截止 · ")+task.due+(task.time?" "+task.time:""),
          cls:"taskhub-badge "+(late?"taskhub-overdue":task.due===today&&!finished(task)?"taskhub-today":"")});
      }
      const completed=finished(task)?completionStamp(task):"";
      if(completed) meta.createEl("span",{text:"完成于 "+completed,cls:"taskhub-badge"});
      meta.createEl("span",{text:task.path,cls:"taskhub-source"});
      if (toggle.disabled) meta.createEl("span",{text:"循环或特殊状态 · 请在原笔记操作",cls:"taskhub-muted"});
      const actions=row.createDiv({cls:"taskhub-row-actions"});
      actions.createEl("button",{text:"编辑"}).addEventListener("click",()=>new TaskEditor(hub,task).open());
      actions.createEl("button",{text:"安排"}).addEventListener("click",()=>new TaskPlanning(hub,task).open());
      actions.createEl("button",{text:"原笔记"}).addEventListener("click",()=>void hub.openSource(task).catch(report));
      if(!finished(task)){
        const handle=row.createEl("span",{text:"⠿",cls:"taskhub-drag-handle",attr:{draggable:"true",title:"拖到日历安排时间"}});
        let token="";
        handle.addEventListener("dragstart",event=>{if(event.dataTransfer)token=hub.beginTaskDrag(task,event.dataTransfer);});
        handle.addEventListener("dragend",()=>{if(token)hub.endTaskDrag(token);});
      }
    }
  }
}
class Workbench extends ItemView {
  private query:Query={scope:"今天"};
  private release?:()=>void;
  private version=0;
  private tasks:Task[]=[];
  private sort="due";
  constructor(leaf:WorkspaceLeaf,private hub:TaskHub) {super(leaf);}
  getViewType(){return VIEW;}
  getDisplayText(){return "TaskHub";}
  getIcon(){return "list-todo";}
  async onOpen() {
    const el=this.contentEl;
    el.empty(); el.addClass("taskhub");
    const header=el.createDiv({cls:"taskhub-header"});
    const heading=header.createDiv();
    heading.createEl("h2",{text:"任务工作台"});
    const subtitle=heading.createEl("p",{cls:"taskhub-muted"});
    const create=()=>new TaskEditor(this.hub,undefined,{
      category:this.query.category??"",project:this.query.project??"",
      due:this.query.scope==="今天"?localDay():"",
      priority:this.query.priority==="none"?"":this.query.priority??""
    }).open();
    const actions=header.createDiv({cls:"taskhub-header-actions"});
    actions.createEl("button",{text:"日历",attr:{title:"打开或关闭日历"}}).addEventListener("click",()=>void this.hub.toggleCalendar().catch(report));
    actions.createEl("button",{text:"看板"}).addEventListener("click",()=>new PlanningBoard(this.hub).open());
    const more=actions.createEl("details",{cls:"taskhub-more"});
    more.createEl("summary",{text:"更多"});
    const menu=more.createDiv({cls:"taskhub-more-menu"});
    const menuItem=(text:string,open:()=>void)=>menu.createEl("button",{text}).addEventListener("click",()=>{more.open=false;open();});
    menuItem("例行清单",()=>new Routines(this.hub).open());
    menuItem("每周回顾",()=>new WeeklyReview(this.hub).open());
    menuItem("完成记录",()=>new CompletionStats(this.hub).open());
    actions.createEl("button",{text:"＋ 新建任务",cls:"mod-cta",attr:{"aria-keyshortcuts":"Q"}}).addEventListener("click",create);
    const nav=el.createDiv({cls:"taskhub-nav",attr:{"aria-label":"任务视图"}});
    const tabs=new Map<string,HTMLButtonElement>();
    for (const scope of scopes) {
      const button=nav.createEl("button",{text:scope}); tabs.set(scope,button);
      button.addEventListener("click",()=>{this.query.scope=scope;render();});
    }
    const toolbar=el.createDiv({cls:"taskhub-toolbar"});
    const search=toolbar.createEl("input",{type:"search",placeholder:"搜索任务、标签或项目…",value:this.query.search??"",attr:{"aria-label":"搜索任务"}});
    search.setAttribute("aria-keyshortcuts","/");
    el.tabIndex=0;
    this.registerDomEvent(el,"keydown",event=>{
      if (event.defaultPrevented || event.repeat || event.isComposing || event.altKey || event.shiftKey) return;
      if (event.key.toLowerCase()==="k"&&(event.ctrlKey||event.metaKey)) {
        event.preventDefault();
        new TaskJump([...scopes.map((scope):[string,()=>void]=>[scope,()=>{this.query.scope=scope;render();}]),
          ["日历",()=>void this.hub.openCalendar().catch(report)],["看板",()=>new PlanningBoard(this.hub).open()],
          ["每周回顾",()=>new WeeklyReview(this.hub).open()]],this.hub).open();
        return;
      }
      if(event.ctrlKey||event.metaKey)return;
      if ((event.target as HTMLElement|null)?.closest("input,textarea,select,[contenteditable=true]")) return;
      if (event.key==="/") {event.preventDefault();search.focus();}
      if (event.key==="q") {event.preventDefault();create();}
    });
    const category=toolbar.createEl("select",{attr:{"aria-label":"分类"}});
    const project=toolbar.createEl("select",{attr:{"aria-label":"项目"}});
    const priority=toolbar.createEl("select",{attr:{"aria-label":"优先级"}});
    addOptions(priority,[...priorityOptions("所有优先级"),["none","普通优先级"]],this.query.priority??"");
    const sorting=toolbar.createEl("select",{attr:{"aria-label":"排序"}});
    addOptions(sorting,[["due","默认排序"],["priority","优先级优先"],["title","任务名称排序"]],this.sort);
    const reset=toolbar.createEl("button",{text:"清除筛选"});
    const summary=el.createDiv({cls:"taskhub-summary"});
    const status=summary.createEl("p",{cls:"taskhub-muted",attr:{"aria-live":"polite"}});
    const retry=summary.createEl("button",{text:"刷新"});
    const list=el.createDiv();
    const clear=()=>{
      this.query={scope:this.query.scope};
      category.value=project.value=priority.value=search.value="";render();
    };
    let renderedSignature="";
    reset.addEventListener("click",clear);
    const render=()=>{
      const today=localDay();
      const overdue=filterTasks(this.tasks,{scope:"逾期"},today,clockTime()).length;
      subtitle.setText(today+(overdue?" · "+overdue+" 项逾期":""));
      for (const [scope,button] of tabs) {
        button.setText(scope+" · "+filterTasks(this.tasks,{scope:scope as Query["scope"]},today,clockTime()).length);
        button.setAttribute("aria-pressed",String(this.query.scope===scope));
      }
      let result=filterTasks(this.tasks,this.query,today,clockTime());
      if (this.sort==="priority") {
        const rank=["🔺","⏫","🔼","","🔽","⏬"];
        result=result.sort((a,b)=>rank.indexOf(a.priority)-rank.indexOf(b.priority));
      } else if (this.sort==="title") result=result.sort((a,b)=>a.title.localeCompare(b.title,"zh-CN"));
      const filtered=!!(this.query.category||this.query.project||this.query.priority||this.query.search);
      reset.disabled=!filtered;
      status.setText((this.query.scope??"今天")+" · "+result.length+" 项"+(filtered?" · 已应用筛选":"")+(this.query.scope==="今天"?" · 今天到期；已过截止时间的任务也列入逾期":""));
      const signature=JSON.stringify([this.query,this.sort,today,clockTime(),result.map(task=>[task.path,task.line,task.raw])]);
      if(signature===renderedSignature)return;
      renderedSignature=signature;
      showTasks(list,this.hub,result,this.query.scope==="项目");
      if (!result.length) {
        list.empty();
        const empty=list.createDiv({cls:"taskhub-empty"});
        empty.createEl("h3",{text:filtered?"没有匹配的任务":this.query.scope==="逾期"?"当前没有逾期任务":this.query.scope==="今天"?"今天没有到期任务":"这里还没有任务"});
        empty.createEl("p",{text:filtered?"试试减少筛选条件，或换一个关键词。":"可以添加任务，也可以切换到全部查看其他安排。",cls:"taskhub-muted"});
        empty.createEl("button",{text:filtered?"清除筛选":"添加任务",cls:"mod-cta"}).addEventListener("click",filtered?clear:create);
      }
    };
    const reload=async()=>{
      const version=++this.version;
      const tasks=await this.hub.tasks();
      if (version!==this.version) return;
      this.tasks=tasks;
      for (const [select,key,label] of [[category,"category","所有分类"],[project,"project","所有项目"]] as const) {
        select.empty();
        const values=[...new Set(tasks.map(t=>t[key]).filter(Boolean))].sort();
        // Keep active filters even if their last task moved to another project.
        if (this.query[key] && !values.includes(this.query[key]!)) values.push(this.query[key]!);
        addOptions(select,[["",label],...values.map((s):[string,string]=>[s,s])],this.query[key]??"");
      }
      render();
    };
    const update=()=>{
      this.query={...this.query,category:category.value,project:project.value,priority:priority.value,search:search.value};
      this.sort=sorting.value;render();
    };
    toolbar.addEventListener("change",update); search.addEventListener("input",update);
    const refresh=()=>void reload().catch(error=>{status.setText("读取失败，点击刷新重试。当前列表可能不是最新数据。");report(error);});
    retry.addEventListener("click",refresh);
    status.setText("正在读取任务…");
    this.release=this.hub.subscribe(refresh);refresh();
  }
  async onClose() {this.version++;this.release?.();}
}

class InlineTasks extends MarkdownRenderChild {
  private version=0;
  private release?:()=>void;
  constructor(el:HTMLElement,private hub:TaskHub,private source:string){super(el);}
  onload(){
    this.containerEl.addClass("taskhub");
    let query:Query;
    try {query=parseQuery(this.source);}
    catch(error) {this.containerEl.setText(String(error));return;}
    const refresh=async()=>{
      const version=++this.version;
      try {
        const tasks=await this.hub.tasks();
        if (version===this.version) showTasks(this.containerEl,this.hub,filterTasks(tasks,query,localDay(),clockTime()),query.scope==="项目");
      } catch(error) {if (version===this.version) this.containerEl.setText(String(error));}
    };
    this.release=this.hub.subscribe(()=>void refresh());
    void refresh();
  }
  onunload(){this.version++;this.release?.();}
}
export default TaskHub;

