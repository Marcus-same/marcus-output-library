# BOSS 单标签执行

这是 recruit-daily 内部操作规则，不是独立 skill。浏览器使用 web-access，复用当前已登录招聘者 tab，所有步骤使用同一 targetId。

- 先运行 web-access 的依赖检查和 targets 探针，再做最小 eval 探针。返回失败时保存进度并停止。
- 推荐数据位于 `iframe[src*=recommend]` 的 contentDocument。禁止刷新、reload 或新建 BOSS tab。
- 先读取岗位下拉 `.job-selecter-wrap .job-item` 的文本和 value，按岗位配置的 boss_job_title 与 job_id 唯一绑定。当前页面岗位不同只表示需要切岗，不能把它改写成目标岗位的绑定。
- 页面存在多个相似岗位时，优先已核验的准确名称与 ID；不能把“c端产品经理”推定为“高级学习产品经理”。无法唯一绑定时暂停询问。
- 在同一 tab 选择目标岗位后，回读 `.ui-dropmenu-label` 和 iframe.contentWindow.location.href 的 jobid；iframe.src 中 jobid=null 不是有效绑定证据。
- 打开 `.filter-label` 后执行 `../scripts/apply-profile-filters.mjs <targetId> --profile-file=<岗位配置绝对路径> --no-writeback`。年龄、选中项集合、第一学历、条件计数均须一致，校验失败不得开始筛选。
- 配置为“不限”的项目同样必须核验，禁止保留历史筛选。不得点击来源不明的“应用上次筛选条件”。
- 页面详情与面板控件可使用脚本提供的兼容点击；发送动作必须使用浏览器真实点击，不能用 DOM click 替代。
- 不开启无头模式，不修改系统、代理或其他 skill 配置。验证码、验证页面、登录异常、权益不足时停止；不能通过切入口绕过。
- 断线后重扫现有 tabs，按 `recovery-and-identity.md` 核查 pending/unknown；禁止自动重发。

