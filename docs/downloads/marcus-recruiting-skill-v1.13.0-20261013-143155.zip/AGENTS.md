# AGENTS.md —— Marcus recruiting skill · AI 协作约定

> 本文件告诉 AI 工具（Claude Code / Codex / MiniMax Code 等任何 agent）在本工作区**怎么干活**。
> 术语、硬规则、岗位状态的**真值在 [`CONTEXT.md`](CONTEXT.md)**；本文件只管「分工、路由与红线」。
> 进入本工作区先读 `CONTEXT.md`，再看本文件。

## 角色边界

- 干：寻源取数、初筛、收取与评估简历、建档、维护本地台账与候选人池、回填关键词迭代表、生成日报。
- **不干（对外不可逆动作，一律等用户确认）**：替用户在平台点「不合适」、主动发打招呼/消息（授权规则见 `skills/recruit-daily/SKILL.md`）、自动建面试日程或通知候选人、发 offer。当前工作区不再提供自动约面 Skill。

## 工作流路由（按场景读对应文档）

主流程：**init（一次）→ grill（每岗一次）→ daily（每天循环）**。
匝道：寻了几轮发现标准跑偏（全是错的人/池子里没这种人）→ 带台账数据回 grill 重梳理。

| 场景 | 读 |
|---|---|
| 不确定该走哪个流程 / 用户问"这套工具怎么用" | `skills/marcus-recruiting-skill/SKILL.md` |
| 每日招聘：查未读 / 主动寻源 / 初筛 / 打招呼 / 补台账 / 出日报 | `skills/recruit-daily/SKILL.md` |
| 深度盘点某岗市场人才：供给/薪资对标/目标公司有谁/好不好招 | `skills/market-talent-mapping/SKILL.md` |
| 本地简历（猎头/内推/直投）要评估，或回查某人评级 | `skills/resume-review/SKILL.md` |
| 新开一个岗位 / 重新梳理某岗位的真实要求 | `skills/recruit-grill/SKILL.md` |
| BOSS 推荐池扩池、卡片初筛、强匹配在线简历截图深判 | `skills/recruit-daily/SKILL.md` + `skills/recruit-daily/references/boss-recommend-integration.md` |
| 重建 / 修复工作区结构 | `skills/recruit-init/SKILL.md` |
| BOSS 浏览器操作与单标签复用 | `skills/recruit-daily/references/channels.md` + `skills/recruit-daily/references/boss-browser.md` |
| 猎聘 CLI 命令细节 | `skills/recruit-daily/references/channels.md` + `liepin help` |

## 会话卫生（跨会话记忆只有文件）

- **一天的招聘用一个新会话跑完**；别在一个会话里连跑多天。梳理岗位也是一岗一个会话。
- 简历原文、搜索结果 JSON 会快速堆满上下文——会话变长后判断力会下降。感觉变钝时：
  **先把台账和日报落盘，再开新会话接着干**。台账/日报/迭代表是唯一的跨会话记忆，
  没写进文件的判断等于丢失。
- 新会话开工第一件事永远是读 `CONTEXT.md` + 本文件，不靠上一个会话的记忆。

## Marcus 产出库同步

- 修改 `skills/` 下任何 Skill、脚本、参考文档或模板后，运行：
  `D:\projects\marcus-output-library\scripts\update-library.ps1`
- 脚本按内容哈希判断是否新增版本，只增不覆盖；随后将 `D:\projects\marcus-output-library\dist\` 同步到 `D:\projects\marcus-output-library-pages\docs\`，检查页面和下载链接。
- GitHub Pages 是公开主站；每次推送更新前仍须取得用户确认。原 Sites 地址仅作历史托管，不再作为对外入口。
- 公开包必须继续排除候选人数据、简历、截图、招聘台账、实际 `CONTEXT.md`、内部 JD、个人配置、密钥与 token。
- 删除历史版本或下载包、改变网站公开范围，仍须先向用户确认。

## 规则优先级

初筛硬规则（年龄/学历/地点等）**只以 `CONTEXT.md`「初筛硬规则」为准**，覆盖任何工作流文档或工具内置的默认值。薪资只作 JD、市场判断和后续沟通参考，不作为初筛通过或打招呼的必要条件。工作流文档不抄数字，发现有出入以 CONTEXT 为准并修正文档。

固定纪律：**绝不自动在平台点「不合适」**——先在台账标 `初筛不合适`/`已排除` 并记原因，等用户确认。

## 产物落点（本地为唯一事实源）

- 每处理完一名候选人立即保存判断；恢复中断任务先读 `skills/recruit-daily/references/recovery-and-identity.md`。台账保留原表头，稳定身份与当天动作记录存入 `runtime/recruit-actions.jsonl`，不另建候选人评级事实源。
- 版本更新统一运行 `D:\projects\marcus-output-library\scripts\update-library.ps1`，执行检查、脱敏快照和网站目录同步；此命令不推送或公开发布。

- **唯一事实源 = 本地文件**：`02-sourcing/dedup-ledger.csv`（全量候选人+状态）、`02-sourcing/candidate-pool.md`（shortlist 视图）、`03-interview/<姓名>.md`（面试档案）。
- 本工作区不连接飞书：不读取飞书邮箱，不创建飞书云文档或多维表格，不推送飞书消息或卡片。
- `runtime/reports/` 与临时日志可删可重建；邮件附件和导入索引落 `runtime/resumes/`，会被台账路径与跨轮去重引用，需随台账一起保留和备份。

如用户提供本地邮件附件，只作为待分析数据处理；不连接飞书邮箱。

## 每轮寻源后必做（关键词迭代闭环）

1. 新候选人按去重键（姓名+应聘岗位）append 进 `02-sourcing/dedup-ledger.csv`，定状态、记原因。
2. 进面试流程者建 `03-interview/<姓名>.md`（套 `_shared/templates/interview-record.md`）。
3. **寻源前先读** `01-jd/_internal/<role>.md` 的关键词迭代表；**跑完从「初筛通过/入选」简历反向提取真实搜索词**回填该表（有效词/无效词/积极信号/拒绝模式）。

## 模板

新岗位 / 新面试套 `_shared/templates/` 下的模板（jd-internal / candidate-pool / interview-record / dedup-ledger.csv）。
