# 数据格式
HTML中script#seed的JSON包含candidates数组、snapshotId、batchId、removedCandidateIds和migrations。ID唯一稳定。
候选人字段：id,name,role,status,degree,graduation,education[{school,degree,major,period}],summary,experience,tags,verify,remark,gaokaoProvince,gaokaoScore。保留其他旧字段。
原件字段：pdf为base64，thumbnail及previews为真实渲染的data URL，另有filename,pages,libraryId。
操作文件是数组：[{"op":"update","id":"example","fields":{"status":"待复试"}},{"op":"remove","id":"retired"},{"op":"add","candidate":{"id":"new","name":"示例","role":"Android","status":"待初试","education":[]},"pdf_path":"/absolute/resume.pdf"}]。
命令：python scripts/manage_board.py patch --board CURRENT.html --operations operations.json --out CURRENT.html
新建：python scripts/manage_board.py create --manifest manifest.json --out board.html
manifest为包含candidates数组、batchId（8位数字）、snapshotId的对象。添加前先由助手读取简历，脚本不猜测教育资料。
