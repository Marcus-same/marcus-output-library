"""Build a new candidate board or patch its seed without rewriting its UI."""
import argparse, base64, copy, io, json, pathlib, re, uuid

SEED = re.compile(r'(<script\b[^>]*\bid=["\']seed["\'][^>]*>)(.*?)(</script>)', re.S)

def encode(value):
    return json.dumps(value, ensure_ascii=False).replace('<', '\\u003c')

def attach_pdf(candidate, path):
    import pypdfium2 as pdfium
    path = pathlib.Path(path)
    document = pdfium.PdfDocument(str(path))
    candidate.update(filename=path.name, pdf=base64.b64encode(path.read_bytes()).decode(), pages=len(document), previews=[])
    for index, page in enumerate(document):
        image = page.render(scale=1.6).to_pil().convert('RGB')
        image.thumbnail((1200, 1800))
        buffer = io.BytesIO()
        image.save(buffer, format='JPEG', quality=88)
        candidate['previews'].append('data:image/jpeg;base64,' + base64.b64encode(buffer.getvalue()).decode())
        if index == 0:
            image.thumbnail((560, 800))
            buffer = io.BytesIO()
            image.save(buffer, format='JPEG', quality=83)
            candidate['thumbnail'] = 'data:image/jpeg;base64,' + base64.b64encode(buffer.getvalue()).decode()
    document.close()

def validate(seed):
    candidates = seed.get('candidates')
    if not isinstance(candidates, list):
        raise ValueError('candidates must be an array')
    ids = [c.get('id') for c in candidates]
    if any(not isinstance(i, str) or not i for i in ids) or len(ids) != len(set(ids)):
        raise ValueError('Candidate IDs must be unique nonempty strings')
    if set(ids) & set(seed.get('removedCandidateIds', [])):
        raise ValueError('Deleted candidate still present')

def patch(seed, operations):
    seed = copy.deepcopy(seed)
    for operation in operations:
        kind = operation['op']
        lookup = {c['id']: c for c in seed['candidates']}
        if kind == 'add':
            candidate = copy.deepcopy(operation['candidate'])
            if candidate['id'] in lookup or candidate['id'] in seed.get('removedCandidateIds', []):
                raise ValueError('Candidate ID already exists or was removed')
            for key in ['remark', 'gaokaoProvince', 'gaokaoScore', 'gaokaoNote', 'note', 'nextAction', 'nextDate', 'decision', 'salary', 'joinDate', 'updatedAt']:
                candidate.setdefault(key, '')
            for key, value in dict(degree='待确认', graduation='待确认', summary='', experience='', verify='', role='', status='待初试', focus=False, tags=[]).items():
                candidate.setdefault(key, value)
            candidate.setdefault('stage', candidate['status'])
            if operation.get('pdf_path'):
                attach_pdf(candidate, operation['pdf_path'])
            seed['candidates'].append(candidate)
        elif kind == 'remove':
            identifier = operation['id']
            if identifier not in lookup:
                raise ValueError('Candidate not found: ' + identifier)
            seed['candidates'] = [c for c in seed['candidates'] if c['id'] != identifier]
            seed['removedCandidateIds'] = sorted(set(seed.get('removedCandidateIds', []) + [identifier]))
        elif kind == 'update':
            candidate = lookup[operation['id']]
            fields = copy.deepcopy(operation['fields'])
            if 'id' in fields:
                raise ValueError('IDs are immutable')
            if 'status' in fields:
                fields['stage'] = fields['status']
            candidate.update(fields)
            seed.setdefault('migrations', []).append(dict(id='update-' + uuid.uuid4().hex, candidateId=candidate['id'], fields=fields))
        else:
            raise ValueError('Unknown operation: ' + kind)
    validate(seed)
    return seed

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    edit = commands.add_parser('patch')
    edit.add_argument('--board', required=True)
    edit.add_argument('--operations', required=True)
    edit.add_argument('--out', required=True)
    create = commands.add_parser('create')
    create.add_argument('--manifest', required=True)
    create.add_argument('--out', required=True)
    args = parser.parse_args()
    if args.command == 'patch':
        html = pathlib.Path(args.board).read_text(encoding='utf-8')
        match = SEED.search(html)
        if not match:
            raise ValueError('Cannot locate script#seed')
        seed = patch(json.loads(match.group(2)), json.loads(pathlib.Path(args.operations).read_text(encoding='utf-8')))
        html = html[:match.start(2)] + encode(seed) + html[match.end(2):]
    else:
        seed = json.loads(pathlib.Path(args.manifest).read_text(encoding='utf-8'))
        validate(seed)
        seed.setdefault('snapshotId', 'board-' + uuid.uuid4().hex)
        seed.setdefault('reportMode', False)
        batch = seed.get('batchId', '20261119')
        if not re.fullmatch(r'\d{8}', batch):
            raise ValueError('batchId must have eight digits')
        html = (pathlib.Path(__file__).resolve().parent.parent / 'assets/dashboard.html').read_text(encoding='utf-8')
        if html.count('__SEED__') != 1:
            raise ValueError('Template seed placeholder missing or ambiguous')
        html = html.replace('20261119', batch).replace('__SEED__', encode(seed))
    output = pathlib.Path(args.out)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + '.tmp')
    temporary.write_text(html, encoding='utf-8')
    temporary.replace(output)
    print(json.dumps(dict(path=str(output.resolve()), candidates=len(seed['candidates'])), ensure_ascii=False))

if __name__ == '__main__':
    main()
