# 岗位画像到 BOSS 执行配置

当 `CONTEXT.md` 已启用 BOSS 时，岗位梳理不能停在自然语言画像；必须额外生成
`01-jd/_internal/<role>.boss-profile.json`，让 `recruit-daily` 可以直接设置 BOSS 并知道哪些条件仍需逐人核验。

## 三层交接

1. **面板条件 `dimensions`**：只写 BOSS 面板的原始选项文案，供 `apply-profile-filters.mjs` 直接执行。
2. **逐人核验 `manual_checks`**：地点、专业、精确经验年限、命脉技能等平台不能精确表达的标准。
3. **入口策略 `channel_strategy`**：明确普通推荐、精选、定向搜索、最新是否启用；禁止 daily 自行扩入口。

薪资不进入 `dimensions`，只在 `manual_checks.salary_reference` 记录为沟通参考。

## 文件格式

```json
{
  "_schema": "Marcus recruiting skill BOSS handoff v1",
  "profiles": [
    {
      "job_title": "岗位在工作区中的标准名称",
      "boss_job_title": "BOSS 页面显示的岗位名称；未知时为 null",
      "job_id": "已核验的 BOSS jobId；未知时为 null",
      "calibrated_at": "ISO 8601 时间",
      "source": "CONTEXT.md + 对内岗位笔记",
      "status": "ready | needs_boss_binding | needs_user_decision",
      "dimensions": {
        "age_range": "16-35 或 不限",
        "activation": "不限",
        "school": ["211"],
        "school_first_degree_only": true,
        "recent_not_viewed": "不限",
        "gender": "不限",
        "exchange_resume_with_colleague": "不限",
        "experience": ["1-3年", "3-5年"],
        "degree": ["本科", "硕士", "博士"]
      },
      "manual_checks": {
        "location": "逐人核验口径",
        "exact_experience": "逐人核验口径",
        "major": "逐人核验口径或不限",
        "must_have": ["命脉技能"],
        "exclude_if": ["排除信号"],
        "salary_reference": "只作记录与沟通参考"
      },
      "channel_strategy": {
        "recommended": true,
        "featured": false,
        "targeted_search": true,
        "latest": false,
        "other_channels": []
      },
      "search_keywords": ["关键词"],
      "mapping_notes": ["平台近似映射及其人工补核说明"]
    }
  ]
}
```

## 映射规则

- 年龄上限明确、下限未设：BOSS 下限取平台最低可选值，不得自行增加年龄下限。
- 精确经验下限落在区间中：选择所有可能包含合格人的区间，再由 `exact_experience` 逐人核验。
- 第一学历院校是硬门槛：选择院校并设置 `school_first_degree_only=true`；详情仍复核真实本科院校。
- 学历“本科及以上”：选择本科、硕士、博士；后续学历不能替代第一学历门槛。
- 地点、专业、命脉技能、排除信号不能依赖面板完成，必须进入 `manual_checks`。
- 活跃度、近期未看过、同事交换简历若用户未提出限制，默认 `不限`，避免把运营偏好误当人才硬门槛。
- 入口策略必须逐岗确认；某入口为 `false` 时，即使供给不足也不能自动切入。

## 完成闸门

岗位只有同时满足以下条件才算 grill 完成：

- JSON 可解析，且仅含该岗位一个 profile；
- `dimensions` 九项齐全，取值使用 BOSS 原文；
- 平台近似映射都写入 `mapping_notes`，对应的精确规则进入 `manual_checks`；
- 薪资未被写成面板条件或打招呼门槛；
- 四个 BOSS 入口均有明确布尔值；
- 未知的 BOSS 岗位名或 `jobId` 用 `null`，状态为 `needs_boss_binding`，不得猜测；首次进入页面时只做岗位绑定并回写，经核验后改为 `ready`。

