#!/usr/bin/env node

import fs from 'fs';

const file = process.argv[2];
if (!file) {
  console.error('用法: node validate-boss-profile.mjs <role.boss-profile.json>');
  process.exit(2);
}

let root;
try {
  root = JSON.parse(fs.readFileSync(file, 'utf8'));
} catch (error) {
  console.error(`❌ JSON 无法读取: ${error.message}`);
  process.exit(2);
}

const errors = [];
const profiles = root?.profiles;
if (!Array.isArray(profiles) || profiles.length !== 1) {
  errors.push('profiles 必须是只包含当前岗位的一项数组');
}

const p = Array.isArray(profiles) ? profiles[0] : null;
if (p) {
  for (const key of ['job_title', 'calibrated_at', 'source', 'status', 'dimensions', 'manual_checks', 'channel_strategy', 'search_keywords', 'mapping_notes']) {
    if (p[key] === undefined || p[key] === null || p[key] === '') errors.push(`缺少 ${key}`);
  }
  if (!['ready', 'needs_boss_binding', 'needs_user_decision'].includes(p.status)) {
    errors.push('status 必须为 ready / needs_boss_binding / needs_user_decision');
  }
  if (p.status === 'ready' && (!p.boss_job_title || !p.job_id)) {
    errors.push('ready 状态必须包含已核验的 boss_job_title 和 job_id');
  }

  const dims = p.dimensions || {};
  const dimKeys = ['age_range', 'activation', 'school', 'school_first_degree_only', 'recent_not_viewed', 'gender', 'exchange_resume_with_colleague', 'experience', 'degree'];
  for (const key of dimKeys) {
    if (!(key in dims)) errors.push(`dimensions 缺少 ${key}`);
  }
  for (const key of Object.keys(dims)) {
    if (/salary|薪资/i.test(key)) errors.push(`薪资不得进入 dimensions: ${key}`);
  }
  for (const key of ['school', 'experience', 'degree']) {
    if (!Array.isArray(dims[key])) errors.push(`dimensions.${key} 必须是数组`);
  }
  if (typeof dims.school_first_degree_only !== 'boolean') {
    errors.push('dimensions.school_first_degree_only 必须是布尔值');
  }

  const manual = p.manual_checks || {};
  for (const key of ['location', 'exact_experience', 'major', 'must_have', 'exclude_if', 'salary_reference']) {
    if (!(key in manual)) errors.push(`manual_checks 缺少 ${key}`);
  }
  if (!Array.isArray(manual.must_have) || !manual.must_have.length) errors.push('manual_checks.must_have 至少一项');
  if (!Array.isArray(manual.exclude_if)) errors.push('manual_checks.exclude_if 必须是数组');
  if (!String(manual.salary_reference || '').includes('参考')) errors.push('salary_reference 必须明确只作参考');

  const channel = p.channel_strategy || {};
  for (const key of ['recommended', 'featured', 'targeted_search', 'latest']) {
    if (typeof channel[key] !== 'boolean') errors.push(`channel_strategy.${key} 必须是布尔值`);
  }
  if (!Array.isArray(channel.other_channels)) errors.push('channel_strategy.other_channels 必须是数组');
  if (!Array.isArray(p.search_keywords) || !p.search_keywords.length) errors.push('search_keywords 至少一项');
  if (!Array.isArray(p.mapping_notes) || !p.mapping_notes.length) errors.push('mapping_notes 至少一项');
}

if (errors.length) {
  console.error('❌ BOSS 交接配置不完整:');
  errors.forEach((e) => console.error(`- ${e}`));
  process.exit(1);
}

console.log(`✅ BOSS 交接配置有效: ${p.job_title} (${p.status})`);
