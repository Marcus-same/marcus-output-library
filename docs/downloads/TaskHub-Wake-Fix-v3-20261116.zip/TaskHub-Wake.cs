using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

public static class TaskHubWake {
    private static Process parent;
    private static bool pipeMode;
    private static int requestSequence;
    private static int acknowledged;
    private static long retryUntil;
    private static long retryAt;
    private static IntPtr retryWindow;
    private static string captureUri="obsidian://taskhub-capture";
    [STAThread]
    public static int Main(string[] args) {
        try {
            if (args.Length==1 && args[0]=="--self-test") SelfTest();
            else {
                if (args.Length>=2 && args[0]=="--parent") parent=Process.GetProcessById(int.Parse(args[1]));
                pipeMode=Array.IndexOf(args,"--pipe")>=0;
                if (args.Length>=4 && args[2]=="--vault") captureUri+="?vault="+Uri.EscapeDataString(args[3]);
                Run();
            }
            return 0;
        } catch (Exception error) {
            Console.Error.WriteLine("ERROR: " + error.Message);
            MessageBox.Show(error.Message,"TaskHub",MessageBoxButtons.OK,MessageBoxIcon.Error);
            return 1;
        }
    }
    private delegate IntPtr KeyboardHook(int code, IntPtr message, IntPtr data);
    [DllImport("user32.dll", SetLastError=true)]
    private static extern IntPtr SetWindowsHookEx(int type, KeyboardHook callback, IntPtr module, uint thread);
    [DllImport("user32.dll")]
    private static extern bool UnhookWindowsHookEx(IntPtr handle);
    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr handle, int code, IntPtr message, IntPtr data);
    [DllImport("kernel32.dll", CharSet=CharSet.Auto)]
    private static extern IntPtr GetModuleHandle(string name);
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")]
    private static extern bool ShowWindowAsync(IntPtr window, int command);
    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr window);
    [DllImport("user32.dll")]
    private static extern bool AttachThreadInput(uint source, uint target, bool attach);
    [DllImport("kernel32.dll")]
    private static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")]
    private static extern bool BringWindowToTop(IntPtr window);
    private static bool ActivateWindow(IntPtr window) {
        if(window==IntPtr.Zero) return false;
        if(IsIconic(window)) ShowWindowAsync(window,9);
        if(SetForegroundWindow(window) && GetForegroundWindow()==window) return true;
        uint ignored;
        uint current=GetCurrentThreadId();
        uint foreground=GetWindowThreadProcessId(GetForegroundWindow(),out ignored);
        uint target=GetWindowThreadProcessId(window,out ignored);
        bool attachedForeground=false;
        bool attachedTarget=false;
        try {
            if(foreground!=0 && foreground!=current) attachedForeground=AttachThreadInput(current,foreground,true);
            if(target!=0 && target!=current && target!=foreground) attachedTarget=AttachThreadInput(current,target,true);
            BringWindowToTop(window);
            SetForegroundWindow(window);
            return GetForegroundWindow()==window;
        } finally {
            if(attachedTarget) AttachThreadInput(current,target,false);
            if(attachedForeground) AttachThreadInput(current,foreground,false);
        }
    }
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int key);

    private sealed class DoubleTap {
        private int held;
        private long down;
        private long last = -1;
        public bool Input(int key, bool pressed, bool modified, long now) {
            bool control = key == 0xA2 || key == 0xA3 || key == 0x11;
            if ((!control && pressed) || modified) { held=0; last=-1; return false; }
            if (!control) return false;
            if (pressed) {
                if (held == key) return false;
                if (held != 0) { held=0; last=-1; return false; }
                held=key;
                down=now;
                return false;
            }
            if (held != key || now-down > 300) { held=0; last=-1; return false; }
            held=0;
            if (last >= 0 && now-last <= 400) { last=-1; return true; }
            last=now;
            return false;
        }
    }

    private static readonly Stopwatch Clock=Stopwatch.StartNew();
    private static readonly DoubleTap Gesture=new DoubleTap();
    private static readonly KeyboardHook Callback=OnKey;
    private static readonly int[] Modifiers={0x10,0x12,0x5B,0x5C};
    private static IntPtr hook;
    private static bool pending;

    private static IntPtr OnKey(int code, IntPtr message, IntPtr data) {
        int msg=message.ToInt32();
        if (code>=0 && (msg==0x100 || msg==0x101 || msg==0x104 || msg==0x105)) {
            int flags=Marshal.ReadInt32(data,8);
            if ((flags & 0x10)==0) {
                bool modified=false;
                foreach (int key in Modifiers) modified |= (GetAsyncKeyState(key) & 0x8000)!=0;
                if (Gesture.Input(Marshal.ReadInt32(data),msg==0x100 || msg==0x104,modified,Clock.ElapsedMilliseconds))
                    pending=true;
            }
        }
        return CallNextHookEx(hook,code,message,data);
    }

    private static void Wake() {
        uint foreground;
        GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
        Process[] apps=Process.GetProcessesByName("Obsidian");
        IntPtr window=IntPtr.Zero;
        bool alreadyFocused=false;
        foreach (Process app in apps) {
            using (app) {
                if (window==IntPtr.Zero) window=app.MainWindowHandle;
                alreadyFocused |= app.Id == foreground;
            }
        }
        // The renderer handles Ctrl twice when Obsidian already has focus.
        if (alreadyFocused) return;
        if (window!=IntPtr.Zero) {
            if (IsIconic(window)) ShowWindowAsync(window,9);
            ActivateWindow(window);
        }
        // Tray mode may have no main window handle until Obsidian receives the URI.
        retryWindow=window;
        retryUntil=Clock.ElapsedMilliseconds+900;
        retryAt=Clock.ElapsedMilliseconds+100;
        int request=Interlocked.Increment(ref requestSequence);
        if (pipeMode) {
            Console.WriteLine("CAPTURE:"+request);
            Console.Out.Flush();
        }
        ThreadPool.QueueUserWorkItem(delegate {
            if (pipeMode) Thread.Sleep(600);
            if (pipeMode && !NeedsUri(
                Interlocked.CompareExchange(ref acknowledged,0,0)>=request,
                Interlocked.CompareExchange(ref requestSequence,0,0)!=request,
                window!=IntPtr.Zero && GetForegroundWindow()==window)) return;
            try { Process.Start(new ProcessStartInfo(captureUri) { UseShellExecute=true }); }
            catch (Exception error) { Console.Error.WriteLine("ERROR: "+error.Message); }
        });
        Console.WriteLine("WAKE: capture request sent");
    }

    public static void Run() {
        if (pipeMode) {
            var reader=new Thread(delegate() {
                try {
                    string line;
                    while ((line=Console.ReadLine())!=null) {
                        int value;
                        if (line.StartsWith("ACK:") && int.TryParse(line.Substring(4),out value))
                            Interlocked.Exchange(ref acknowledged,value);
                    }
                } catch (System.IO.IOException) { }
            });
            reader.IsBackground=true;
            reader.Start();
        }
        bool created;
        using (var singleton=new Mutex(true,@"Local\TaskHubWake",out created)) {
            if (!created) { Console.Error.WriteLine("CONFLICT: old TaskHub helper running"); Environment.Exit(2); return; }
            using (var icon=new NotifyIcon())
            using (var menu=new ContextMenuStrip())
            using (var timer=new System.Windows.Forms.Timer()) {
                icon.Icon=System.Drawing.SystemIcons.Application;
                icon.Text="TaskHub · Ctrl x2";
                menu.Items.Add("Test capture",null,delegate { TryWake(icon); });
                menu.Items.Add("Exit TaskHub",null,delegate { Application.ExitThread(); });
                icon.ContextMenuStrip=menu;
                icon.Visible=true;
                timer.Interval=30;
                timer.Tick+=delegate {
                    if (parent!=null && parent.HasExited) { Application.ExitThread(); return; }
                    if (retryWindow!=IntPtr.Zero && Clock.ElapsedMilliseconds>=retryAt) {
                        if (GetForegroundWindow()==retryWindow || Clock.ElapsedMilliseconds>retryUntil) retryWindow=IntPtr.Zero;
                        else { ActivateWindow(retryWindow); retryAt=Clock.ElapsedMilliseconds+200; }
                    }
                    if (!pending) return;
                    pending=false;
                    Console.WriteLine("KEY: double Ctrl received");
                    TryWake(icon);
                };
                hook=SetWindowsHookEx(13,Callback,GetModuleHandle(null),0);
                if (hook==IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
                try { Console.WriteLine("READY: global Ctrl x2"); timer.Start(); Application.Run(); }
                finally { UnhookWindowsHookEx(hook); }
            }
        }
    }

    private static void TryWake(NotifyIcon icon) {
        try { Wake(); }
        catch (Exception error) { Console.Error.WriteLine("ERROR: " + error.Message); icon.ShowBalloonTip(4000,"TaskHub",error.Message,ToolTipIcon.Warning); }
    }

    private static bool NeedsUri(bool accepted, bool superseded, bool foreground) {
        return !superseded && (!accepted || !foreground);
    }

    public static void SelfTest() {
        if (!NeedsUri(true,false,false)) throw new Exception("Background ACK must still activate Obsidian.");
        if (NeedsUri(true,false,true)) throw new Exception("Foreground ACK should not reopen URI.");
        if (NeedsUri(false,true,false)) throw new Exception("Superseded wake should not activate.");
        if (!NeedsUri(false,false,true)) throw new Exception("Missing ACK requires URI fallback.");
        var tap=new DoubleTap();
        if (tap.Input(0xA2,true,false,0) || tap.Input(0xA2,false,false,50) ||
            tap.Input(0xA3,true,false,100) || !tap.Input(0xA3,false,false,150))
            throw new Exception("Double Ctrl recognition failed.");
        tap.Input(0xA2,true,false,200);
        tap.Input(0x43,true,false,220);
        tap.Input(0xA2,false,false,240);
        tap.Input(0xA2,true,false,270);
        if (tap.Input(0xA2,false,false,300)) throw new Exception("Ctrl+C triggered capture.");
        tap.Input(0xA2,true,false,350);
        if (tap.Input(0xA2,false,false,700)) throw new Exception("Long press triggered capture.");
        Console.WriteLine("Double Ctrl checks passed.");
    }
}

