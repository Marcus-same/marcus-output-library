$ErrorActionPreference = 'Stop'
try {
    $config = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $env:APPDATA 'obsidian\obsidian.json') | ConvertFrom-Json
    $targets = @($config.vaults.psobject.Properties.Value | ForEach-Object { Join-Path $_.path '.obsidian\plugins\taskhub' } | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'main.js') })
    if ($targets.Count -ne 1) { throw 'Expected one installed TaskHub. No files changed.' }
    $target = $targets[0]
    $expected = 'B66334EB8FF495FEDAA93312235D87EB210329AD60C668CE33F3D7B4F5134105'
    $current = (Get-FileHash -LiteralPath (Join-Path $target 'main.js')).Hash
    $patched='ECDDD084BA7AF0ADC62B464E4F6F7ABB1F34D98EE709436119DF1FF62E71100F'
    $helperCurrent=(Get-FileHash -LiteralPath (Join-Path $target 'TaskHub-Wake.exe')).Hash
    $helperNew=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'TaskHub-Wake.exe')).Hash
    if ($current -eq $patched -and $helperCurrent -eq $helperNew) { Write-Host 'Patch already installed.'; exit 0 }
    if ($current -ne $expected -and $current -ne $patched) { throw 'TaskHub has changed since this patch was made. Installation stopped to protect your newer version.' }
    if (Get-Process Obsidian,TaskHub-Wake -ErrorAction SilentlyContinue) { throw 'Please fully quit Obsidian and TaskHub tray helper, then run Install.cmd again.' }
    $backup = Join-Path $target ('wake-backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    New-Item -ItemType Directory -Path $backup | Out-Null
    foreach ($name in @('main.js','TaskHub-Wake.exe')) { Copy-Item -LiteralPath (Join-Path $target $name) -Destination $backup }
    try {
        foreach ($name in @('main.js','TaskHub-Wake.exe')) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $target $name) -Force }
    } catch {
        foreach ($name in @('main.js','TaskHub-Wake.exe')) { Copy-Item -LiteralPath (Join-Path $backup $name) -Destination (Join-Path $target $name) -Force }
        throw
    }
    Write-Host 'TaskHub wake patch installed. Open Obsidian, minimize it, then double-tap Ctrl.' -ForegroundColor Green
    Write-Host ('Backup: ' + $backup)
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
