"use strict";
const core = (() => {
const priorities = [
    "",
    "🔺",
    "⏫",
    "🔼",
    "🔽",
    "⏬"
];
const scopes = [
    "今天",
    "逾期",
    "收集箱",
    "项目",
    "全部",
    "已完成"
];
const checkbox = /^(\s*(?:[-+*]|\d+[.)])\s+\[)([^\]\r\n])(\]\s+)(.+)$/u;
const tag = /(^|\s)#(分类|category|cat|项目|project)\/([\p{L}\p{M}\p{N}_/-]+)/giu;
const flatCategory = /(^|\s)#(招聘|工作|人事|行政|财务|学习|个人|生活|收集箱|收件箱|未分类|inbox)(?=\s|$)/giu;
const symbols = "(?:🔺|⏫|🔼|🔽|⏬)";
const dateField = /(?:^|\s)([📅📆🗓]️?\s*(\d{4}-\d{2}-\d{2})|\[due::\s*(\d{4}-\d{2}-\d{2})\s*\])/gu;
const markers = new RegExp("(^|\\s)(" + symbols + "|[📅📆🗓🛫⏳➕✅❌]️?\\s*\\d{4}-\\d{2}-\\d{2}|🔁|🆔|⛔|🏁|\\[(?:taskhub-time|taskhub-repeat|taskhub-block|taskhub-board|due|priority|scheduled|start|created|completion|done|cancelled|repeat|recurrence|id|dependsOn)::|<!-- taskhub-id:|\\^[\\w-]+\\s*$)", "u");
const inlinePriorities = {
    highest: "🔺",
    high: "⏫",
    medium: "🔼",
    low: "🔽",
    lowest: "⏬"
};
const idPattern = /<!-- taskhub-id:([a-z0-9-]{8,80}) -->/g;
const blockId = /(?:^|\s)\^taskhub-([a-z0-9-]{8,80})\s*$/;
function localDay(d = new Date()) {
    return [
        d.getFullYear(),
        d.getMonth() + 1,
        d.getDate()
    ].map((v)=>String(v).padStart(2, "0")).join("-");
}
function validDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const d = new Date(value + "T00:00:00Z");
    return Number.isFinite(d.getTime()) && d.toISOString().slice(0, 10) === value;
}
function emailSubject(text) {
    const headers = text.replace(/^\uFEFF/, "").split(/\r?\n\r?\n/, 1)[0].replace(/\r?\n[ \t]+/g, " ");
    const subject = headers.match(/^subject:[ \t]*(.*)$/im)?.[1];
    if (!subject) throw new Error("邮件缺少 Subject 标题。请选择导出的 .eml 邮件文件。");
    const decoded = subject.replace(/(\?=)\s+(?==\?)/g, "$1").replace(/=\?([^?]+)\?([bq])\?([^?]*)\?=/gi, (word, charset, encoding, data)=>{
        try {
            const bytes = encoding.toLowerCase() === "b" ? atob(data) : data.replace(/_/g, " ").replace(/=([0-9a-f]{2})/gi, (_match, hex)=>String.fromCharCode(parseInt(hex, 16)));
            return new TextDecoder(charset, {
                fatal: true
            }).decode(Uint8Array.from(bytes, (c)=>c.charCodeAt(0)));
        } catch  {
            return word;
        }
    });
    const result = decoded.replace(/[\r\n\0]/g, " ").trim().slice(0, 500);
    if (!result) throw new Error("邮件主题为空");
    return result;
}
const repeatRules = [
    "daily",
    "mwf",
    "month-end"
];
function validRepeatRule(rule) {
    if (repeatRules.some((value)=>value === rule)) return true;
    if (/^monthly:(?:[1-9]|[12]\d|3[01])$/.test(rule)) return true;
    if (!/^weekly:[0-6](?:,[0-6]){0,6}$/.test(rule)) return false;
    const days = rule.slice(7).split(",");
    return new Set(days).size === days.length;
}
function nextRepeatDate(rule, after) {
    if (!validDate(after)) throw new Error("重复任务需要有效的截止日期");
    if (!validRepeatRule(rule)) throw new Error("未知重复规则");
    const date = new Date(after + "T12:00:00");
    if (rule === "daily") date.setDate(date.getDate() + 1);
    else if (rule === "mwf" || rule.startsWith("weekly:")) {
        const weekdays = rule === "mwf" ? [
            1,
            3,
            5
        ] : rule.slice(7).split(",").map(Number);
        do {
            date.setDate(date.getDate() + 1);
        }while (!weekdays.includes(date.getDay()))
    } else if (rule.startsWith("monthly:")) {
        const day = Number(rule.slice(8));
        for(let offset = 0; offset <= 12; offset++){
            const candidate = new Date(date.getFullYear(), date.getMonth() + offset, day, 12);
            if (candidate.getDate() === day && candidate > date) return localDay(candidate);
        }
        throw new Error("未找到下一次月度日期");
    } else if (rule === "month-end") {
        const end = (offset)=>{
            const result = new Date(date.getFullYear(), date.getMonth() + offset + 1, 0, 12);
            while([
                0,
                6
            ].includes(result.getDay()))result.setDate(result.getDate() - 1);
            return result;
        };
        return localDay(end(0)) > after ? localDay(end(0)) : localDay(end(1));
    }
    return localDay(date);
}
function taskField(task, key) {
    return task.metadata.match(new RegExp("\\[taskhub-" + key + "::\\s*([^\\]\\r\\n]+)\\]"))?.[1].trim() ?? "";
}
function setTaskField(task, key, value) {
    const raw = task.raw.replace(new RegExp("[ \\t]*\\[taskhub-" + key + "::[^\\]\\r\\n]*\\]", "g"), "");
    if (!value) return raw;
    const tail = raw.match(/\s+\^[\w-]+\s*$/)?.index ?? raw.length;
    return raw.slice(0, tail) + " [taskhub-" + key + ":: " + value + "]" + raw.slice(tail);
}
function parseQuickTitle(value, now = new Date()) {
    const match = value.trim().match(/^(今天|明天|后天|(?:本|下)?周[一二三四五六日天]|\d{4}-\d{2}-\d{2})\s*(.*)$/u);
    if (!match) return null;
    const [, dateWord, rest] = match;
    const date = new Date(now);
    if (/^\d/.test(dateWord) && !validDate(dateWord)) return null;
    if (dateWord.endsWith("天") && [
        "今天",
        "明天",
        "后天"
    ].includes(dateWord)) {
        date.setDate(date.getDate() + [
            "今天",
            "明天",
            "后天"
        ].indexOf(dateWord));
    } else if (dateWord.includes("周")) {
        const weekday = "一二三四五六日".indexOf(dateWord.at(-1).replace("天", "日"));
        const offset = weekday - (date.getDay() + 6) % 7;
        const weeks = dateWord.startsWith("下") || !dateWord.startsWith("本") && offset < 0 ? 7 : 0;
        date.setDate(date.getDate() + offset + weeks);
    }
    const due = /^\d/.test(dateWord) ? dateWord : localDay(date);
    let title = rest.trim(), time = "";
    const clock = title.match(/^(上午|下午|晚上|中午|早上)?\s*(\d{1,2})(?::(\d{2})|[点时](半|\d{1,2}分)?)(?!\d)\s*/u);
    if (clock) {
        let hour = Number(clock[2]);
        const minute = clock[4] === "半" ? 30 : Number(clock[3] ?? clock[4]?.slice(0, -1) ?? 0);
        if (minute > 59 || hour > 23 || clock[1] && (hour < 1 || hour > 12)) return null;
        if ([
            "下午",
            "晚上",
            "中午"
        ].includes(clock[1]) && hour < 12) hour += 12;
        if ([
            "上午",
            "早上"
        ].includes(clock[1]) && hour === 12) hour = 0;
        time = String(hour).padStart(2, "0") + ":" + String(minute).padStart(2, "0");
        title = title.slice(clock[0].length).trim();
    }
    return title ? {
        title,
        due,
        time
    } : null;
}
function tagsIn(text) {
    return Array.from(text.matchAll(tag));
}
function clean(text) {
    return text.replace(/\s{2,}/g, " ").trim();
}
function parseLine(raw, path, line) {
    const match = raw.match(checkbox);
    if (!match) return null;
    const [, prefix, status, , body] = match;
    const cut = body.search(markers);
    const leading = cut < 0 ? body : body.slice(0, cut);
    const metadata = cut < 0 ? "" : body.slice(cut).trim();
    const tags = tagsIn(body);
    const namespacedCategory = tags.find((t)=>/^(分类|category|cat)$/i.test(t[2]))?.[3];
    const flat = namespacedCategory ? undefined : Array.from(body.matchAll(flatCategory))[0]?.[2];
    const category = namespacedCategory ?? flat ?? "";
    const project = tags.find((t)=>/^(项目|project)$/i.test(t[2]))?.[3] ?? "";
    const date = Array.from(body.matchAll(dateField))[0];
    const dateValue = date?.[2] ?? date?.[3] ?? "";
    const priority = metadata.match(new RegExp("(?:^|\\s)(" + symbols + ")(?=\\s|$)", "u"))?.[1] ?? inlinePriorities[metadata.match(/\[priority::\s*(\w+)\s*\]/i)?.[1]?.toLowerCase() ?? ""] ?? "";
    const title = leading.replace(tag, "$1").replace(flatCategory, (full, space, name)=>name === category ? space : full).trim();
    if (!title) return null;
    return {
        path,
        line,
        raw,
        prefix,
        status,
        body,
        title,
        metadata,
        category,
        project,
        due: validDate(dateValue) ? dateValue : "",
        priority,
        time: body.match(/\[taskhub-time::\s*((?:[01]\d|2[0-3]):[0-5]\d)\s*\]/)?.[1] ?? "",
        ids: [
            ...Array.from(body.matchAll(idPattern), (m)=>m[1]),
            body.match(blockId)?.[1]
        ].filter((v)=>!!v),
        recurring: /🔁|\[(?:repeat|recurrence)::/iu.test(metadata)
    };
}
function parseNote(text, path) {
    const tasks = [];
    let fence = "";
    let comment = false;
    let frontmatter = false;
    text.split(/\r?\n/).forEach((line, i)=>{
        if (i === 0 && /^\uFEFF?---\s*$/.test(line)) {
            frontmatter = true;
            return;
        }
        if (frontmatter) {
            if (/^(---|\.\.\.)\s*$/.test(line)) frontmatter = false;
            return;
        }
        if (comment) {
            if (line.includes("-->")) comment = false;
            return;
        }
        const delimiter = line.match(/^\s{0,3}(\x60{3,}|~{3,})(.*)$/);
        if (fence) {
            if (delimiter && delimiter[1][0] === fence[0] && delimiter[1].length >= fence.length && !delimiter[2].trim()) fence = "";
            return;
        }
        if (delimiter) {
            fence = delimiter[1];
            return;
        }
        if (/^\s*<!--/.test(line)) {
            comment = !line.includes("-->");
            return;
        }
        const task = parseLine(line, path, i);
        if (task) tasks.push(task);
    });
    return tasks;
}
function draftOf(task) {
    return {
        title: task?.title ?? "",
        category: task?.category ?? "",
        project: task?.project ?? "",
        priority: task?.priority ?? "",
        due: task?.due ?? "",
        time: task?.time ?? ""
    };
}
function validateDraft(draft) {
    const value = {
        ...draft,
        time: draft.time ?? "",
        title: draft.title.trim(),
        category: draft.category.trim().replace(/ +/g, "_"),
        project: draft.project.trim().replace(/ +/g, "_")
    };
    if (!value.title || /[\r\n\0]/.test(value.title) || value.title.length > 1000) throw new Error("请输入 1–1000 字的单行任务内容。");
    for (const field of [
        value.category,
        value.project
    ]){
        if (field && (field.length > 100 || !/^[\p{L}\p{M}\p{N}_-]+(?:\/[\p{L}\p{M}\p{N}_-]+)*$/u.test(field) || !/[\p{L}_-]/u.test(field))) throw new Error("分类和项目需使用有效的标签名称。");
    }
    if (!priorities.some((p)=>p === value.priority)) throw new Error("优先级无效。");
    if (value.due && !validDate(value.due)) throw new Error("截止日期无效。");
    if (value.time && (!value.due || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value.time))) throw new Error("请先选择截止日期，再设置有效时间（00:00–23:59）。");
    return value;
}
function safePath(value) {
    const parts = value.trim().replace(/\\/g, "/").replace(/\/+$/, "").split("/");
    if (parts.some((p)=>!p || p === "." || p === ".." || /[:*?"<>|\x00-\x1F]/.test(p) || p.startsWith(".") || /[. ]$/.test(p) || /^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(p))) throw new Error("请输入库内相对路径。");
    return parts.join("/");
}
function tagValue(field, value, source) {
    const pattern = field === "category" ? /^(分类|category|cat)$/i : /^(项目|project)$/i;
    const namespace = source && tagsIn(source.body).find((m)=>pattern.test(m[2]))?.[2];
    return value ? "#" + (namespace || (field === "category" ? "分类" : "项目")) + "/" + value : "";
}
function renderLine(draft, globalTag, old, id) {
    const d = validateDraft(draft);
    if (old && Object.keys(d).every((k)=>d[k] === old[k])) return old.raw;
    if (old) {
        const tags = tagsIn(old.body);
        if (tags.filter((t)=>/^(分类|category|cat)$/i.test(t[2])).length > 1 || tags.filter((t)=>/^(项目|project)$/i.test(t[2])).length > 1) throw new Error("此任务含多个分类或项目标签，请在原笔记编辑以保留全部标签。");
    }
    let title = d.title;
    if (!old && globalTag && !title.split(/\s+/).includes(globalTag)) title += " " + globalTag;
    let metadata = old?.metadata ?? "";
    metadata = metadata.replace(tag, "$1");
    const oldFlat = old?.category;
    if (oldFlat) metadata = metadata.replace(flatCategory, (full, space, name)=>name === oldFlat ? space : full);
    const legacy = d.category && Array.from((" #" + d.category).matchAll(flatCategory)).length && !title.split(/\s+/).includes("#" + d.category) ? "#" + d.category : "";
    if (d.due !== old?.due) metadata = metadata.replace(dateField, " ");
    if (d.priority !== old?.priority) metadata = metadata.replace(new RegExp("(^|\\s)(" + symbols + "(?=\\s|$)|\\[priority::\\s*\\w+\\s*\\])", "gu"), "$1");
    if (d.time !== (old?.time ?? "")) metadata = metadata.replace(/\[taskhub-time::[^\]]*\]/g, "");
    const block = metadata.match(/(?:^|\s)(\^[\w-]+)\s*$/)?.[1] ?? "";
    if (block) metadata = metadata.trimEnd().slice(0, -block.length);
    return [
        old ? old.prefix + old.status + "]" : "- [ ]",
        title,
        tagValue("category", d.category, old),
        legacy,
        tagValue("project", d.project, old),
        d.priority !== old?.priority ? d.priority : "",
        d.due && d.due !== old?.due ? "📅 " + d.due : "",
        d.time && d.time !== (old?.time ?? "") ? "[taskhub-time:: " + d.time + "]" : "",
        metadata.trim(),
        id ? "^taskhub-" + id : block
    ].filter(Boolean).join(" ");
}
function appendLine(text, line) {
    const eol = text.includes("\r\n") ? "\r\n" : "\n";
    return text + (text.endsWith(eol + eol) || !text ? "" : text.endsWith(eol) ? eol : eol + eol) + line + eol;
}
function replaceLine(text, target, replacement) {
    const rows = text.split(/(\r?\n)/);
    const matches = parseNote(text, target.path).filter((t)=>t.raw === target.raw);
    if (matches.length !== 1) throw new Error("任务原文已变更或有相同记录，请刷新后在原笔记检查。");
    rows[matches[0].line * 2] = replacement;
    return rows.join("");
}
function deleteTaskLine(text, target) {
    const matches = parseNote(text, target.path).filter((task)=>task.raw === target.raw);
    if (matches.length !== 1) throw new Error("任务原文已变更或有相同记录，请刷新后重试。");
    const rows = text.split(/(\r?\n)/);
    const index = matches[0].line * 2;
    const indentation = (line)=>(line.match(/^[ \t]*/)?.[0] ?? "").replace(/\t/g, "    ").length;
    for(let next = index + 2; next < rows.length; next += 2){
        if (!rows[next].trim()) continue;
        if (indentation(rows[next]) > indentation(rows[index])) throw new Error("该任务下有子任务或缩进正文，请先在原笔记处理后再删除。");
        break;
    }
    rows.splice(index, 2);
    return rows.join("");
}
function finished(task) {
    return /[xX]/.test(task.status) || /(?:^|\s)(?:❌\s*\d{4}-\d{2}-\d{2}|\[cancelled::\s*\d{4}-\d{2}-\d{2}\s*\])/u.test(task.metadata);
}
function completionStamp(task) {
    const day = task.metadata.match(/✅\s*(\d{4}-\d{2}-\d{2})|\[(?:completion|done)::\s*(\d{4}-\d{2}-\d{2})\s*\]/u);
    const date = day?.[1] ?? day?.[2];
    if (!date) return "";
    const time = taskField(task, "completed-time");
    return /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time) ? date + " " + time : date;
}
function completionLine(task, today, time = "") {
    if (task.recurring || ![
        " ",
        "x",
        "X"
    ].includes(task.status) || /❌|\[cancelled::/u.test(task.metadata)) throw new Error("请在原笔记通过 Tasks 修改循环任务或自定义状态。");
    const body = task.body.replace(/(?:^|\s)(?:✅\s*\d{4}-\d{2}-\d{2}|\[(?:completion|done)::\s*\d{4}-\d{2}-\d{2}\s*\]|\[taskhub-completed-time::[^\]\r\n]*\])/gu, "");
    const suffix = task.raw.slice(task.prefix.length + 2, task.raw.length - task.body.length);
    if (finished(task)) return task.prefix + " ]" + suffix + body;
    const tail = body.match(/\s+(?=<!-- taskhub-id:|\^[\w-]+\s*$)/)?.index ?? body.length;
    const stamp = time ? " [taskhub-completed-time:: " + time + "]" : "";
    return task.prefix + "x]" + suffix + body.slice(0, tail) + " ✅ " + today + stamp + body.slice(tail);
}
function key(text) {
    return clean(text.normalize("NFKC")).toLowerCase();
}
function isDuplicate(tasks, draft, globalTag, exclude) {
    const titleKey = (title)=>key(title.split(/\s+/).filter((t)=>!globalTag || t !== globalTag).join(" "));
    return tasks.some((t)=>!finished(t) && !(exclude && t.path === exclude.path && t.line === exclude.line) && titleKey(t.title) === titleKey(draft.title) && key(t.category) === key(draft.category) && key(t.project) === key(draft.project) && t.due === draft.due && (t.time ?? "") === (draft.time ?? ""));
}
function filterTasks(tasks, query, today, nowTime = "") {
    return tasks.filter((t)=>{
        const scope = query.scope ?? "全部";
        if (scope === "已完成" ? !finished(t) : finished(t)) return false;
        if (scope === "今天" && t.due !== today) return false;
        if (scope === "逾期" && (!t.due || t.due > today || t.due === today && (!t.time || t.time >= nowTime))) return false;
        if (scope === "收集箱" && (t.project || t.category && !/^(inbox|收集箱|收件箱|未分类)$/i.test(t.category))) return false;
        if (scope === "项目" && !t.project) return false;
        return (!query.category || key(t.category) === key(query.category)) && (!query.project || key(t.project) === key(query.project)) && (!query.priority || (query.priority === "none" ? !t.priority : t.priority === query.priority)) && (!query.search || key(t.body).includes(key(query.search)) || completionStamp(t).includes(key(query.search).trim()));
    }).sort((a, b)=>(query.scope === "已完成" ? completionStamp(b).localeCompare(completionStamp(a)) : 0) || (a.due || "9999").localeCompare(b.due || "9999") || (a.time || "23:59").localeCompare(b.time || "23:59") || [
            "🔺",
            "⏫",
            "🔼",
            "",
            "🔽",
            "⏬"
        ].indexOf(a.priority) - [
            "🔺",
            "⏫",
            "🔼",
            "",
            "🔽",
            "⏬"
        ].indexOf(b.priority));
}
function parseQuery(source) {
    const q = {};
    for (const row of source.split(/\r?\n/)){
        if (!row.trim()) continue;
        const m = row.match(/^\s*(scope|category|project|priority|search)\s*:\s*(.*?)\s*$/);
        if (!m) throw new Error("不支持的查询条件：" + row);
        if (m[1] === "scope" && !scopes.includes(m[2])) throw new Error("未知任务视图：" + m[2]);
        if (m[1] === "priority" && m[2] !== "none" && !priorities.some((p)=>p === m[2])) throw new Error("未知优先级：" + m[2]);
        Object.assign(q, {
            [m[1]]: m[2]
        });
    }
    return q;
}
function parseCapture(text) {
    if (text.length > 16000) throw new Error("录入数据太长。");
    const raw = JSON.parse(text.replace(/^\uFEFF/, ""));
    if (!raw || raw.version !== 1 || typeof raw.id !== "string" || !/^[a-z0-9-]{8,80}$/.test(raw.id) || typeof raw.source !== "string" || !raw.task || typeof raw.task.title !== "string") throw new Error("录入数据格式无效。");
    const fields = {
        title: raw.task.title,
        category: raw.task.category ?? "",
        project: raw.task.project ?? "",
        due: raw.task.due ?? "",
        priority: raw.task.priority ?? "",
        time: raw.task.time ?? ""
    };
    if (Object.values(fields).some((v)=>typeof v !== "string")) throw new Error("录入字段必须为文本。");
    return {
        version: 1,
        id: raw.id,
        source: raw.source,
        task: validateDraft(fields)
    };
}

return {priorities,scopes,localDay,validDate,emailSubject,repeatRules,validRepeatRule,nextRepeatDate,taskField,setTaskField,parseQuickTitle,parseLine,parseNote,draftOf,validateDraft,safePath,renderLine,appendLine,replaceLine,deleteTaskLine,finished,completionStamp,completionLine,isDuplicate,filterTasks,parseQuery,parseCapture};
})();
const { ItemView, MarkdownRenderChild, Modal, Notice, Plugin, PluginSettingTab, Setting, TFile, TFolder, WorkspaceLeaf } = require("obsidian");
const { appendLine, completionLine, completionStamp, draftOf, filterTasks, finished, isDuplicate, localDay, parseCapture, parseQuickTitle, parseNote, parseQuery, priorities, renderLine, replaceLine, safePath, scopes, validateDraft, nextRepeatDate, validRepeatRule, taskField, setTaskField, validDate, emailSubject, deleteTaskLine } = core;
const VIEW = "taskhub-workbench";
const defaults = {
    folder: "00-任务中枢/待办库",
    tag: "#task",
    queue: "00-任务中枢/TaskHub-录入队列",
    backups: "00-任务中枢/TaskHub-备份",
    autoImport: false,
    linkedFolders: "01-Daily\n06-工作",
    reminders: false,
    promoteTomorrow: false
};
const priorityLabels = [
    "普通",
    "最高",
    "高",
    "中",
    "低",
    "最低"
];
function report(error) {
    new Notice("TaskHub · " + (error instanceof Error ? error.message : String(error)), 7000);
}
function addOptions(select, values, value) {
    for (const [id, label] of values)select.createEl("option", {
        value: id,
        text: label
    });
    select.value = value;
}
function priorityOptions(normal) {
    return priorities.map((p, i)=>[
            p,
            i === 0 ? normal : p + " " + priorityLabels[i]
        ]);
}
function clockTime(d = new Date()) {
    return String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0");
}
function under(path, folder) {
    return path.startsWith(folder + "/");
}
class TaskHub extends Plugin {
    settings = {
        ...defaults
    };
    changes = new Set();
    pending = Promise.resolve();
    timer;
    day = localDay();
    reminderKeys = new Set();
    checkingReminders = false;
    alive = true;
    hotkeyStatus = "全局快捷键尚未启动";
    async onload() {
        const saved = await this.loadData();
        if (saved) {
            for (const key of [
                "folder",
                "queue",
                "backups",
                "tag",
                "linkedFolders"
            ])if (typeof saved[key] === "string") this.settings[key] = saved[key];
            this.settings.autoImport = saved.autoImport === true;
            this.settings.reminders = saved.reminders === true;
            this.settings.promoteTomorrow = saved.promoteTomorrow === true;
        }
        this.registerView(VIEW, (leaf)=>new Workbench(leaf, this));
        this.addRibbonIcon("list-todo", "打开 TaskHub", ()=>void this.openView().catch(report));
        this.addCommand({
            id: "capture",
            name: "快捷录入任务",
            callback: ()=>new TaskEditor(this).open()
        });
        this.registerDoubleControl();
        this.startWindowsHotkey();
        this.addCommand({
            id: "global-hotkey-status",
            name: "查看全局快捷键状态",
            callback: ()=>new Notice(this.hotkeyStatus, 10000)
        });
        this.registerObsidianProtocolHandler("taskhub-capture", ()=>{
            if (!document.querySelector(".modal-container")) new TaskEditor(this).open();
        });
        this.registerObsidianProtocolHandler("taskhub-web", (params)=>{
            if (document.querySelector(".modal-container")) return;
            try {
                const url = new URL(params.url ?? "");
                if (![
                    "https:",
                    "http:"
                ].includes(url.protocol) || url.username || url.password || url.href.length > 700) return;
                const title = (params.title ?? "").replace(/[\r\n\0]/g, " ").trim().slice(0, 220);
                new TaskEditor(this, undefined, {
                    title: (title || "阅读网页") + " " + url.href
                }).open();
            } catch  {
                new Notice("网页地址无效");
            }
        });
        this.addCommand({
            id: "workbench",
            name: "打开任务工作台",
            callback: ()=>void this.openView().catch(report)
        });
        this.addCommand({
            id: "weekly-review",
            name: "开始每周回顾",
            callback: ()=>new WeeklyReview(this).open()
        });
        this.addCommand({
            id: "import-email",
            name: "从邮件文件录入任务",
            callback: ()=>new EmailCapture(this).open()
        });
        this.addCommand({
            id: "toggle-reminders",
            name: "切换到期提醒",
            callback: ()=>void this.updateSettings({
                    ...this.settings,
                    reminders: !this.settings.reminders
                }).then(()=>new Notice(this.settings.reminders ? "到期提醒已开启" : "到期提醒已关闭")).catch(report)
        });
        this.addCommand({
            id: "backup",
            name: "创建任务库备份",
            callback: ()=>void this.backup().then((p)=>new Notice("备份已保存 · " + p)).catch(report)
        });
        this.addCommand({
            id: "migrate",
            name: "接管旧版任务库",
            callback: ()=>new Migration(this).open()
        });
        this.addCommand({
            id: "import-captures",
            name: "导入外部录入队列",
            callback: ()=>void this.importQueue(true).catch(report)
        });
        this.addCommand({
            id: "insert-query",
            name: "插入动态任务查询",
            editorCallback: (editor)=>{
                const selected = editor.getSelection().trim();
                new QueryEditor(this, selected, (block)=>editor.replaceRange(block, editor.getCursor("to"))).open();
            }
        });
        this.registerMarkdownCodeBlockProcessor("taskhub", (source, el, ctx)=>ctx.addChild(new InlineTasks(el, this, source)));
        this.addSettingTab(new HubSettings(this));
        for (const event of [
            "create",
            "modify",
            "delete"
        ]){
            this.registerEvent(this.app.vault.on(event, (file)=>{
                if (this.includesTaskPath(file.path)) this.changed();
            }));
        }
        this.registerEvent(this.app.vault.on("rename", (file, old)=>{
            if ([
                file.path,
                old
            ].some((path)=>this.includesTaskPath(path) || this.taskFolders().includes(path))) this.changed();
        }));
        this.registerInterval(window.setInterval(()=>{
            const now = localDay();
            if (this.day !== now) this.reminderKeys.clear();
            this.day = now;
            this.changed();
            if (this.settings.autoImport) this.autoImport();
            if (this.settings.reminders) void this.checkReminders().catch(report);
        }, 15000));
        this.app.workspace.onLayoutReady(()=>{
            if (this.alive && this.settings.autoImport) this.autoImport();
        });
    }
    async checkReminders(now = new Date()) {
        if (!this.settings.reminders || this.checkingReminders) return;
        this.checkingReminders = true;
        try {
            const today = localDay(now);
            const tasks = await this.tasks();
            if (!this.alive || !this.settings.reminders) return;
            for (const task of tasks){
                if (finished(task) || !task.time || task.due !== today) continue;
                const elapsed = now.getTime() - new Date(task.due + "T" + task.time + ":00").getTime();
                const key = JSON.stringify([
                    task.path,
                    task.title,
                    task.due,
                    task.time
                ]);
                if (!(elapsed >= 0 && elapsed < 300000) || this.reminderKeys.has(key)) continue;
                this.reminderKeys.add(key);
                new Notice("任务到期 · " + task.time + " · " + task.title, 12000);
            }
        } finally{
            this.checkingReminders = false;
        }
    }
    onunload() {
        this.alive = false;
        window.clearTimeout(this.timer);
        this.changes.clear();
        this.app.workspace.detachLeavesOfType(VIEW);
    }
    registerDoubleControl() {
        let pressedAt;
        let lastTap;
        const reset = ()=>{
            pressedAt = undefined;
            lastTap = undefined;
        };
        this.registerDomEvent(window, "blur", reset);
        this.registerDomEvent(window, "pointerdown", reset, true);
        this.registerDomEvent(window, "keydown", (event)=>{
            if (event.key !== "Control" || event.altKey || event.shiftKey || event.metaKey) {
                reset();
                return;
            }
            if (!event.repeat) {
                if (pressedAt !== undefined) reset();
                else pressedAt = Date.now();
            }
        }, true);
        this.registerDomEvent(window, "keyup", (event)=>{
            if (event.key !== "Control") return;
            const now = Date.now();
            if (pressedAt === undefined || now - pressedAt > 300 || event.ctrlKey) {
                reset();
                return;
            }
            pressedAt = undefined;
            if (lastTap !== undefined && now - lastTap <= 400) {
                reset();
                if (!document.querySelector(".modal-container")) new TaskEditor(this).open();
            } else lastTap = now;
        }, true);
    }
    startWindowsHotkey() {
        try {
            if (typeof require !== "function") return;
            const runtime = require("process");
            if (runtime.platform !== "win32") return;
            const adapter = this.app.vault.adapter;
            const base = adapter.getBasePath?.();
            if (!base || !this.manifest.dir) throw new Error("无法定位全局快捷键组件。");
            const path = require("path");
            const child = require("child_process").spawn(path.join(base, this.manifest.dir, "TaskHub-Wake.exe"), [
                "--parent",
                String(runtime.pid)
            ], {
                windowsHide: true,
                stdio: [
                    "ignore",
                    "pipe",
                    "pipe"
                ]
            });
            this.hotkeyStatus = "正在启动 Windows 全局快捷键";
            child.stdout.on("data", (data)=>{
                this.hotkeyStatus = data.toString().trim();
                if (this.hotkeyStatus.includes("READY")) new Notice("TaskHub 全局双击 Ctrl 已启动");
            });
            child.stderr.on("data", (data)=>{
                this.hotkeyStatus = data.toString().trim();
            });
            child.on("error", (error)=>{
                this.hotkeyStatus = "全局快捷键启动失败：" + error.message;
                report(new Error(this.hotkeyStatus));
            });
            child.on("exit", (code)=>{
                if (!this.alive) return;
                this.hotkeyStatus = code === 2 ? "旧版 TaskHub 助手仍在运行，请退出托盘中的助手，再重新启用插件。" : "全局快捷键进程已退出，退出码：" + code + "。" + this.hotkeyStatus;
                new Notice(this.hotkeyStatus, 12000);
            });
            this.register(()=>{
                if (child.exitCode === null) child.kill();
            });
        } catch (error) {
            this.hotkeyStatus = String(error);
            report(error);
        }
    }
    importing = false;
    autoImport() {
        if (this.importing) return;
        this.importing = true;
        void this.importQueue(false).catch(report).finally(()=>{
            this.importing = false;
        });
    }
    subscribe(callback) {
        this.changes.add(callback);
        return ()=>this.changes.delete(callback);
    }
    changed() {
        window.clearTimeout(this.timer);
        this.timer = window.setTimeout(()=>this.changes.forEach((callback)=>callback()), 120);
    }
    serial(operation) {
        const current = this.pending.then(operation);
        this.pending = current.catch(()=>{});
        return current;
    }
    async openView() {
        let leaf = this.app.workspace.getLeavesOfType(VIEW)[0];
        if (!leaf) {
            leaf = this.app.workspace.getLeaf("tab");
            await leaf.setViewState({
                type: VIEW,
                active: true
            });
        }
        await this.app.workspace.revealLeaf(leaf);
    }
    files(folder = this.settings.folder) {
        return this.app.vault.getMarkdownFiles().filter((file)=>under(file.path, folder));
    }
    taskFolders() {
        return [
            ...new Set([
                this.settings.folder,
                ...this.settings.linkedFolders.split(/\r?\n/).map((s)=>s.trim()).filter(Boolean)
            ])
        ];
    }
    includesTaskPath(path) {
        return this.taskFolders().some((folder)=>under(path, folder)) && ![
            this.settings.backups,
            this.settings.queue
        ].some((folder)=>under(path, folder));
    }
    async tasks(folder, fresh = false) {
        const vault = this.app.vault;
        const files = folder ? this.files(folder) : vault.getMarkdownFiles().filter((file)=>this.includesTaskPath(file.path));
        const groups = await Promise.all(files.map(async (f)=>parseNote(await (fresh ? vault.read(f) : vault.cachedRead(f)), f.path)));
        return groups.flat();
    }
    async updateSettings(next) {
        return this.serial(()=>this.applySettings(next));
    }
    async applySettings(next) {
        const setting = {
            ...next,
            folder: safePath(next.folder),
            queue: safePath(next.queue),
            backups: safePath(next.backups)
        };
        setting.tag = setting.tag.trim();
        if (setting.tag && !/^#[\p{L}\p{M}\p{N}_/-]+$/u.test(setting.tag)) throw new Error("全局任务标记需为单个 #标签。");
        const dirs = [
            setting.folder,
            setting.queue,
            setting.backups
        ];
        if (dirs.some((a, i)=>dirs.some((b, j)=>j !== i && (a.toLowerCase() === b.toLowerCase() || under(a, b))))) throw new Error("任务库、录入队列和备份需要各自独立的目录。");
        setting.linkedFolders = setting.linkedFolders.split(/\r?\n/).map((s)=>s.trim()).filter(Boolean).map(safePath).join("\n");
        if (setting.linkedFolders.split("\n").filter(Boolean).some((p)=>[
                setting.backups,
                setting.queue
            ].some((q)=>p === q || under(p, q) || under(q, p)))) throw new Error("联动目录不能包含备份或录入队列目录。");
        await this.saveData(setting);
        this.settings = setting;
        this.changed();
    }
    async makeFolders(path) {
        const vault = this.app.vault;
        let parent = "";
        for (const part of safePath(path).split("/")){
            parent = parent ? parent + "/" + part : part;
            const current = vault.getAbstractFileByPath(parent);
            if (current && !(current instanceof TFolder)) throw new Error("文件占用了目录 · " + parent);
            if (!current) await vault.createFolder(parent);
        }
    }
    async add(draft, id, steps = [], daily = false) {
        const d = validateDraft(draft);
        const { folder, tag } = this.settings;
        const tasks = await this.tasks(undefined, true);
        if (id) {
            const received = tasks.filter((t)=>t.ids.includes(id));
            if (received.length > 1) throw new Error("多个任务使用同一外部录入 ID，请先检查原笔记。");
            if (received.length === 1) return false;
        }
        if (isDuplicate(tasks, d, tag)) {
            if (id) throw new Error("任务重复，外部录入已保留以便核对。");
            throw new Error("已有同内容、分类、项目和截止日的未完成任务。");
        }
        const month = localDay().slice(0, 7);
        const [year, number] = month.split("-");
        const legacyMonth = new RegExp("(^|[^0-9])" + year + "(?:[-_年]?)0?" + Number(number) + "(?:月)?([^0-9]|$)");
        const monthly = this.files(folder).filter((file)=>legacyMonth.test(file.basename));
        const standard = folder + "/" + month + ".md";
        const preferred = monthly.find((file)=>file.path === standard);
        if (!preferred && monthly.length > 1) throw new Error("找到多份本月任务笔记，请保留唯一月度文件或使用 " + month + ".md 作为录入目标。");
        const path = preferred?.path ?? monthly[0]?.path ?? standard;
        const vault = this.app.vault;
        const line = renderLine(d, tag, undefined, id) + (daily ? " [taskhub-repeat:: daily]" : "");
        const childLines = steps.map((title)=>"    " + renderLine({
                ...d,
                title,
                due: "",
                time: "",
                priority: ""
            }, tag, undefined, Date.now().toString(36) + "-" + Math.random().toString(36).slice(2)));
        const insert = (text)=>{
            const lines = [
                line,
                ...childLines
            ];
            const next = appendLine(text, lines.join(text.includes("\r\n") ? "\r\n" : "\n"));
            const offset = next.split(/\r?\n/).length - 1 - lines.length;
            const parsed = parseNote(next, path);
            if (lines.some((raw, index)=>!parsed.some((task)=>task.line === offset + index && task.raw === raw))) throw new Error("月度笔记末尾无法写入任务，请检查代码块或注释是否关闭。");
            return next;
        };
        await this.makeFolders(folder);
        const target = vault.getAbstractFileByPath(path);
        if (target instanceof TFile) {
            await vault.process(target, (text)=>{
                if (isDuplicate(parseNote(text, path), d, tag)) throw new Error("目标文件已有重复任务。");
                return insert(text);
            });
        } else if (!target) {
            await vault.create(path, insert("# " + month + " 任务\n"));
        } else {
            throw new Error("月度文件路径已被占用 · " + path);
        }
        this.changed();
        return true;
    }
    createFromTemplate(title, steps) {
        return this.serial(async ()=>{
            if (!steps.length || steps.length > 30) throw new Error("请填写 1–30 条步骤");
            await this.add({
                title,
                category: "",
                project: "",
                due: "",
                priority: ""
            }, undefined, steps);
        });
    }
    createHabit(title) {
        return this.serial(async ()=>{
            await this.add({
                title,
                category: "",
                project: "",
                due: localDay(),
                priority: ""
            }, undefined, [], true);
        });
    }
    save(draft, task) {
        return this.serial(async ()=>{
            if (!task) {
                await this.add(draft);
                return;
            }
            const d = validateDraft(draft);
            const existing = await this.tasks(undefined, true);
            const matches = existing.filter((t)=>t.path === task.path && t.raw === task.raw);
            if (matches.length !== 1) throw new Error("任务已变更或有相同记录，请刷新后重试。");
            const current = matches[0];
            const tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate() + 1);
            if (this.settings.promoteTomorrow && !finished(current) && current.due !== d.due && d.due === localDay(tomorrow) && [
                "",
                "🔽",
                "⏬"
            ].includes(d.priority) && d.priority === current.priority) d.priority = "🔼";
            const replacement = renderLine(d, this.settings.tag, current);
            if (replacement === current.raw) return;
            if (!finished(current) && isDuplicate(existing, d, this.settings.tag, current)) throw new Error("编辑后会与另一条未完成任务重复。");
            await this.writeTask(current, replacement);
        });
    }
    toggle(task) {
        return this.serial(async ()=>{
            const now = new Date();
            const today = localDay(now);
            const replacement = completionLine(task, today, clockTime(now));
            const rule = taskField(task, "repeat");
            if (!rule) {
                await this.writeTask(task, replacement);
                return;
            }
            if (finished(task)) throw new Error("此重复任务已生成下一次，请在原笔记中处理历史记录");
            const due = nextRepeatDate(rule, task.due > today ? task.due : today);
            const raw = renderLine({
                ...draftOf(task),
                due
            }, this.settings.tag);
            const successor = raw + " [taskhub-repeat:: " + rule + "]";
            await this.writeGroup(task, (text)=>{
                const updated = replaceLine(text, task, replacement);
                const next = appendLine(updated, successor);
                if (!parseNote(next, task.path).some((row)=>row.raw === successor && row.line === next.split(/\r?\n/).length - 2)) throw new Error("原笔记末尾无法插入下一次重复任务");
                return next;
            });
        });
    }
    updateField(task, key, value) {
        return this.serial(async ()=>{
            if (key === "repeat" && value && (!validRepeatRule(value) || !task.due || task.recurring || finished(task))) throw new Error("请为未完成的普通任务设置截止日期后再添加重复规则");
            if (key === "board" && ![
                "",
                "进行中"
            ].includes(value)) throw new Error("看板状态无效");
            if (key === "block" && value) {
                const match = value.match(/^(\d{4}-\d{2}-\d{2}) ((?:[01]\d|2[0-3]):[0-5]\d) (15|30|45|60|90|120)$/);
                if (!match || !validDate(match[1])) throw new Error("请选择有效的排期日期、时间和时长");
                const [hour, minute] = match[2].split(":").map(Number);
                if (hour * 60 + minute + Number(match[3]) > 1440) throw new Error("时间块不能跨午夜");
            }
            const raw = setTaskField(task, key, value);
            if (raw !== task.raw) await this.writeTask(task, raw);
        });
    }
    addSubtask(task, title) {
        return this.serial(()=>{
            const draft = validateDraft({
                title,
                category: "",
                project: "",
                due: "",
                priority: ""
            });
            const indent = task.raw.match(/^\s*/)?.[0] ?? "";
            const child = indent + "    " + renderLine(draft, this.settings.tag);
            return this.writeGroup(task, (text)=>replaceLine(text, task, task.raw + (text.includes("\r\n") ? "\r\n" : "\n") + child));
        });
    }
    async writeGroup(task, transform) {
        const vault = this.app.vault;
        const file = vault.getAbstractFileByPath(task.path);
        if (!this.includesTaskPath(task.path) || !(file instanceof TFile)) throw new Error("任务文件已移动。");
        await vault.process(file, transform);
        this.changed();
    }
    deleteTask(task) {
        return this.serial(()=>this.writeGroup(task, (text)=>deleteTaskLine(text, task)));
    }
    async writeTask(task, replacement) {
        const vault = this.app.vault;
        const file = vault.getAbstractFileByPath(task.path);
        if (!this.includesTaskPath(task.path) || !(file instanceof TFile)) throw new Error("任务文件已移动。");
        await vault.process(file, (text)=>replaceLine(text, task, replacement));
        this.changed();
    }
    async openSource(task) {
        const file = this.app.vault.getAbstractFileByPath(task.path);
        if (!(file instanceof TFile)) throw new Error("原笔记已移动。");
        const leaf = this.app.workspace.getLeaf("tab");
        await leaf.openFile(file, {
            eState: {
                line: task.line
            }
        });
    }
    async createBackup(folder) {
        const files = folder ? this.files(folder) : this.app.vault.getMarkdownFiles().filter((file)=>this.includesTaskPath(file.path));
        const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
        const path = this.settings.backups + "/" + timestamp + "-" + Math.random().toString(36).slice(2, 8) + ".json";
        const notes = await Promise.all(files.map(async (f)=>({
                path: f.path,
                content: await this.app.vault.read(f)
            })));
        await this.makeFolders(this.settings.backups);
        await this.app.vault.create(path, JSON.stringify({
            version: 1,
            createdAt: new Date().toISOString(),
            settings: {
                ...this.settings
            },
            sourceFolder: folder,
            notes
        }, null, 2));
        return path;
    }
    backup() {
        return this.serial(()=>this.createBackup());
    }
    migrate(folder) {
        return this.serial(async ()=>{
            const path = safePath(folder);
            if (!this.files(path).length) throw new Error("目录内没有 Markdown 笔记，请检查旧任务库路径。");
            if ([
                this.settings.backups,
                this.settings.queue
            ].some((p)=>under(p, path) || under(path, p) || path.toLowerCase() === p.toLowerCase())) throw new Error("旧任务目录与队列或备份目录重叠。");
            const tasks = await this.tasks(path, true);
            if (!tasks.length) throw new Error("目录内没有可识别的 Markdown 任务。");
            const backup = await this.createBackup(path);
            await this.applySettings({
                ...this.settings,
                folder: path
            });
            return {
                count: tasks.length,
                backup
            };
        });
    }
    importQueue(manual) {
        return this.serial(async ()=>{
            const { queue } = this.settings;
            const vault = this.app.vault;
            if (!await vault.adapter.exists(queue)) {
                if (manual) new Notice("录入队列为空");
                return;
            }
            const paths = (await vault.adapter.list(queue)).files.filter((p)=>under(p, queue) && p.endsWith(".taskhub.json")).sort();
            let added = 0, removed = 0;
            const errors = [];
            for (const path of paths){
                try {
                    const original = await vault.adapter.read(path);
                    const entry = parseCapture(original);
                    if (await this.add(entry.task, entry.id)) added++;
                    if (await vault.adapter.read(path) !== original) throw new Error("队列文件在导入过程中发生变化，已保留以便重试。");
                    await vault.adapter.remove(path);
                    removed++;
                } catch (error) {
                    errors.push(path.split("/").at(-1) + " · " + (error instanceof Error ? error.message : String(error)));
                }
            }
            if (manual || removed) new Notice("TaskHub · 新增 " + added + " 条，确认 " + removed + " 份队列文件，待处理 " + errors.length + " 份。");
            if (manual && errors.length) new Notice(errors.slice(0, 5).join("\n"), 10000);
        });
    }
}
class HubModal extends Modal {
    setTitle(title) {
        super.setTitle(title);
        this.modalEl?.addClass("taskhub-modal");
        this.contentEl.addClass("taskhub-dialog");
    }
}
class TaskEditor extends HubModal {
    hub;
    task;
    preset;
    constructor(hub, task, preset = {}){
        super(hub.app), this.hub = hub, this.task = task, this.preset = preset;
    }
    onOpen() {
        const { contentEl } = this;
        this.setTitle(this.task ? "编辑任务" : "新建任务");
        const form = contentEl.createEl("form", {
            cls: "taskhub-form"
        });
        const draft = {
            ...draftOf(this.task),
            ...!this.task ? this.preset : {}
        };
        const input = (parent, label, type, key)=>{
            const row = parent.createEl("label", {
                text: label
            });
            const el = row.createEl("input", {
                type,
                value: draft[key] ?? ""
            });
            el.addEventListener("input", ()=>{
                draft[key] = el.value;
            });
            return el;
        };
        const title = input(form, "要做什么？", "text", "title");
        title.required = true;
        title.maxLength = 1000;
        title.placeholder = "例如：联系候选人，确认周五面试时间";
        form.createEl("p", {
            text: "只写内容即可保存；分类、项目与日期可以稍后补充。",
            cls: "taskhub-muted"
        });
        const fields = form.createDiv({
            cls: "taskhub-fields"
        });
        const category = input(fields, "分类", "text", "category");
        category.placeholder = "例如：招聘、个人";
        const project = input(fields, "项目", "text", "project");
        project.placeholder = "例如：FDE 招聘";
        const due = input(fields, "截止日期", "date", "due");
        const time = input(fields, "截止时间（可选）", "time", "time");
        time.step = "60";
        const suggestion = this.task ? undefined : form.createDiv({
            cls: "taskhub-quick-suggestion"
        });
        if (suggestion) {
            const preview = ()=>{
                suggestion.empty();
                const parsed = parseQuickTitle(title.value);
                if (!parsed) return;
                suggestion.createEl("span", {
                    text: "识别到 " + parsed.due + (parsed.time ? " " + parsed.time : "")
                });
                suggestion.createEl("button", {
                    text: "应用日期时间",
                    attr: {
                        type: "button"
                    }
                }).addEventListener("click", ()=>{
                    title.value = draft.title = parsed.title;
                    due.value = draft.due = parsed.due;
                    time.value = draft.time = parsed.time;
                    suggestion.empty();
                    title.focus();
                });
            };
            title.addEventListener("input", preview);
        }
        due.addEventListener("input", ()=>{
            if (!due.value) {
                draft.time = "";
                time.value = "";
            }
        });
        const priority = fields.createEl("label", {
            text: "优先级"
        }).createEl("select");
        addOptions(priority, priorityOptions("普通"), draft.priority);
        priority.addEventListener("change", ()=>{
            draft.priority = priority.value;
        });
        const dates = form.createDiv({
            cls: "taskhub-date-shortcuts"
        });
        for (const [label, offset] of [
            [
                "今天",
                0
            ],
            [
                "明天",
                1
            ],
            [
                "一周后",
                7
            ],
            [
                "不设日期",
                -1
            ]
        ]){
            dates.createEl("button", {
                text: label,
                attr: {
                    type: "button"
                }
            }).addEventListener("click", ()=>{
                const date = new Date();
                date.setDate(date.getDate() + Math.max(0, offset));
                due.value = draft.due = offset < 0 ? "" : localDay(date);
                if (offset < 0) {
                    draft.time = "";
                    time.value = "";
                }
            });
        }
        void this.hub.tasks().then((tasks)=>{
            for (const [el, key] of [
                [
                    category,
                    "category"
                ],
                [
                    project,
                    "project"
                ]
            ]){
                if (!el.isConnected) return;
                const list = form.createEl("datalist");
                list.id = "taskhub-" + key + "-" + Math.random().toString(36).slice(2);
                el.setAttribute("list", list.id);
                for (const value of new Set(tasks.map((t)=>t[key]).filter(Boolean)))list.createEl("option", {
                    value
                });
            }
        }).catch(report);
        const status = form.createDiv({
            cls: "taskhub-form-status",
            attr: {
                "aria-live": "polite"
            }
        });
        const footer = form.createDiv({
            cls: "taskhub-editor-footer"
        });
        let keep;
        if (!this.task) {
            const label = footer.createEl("label", {
                cls: "taskhub-keep"
            });
            keep = label.createEl("input", {
                type: "checkbox"
            });
            label.createEl("span", {
                text: "保存后继续添加"
            });
        }
        const submit = footer.createEl("button", {
            text: this.task ? "保存修改" : "添加任务",
            cls: "mod-cta",
            attr: {
                type: "submit"
            }
        });
        const task = this.task;
        if (task) {
            const remove = footer.createEl("button", {
                text: "删除任务",
                cls: "taskhub-danger",
                attr: {
                    type: "button"
                }
            });
            const confirm = form.createDiv({
                cls: "taskhub-confirm"
            });
            confirm.hidden = true;
            confirm.createEl("p", {
                text: "确认从原笔记删除这条任务？"
            });
            const actions = confirm.createDiv({
                cls: "taskhub-actions"
            });
            const cancel = actions.createEl("button", {
                text: "取消",
                attr: {
                    type: "button"
                }
            });
            const accept = actions.createEl("button", {
                text: "确认删除",
                cls: "mod-warning",
                attr: {
                    type: "button"
                }
            });
            remove.addEventListener("click", ()=>{
                confirm.hidden = false;
                submit.disabled = true;
                remove.disabled = true;
                cancel.focus();
            });
            cancel.addEventListener("click", ()=>{
                confirm.hidden = true;
                submit.disabled = false;
                remove.disabled = false;
                remove.focus();
            });
            accept.addEventListener("click", ()=>{
                if (accept.disabled) return;
                accept.disabled = cancel.disabled = true;
                void this.hub.deleteTask(task).then(()=>{
                    new Notice("任务已删除");
                    this.close();
                }).catch((error)=>{
                    status.setText(error instanceof Error ? error.message : String(error));
                }).finally(()=>{
                    accept.disabled = cancel.disabled = false;
                });
            });
        }
        form.addEventListener("submit", (event)=>{
            event.preventDefault();
            if (submit.disabled) return;
            submit.disabled = true;
            submit.setText("正在保存…");
            status.setText("");
            const next = {
                ...draft
            };
            const controls = Array.from(form.querySelectorAll("input,select,button"));
            controls.forEach((control)=>{
                control.disabled = true;
            });
            void this.hub.save(next, this.task).then(()=>{
                if (keep?.checked) {
                    draft.title = "";
                    title.value = "";
                    suggestion?.empty();
                    status.setText("已添加。分类、项目和日期已保留，可继续录入。");
                } else {
                    new Notice(this.task ? "修改已保存" : "任务已添加");
                    this.close();
                }
            }).catch((error)=>{
                status.setText(error instanceof Error ? error.message : String(error));
            }).finally(()=>{
                controls.forEach((control)=>{
                    control.disabled = false;
                });
                submit.setText(this.task ? "保存修改" : "添加任务");
                title.focus();
            });
        });
        title.focus();
    }
    onClose() {
        this.contentEl.empty();
    }
}
class EmailCapture extends HubModal {
    hub;
    generation = 0;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("邮件转任务");
        const el = this.contentEl;
        el.createEl("p", {
            text: "选择导出的 .eml 邮件。插件在本地读取主题，生成可编辑的录入预览。"
        });
        const input = el.createEl("input", {
            type: "file",
            attr: {
                accept: ".eml,message/rfc822",
                "aria-label": "选择邮件文件"
            }
        });
        const status = el.createEl("p", {
            attr: {
                "aria-live": "polite"
            }
        });
        const preview = el.createEl("button", {
            text: "打开录入预览",
            cls: "mod-cta"
        });
        preview.disabled = true;
        let title = "";
        input.addEventListener("change", ()=>{
            const id = ++this.generation, file = input.files?.[0];
            title = "";
            preview.disabled = true;
            status.setText("");
            if (!file) return;
            void file.slice(0, 65536).text().then((text)=>{
                if (id !== this.generation) return;
                title = emailSubject(text);
                status.setText("邮件主题 · " + title);
                preview.disabled = false;
            }).catch((error)=>{
                if (id === this.generation) status.setText(error instanceof Error ? error.message : String(error));
            });
        });
        preview.addEventListener("click", ()=>{
            if (title) {
                this.close();
                new TaskEditor(this.hub, undefined, {
                    title: "处理邮件：" + title
                }).open();
            }
        });
    }
    onClose() {
        this.generation++;
        this.contentEl.empty();
    }
}
class TaskJump extends HubModal {
    destinations;
    constructor(destinations, hub){
        super(hub.app), this.destinations = destinations;
    }
    onOpen() {
        this.setTitle("跳转到");
        const input = this.contentEl.createEl("input", {
            type: "search",
            placeholder: "搜索视图",
            attr: {
                "aria-label": "搜索视图"
            }
        });
        const list = this.contentEl.createDiv({
            cls: "taskhub-review-nav"
        });
        const matches = ()=>this.destinations.filter(([name])=>name.includes(input.value.trim()));
        const choose = (action)=>{
            this.close();
            action();
        };
        const render = ()=>{
            list.empty();
            for (const [name, action] of matches())list.createEl("button", {
                text: name
            }).addEventListener("click", ()=>choose(action));
        };
        input.addEventListener("input", render);
        input.addEventListener("keydown", (event)=>{
            const first = matches()[0];
            if (event.key === "Enter" && !event.isComposing && first) {
                event.preventDefault();
                choose(first[1]);
            }
        });
        render();
        input.focus();
    }
    onClose() {
        this.contentEl.empty();
    }
}
class Routines extends HubModal {
    hub;
    version = 0;
    release;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("例行清单");
        const el = this.contentEl;
        el.addClass("taskhub-dialog");
        const tabs = el.createDiv({
            cls: "taskhub-nav"
        });
        const template = tabs.createEl("button", {
            text: "清单模板"
        });
        const habit = tabs.createEl("button", {
            text: "每日习惯"
        });
        const panel = el.createDiv();
        const switchTo = (daily)=>{
            this.version++;
            this.release?.();
            this.release = undefined;
            panel.empty();
            template.setAttribute("aria-pressed", String(!daily));
            habit.setAttribute("aria-pressed", String(daily));
            if (daily) this.renderHabits(panel);
            else this.renderTemplates(panel);
        };
        template.addEventListener("click", ()=>switchTo(false));
        habit.addEventListener("click", ()=>switchTo(true));
        switchTo(false);
    }
    renderHabits(el) {
        const form = el.createDiv({
            cls: "taskhub-section"
        });
        const title = form.createEl("label", {
            text: "新习惯"
        }).createEl("input", {
            type: "text",
            placeholder: "例如：每天整理收集箱"
        });
        const create = form.createEl("button", {
            text: "添加每日习惯",
            cls: "mod-cta"
        });
        const stats = el.createEl("p", {
            cls: "taskhub-muted"
        });
        const list = el.createDiv();
        const refresh = async ()=>{
            const version = ++this.version;
            try {
                const tasks = await this.hub.tasks();
                if (version !== this.version) return;
                const habits = tasks.filter((task)=>taskField(task, "repeat") === "daily");
                const today = localDay();
                stats.setText("今天已打卡 " + habits.filter((task)=>finished(task) && task.metadata.includes("✅ " + today)).length + " 次");
                showTasks(list, this.hub, habits.filter((task)=>!finished(task) && task.due <= today), false);
            } catch (error) {
                if (version === this.version) report(error);
            }
        };
        this.release = this.hub.subscribe(()=>void refresh());
        void refresh();
        create.addEventListener("click", ()=>{
            if (create.disabled) return;
            create.disabled = true;
            void this.hub.createHabit(title.value).then(()=>{
                title.value = "";
                new Notice("习惯已添加");
            }).catch(report).finally(()=>{
                create.disabled = false;
            });
        });
    }
    renderTemplates(panel) {
        const el = panel.createDiv({
            cls: "taskhub-section"
        });
        const templates = {
            "月度结账": [
                "核对本月流水",
                "确认应收应付",
                "整理结账凭证"
            ],
            "出差准备": [
                "确认行程和住宿",
                "准备会议材料",
                "整理报销凭证"
            ],
            "旅行打包": [
                "检查证件",
                "准备充电器",
                "整理衣物和洗漱用品"
            ]
        };
        const select = el.createEl("label", {
            text: "模板"
        }).createEl("select");
        addOptions(select, Object.keys(templates).map((name)=>[
                name,
                name
            ]), "月度结账");
        const title = el.createEl("label", {
            text: "任务名称"
        }).createEl("input", {
            type: "text"
        });
        const steps = el.createEl("label", {
            text: "清单步骤（每行一项）"
        }).createEl("textarea", {
            attr: {
                rows: "6"
            }
        });
        const fill = ()=>{
            title.value = select.value;
            steps.value = templates[select.value].join("\n");
        };
        select.addEventListener("change", fill);
        fill();
        const submit = el.createEl("button", {
            text: "创建清单",
            cls: "mod-cta"
        });
        submit.addEventListener("click", ()=>{
            if (submit.disabled) return;
            submit.disabled = true;
            void this.hub.createFromTemplate(title.value, steps.value.split(/\r?\n/).map((s)=>s.trim()).filter(Boolean)).then(()=>{
                new Notice("清单已创建");
                this.close();
            }).catch(report).finally(()=>{
                submit.disabled = false;
            });
        });
    }
    onClose() {
        this.version++;
        this.release?.();
        this.contentEl.empty();
    }
}
class TaskPlanning extends HubModal {
    hub;
    task;
    day;
    after;
    constructor(hub, task, day, after){
        super(hub.app), this.hub = hub, this.task = task, this.day = day, this.after = after;
    }
    onOpen() {
        this.setTitle("任务安排");
        const el = this.contentEl;
        el.addClass("taskhub-dialog");
        el.createEl("p", {
            text: this.task.title.split(/\s+/).filter((word)=>word !== this.hub.settings.tag).join(" "),
            cls: "taskhub-dialog-task"
        });
        const save = (operation)=>{
            const buttons = Array.from(el.querySelectorAll("input,select,button"));
            buttons.forEach((b)=>{
                b.disabled = true;
            });
            void operation().then(()=>{
                this.close();
                this.after?.();
            }).catch((error)=>{
                report(error);
                buttons.forEach((b)=>{
                    b.disabled = false;
                });
            });
        };
        const section = (title)=>{
            const panel = el.createDiv({
                cls: "taskhub-section"
            });
            panel.createEl("h3", {
                text: title
            });
            return panel;
        };
        const schedule = section("时间块");
        const fields = schedule.createDiv({
            cls: "taskhub-schedule-grid"
        });
        const [day, time, duration] = taskField(this.task, "block").split(" ");
        const date = fields.createEl("label", {
            text: "排期日期"
        }).createEl("input", {
            type: "date",
            value: this.day || day || localDay()
        });
        const clock = fields.createEl("label", {
            text: "开始时间"
        }).createEl("input", {
            type: "time",
            value: time || "09:00"
        });
        const length = fields.createEl("label", {
            text: "时长（分钟）"
        }).createEl("select");
        addOptions(length, [
            15,
            30,
            45,
            60,
            90,
            120
        ].map((n)=>[
                String(n),
                String(n)
            ]), duration || "30");
        const scheduleActions = schedule.createDiv({
            cls: "taskhub-actions"
        });
        if (day) scheduleActions.createEl("button", {
            text: "移除时间块"
        }).addEventListener("click", ()=>save(()=>this.hub.updateField(this.task, "block", "")));
        scheduleActions.createEl("button", {
            text: "保存时间块",
            cls: "mod-cta"
        }).addEventListener("click", ()=>save(()=>this.hub.updateField(this.task, "block", [
                    date.value,
                    clock.value,
                    length.value
                ].join(" "))));
        if (!finished(this.task) && !this.task.recurring) {
            const rule = section("重复规则");
            const repeat = rule.createEl("label", {
                text: "完成后生成下一次"
            }).createEl("select");
            const current = taskField(this.task, "repeat");
            const kind = current === "mwf" || current.startsWith("weekly:") ? "weekly" : current.startsWith("monthly:") ? "monthly" : current;
            addOptions(repeat, [
                [
                    "",
                    "不重复"
                ],
                [
                    "daily",
                    "每天"
                ],
                [
                    "weekly",
                    "每周 · 选择星期"
                ],
                [
                    "monthly",
                    "每月 · 指定日期"
                ],
                [
                    "month-end",
                    "每月最后一个工作日"
                ]
            ], kind);
            const start = new Date((this.task.due || localDay()) + "T12:00:00");
            const selected = current === "mwf" ? [
                1,
                3,
                5
            ] : current.startsWith("weekly:") ? current.slice(7).split(",").map(Number) : [
                start.getDay()
            ];
            const week = rule.createEl("fieldset", {
                cls: "taskhub-repeat-days"
            });
            week.createEl("legend", {
                text: "星期（可多选）"
            });
            const weekdays = [
                1,
                2,
                3,
                4,
                5,
                6,
                0
            ].map((day, index)=>{
                const label = week.createEl("label");
                const input = label.createEl("input", {
                    type: "checkbox"
                });
                input.checked = selected.includes(day);
                label.createEl("span", {
                    text: "周" + "一二三四五六日"[index]
                });
                return {
                    day,
                    input
                };
            });
            const month = rule.createEl("label", {
                text: "每月几号"
            });
            const monthDay = month.createEl("select");
            addOptions(monthDay, Array.from({
                length: 31
            }, (_, i)=>[
                    String(i + 1),
                    i + 1 + " 号"
                ]), current.startsWith("monthly:") ? current.slice(8) : String(start.getDate()));
            const hint = rule.createEl("p", {
                cls: "taskhub-muted"
            });
            const update = ()=>{
                week.hidden = repeat.value !== "weekly";
                month.hidden = repeat.value !== "monthly";
                hint.setText(!this.task.due ? "请先在「编辑」中为这条任务设置截止日期。" : repeat.value === "monthly" ? "没有所选日期的月份会跳过。" : "首次仍按当前截止日期，完成后按规则生成下一次。");
            };
            repeat.addEventListener("change", update);
            update();
            rule.createDiv({
                cls: "taskhub-actions"
            }).createEl("button", {
                text: "保存重复规则"
            }).addEventListener("click", ()=>{
                const days = weekdays.filter(({ input })=>input.checked).map(({ day })=>day);
                if (repeat.value === "weekly" && !days.length) {
                    new Notice("请选择至少一个星期");
                    return;
                }
                const value = repeat.value === "weekly" ? "weekly:" + days.join(",") : repeat.value === "monthly" ? "monthly:" + monthDay.value : repeat.value;
                save(()=>this.hub.updateField(this.task, "repeat", value));
            });
        }
        const subtasks = section("子任务");
        const child = subtasks.createEl("label", {
            text: "步骤内容"
        }).createEl("input", {
            type: "text",
            placeholder: "例如：准备面试材料"
        });
        subtasks.createDiv({
            cls: "taskhub-actions"
        }).createEl("button", {
            text: "添加子任务"
        }).addEventListener("click", ()=>save(()=>this.hub.addSubtask(this.task, child.value)));
        if (!finished(this.task)) {
            const doing = taskField(this.task, "board") === "进行中";
            el.createDiv({
                cls: "taskhub-actions"
            }).createEl("button", {
                text: doing ? "移回待办" : "标为进行中"
            }).addEventListener("click", ()=>save(()=>this.hub.updateField(this.task, "board", doing ? "" : "进行中")));
        }
    }
    onClose() {
        this.contentEl.empty();
    }
}
class PlanningBoard extends HubModal {
    hub;
    calendar;
    offset = 0;
    generation = 0;
    constructor(hub, calendar){
        super(hub.app), this.hub = hub, this.calendar = calendar;
    }
    onOpen() {
        this.setTitle(this.calendar ? "七天排期" : "任务看板");
        this.modalEl?.addClass("taskhub-modal-wide");
        void this.render();
    }
    onClose() {
        this.generation++;
        this.contentEl.empty();
    }
    async render() {
        const id = ++this.generation;
        const el = this.contentEl;
        el.setText("正在读取任务…");
        try {
            const tasks = await this.hub.tasks();
            if (id !== this.generation) return;
            el.empty();
            if (!this.calendar) {
                const board = el.createDiv({
                    cls: "taskhub-board"
                });
                for (const column of [
                    "待办",
                    "进行中",
                    "已完成"
                ]){
                    const section = board.createDiv();
                    section.createEl("h3", {
                        text: column
                    });
                    const items = tasks.filter((task)=>(finished(task) ? "已完成" : taskField(task, "board") || "待办") === column);
                    for (const task of items)section.createEl("button", {
                        text: task.title
                    }).addEventListener("click", ()=>new TaskPlanning(this.hub, task, undefined, ()=>void this.render()).open());
                }
                return;
            }
            const nav = el.createDiv({
                cls: "taskhub-review-nav"
            });
            for (const [label, offset] of [
                [
                    "前七天",
                    -7
                ],
                [
                    "回到今天",
                    0
                ],
                [
                    "后七天",
                    7
                ]
            ])nav.createEl("button", {
                text: label
            }).addEventListener("click", ()=>{
                this.offset = offset ? this.offset + offset : 0;
                void this.render();
            });
            const calendar = el.createDiv({
                cls: "taskhub-board"
            });
            let dragging;
            const card = (parent, task, label)=>{
                const button = parent.createEl("button", {
                    text: label,
                    attr: {
                        draggable: "true"
                    }
                });
                button.addEventListener("click", ()=>new TaskPlanning(this.hub, task, undefined, ()=>void this.render()).open());
                button.addEventListener("dragstart", (event)=>{
                    dragging = task;
                    event.dataTransfer?.setData("text/plain", "TaskHub");
                });
                button.addEventListener("dragend", ()=>{
                    dragging = undefined;
                });
            };
            const active = tasks.filter((task)=>!finished(task));
            for(let i = 0; i < 7; i++){
                const date = new Date();
                date.setDate(date.getDate() + this.offset + i);
                const day = localDay(date), column = calendar.createDiv();
                column.createEl("h3", {
                    text: day
                });
                column.addEventListener("dragover", (event)=>{
                    if (dragging) event.preventDefault();
                });
                column.addEventListener("drop", (event)=>{
                    if (!dragging) return;
                    event.preventDefault();
                    const task = dragging;
                    dragging = undefined;
                    new TaskPlanning(this.hub, task, day, ()=>void this.render()).open();
                });
                const items = active.filter((task)=>taskField(task, "block").startsWith(day + " "));
                items.sort((a, b)=>taskField(a, "block").localeCompare(taskField(b, "block")));
                for (const task of items){
                    const [, time, length] = taskField(task, "block").split(" ");
                    card(column, task, time + " · " + length + " 分 · " + task.title);
                }
            }
            el.createEl("h3", {
                text: "未排期"
            });
            const pool = el.createDiv({
                cls: "taskhub-review-nav"
            });
            for (const task of active.filter((task)=>!taskField(task, "block")))card(pool, task, task.title);
        } catch (error) {
            if (id === this.generation) el.setText(String(error));
        }
    }
}
class CompletionStats extends HubModal {
    hub;
    closed = false;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("近七天完成记录");
        const el = this.contentEl;
        el.setText("正在读取任务…");
        void this.hub.tasks().then((tasks)=>{
            if (this.closed) return;
            const counts = new Map();
            for(let offset = 34; offset >= 0; offset--){
                const date = new Date();
                date.setDate(date.getDate() - offset);
                counts.set(localDay(date), 0);
            }
            for (const task of tasks){
                if (!/^[xX]$/.test(task.status)) continue;
                const date = task.metadata.match(/✅\s*(\d{4}-\d{2}-\d{2})|\[(?:done|completion)::\s*(\d{4}-\d{2}-\d{2})\s*\]/u);
                const day = date?.[1] ?? date?.[2];
                if (day && counts.has(day)) counts.set(day, (counts.get(day) ?? 0) + 1);
            }
            el.empty();
            el.createEl("p", {
                text: "近七天完成 " + [
                    ...counts.values()
                ].slice(-7).reduce((sum, value)=>sum + value, 0) + " 项"
            });
            const heatmap = el.createDiv({
                cls: "taskhub-heatmap",
                attr: {
                    "aria-label": "近 35 天完成热力图"
                }
            });
            for (const [day, count] of counts)heatmap.createEl("span", {
                text: String(count),
                attr: {
                    title: day + " · " + count + " 项",
                    "data-level": String(Math.min(3, count))
                }
            });
            const list = el.createEl("ul");
            for (const [day, count] of [
                ...counts
            ].slice(-7))list.createEl("li", {
                text: day + " · " + count + " 项"
            });
            el.createEl("p", {
                text: "仅统计有完成日期的任务。",
                cls: "taskhub-muted"
            });
        }).catch((error)=>{
            if (!this.closed) el.setText(String(error));
        });
    }
    onClose() {
        this.closed = true;
        this.contentEl.empty();
    }
}
class WeeklyReview extends HubModal {
    hub;
    step = 0;
    selected = new Map();
    renderId = 0;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("每周回顾");
        void this.render();
    }
    onClose() {
        this.renderId++;
        this.contentEl.empty();
    }
    async render() {
        const id = ++this.renderId;
        const el = this.contentEl;
        el.empty();
        el.createEl("p", {
            text: "正在读取任务…"
        });
        try {
            const tasks = await this.hub.tasks();
            if (id !== this.renderId) return;
            el.empty();
            const names = [
                "处理逾期",
                "整理收集箱",
                "选出下周最重要的三件事"
            ];
            const scope = [
                "逾期",
                "收集箱",
                "全部"
            ][this.step];
            const items = filterTasks(tasks, {
                scope
            }, localDay(), clockTime());
            el.createEl("h3", {
                text: this.step + 1 + " / 3 · " + names[this.step]
            });
            if (this.step < 2) {
                el.createEl("p", {
                    text: this.step === 0 ? "完成已处理的任务，或编辑仍需跟进的截止时间。" : "给值得保留的任务补上分类、项目或截止日期。",
                    cls: "taskhub-muted"
                });
                showTasks(el.createDiv({
                    cls: "taskhub-review-list"
                }), this.hub, items, false);
            } else {
                const list = el.createDiv({
                    cls: "taskhub-review-list"
                });
                const status = el.createEl("p", {
                    attr: {
                        "aria-live": "polite"
                    }
                });
                const output = el.createEl("textarea", {
                    attr: {
                        readonly: "",
                        rows: "5",
                        "aria-label": "下周重点 Markdown"
                    }
                });
                const active = new Set(items.map((t)=>t.path + ":" + t.line + ":" + t.raw));
                for (const key of this.selected.keys())if (!active.has(key)) this.selected.delete(key);
                const update = ()=>{
                    status.setText("已选 " + this.selected.size + " / 3");
                    output.value = this.selected.size ? "## 下周重点\n" + [
                        ...this.selected.values()
                    ].map((title, i)=>i + 1 + ". " + title).join("\n") : "";
                };
                for (const task of items){
                    const key = task.path + ":" + task.line + ":" + task.raw;
                    const row = list.createEl("label", {
                        cls: "taskhub-review-choice"
                    });
                    const toggle = row.createEl("input", {
                        type: "checkbox"
                    });
                    row.createEl("span", {
                        text: task.title
                    });
                    toggle.checked = this.selected.has(key);
                    toggle.addEventListener("change", ()=>{
                        if (!toggle.checked) this.selected.delete(key);
                        else if (this.selected.size < 3) this.selected.set(key, task.title);
                        else {
                            toggle.checked = false;
                            new Notice("最多选择三件事");
                        }
                        update();
                    });
                }
                update();
                el.createEl("button", {
                    text: "复制下周重点"
                }).addEventListener("click", ()=>{
                    if (!output.value) {
                        new Notice("先选择至少一项任务");
                        return;
                    }
                    void navigator.clipboard.writeText(output.value).then(()=>new Notice("已复制下周重点")).catch(report);
                });
            }
            const nav = el.createDiv({
                cls: "taskhub-review-nav"
            });
            if (this.step > 0) nav.createEl("button", {
                text: "上一步"
            }).addEventListener("click", ()=>{
                this.step--;
                void this.render();
            });
            nav.createEl("button", {
                text: "刷新本步"
            }).addEventListener("click", ()=>void this.render());
            nav.createEl("button", {
                text: this.step === 2 ? "完成回顾" : "下一步",
                cls: "mod-cta"
            }).addEventListener("click", ()=>{
                if (this.step === 2) this.close();
                else {
                    this.step++;
                    void this.render();
                }
            });
        } catch (error) {
            if (id === this.renderId) el.setText(String(error));
        }
    }
}
class QueryEditor extends HubModal {
    hub;
    selected;
    insert;
    constructor(hub, selected, insert){
        super(hub.app), this.hub = hub, this.selected = selected, this.insert = insert;
    }
    onOpen() {
        this.setTitle("插入动态任务查询");
        const { contentEl } = this;
        const scope = contentEl.createEl("label", {
            text: "视图"
        }).createEl("select");
        addOptions(scope, scopes.map((s)=>[
                s,
                s
            ]), "全部");
        const project = contentEl.createEl("label", {
            text: "项目（可选）"
        }).createEl("input", {
            type: "text",
            value: this.selected
        });
        contentEl.createEl("button", {
            text: "插入查询",
            cls: "mod-cta"
        }).addEventListener("click", ()=>{
            const value = project.value.trim().replace(/[\r\n]/g, "");
            const fence = String.fromCharCode(96).repeat(3);
            this.insert("\n\n" + fence + "taskhub\nscope: " + scope.value + (value ? "\nproject: " + value : "") + "\n" + fence + "\n\n");
            this.close();
        });
    }
    onClose() {
        this.contentEl.empty();
    }
}
class Migration extends HubModal {
    hub;
    constructor(hub){
        super(hub.app), this.hub = hub;
    }
    onOpen() {
        this.setTitle("接管旧版任务库");
        const { contentEl } = this;
        contentEl.createEl("p", {
            text: "选定旧 Markdown 目录后，先备份，再让 TaskHub 原地读取。旧笔记和 Tasks 查询继续使用原路径。"
        });
        const path = contentEl.createEl("label", {
            text: "旧任务库目录"
        }).createEl("input", {
            type: "text",
            value: defaults.folder
        });
        const status = contentEl.createEl("p", {
            attr: {
                "aria-live": "polite"
            }
        });
        const preview = contentEl.createEl("button", {
            text: "扫描"
        });
        const apply = contentEl.createEl("button", {
            text: "备份并接管",
            cls: "mod-cta"
        });
        apply.disabled = true;
        let approved = "";
        path.addEventListener("input", ()=>{
            approved = "";
            apply.disabled = true;
            status.empty();
        });
        preview.addEventListener("click", ()=>{
            try {
                const target = safePath(path.value);
                approved = "";
                apply.disabled = true;
                void this.hub.tasks(target, true).then((tasks)=>{
                    if (safePath(path.value) !== target) return;
                    status.setText(this.hub.files(target).length + " 个 Markdown 文件，识别到 " + tasks.length + " 条任务。");
                    approved = target;
                    apply.disabled = !tasks.length;
                }).catch(report);
            } catch (error) {
                report(error);
            }
        });
        apply.addEventListener("click", ()=>{
            if (!approved) return;
            apply.disabled = true;
            void this.hub.migrate(approved).then((result)=>{
                new Notice("接管 " + result.count + " 条任务 · " + result.backup, 8000);
                this.close();
            }).catch((error)=>{
                report(error);
                apply.disabled = false;
            });
        });
    }
    onClose() {
        this.contentEl.empty();
    }
}
class HubSettings extends PluginSettingTab {
    hub;
    constructor(hub){
        super(hub.app, hub), this.hub = hub;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        const draft = {
            ...this.hub.settings
        };
        new Setting(containerEl).setName("改到明天时提升普通或低优先级").setDesc("仅在 TaskHub 编辑截止日期且未同时修改优先级时，将普通或低优先级调整为中。").addToggle((t)=>t.setValue(draft.promoteTomorrow).onChange((value)=>{
                draft.promoteTomorrow = value;
            }));
        const fields = [
            [
                "folder",
                "Markdown 任务库目录"
            ],
            [
                "tag",
                "新任务的 Tasks 全局标记"
            ],
            [
                "queue",
                "外部录入队列目录"
            ],
            [
                "backups",
                "备份目录"
            ]
        ];
        for (const [field, label] of fields){
            new Setting(containerEl).setName(label).addText((t)=>t.setValue(draft[field]).onChange((v)=>{
                    draft[field] = v;
                }));
        }
        new Setting(containerEl).setName("联动已有待办目录").setDesc("每行一个库内目录；任务直接在原笔记更新，不复制。留空则只显示统一任务库。").addTextArea((t)=>t.setValue(draft.linkedFolders).onChange((v)=>{
                draft.linkedFolders = v;
            }));
        new Setting(containerEl).setName("自动导入外部录入").setDesc("启动后及每 15 秒检查队列。").addToggle((t)=>t.setValue(draft.autoImport).onChange((v)=>{
                draft.autoImport = v;
            }));
        new Setting(containerEl).addButton((b)=>b.setButtonText("保存设置").setCta().onClick(()=>{
                b.setDisabled(true);
                void this.hub.updateSettings(draft).then(()=>new Notice("TaskHub 设置已保存")).catch(report).finally(()=>b.setDisabled(false));
            }));
        new Setting(containerEl).setName("旧版迁移").addButton((b)=>b.setButtonText("扫描旧任务库").onClick(()=>new Migration(this.hub).open()));
    }
}
function showTasks(el, hub, tasks, group) {
    el.empty();
    if (!tasks.length) {
        el.createEl("p", {
            text: "没有符合条件的任务。",
            cls: "taskhub-muted"
        });
        return;
    }
    const projects = group ? [
        ...new Set(tasks.map((t)=>t.project))
    ].sort() : [
        ""
    ];
    for (const project of projects){
        if (group) el.createEl("h3", {
            text: project
        });
        const list = el.createEl("ul", {
            cls: "taskhub-list"
        });
        for (const task of group ? tasks.filter((t)=>t.project === project) : tasks){
            const row = list.createEl("li", {
                cls: "taskhub-row"
            });
            const toggle = row.createEl("input", {
                type: "checkbox",
                attr: {
                    "aria-label": "完成 " + task.title
                }
            });
            toggle.checked = finished(task);
            toggle.disabled = task.recurring || ![
                " ",
                "x",
                "X"
            ].includes(task.status) || /❌|\[cancelled::/u.test(task.metadata) || finished(task) && !!taskField(task, "repeat");
            if (toggle.disabled) toggle.title = "请在原笔记使用 Tasks 修改此状态。";
            toggle.addEventListener("change", ()=>{
                toggle.disabled = true;
                void hub.toggle(task).catch((error)=>{
                    toggle.checked = finished(task);
                    report(error);
                }).finally(()=>{
                    toggle.disabled = false;
                });
            });
            const text = row.createDiv({
                cls: "taskhub-text"
            });
            const displayTitle = task.title.split(/\s+/).filter((t)=>t !== hub.settings.tag).join(" ") || task.title;
            text.createDiv({
                text: displayTitle,
                cls: finished(task) ? "taskhub-done" : "taskhub-title"
            });
            const meta = text.createDiv({
                cls: "taskhub-meta"
            });
            for (const value of [
                task.category,
                task.project ? "项目 · " + task.project : "",
                task.priority
            ])if (value) meta.createEl("span", {
                text: value,
                cls: "taskhub-badge"
            });
            if (task.due) {
                const today = localDay();
                const late = !finished(task) && (task.due < today || task.due === today && !!task.time && task.time < clockTime());
                meta.createEl("span", {
                    text: (late ? "已逾期 · " : task.due === today ? "今天到期 · " : "截止 · ") + task.due + (task.time ? " " + task.time : ""),
                    cls: "taskhub-badge " + (late ? "taskhub-overdue" : task.due === today && !finished(task) ? "taskhub-today" : "")
                });
            }
            const completed = finished(task) ? completionStamp(task) : "";
            if (completed) meta.createEl("span", {
                text: "完成于 " + completed,
                cls: "taskhub-badge"
            });
            meta.createEl("span", {
                text: task.path,
                cls: "taskhub-source"
            });
            if (toggle.disabled) meta.createEl("span", {
                text: "循环或特殊状态 · 请在原笔记操作",
                cls: "taskhub-muted"
            });
            const actions = row.createDiv({
                cls: "taskhub-row-actions"
            });
            actions.createEl("button", {
                text: "编辑"
            }).addEventListener("click", ()=>new TaskEditor(hub, task).open());
            actions.createEl("button", {
                text: "安排"
            }).addEventListener("click", ()=>new TaskPlanning(hub, task).open());
            actions.createEl("button", {
                text: "原笔记"
            }).addEventListener("click", ()=>void hub.openSource(task).catch(report));
        }
    }
}
class Workbench extends ItemView {
    hub;
    query = {
        scope: "今天"
    };
    release;
    version = 0;
    tasks = [];
    sort = "due";
    constructor(leaf, hub){
        super(leaf), this.hub = hub;
    }
    getViewType() {
        return VIEW;
    }
    getDisplayText() {
        return "TaskHub";
    }
    getIcon() {
        return "list-todo";
    }
    async onOpen() {
        const el = this.contentEl;
        el.empty();
        el.addClass("taskhub");
        const header = el.createDiv({
            cls: "taskhub-header"
        });
        const heading = header.createDiv();
        heading.createEl("h2", {
            text: "任务工作台"
        });
        const subtitle = heading.createEl("p", {
            cls: "taskhub-muted"
        });
        const create = ()=>new TaskEditor(this.hub, undefined, {
                category: this.query.category ?? "",
                project: this.query.project ?? "",
                due: this.query.scope === "今天" ? localDay() : "",
                priority: this.query.priority === "none" ? "" : this.query.priority ?? ""
            }).open();
        const actions = header.createDiv({
            cls: "taskhub-header-actions"
        });
        actions.createEl("button", {
            text: "排期"
        }).addEventListener("click", ()=>new PlanningBoard(this.hub, true).open());
        actions.createEl("button", {
            text: "看板"
        }).addEventListener("click", ()=>new PlanningBoard(this.hub, false).open());
        const more = actions.createEl("details", {
            cls: "taskhub-more"
        });
        more.createEl("summary", {
            text: "更多"
        });
        const menu = more.createDiv({
            cls: "taskhub-more-menu"
        });
        const menuItem = (text, open)=>menu.createEl("button", {
                text
            }).addEventListener("click", ()=>{
                more.open = false;
                open();
            });
        menuItem("例行清单", ()=>new Routines(this.hub).open());
        menuItem("每周回顾", ()=>new WeeklyReview(this.hub).open());
        menuItem("完成记录", ()=>new CompletionStats(this.hub).open());
        actions.createEl("button", {
            text: "＋ 新建任务",
            cls: "mod-cta",
            attr: {
                "aria-keyshortcuts": "Q"
            }
        }).addEventListener("click", create);
        const nav = el.createDiv({
            cls: "taskhub-nav",
            attr: {
                "aria-label": "任务视图"
            }
        });
        const tabs = new Map();
        for (const scope of scopes){
            const button = nav.createEl("button", {
                text: scope
            });
            tabs.set(scope, button);
            button.addEventListener("click", ()=>{
                this.query.scope = scope;
                render();
            });
        }
        const toolbar = el.createDiv({
            cls: "taskhub-toolbar"
        });
        const search = toolbar.createEl("input", {
            type: "search",
            placeholder: "搜索任务、标签或项目…",
            value: this.query.search ?? "",
            attr: {
                "aria-label": "搜索任务"
            }
        });
        search.setAttribute("aria-keyshortcuts", "/");
        el.tabIndex = 0;
        this.registerDomEvent(el, "keydown", (event)=>{
            if (event.defaultPrevented || event.repeat || event.isComposing || event.altKey || event.shiftKey) return;
            if (event.key.toLowerCase() === "k" && (event.ctrlKey || event.metaKey)) {
                event.preventDefault();
                new TaskJump([
                    ...scopes.map((scope)=>[
                            scope,
                            ()=>{
                                this.query.scope = scope;
                                render();
                            }
                        ]),
                    [
                        "排期",
                        ()=>new PlanningBoard(this.hub, true).open()
                    ],
                    [
                        "看板",
                        ()=>new PlanningBoard(this.hub, false).open()
                    ],
                    [
                        "每周回顾",
                        ()=>new WeeklyReview(this.hub).open()
                    ]
                ], this.hub).open();
                return;
            }
            if (event.ctrlKey || event.metaKey) return;
            if (event.target?.closest("input,textarea,select,[contenteditable=true]")) return;
            if (event.key === "/") {
                event.preventDefault();
                search.focus();
            }
            if (event.key === "q") {
                event.preventDefault();
                create();
            }
        });
        const category = toolbar.createEl("select", {
            attr: {
                "aria-label": "分类"
            }
        });
        const project = toolbar.createEl("select", {
            attr: {
                "aria-label": "项目"
            }
        });
        const priority = toolbar.createEl("select", {
            attr: {
                "aria-label": "优先级"
            }
        });
        addOptions(priority, [
            ...priorityOptions("所有优先级"),
            [
                "none",
                "普通优先级"
            ]
        ], this.query.priority ?? "");
        const sorting = toolbar.createEl("select", {
            attr: {
                "aria-label": "排序"
            }
        });
        addOptions(sorting, [
            [
                "due",
                "默认排序"
            ],
            [
                "priority",
                "优先级优先"
            ],
            [
                "title",
                "任务名称排序"
            ]
        ], this.sort);
        const reset = toolbar.createEl("button", {
            text: "清除筛选"
        });
        const summary = el.createDiv({
            cls: "taskhub-summary"
        });
        const status = summary.createEl("p", {
            cls: "taskhub-muted",
            attr: {
                "aria-live": "polite"
            }
        });
        const retry = summary.createEl("button", {
            text: "刷新"
        });
        const list = el.createDiv();
        const clear = ()=>{
            this.query = {
                scope: this.query.scope
            };
            category.value = project.value = priority.value = search.value = "";
            render();
        };
        let renderedSignature = "";
        reset.addEventListener("click", clear);
        const render = ()=>{
            const today = localDay();
            const overdue = filterTasks(this.tasks, {
                scope: "逾期"
            }, today, clockTime()).length;
            subtitle.setText(today + (overdue ? " · " + overdue + " 项逾期" : ""));
            for (const [scope, button] of tabs){
                button.setText(scope + " · " + filterTasks(this.tasks, {
                    scope: scope
                }, today, clockTime()).length);
                button.setAttribute("aria-pressed", String(this.query.scope === scope));
            }
            let result = filterTasks(this.tasks, this.query, today, clockTime());
            if (this.sort === "priority") {
                const rank = [
                    "🔺",
                    "⏫",
                    "🔼",
                    "",
                    "🔽",
                    "⏬"
                ];
                result = result.sort((a, b)=>rank.indexOf(a.priority) - rank.indexOf(b.priority));
            } else if (this.sort === "title") result = result.sort((a, b)=>a.title.localeCompare(b.title, "zh-CN"));
            const filtered = !!(this.query.category || this.query.project || this.query.priority || this.query.search);
            reset.disabled = !filtered;
            status.setText((this.query.scope ?? "今天") + " · " + result.length + " 项" + (filtered ? " · 已应用筛选" : "") + (this.query.scope === "今天" ? " · 今天到期；已过截止时间的任务也列入逾期" : ""));
            const signature = JSON.stringify([
                this.query,
                this.sort,
                today,
                clockTime(),
                result.map((task)=>[
                        task.path,
                        task.line,
                        task.raw
                    ])
            ]);
            if (signature === renderedSignature) return;
            renderedSignature = signature;
            showTasks(list, this.hub, result, this.query.scope === "项目");
            if (!result.length) {
                list.empty();
                const empty = list.createDiv({
                    cls: "taskhub-empty"
                });
                empty.createEl("h3", {
                    text: filtered ? "没有匹配的任务" : this.query.scope === "逾期" ? "当前没有逾期任务" : this.query.scope === "今天" ? "今天没有到期任务" : "这里还没有任务"
                });
                empty.createEl("p", {
                    text: filtered ? "试试减少筛选条件，或换一个关键词。" : "可以添加任务，也可以切换到全部查看其他安排。",
                    cls: "taskhub-muted"
                });
                empty.createEl("button", {
                    text: filtered ? "清除筛选" : "添加任务",
                    cls: "mod-cta"
                }).addEventListener("click", filtered ? clear : create);
            }
        };
        const reload = async ()=>{
            const version = ++this.version;
            const tasks = await this.hub.tasks();
            if (version !== this.version) return;
            this.tasks = tasks;
            for (const [select, key, label] of [
                [
                    category,
                    "category",
                    "所有分类"
                ],
                [
                    project,
                    "project",
                    "所有项目"
                ]
            ]){
                select.empty();
                const values = [
                    ...new Set(tasks.map((t)=>t[key]).filter(Boolean))
                ].sort();
                if (this.query[key] && !values.includes(this.query[key])) values.push(this.query[key]);
                addOptions(select, [
                    [
                        "",
                        label
                    ],
                    ...values.map((s)=>[
                            s,
                            s
                        ])
                ], this.query[key] ?? "");
            }
            render();
        };
        const update = ()=>{
            this.query = {
                ...this.query,
                category: category.value,
                project: project.value,
                priority: priority.value,
                search: search.value
            };
            this.sort = sorting.value;
            render();
        };
        toolbar.addEventListener("change", update);
        search.addEventListener("input", update);
        const refresh = ()=>void reload().catch((error)=>{
                status.setText("读取失败，点击刷新重试。当前列表可能不是最新数据。");
                report(error);
            });
        retry.addEventListener("click", refresh);
        status.setText("正在读取任务…");
        this.release = this.hub.subscribe(refresh);
        refresh();
    }
    async onClose() {
        this.version++;
        this.release?.();
    }
}
class InlineTasks extends MarkdownRenderChild {
    hub;
    source;
    version = 0;
    release;
    constructor(el, hub, source){
        super(el), this.hub = hub, this.source = source;
    }
    onload() {
        this.containerEl.addClass("taskhub");
        let query;
        try {
            query = parseQuery(this.source);
        } catch (error) {
            this.containerEl.setText(String(error));
            return;
        }
        const refresh = async ()=>{
            const version = ++this.version;
            try {
                const tasks = await this.hub.tasks();
                if (version === this.version) showTasks(this.containerEl, this.hub, filterTasks(tasks, query, localDay(), clockTime()), query.scope === "项目");
            } catch (error) {
                if (version === this.version) this.containerEl.setText(String(error));
            }
        };
        this.release = this.hub.subscribe(()=>void refresh());
        void refresh();
    }
    onunload() {
        this.version++;
        this.release?.();
    }
}
module.exports = TaskHub;
