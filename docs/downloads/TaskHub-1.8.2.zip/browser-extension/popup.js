const status = document.getElementById("status");
const capture = document.getElementById("capture");

chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  if (chrome.runtime.lastError || !tab?.url) {
    status.textContent = "当前页面无法读取。";
    return;
  }
  const url = new URL(tab.url);
  if (!["https:", "http:"].includes(url.protocol) || url.username || url.password || url.href.length > 700) {
    status.textContent = "请选择链接长度不超过 700 字符的普通网页。";
    return;
  }
  const title = (tab.title || "阅读网页").slice(0, 220);
  const params = new URLSearchParams({ title, url: url.href });
  capture.href = "obsidian://taskhub-web?" + params;
  capture.hidden = false;
  status.textContent = title;
});
