using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

public static class TaskHubWake {
    private static Process parent;
    [STAThread]
    public static int Main(string[] args) {
        try {
            if (args.Length==1 && args[0]=="--self-test") SelfTest();
            else {
                if (args.Length==2 && args[0]=="--parent") parent=Process.GetProcessById(int.Parse(args[1]));
                Run();
            }
            return 0;
        } catch (Exception error) {
            Console.Error.WriteLine("ERROR: " + error.Message);
            MessageBox.Show(error.Message,"TaskHub",MessageBoxButtons.OK,MessageBoxIcon.Error);
            return 1;
        }
    }
    private delegate IntPtr KeyboardHook(int code, IntPtr message, IntPtr data);
    [DllImport("user32.dll", SetLastError=true)]
    private static extern IntPtr SetWindowsHookEx(int type, KeyboardHook callback, IntPtr module, uint thread);
    [DllImport("user32.dll")]
    private static extern bool UnhookWindowsHookEx(IntPtr handle);
    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr handle, int code, IntPtr message, IntPtr data);
    [DllImport("kernel32.dll", CharSet=CharSet.Auto)]
    private static extern IntPtr GetModuleHandle(string name);
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")]
    private static extern bool IsIconic(IntPtr window);
    [DllImport("user32.dll")]
    private static extern bool ShowWindowAsync(IntPtr window, int command);
    [DllImport("user32.dll")]
    private static extern bool SetForegroundWindow(IntPtr window);
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(IntPtr window, out uint pid);
    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int key);

    private sealed class DoubleTap {
        private int held;
        private long down;
        private long last = -1;
        public bool Input(int key, bool pressed, bool modified, long now) {
            bool control = key == 0xA2 || key == 0xA3 || key == 0x11;
            if ((!control && pressed) || modified) { held=0; last=-1; return false; }
            if (!control) return false;
            if (pressed) {
                if (held == key) return false;
                if (held != 0) { held=0; last=-1; return false; }
                held=key;
                down=now;
                return false;
            }
            if (held != key || now-down > 300) { held=0; last=-1; return false; }
            held=0;
            if (last >= 0 && now-last <= 400) { last=-1; return true; }
            last=now;
            return false;
        }
    }

    private static readonly Stopwatch Clock=Stopwatch.StartNew();
    private static readonly DoubleTap Gesture=new DoubleTap();
    private static readonly KeyboardHook Callback=OnKey;
    private static readonly int[] Modifiers={0x10,0x12,0x5B,0x5C};
    private static IntPtr hook;
    private static bool pending;

    private static IntPtr OnKey(int code, IntPtr message, IntPtr data) {
        int msg=message.ToInt32();
        if (code>=0 && (msg==0x100 || msg==0x101 || msg==0x104 || msg==0x105)) {
            int flags=Marshal.ReadInt32(data,8);
            if ((flags & 0x10)==0) {
                bool modified=false;
                foreach (int key in Modifiers) modified |= (GetAsyncKeyState(key) & 0x8000)!=0;
                if (Gesture.Input(Marshal.ReadInt32(data),msg==0x100 || msg==0x104,modified,Clock.ElapsedMilliseconds))
                    pending=true;
            }
        }
        return CallNextHookEx(hook,code,message,data);
    }

    private static void Wake() {
        uint foreground;
        GetWindowThreadProcessId(GetForegroundWindow(),out foreground);
        Process[] apps=Process.GetProcessesByName("Obsidian");
        IntPtr window=IntPtr.Zero;
        bool alreadyFocused=false;
        foreach (Process app in apps) {
            using (app) {
                if (window==IntPtr.Zero) window=app.MainWindowHandle;
                alreadyFocused |= app.Id == foreground;
            }
        }
        if (window!=IntPtr.Zero && !alreadyFocused) {
            if (IsIconic(window)) ShowWindowAsync(window,9);
            SetForegroundWindow(window);
            Process.Start(new ProcessStartInfo("obsidian://taskhub-capture") { UseShellExecute=true });
        }
    }

    public static void Run() {
        bool created;
        using (var singleton=new Mutex(true,@"Local\TaskHubWake",out created)) {
            if (!created) { Console.Error.WriteLine("CONFLICT: old TaskHub helper running"); Environment.Exit(2); return; }
            using (var icon=new NotifyIcon())
            using (var menu=new ContextMenuStrip())
            using (var timer=new System.Windows.Forms.Timer()) {
                icon.Icon=System.Drawing.SystemIcons.Application;
                icon.Text="TaskHub · Ctrl x2";
                menu.Items.Add("Test capture",null,delegate { TryWake(icon); });
                menu.Items.Add("Exit TaskHub",null,delegate { Application.ExitThread(); });
                icon.ContextMenuStrip=menu;
                icon.Visible=true;
                timer.Interval=30;
                timer.Tick+=delegate {
                    if (parent!=null && parent.HasExited) { Application.ExitThread(); return; }
                    if (!pending) return;
                    pending=false;
                    Console.WriteLine("KEY: double Ctrl received");
                    TryWake(icon);
                };
                hook=SetWindowsHookEx(13,Callback,GetModuleHandle(null),0);
                if (hook==IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
                try { Console.WriteLine("READY: global Ctrl x2"); timer.Start(); Application.Run(); }
                finally { UnhookWindowsHookEx(hook); }
            }
        }
    }

    private static void TryWake(NotifyIcon icon) {
        try { Wake(); }
        catch (Exception error) { Console.Error.WriteLine("ERROR: " + error.Message); icon.ShowBalloonTip(4000,"TaskHub",error.Message,ToolTipIcon.Warning); }
    }

    public static void SelfTest() {
        var tap=new DoubleTap();
        if (tap.Input(0xA2,true,false,0) || tap.Input(0xA2,false,false,50) ||
            tap.Input(0xA3,true,false,100) || !tap.Input(0xA3,false,false,150))
            throw new Exception("Double Ctrl recognition failed.");
        tap.Input(0xA2,true,false,200);
        tap.Input(0x43,true,false,220);
        tap.Input(0xA2,false,false,240);
        tap.Input(0xA2,true,false,270);
        if (tap.Input(0xA2,false,false,300)) throw new Exception("Ctrl+C triggered capture.");
        tap.Input(0xA2,true,false,350);
        if (tap.Input(0xA2,false,false,700)) throw new Exception("Long press triggered capture.");
        Console.WriteLine("Double Ctrl checks passed.");
    }
}

