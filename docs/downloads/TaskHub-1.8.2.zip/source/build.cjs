const fs = require("node:fs");
const {stripTypeScriptTypes} = require("node:module");
const compile = path => stripTypeScriptTypes(fs.readFileSync(path, "utf8"), {mode:"transform"});
const names = [];
const core = compile("src/core.ts").replace(/^export (const|function) (\w+)/gm, (_, kind, name) => {
  names.push(name);
  return kind + " " + name;
});
const main = compile("src/main.ts")
  .replace(/^import (\{[^}]+\}) from "obsidian";/m, 'const $1 = require("obsidian");')
  .replace(/^import (\{[^}]+\}) from "\.\/core\.ts";/m, 'const $1 = core;')
  .replace(/^export default TaskHub;$/m, "module.exports = TaskHub;");
if (/^(import|export) /m.test(core+"\n"+main) || !main.includes("module.exports = TaskHub;") || !names.length)
  throw new Error("Build entry points changed.");
fs.writeFileSync("main.js", '"use strict";\nconst core = (() => {\n' + core + '\nreturn {' +
  names.join(",") + '};\n})();\n' + main);

