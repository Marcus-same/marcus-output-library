const test=require("node:test");
const assert=require("node:assert/strict");
const fs=require("node:fs");
const vm=require("node:vm");
const path=require("node:path");
const {execFileSync}=require("node:child_process");
const capture=entry=>JSON.stringify({version:1,id:entry.id,source:"test",task:{title:entry.title}});
const draft=title=>({title,category:"",project:"",due:"",priority:""});
class TFolder {constructor(path){this.path=path;}}
class TFile {
  constructor(path){this.path=path;this.basename=path.split("/").at(-1).replace(/\.md$/,"");}
}
class Element {
  constructor(text=""){this.text=text;this.children=[];this.events={};this.value="";this.attributes={};this.isConnected=true;}
  setAttribute(name,value){this.attributes[name]=value;}
  focus(){}
  querySelectorAll(selector){return this.children.flatMap(c=>[...(selector.split(',').includes(c.tag)?[c]:[]),...c.querySelectorAll(selector)]);}
  addClass(){}
  empty(){this.children=[];this.text="";}
  setText(text){this.text=text;}
  createEl(tag,options={}){const node=new Element(options.text);node.tag=tag;node.cls=options.cls;node.value=options.value??"";node.attributes=options.attr??{};this.children.push(node);return node;}
  createDiv(options){return this.createEl("div",options);}
  addEventListener(name,fn){const previous=this.events[name];this.events[name]=previous?event=>{previous(event);fn(event);}:fn;}
  get textContent(){return this.text+this.children.map(el=>el.textContent).join(" ");}
}
function fixture(native={}) {
  const vaultFiles=new Map();
  const queue=new Map();
  const notices=[];
  const commands=new Map();
  const processors=new Map();
  const views=new Map(),modals=[];
  const disposals=[];
  const vault={
    on:()=>null,
    getMarkdownFiles:()=>[...vaultFiles.keys()].filter(p=>p.endsWith(".md")).map(p=>new TFile(p)),
    getAbstractFileByPath:p=>vaultFiles.has(p)?vaultFiles.get(p)===null?new TFolder(p):new TFile(p):null,
    read:async f=>vaultFiles.get(f.path),
    cachedRead:async f=>vaultFiles.get(f.path),
    create:async(p,text)=>{assert(!vaultFiles.has(p));vaultFiles.set(p,text);return new TFile(p);},
    createFolder:async p=>{assert(!vaultFiles.has(p));vaultFiles.set(p,null);},
    process:async (f,fn)=>{vaultFiles.set(f.path,fn(vaultFiles.get(f.path)));},
    adapter:{exists:async()=>true,list:async()=>({files:[...queue.keys()]}),read:async p=>queue.get(p),
      remove:async p=>{if (p.endsWith("hold.taskhub.json")&&queue.fail) throw Error("模拟队列删除失败"); queue.delete(p);}}
  };
  class Plugin {
    manifest={dir:".obsidian/plugins/taskhub"};
    register=fn=>disposals.push(fn);
    app={vault,workspace:{onLayoutReady:cb=>cb(),detachLeavesOfType:()=>{}}};
    loadData=async()=>null;
    saveData=async data=>{this.saved=data;};
    registerView=(name,factory)=>views.set(name,factory);
    addRibbonIcon=()=>{};
    addCommand=cmd=>commands.set(cmd.id,cmd);
    registerMarkdownCodeBlockProcessor=(name,fn)=>processors.set(name,fn);
    addSettingTab=()=>{};
    registerEvent=()=>{};
    registerDomEvent=()=>{};
    registerObsidianProtocolHandler=()=>{};
    registerInterval=()=>{};
  }
  class Notice {constructor(message){notices.push(message);}}
  const obsidian={Plugin,TFolder,TFile,Notice,ItemView:class{contentEl=new Element();registerDomEvent(el,name,fn){el.addEventListener(name,fn);}},
    MarkdownRenderChild:class{constructor(el){this.containerEl=el;}},
    Modal:class{contentEl=new Element();setTitle(){} open(){modals.push(this);this.onOpen();} close(){this.closed=true;this.onClose();}},PluginSettingTab:class{},Setting:class{}};
  const module={exports:{}};
  vm.runInNewContext(fs.readFileSync("main.js","utf8"),{module,require:name=>{
    if(name==="obsidian") return obsidian;
    if(name in native) return native[name];
    if(name==="process") return {platform:"linux"};
    throw Error("Unexpected module: "+name);
  },window:{setInterval:()=>0,setTimeout:()=>0,clearTimeout:()=>{}}});
  return {hub:new module.exports(),vaultFiles,queue,notices,commands,processors,disposals,views,modals};
}

const settle=()=>new Promise(resolve=>setImmediate(resolve));
test("工作台数据未变化时刷新保留列表节点，任务变化后更新列表",async()=>{
  const {hub,views}=fixture();await hub.onload();await hub.save(draft("待处理"));
  const view=views.get("taskhub-workbench")({});await view.onOpen();await settle();
  descendants(view.contentEl).find(node=>node.text==="全部 · 1").events.click();
  const findRow=()=>descendants(view.contentEl).find(node=>node.cls==="taskhub-row");
  const before=findRow();assert(before);
  const refresh=()=>descendants(view.contentEl).find(node=>node.text==="刷新").events.click();
  refresh();await settle();assert.equal(findRow(),before);
  await hub.save(draft("新增任务"));refresh();await settle();
  assert.notEqual(findRow(),before);
  assert(view.contentEl.textContent.includes("新增任务"));
});
test("安排弹窗可把旧版周一三五规则改成每月指定日期",async()=>{
  const {hub,vaultFiles,views,modals}=fixture();
  vaultFiles.set("01-Daily/repeat.md","- [ ] 复盘 📅 2099-01-01 [taskhub-repeat:: mwf]\n");
  await hub.onload();
  const view=views.get("taskhub-workbench")({});await view.onOpen();await settle();
  descendants(view.contentEl).find(node=>node.text==="全部 · 1").events.click();
  descendants(view.contentEl).find(node=>node.text==="安排").events.click();
  const nodes=descendants(modals[0].contentEl);
  const rule=nodes.find(node=>node.tag==="select"&&node.value==="weekly");
  const weekdays=descendants(nodes.find(node=>node.tag==="fieldset")).filter(node=>node.tag==="input");
  assert.deepEqual(weekdays.map(node=>node.checked),[true,false,true,false,true,false,false]);
  rule.value="monthly";rule.events.change();
  nodes.find(node=>node.text==="每月几号").children[0].value="31";
  nodes.find(node=>node.text==="保存重复规则").events.click();await settle();
  const [task]=await hub.tasks();assert.match(task.raw,/taskhub-repeat:: monthly:31/);
  await hub.toggle(task);
  assert((await hub.tasks()).some(row=>row.due==="2099-01-31"));
});
test("编辑内删除需确认，保留同笔记的其他内容",async()=>{
  const {hub,vaultFiles,views,modals}=fixture();
  const path="01-Daily/delete.md";
  const original="# 日记\r\n- [ ] 待删除\r\n- [ ] 保留\r\n正文\r\n";
  vaultFiles.set(path,original);await hub.onload();
  const view=views.get("taskhub-workbench")({});await view.onOpen();await settle();
  descendants(view.contentEl).find(node=>node.text==="全部 · 2").events.click();
  descendants(view.contentEl).find(node=>node.text==="编辑").events.click();
  const button=text=>descendants(modals[0].contentEl).find(node=>node.tag==="button"&&node.text===text);
  button("删除任务").events.click();button("取消").events.click();
  assert.equal(vaultFiles.get(path),original);
  button("删除任务").events.click();button("确认删除").events.click();await settle();
  assert.equal(vaultFiles.get(path),"# 日记\r\n- [ ] 保留\r\n正文\r\n");
});
test("删除拒绝覆盖原文变化，保护子任务；每日习惯使用现有重复规则",async()=>{
  const {hub,vaultFiles}=fixture();
  const path="01-Daily/delete.md";
  const original="- [ ] 父任务\n    - [ ] 子任务\n";
  vaultFiles.set(path,original);
  const [parent,child]=await hub.tasks();
  await assert.rejects(hub.deleteTask(parent),/有子任务/);
  vaultFiles.set(path,original.replace("子任务","改过的步骤"));
  await assert.rejects(hub.deleteTask(child),/原文已变更/);
  await hub.createHabit("整理收集箱");
  const habit=(await hub.tasks()).find(task=>task.title.includes("整理收集箱"));
  assert.match(habit.raw,/taskhub-repeat:: daily/);
  await hub.toggle(habit);
  assert.equal((await hub.tasks()).filter(task=>task.title.includes("整理收集箱")).length,2);
});
test("重复任务完成时只生成一次后续任务",async()=>{
  const {hub,vaultFiles}=fixture();
  const path="01-Daily/repeat.md";
  const original="- [ ] 日常复盘 📅 2099-01-01 [taskhub-repeat:: daily]\r\n";
  vaultFiles.set(path,original);
  const [task]=await hub.tasks();
  await hub.toggle(task);
  const rows=await hub.tasks();
  assert.equal(rows.length,2);assert.equal(rows[0].status,"x");assert.equal(rows[1].due,"2099-01-02");
  await assert.rejects(hub.toggle(task),/原文已变更/);
  assert.equal((await hub.tasks()).length,2);
});
test("模板原子写入清单，时间块不覆盖截止日期",async()=>{
  const {hub}=fixture();await hub.createFromTemplate("出差准备",["确认航班","核对材料"]);
  let [parent,...children]=await hub.tasks();
  assert.equal(children.length,2);assert(children.every(child=>child.raw.startsWith("    - [ ]")));
  await hub.updateField(parent,"block","2026-11-12 09:00 30");
  [parent]=await hub.tasks();assert.equal(parent.due,"");assert.match(parent.raw,/taskhub-block:: 2026-11-12 09:00 30/);
  await assert.rejects(hub.updateField(parent,"block","2026-11-12 23:50 30"),/跨午夜/);
});
test("提醒只通知近期到点未完成任务，当前会话不重复",async()=>{
  const {hub,vaultFiles,notices}=fixture();
  vaultFiles.set("01-Daily/test.md",[
    "- [ ] 面试 📅 2026-11-12 [taskhub-time:: 14:30]",
    "- [ ] 旧任务 📅 2026-11-12 [taskhub-time:: 13:00]",
    "- [ ] 全天 📅 2026-11-12",
    "- [x] 已完成 📅 2026-11-12 [taskhub-time:: 14:30]"
  ].join("\n"));
  const now=new Date(2026,10,12,14,30,5);
  await hub.checkReminders(now);assert.equal(notices.length,0);
  await hub.updateSettings({...hub.settings,reminders:true});
  await hub.checkReminders(now);await hub.checkReminders(now);
  assert.deepEqual(notices,["任务到期 · 14:30 · 面试"]);
});
test("录入先预览日期时间，经确认后才写入任务",async()=>{
  const {hub,commands,modals}=fixture();await hub.onload();commands.get("capture").callback();
  const form=modals[0].contentEl.children[0];
  const title=descendants(form).find(n=>n.tag==="input");
  title.value="2026-11-13 下午3点交报告";title.events.input();
  assert.equal((await hub.tasks()).length,0);
  descendants(form).find(n=>n.text==="应用日期时间").events.click();
  form.events.submit({preventDefault(){}});await settle();
  const [task]=await hub.tasks();
  assert.equal(task.title,"交报告 #task");assert.equal(task.due,"2026-11-13");assert.equal(task.time,"15:00");
});
test("联动日记和项目原文，编辑完成回写且不复制；备份覆盖所有来源",async()=>{
  const {hub,vaultFiles}=fixture();
  const daily="01-Daily/旧日记.md",project="06-工作/招聘/进度.md";
  vaultFiles.set(daily,"# 日记\r\n- [ ] 约面试\r\n保留段落\r\n");
  vaultFiles.set(project,"- [ ] 跟进候选人");
  vaultFiles.set("20-Actions/_行动卡模板.md","- [ ] 模板");
  assert.equal((await hub.tasks()).length,2);
  const t=(await hub.tasks()).find(t=>t.path===daily);
  await hub.save({...draft("约面试"),due:"2026-11-12",time:"14:30"},t);
  const edited=(await hub.tasks()).find(t=>t.path===daily);await hub.toggle(edited);
  assert(vaultFiles.get(daily).includes("- [x] 约面试"));
  assert(vaultFiles.get(daily).endsWith("保留段落\r\n"));
  assert.equal((await hub.tasks(hub.settings.folder)).length,0);
  const backup=JSON.parse(vaultFiles.get(await hub.backup()));
  assert.equal(backup.notes.length,2);
  await hub.updateSettings({...hub.settings,linkedFolders:"01-Daily\n01-Daily"});
  assert.equal((await hub.tasks()).length,1);
  await assert.rejects(hub.toggle((await hub.tasks("06-工作"))[0]),/已移动/);
});
const descendants=el=>[el,...el.children.flatMap(descendants)];
test("工作台视图数量、组合筛选、空状态清除及项目录入上下文",async()=>{
  const {hub,views,modals}=fixture(); await hub.onload();
  await hub.save({...draft("联系候选人"),project:"FDE",priority:"⏫"});
  await hub.save(draft("买牛奶"));
  const view=views.get("taskhub-workbench")({});await view.onOpen();await settle();
  const nodes=()=>descendants(view.contentEl);
  const button=text=>nodes().find(n=>n.tag==="button"&&n.text===text);
  button("项目 · 1").events.click();
  assert(view.contentEl.textContent.includes("联系候选人"));
  assert(!view.contentEl.textContent.includes("买牛奶"));
  const project=nodes().find(n=>n.attributes['aria-label']==="项目"); project.value="FDE";
  const toolbar=nodes().find(n=>n.cls==="taskhub-toolbar");toolbar.events.change();
  button("＋ 新建任务").events.click();
  assert(descendants(modals[0].contentEl).some(n=>n.tag==="input"&&n.value==="FDE"));
  const search=nodes().find(n=>n.attributes['aria-label']==="搜索任务"); search.value="没有这个任务";search.events.input();
  assert(view.contentEl.textContent.includes("没有匹配的任务"));
  button("清除筛选").events.click();
  assert(view.contentEl.textContent.includes("联系候选人"));
  await view.onClose();
});
test("连续录入保留分类且不丢失败草稿，重复提交不会重复写入",async()=>{
  const {hub,commands,modals}=fixture();await hub.onload();commands.get("capture").callback();
  const modal=modals[0],form=modal.contentEl.children[0];
  const controls=descendants(form),inputs=controls.filter(n=>n.tag==="input");
  inputs[0].value="第一项";inputs[0].events.input();inputs[1].value="招聘";inputs[1].events.input();
  inputs.at(-1).checked=true;
  form.events.submit({preventDefault(){}});form.events.submit({preventDefault(){}});await settle();
  assert.equal((await hub.tasks()).length,1);assert.equal(inputs[0].value,"");assert.equal(inputs[1].value,"招聘");assert(!modal.closed);
  inputs[0].value="第一项";inputs[0].events.input();form.events.submit({preventDefault(){}});await settle();
  assert.equal(inputs[0].value,"第一项");assert.equal((await hub.tasks()).length,1);
  assert(form.textContent.includes("已有同内容"));
});

test("global helper uses CommonJS without window.require and reports lifecycle",async()=>{
  const {EventEmitter}=require("node:events");
  const child=new EventEmitter();
  child.stdout=new EventEmitter(); child.stderr=new EventEmitter(); child.exitCode=null;
  let killed=false, spawned;
  child.kill=()=>{killed=true;};
  const {hub,commands,notices,disposals}=fixture({process:{platform:"win32",pid:42},path,
    child_process:{spawn:(...args)=>{spawned=args;return child;}}});
  hub.app.vault.adapter.getBasePath=()=>"C:/Vault";
  await hub.onload();
  assert.equal(spawned[0],path.join("C:/Vault",".obsidian/plugins/taskhub","TaskHub-Wake.exe"));
  assert.equal(spawned[1].join(" "),"--parent 42");
  assert.equal(spawned[2].windowsHide,true);
  child.stdout.emit("data",Buffer.from("READY: global Ctrl x2"));
  commands.get("global-hotkey-status").callback();
  assert(notices.includes("READY: global Ctrl x2"));
  child.emit("error",Error("ENOENT"));
  commands.get("global-hotkey-status").callback();
  assert(notices.at(-1).includes("ENOENT"));
  child.emit("exit",2);
  assert(notices.at(-1).includes("旧版"));
  disposals.forEach(fn=>fn());
  assert(killed);
});

test("修改设置与任务写入按提交顺序执行",async()=>{
  const {hub}=fixture();
  await Promise.all([hub.save(draft("旧目录任务")),hub.updateSettings({...hub.settings,folder:"新任务"}),hub.save(draft("新目录任务"))]);
  assert.equal((await hub.tasks())[0].title,"新目录任务 #task");
  assert.equal((await hub.tasks("00-任务中枢/待办库"))[0].title,"旧目录任务 #task");
});
test("导入过程中队列文件改变时保留新内容",async()=>{
  const {hub,queue}=fixture();
  const name=hub.settings.queue+"/changed.taskhub.json";
  queue.set(name,capture({id:"first-id",title:"第一条"}));
  const read=hub.app.vault.adapter.read;
  let reads=0;
  hub.app.vault.adapter.read=async p=>{
    if (++reads===2) queue.set(name,capture({id:"second-id",title:"第二条"}));
    return read(p);
  };
  await hub.importQueue(true);
  assert(queue.has(name));
  await hub.importQueue(true);
  assert.equal((await hub.tasks()).length,2);
  assert.equal(queue.size,0);
});
test("大小写不同的库目录保持独立",async()=>{
  const {hub,vaultFiles}=fixture();
  vaultFiles.set("Tasks/a.md","- [ ] A");
  vaultFiles.set("tasks/a.md","- [ ] B");
  assert.equal((await hub.tasks("Tasks")).length,1);
});

test("插件入口注册命令和查询；原地接管先备份，旧笔记逐字保留",async()=>{
  const {hub,vaultFiles,commands,processors}=fixture();
  await hub.onload();
  assert(commands.has("capture") && commands.has("migrate") && commands.has("insert-query"));
  assert(processors.has("taskhub"));
  const legacy="旧待办/2026-11.md";
  const content="# 原笔记\r\n\r\n- [ ] 面试 #招聘 📅 2026-11-11\r\n";
  vaultFiles.set(legacy,content);
  const result=await hub.migrate("旧待办");
  assert.equal(result.count,1);
  assert.equal(hub.saved.folder,"旧待办");
  assert.equal(vaultFiles.get(legacy),content);
  assert.equal(JSON.parse(vaultFiles.get(result.backup)).notes[0].content,content);
  assert.equal((await hub.tasks()).length,1);
});

test("序列化并发录入、去重、原位更新和完成",async()=>{
  const {hub,vaultFiles}=fixture();
  const result=await Promise.allSettled([hub.save(draft("候选人")),hub.save(draft("候选人"))]);
  assert.deepEqual(result.map(r=>r.status),["fulfilled","rejected"]);
  let [task]=await hub.tasks();
  await hub.save({...draft("更新候选人"),category:"招聘",project:"FDE"},task);
  await assert.rejects(hub.toggle(task),/已变更/);
  [task]=await hub.tasks();
  assert.equal(task.project,"FDE");
  await hub.toggle(task);
  assert.match(vaultFiles.get(task.path),/\[x\] 更新候选人.*✅/);
});

test("Windows 队列重试幂等；格式异常和重复条目保留",async()=>{
  const {hub,queue,notices}=fixture();
  const key=hub.settings.queue+"/";
  queue.set(key+"hold.taskhub.json",capture({id:"unique-id",title:"同步任务"}));
  queue.set(key+"bad.taskhub.json","{");
  queue.fail=true;
  await hub.importQueue(true);
  assert.equal((await hub.tasks()).length,1);
  assert.equal(queue.size,2);
  queue.fail=false;
  queue.set(key+"repeat.taskhub.json",capture({id:"other-id",title:"同步任务"}));
  await hub.importQueue(true);
  assert.equal((await hub.tasks()).length,1);
  assert.equal(queue.size,2);
  assert(!queue.has(key+"hold.taskhub.json"));
  assert(notices.some(n=>n.includes("任务重复")));
});

test("迁移备份失败时保留旧目录设置",async()=>{
  const {hub,vaultFiles}=fixture();
  vaultFiles.set("迁移测试/2026-11.md","- [ ] 保留");
  vaultFiles.set(hub.settings.backups,"已有文件冲突");
  const before=hub.settings.folder;
  await assert.rejects(hub.migrate("迁移测试"),/占用了目录/);
  assert.equal(hub.settings.folder,before);
  assert.equal(vaultFiles.get("迁移测试/2026-11.md"),"- [ ] 保留");
});

test("两处动态查询读取同一条任务，完成后共用源数据",async()=>{
  const {hub,processors}=fixture();
  await hub.onload();
  await hub.save({...draft("确认复试"),project:"FDE"});
  const nodes=[new Element(),new Element()];
  const children=nodes.map(el=>{
    let child;
    processors.get("taskhub")("scope: 项目\nproject: FDE",el,{addChild(value){child=value;}});
    child.onload();
    return child;
  });
  await new Promise(resolve=>setImmediate(resolve));
  assert(nodes.every(el=>el.textContent.includes("确认复试")));
  assert.equal((await hub.tasks()).length,1);
  const toggle=nodes[0].children[1].children[0].children[0];
  toggle.events.change();
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal((await hub.tasks())[0].status,"x");
  children.forEach(child=>child.onunload());
  hub.onunload();
});

test("Windows PowerShell 写出的 UTF-8 队列文件可由实际构建包导入",{
  skip:process.platform!=="win32"
},async()=>{
  const {hub,vaultFiles,queue}=fixture();
  const root=fs.mkdtempSync(path.join(process.cwd(),"TaskHub-Test-"));
  const config=path.join(root,".obsidian");
  const queueFolder=path.join(root,...hub.settings.queue.split("/"));
  const launcher=path.resolve("windows/TaskHub-Capture.ps1");
  const powerShell=path.join(process.env.SystemRoot,"System32","WindowsPowerShell","v1.0","powershell.exe");
  fs.mkdirSync(config);
  try {
    execFileSync(powerShell,["-NoProfile","-STA","-File",launcher,"-SelfTest","-Vault",root]);
    const files=fs.readdirSync(queueFolder);
    assert.equal(files.length,1);
    assert.match(files[0],/\.taskhub\.json$/);
    queue.set(hub.settings.queue+"/"+files[0],fs.readFileSync(path.join(queueFolder,files[0]),"utf8"));
    await hub.importQueue(true);
    const [task]=await hub.tasks();
    assert.match(vaultFiles.get(task.path),/验证中文录入.*#招聘.*#项目\/FDE.*⏫.*2026-11-12/);
    assert.equal(queue.size,0);
  } finally {
    if (fs.existsSync(queueFolder)) {
      for (const file of fs.readdirSync(queueFolder)) fs.unlinkSync(path.join(queueFolder,file));
      fs.rmdirSync(queueFolder);
      fs.rmdirSync(path.dirname(queueFolder));
    }
    fs.rmdirSync(config);
    fs.rmdirSync(root);
  }
});

