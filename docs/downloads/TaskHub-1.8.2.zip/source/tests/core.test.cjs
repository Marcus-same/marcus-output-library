const test=require("node:test");
const assert=require("node:assert/strict");
const fs=require("node:fs");
const {stripTypeScriptTypes}=require("node:module");
const source=stripTypeScriptTypes(fs.readFileSync("src/core.ts","utf8"),{mode:"transform"});
const core=import("data:text/javascript;base64,"+Buffer.from(source).toString("base64"));
const path="00-任务中枢/待办库/2026-11.md";
const date="2026-11-11";
test("完成时间可搜索、按新到旧排序，取消勾选时移除",async()=>{
  const c=await core;
  const path="tasks.md";
  const [open]=c.parseNote("- [ ] 回访 ^source",path);
  const completed=c.completionLine(open,date,"14:35");
  const [task,older]=c.parseNote(completed+"\n- [x] 旧任务 ✅ "+date,path);
  assert.equal(c.completionStamp(task),date+" 14:35");
  assert.equal(c.completionStamp(older),date);
  assert.deepEqual(c.filterTasks([older,task],{scope:"已完成"},date),[task,older]);
  assert.deepEqual(c.filterTasks([older,task],{scope:"已完成",search:date+" 14:35"},date),[task]);
  assert.equal(c.completionLine(task,date,"15:00"),open.raw);
});
test("自定义周规则、跨月、短月和闰年",async()=>{
  const c=await core;
  assert.equal(c.nextRepeatDate("weekly:2,4","2026-11-12"),"2026-11-17");
  assert.equal(c.nextRepeatDate("weekly:0","2026-11-12"),"2026-11-15");
  assert.equal(c.nextRepeatDate("monthly:15","2026-11-12"),"2026-11-15");
  assert.equal(c.nextRepeatDate("monthly:31","2026-01-31"),"2026-03-31");
  assert.equal(c.nextRepeatDate("monthly:29","2028-01-29"),"2028-02-29");
  assert.equal(c.nextRepeatDate("mwf","2026-11-13"),"2026-11-16");
  assert.equal(c.validRepeatRule("weekly:1,1"),false);
  assert.throws(()=>c.nextRepeatDate("monthly:32","2026-01-31"),/未知重复规则/);
});

test("邮件读取折行编码主题，不把正文或附件当作主题",async()=>{
  const c=await core;
  const encoded=Buffer.from("面试确认").toString("base64");
  assert.equal(c.emailSubject(`From: test@example.com\r\nSubject: =?UTF-8?B?${encoded}?=\r\n  =?UTF-8?Q?_Friday?=\r\n\r\nSubject: 正文`),"面试确认 Friday");
  assert.throws(()=>c.emailSubject("From: sender\n\nSubject: 正文"),/缺少 Subject/);
});

test("中文录入日期和时分，跨周跨月及拒绝非法时间",async()=>{
  const c=await core;
  const now=new Date(2026,10,12,10);
  assert.deepEqual(c.parseQuickTitle("周五下午3点交报告",now),{title:"交报告",due:"2026-11-13",time:"15:00"});
  assert.deepEqual(c.parseQuickTitle("下周一 09:30 确认面试",now),{title:"确认面试",due:"2026-11-16",time:"09:30"});
  assert.equal(c.parseQuickTitle("明天买牛奶",new Date(2026,11,31)).due,"2027-01-01");
  assert.equal(c.parseQuickTitle("明天25:30交报告",now),null);
  assert.equal(c.parseQuickTitle("2026-02-30交报告",now),null);
  assert.equal(c.parseQuickTitle("周五下午3点",now),null);
});

test("时间读写、清除、完成往返与精确逾期边界",async()=>{
  const c=await core;
  const d={title:"面试",category:"招聘",project:"FDE",due:date,time:"09:30",priority:""};
  const raw=c.renderLine(d,"#task",undefined,"unique-time-id");
  const t=c.parseLine(raw,path,0);
  assert.equal(t.time,"09:30");assert(!t.title.includes("taskhub-time"));
  assert.equal(c.filterTasks([t],{scope:"逾期"},date,"09:29").length,0);
  assert.equal(c.filterTasks([t],{scope:"逾期"},date,"09:30").length,0);
  assert.equal(c.filterTasks([t],{scope:"逾期"},date,"09:31").length,1);
  assert.equal(c.parseLine(c.completionLine(t,date),path,0).time,"09:30");
  const edited=c.renderLine({...c.draftOf(t),time:"14:00"},"#task",t);
  assert.equal(c.parseLine(edited,path,0).time,"14:00");assert(edited.endsWith("^taskhub-unique-time-id"));
  assert(!c.renderLine({...c.draftOf(t),time:""},"#task",t).includes("taskhub-time"));
  assert.throws(()=>c.validateDraft({...d,due:""}));assert.throws(()=>c.validateDraft({...d,time:"24:00"}));
  assert.equal(c.isDuplicate([t],{...c.draftOf(t),time:"10:00"},"#task"),false);
  const allDay=c.parseLine("- [ ] 全天 📅 "+date,path,1);
  assert.equal(c.filterTasks([allDay],{scope:"逾期"},date,"23:59").length,0);
});

test("正常优先级位于中与低之间",async()=>{
  const c=await core;
  const tasks=c.parseNote(["- [ ] 普通","- [ ] 最低 ⏬","- [ ] 低 🔽","- [ ] 中 🔼","- [ ] 高 ⏫","- [ ] 最高 🔺"].join("\n"),path);
  assert.deepEqual(c.filterTasks(tasks,{},date).map(t=>t.title),["最高","高","中","普通","低","最低"]);
});
test("多分类编辑拒绝丢标签；Dataview 取消状态；Windows 保留名称",async()=>{
  const c=await core;
  const t=c.parseLine("- [ ] 面试 #分类/招聘 #category/工作",path,0);
  assert.equal(c.renderLine(c.draftOf(t),"#task",t),t.raw);
  assert.throws(()=>c.renderLine({...c.draftOf(t),due:date},"#task",t),/多个分类/);
  const cancelled=c.parseLine("- [ ] 已取消 [cancelled:: 2026-11-11]",path,0);
  assert(c.finished(cancelled));
  assert.throws(()=>c.completionLine(cancelled,date));
  for(const name of ["CON","a/NUL.txt","LPT1","COM9/x"]) assert.throws(()=>c.safePath(name));
});

test("v1.4 推断样例：平铺招聘标签、截止日期、优先级及块 ID",async()=>{
  const c=await core;
  const raw="- [ ] 确认 FDE 复试时间 #招聘 #project/FDE招聘 ⏫ 📅 2026-11-11 ^legacy-1";
  const [t]=c.parseNote(raw,path);
  assert.deepEqual(c.draftOf(t),{title:"确认 FDE 复试时间",category:"招聘",project:"FDE招聘",priority:"⏫",due:date,time:""});
  assert.equal(c.renderLine(c.draftOf(t),"#task",t),raw);
  const revised=c.renderLine({...c.draftOf(t),due:"2026-11-12"},"#task",t);
  assert.match(revised,/#招聘 #project\/FDE招聘/);
  assert.match(revised,/\^legacy-1$/);
  assert.equal(c.parseLine(revised,path,0).due,"2026-11-12");
});

test("更新一行保留 CRLF、未知 Tasks 元数据、ID、相邻笔记",async()=>{
  const c=await core;
  const line="  * [ ] 更新资料 #cat/工作 🔁 every week 🆔 abc ⛔ def 🛫 2026-11-09 📅 2026-11-11 ^reference";
  const content="# 保留\r\n"+line+"\r\n后续说明\r\n";
  const [t]=c.parseNote(content,path);
  const revision=c.renderLine({...c.draftOf(t),title:"更新报价",priority:"🔺",due:""},"#task",t);
  assert.equal(c.replaceLine(content,t,revision),"# 保留\r\n"+revision+"\r\n后续说明\r\n");
  assert.match(revision,/🔁 every week 🆔 abc ⛔ def 🛫 2026-11-09 \^reference$/);
  assert.doesNotMatch(revision,/📅/);
  assert.throws(()=>c.completionLine(t,date),/循环任务/);
  assert.throws(()=>c.replaceLine(content+line,t,revision),/相同记录/);
  assert.throws(()=>c.replaceLine(content.replace("更新资料","手工修改"),t,revision),/已变更/);
});

test("忽略 YAML、代码块和 HTML 注释；保留嵌套和编号任务",async()=>{
  const c=await core;
  const fence=String.fromCharCode(96).repeat(3);
  const content=["---","- [ ] hidden","---",fence+"tasks","- [ ] 示例",fence,"<!--",
    "- [ ] 说明","-->","  + [ ] 子任务","3. [X] 已完成"].join("\n");
  assert.deepEqual(c.parseNote(content,path).map(t=>[t.line,t.title]),[[9,"子任务"],[10,"已完成"]]);
});

test("录入兼容全局标记与外部块 ID，完成与撤销保留 ID",async()=>{
  const c=await core;
  const draft={title:"安排面试",category:"招聘",project:"FDE",due:date,priority:"⏫"};
  const line=c.renderLine(draft,"#task",undefined,"abcd1234");
  const t=c.parseLine(line,path,0);
  assert.deepEqual(t.ids,["abcd1234"]);
  assert.match(line,/#task #分类\/招聘 #招聘 #项目\/FDE ⏫ 📅 2026-11-11 \^taskhub-abcd1234$/);
  const done=c.completionLine(t,date);
  assert.match(done,/\[x\].*✅ 2026-11-11 \^taskhub-abcd1234$/);
  assert.equal(c.completionLine(c.parseLine(done,path,0),date),line);
  assert.equal(c.isDuplicate([t],draft,"#task"),true);
  assert.equal(c.isDuplicate([t],{...draft,project:"Other"},"#task"),false);
});

test("筛选、分类、普通优先级与查询错误",async()=>{
  const c=await core;
  const tasks=c.parseNote(["- [ ] 今日 #招聘 #项目/FDE 📅 2026-11-11",
    "- [ ] 早 📅 2026-11-10","- [ ] 未整理","- [x] 旧记录"].join("\n"),path);
  for (const [scope,expected] of Object.entries({"今天":["今日"],"逾期":["早"],"收集箱":["早","未整理"],"项目":["今日"],"已完成":["旧记录"]})) {
    assert.deepEqual(c.filterTasks(tasks,{scope},date).map(t=>t.title),expected);
  }
  const query=c.parseQuery("scope: 项目\nproject: FDE\ncategory: 招聘\npriority: none");
  assert.deepEqual(c.filterTasks(tasks,query,date).map(t=>t.title),["今日"]);
  assert.throws(()=>c.parseQuery("scope: tomorrow"));
  assert.throws(()=>c.parseQuery("constructor: x"));
});

test("校验日期、队列与库内路径",async()=>{
  const c=await core;
  assert.equal(c.validDate("2024-02-29"),true);
  assert.equal(c.validDate("2026-02-29"),false);
  for (const p of ["../notes","D:/notes","/notes",".obsidian/plugins","a//b"]) assert.throws(()=>c.safePath(p));
  assert.equal(c.safePath("项目\\待办/"),"项目/待办");
  assert.throws(()=>c.parseCapture('{"version":2}'));
  assert.throws(()=>c.parseCapture(JSON.stringify({version:1,id:"valid-id",source:"windows",task:{title:"a",priority:1}})));
  const envelope={version:1,id:"valid-id",source:"windows",task:{title:"候选人跟进",category:"招聘",project:"FDE 校招"}};
  assert.equal(c.parseCapture("\uFEFF"+JSON.stringify(envelope)).task.project,"FDE_校招");
});

