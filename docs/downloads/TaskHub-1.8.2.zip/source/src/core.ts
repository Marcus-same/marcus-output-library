export const priorities = ["", "🔺", "⏫", "🔼", "🔽", "⏬"] as const;
export type Scope = "今天" | "逾期" | "收集箱" | "项目" | "全部" | "已完成";
export type Draft = {title: string; category: string; project: string; priority: string; due: string; time?: string};
export type Query = {scope?: Scope; category?: string; project?: string; priority?: string; search?: string};
export type Task = Draft & {
  path: string; line: number; raw: string; prefix: string; status: string;
  body: string; metadata: string; ids: string[]; recurring: boolean;
};
export type Capture = {version: 1; id: string; source: string; task: Draft};
export const scopes: Scope[] = ["今天", "逾期", "收集箱", "项目", "全部", "已完成"];
const checkbox = /^(\s*(?:[-+*]|\d+[.)])\s+\[)([^\]\r\n])(\]\s+)(.+)$/u;
const tag = /(^|\s)#(分类|category|cat|项目|project)\/([\p{L}\p{M}\p{N}_/-]+)/giu;
const flatCategory = /(^|\s)#(招聘|工作|人事|行政|财务|学习|个人|生活|收集箱|收件箱|未分类|inbox)(?=\s|$)/giu;
const symbols = "(?:🔺|⏫|🔼|🔽|⏬)";
const dateField = /(?:^|\s)([📅📆🗓]️?\s*(\d{4}-\d{2}-\d{2})|\[due::\s*(\d{4}-\d{2}-\d{2})\s*\])/gu;
const markers = new RegExp("(^|\\s)(" + symbols + "|[📅📆🗓🛫⏳➕✅❌]️?\\s*\\d{4}-\\d{2}-\\d{2}|🔁|🆔|⛔|🏁|\\[(?:taskhub-time|taskhub-repeat|taskhub-block|taskhub-board|due|priority|scheduled|start|created|completion|done|cancelled|repeat|recurrence|id|dependsOn)::|<!-- taskhub-id:|\\^[\\w-]+\\s*$)", "u");
const inlinePriorities: Record<string, string> = {highest:"🔺",high:"⏫",medium:"🔼",low:"🔽",lowest:"⏬"};
const idPattern = /<!-- taskhub-id:([a-z0-9-]{8,80}) -->/g;
const blockId = /(?:^|\s)\^taskhub-([a-z0-9-]{8,80})\s*$/;

export function localDay(d = new Date()): string {
  return [d.getFullYear(), d.getMonth()+1, d.getDate()].map(v => String(v).padStart(2,"0")).join("-");
}
export function validDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const d = new Date(value+"T00:00:00Z");
  return Number.isFinite(d.getTime()) && d.toISOString().slice(0,10) === value;
}
export function emailSubject(text:string) {
  const headers=text.replace(/^\uFEFF/,"").split(/\r?\n\r?\n/,1)[0].replace(/\r?\n[ \t]+/g," ");
  const subject=headers.match(/^subject:[ \t]*(.*)$/im)?.[1];
  if(!subject) throw new Error("邮件缺少 Subject 标题。请选择导出的 .eml 邮件文件。");
  const decoded=subject.replace(/(\?=)\s+(?==\?)/g,"$1").replace(/=\?([^?]+)\?([bq])\?([^?]*)\?=/gi,(word,charset,encoding,data)=>{
    try {
      const bytes=encoding.toLowerCase()==="b"?atob(data):data.replace(/_/g," ").replace(/=([0-9a-f]{2})/gi,(_match,hex)=>String.fromCharCode(parseInt(hex,16)));
      return new TextDecoder(charset,{fatal:true}).decode(Uint8Array.from(bytes,c=>c.charCodeAt(0)));
    } catch {return word;}
  });
  const result=decoded.replace(/[\r\n\0]/g," ").trim().slice(0,500);
  if(!result) throw new Error("邮件主题为空");
  return result;
}
export const repeatRules=["daily","mwf","month-end"] as const;
export function validRepeatRule(rule:string) {
  if(repeatRules.some(value=>value===rule)) return true;
  if(/^monthly:(?:[1-9]|[12]\d|3[01])$/.test(rule)) return true;
  if(!/^weekly:[0-6](?:,[0-6]){0,6}$/.test(rule)) return false;
  const days=rule.slice(7).split(",");
  return new Set(days).size===days.length;
}
export function nextRepeatDate(rule:string, after:string) {
  if (!validDate(after)) throw new Error("重复任务需要有效的截止日期");
  if (!validRepeatRule(rule)) throw new Error("未知重复规则");
  const date=new Date(after+"T12:00:00");
  if(rule==="daily") date.setDate(date.getDate()+1);
  else if(rule==="mwf"||rule.startsWith("weekly:")) {
    const weekdays=rule==="mwf"?[1,3,5]:rule.slice(7).split(",").map(Number);
    do {date.setDate(date.getDate()+1);} while(!weekdays.includes(date.getDay()));
  } else if(rule.startsWith("monthly:")) {
    const day=Number(rule.slice(8));
    for(let offset=0;offset<=12;offset++) {
      const candidate=new Date(date.getFullYear(),date.getMonth()+offset,day,12);
      if(candidate.getDate()===day && candidate>date) return localDay(candidate);
    }
    throw new Error("未找到下一次月度日期");
  } else if(rule==="month-end") {
    const end=(offset:number)=>{
      const result=new Date(date.getFullYear(),date.getMonth()+offset+1,0,12);
      while([0,6].includes(result.getDay())) result.setDate(result.getDate()-1);
      return result;
    };
    return localDay(end(0))>after?localDay(end(0)):localDay(end(1));
  }
  return localDay(date);
}
export function taskField(task:Task,key:string) {
  return task.metadata.match(new RegExp("\\[taskhub-"+key+"::\\s*([^\\]\\r\\n]+)\\]"))?.[1].trim()??"";
}
export function setTaskField(task:Task,key:string,value:string) {
  const raw=task.raw.replace(new RegExp("[ \\t]*\\[taskhub-"+key+"::[^\\]\\r\\n]*\\]","g"),"");
  if (!value) return raw;
  const tail=raw.match(/\s+\^[\w-]+\s*$/)?.index??raw.length;
  return raw.slice(0,tail)+" [taskhub-"+key+":: "+value+"]"+raw.slice(tail);
}
export function parseQuickTitle(value:string, now=new Date()) {
  const match=value.trim().match(/^(今天|明天|后天|(?:本|下)?周[一二三四五六日天]|\d{4}-\d{2}-\d{2})\s*(.*)$/u);
  if (!match) return null;
  const [, dateWord, rest]=match;
  const date=new Date(now);
  if (/^\d/.test(dateWord) && !validDate(dateWord)) return null;
  if (dateWord.endsWith("天") && ["今天","明天","后天"].includes(dateWord)) {
    date.setDate(date.getDate()+["今天","明天","后天"].indexOf(dateWord));
  } else if (dateWord.includes("周")) {
    const weekday="一二三四五六日".indexOf(dateWord.at(-1)!.replace("天","日"));
    const offset=weekday-((date.getDay()+6)%7);
    const weeks=dateWord.startsWith("下") || (!dateWord.startsWith("本") && offset<0) ? 7 : 0;
    date.setDate(date.getDate()+offset+weeks);
  }
  const due=/^\d/.test(dateWord)?dateWord:localDay(date);
  let title=rest.trim(),time="";
  const clock=title.match(/^(上午|下午|晚上|中午|早上)?\s*(\d{1,2})(?::(\d{2})|[点时](半|\d{1,2}分)?)(?!\d)\s*/u);
  if (clock) {
    let hour=Number(clock[2]);
    const minute=clock[4]==="半"?30:Number(clock[3]??clock[4]?.slice(0,-1)??0);
    if (minute>59 || hour>23 || (clock[1] && (hour<1 || hour>12))) return null;
    if (["下午","晚上","中午"].includes(clock[1]) && hour<12) hour+=12;
    if (["上午","早上"].includes(clock[1]) && hour===12) hour=0;
    time=String(hour).padStart(2,"0")+":"+String(minute).padStart(2,"0");
    title=title.slice(clock[0].length).trim();
  }
  return title ? {title,due,time} : null;
}
function tagsIn(text: string) {
  return Array.from(text.matchAll(tag));
}
function clean(text: string): string {
  return text.replace(/\s{2,}/g," ").trim();
}
export function parseLine(raw: string, path: string, line: number): Task | null {
  const match = raw.match(checkbox);
  if (!match) return null;
  const [, prefix, status,,body] = match;
  const cut = body.search(markers);
  const leading = cut < 0 ? body : body.slice(0,cut);
  const metadata = cut < 0 ? "" : body.slice(cut).trim();
  const tags = tagsIn(body);
  const namespacedCategory = tags.find(t => /^(分类|category|cat)$/i.test(t[2]))?.[3];
  const flat = namespacedCategory ? undefined : Array.from(body.matchAll(flatCategory))[0]?.[2];
  const category = namespacedCategory ?? flat ?? "";
  const project = tags.find(t => /^(项目|project)$/i.test(t[2]))?.[3] ?? "";
  const date = Array.from(body.matchAll(dateField))[0];
  const dateValue = date?.[2] ?? date?.[3] ?? "";
  const priority = metadata.match(new RegExp("(?:^|\\s)("+symbols+")(?=\\s|$)","u"))?.[1]
    ?? inlinePriorities[metadata.match(/\[priority::\s*(\w+)\s*\]/i)?.[1]?.toLowerCase() ?? ""] ?? "";
  const title = leading.replace(tag,"$1").replace(flatCategory,(full,space,name)=>name===category ? space : full).trim();
  if (!title) return null;
  return {path,line,raw,prefix,status,body,title,metadata,category,project,
    due: validDate(dateValue) ? dateValue : "",priority,
    time:body.match(/\[taskhub-time::\s*((?:[01]\d|2[0-3]):[0-5]\d)\s*\]/)?.[1]??"",
    ids:[...Array.from(body.matchAll(idPattern), m=>m[1]),body.match(blockId)?.[1]].filter((v):v is string=>!!v),
    recurring:/🔁|\[(?:repeat|recurrence)::/iu.test(metadata)};
}
export function parseNote(text: string, path: string): Task[] {
  const tasks: Task[] = [];
  let fence = "";
  let comment = false;
  let frontmatter = false;
  text.split(/\r?\n/).forEach((line,i)=>{
    if (i===0 && /^\uFEFF?---\s*$/.test(line)) { frontmatter=true; return; }
    if (frontmatter) { if (/^(---|\.\.\.)\s*$/.test(line)) frontmatter=false; return; }
    if (comment) { if (line.includes("-->")) comment=false; return; }
    const delimiter = line.match(/^\s{0,3}(\x60{3,}|~{3,})(.*)$/);
    if (fence) {
      if (delimiter && delimiter[1][0]===fence[0] && delimiter[1].length>=fence.length && !delimiter[2].trim()) fence="";
      return;
    }
    if (delimiter) { fence=delimiter[1]; return; }
    if (/^\s*<!--/.test(line)) { comment=!line.includes("-->"); return; }
    const task = parseLine(line,path,i);
    if (task) tasks.push(task);
  });
  return tasks;
}
export function draftOf(task?: Task): Draft {
  return {title:task?.title??"",category:task?.category??"",project:task?.project??"",
    priority:task?.priority??"",due:task?.due??"",time:task?.time??""};
}
export function validateDraft(draft: Draft): Draft {
  const value = {...draft,time:draft.time??"",title:draft.title.trim(),category:draft.category.trim().replace(/ +/g,"_"),
    project:draft.project.trim().replace(/ +/g,"_")};
  if (!value.title || /[\r\n\0]/.test(value.title) || value.title.length>1000)
    throw new Error("请输入 1–1000 字的单行任务内容。");
  for (const field of [value.category,value.project]) {
    if (field && (field.length>100 || !/^[\p{L}\p{M}\p{N}_-]+(?:\/[\p{L}\p{M}\p{N}_-]+)*$/u.test(field)
      || !/[\p{L}_-]/u.test(field))) throw new Error("分类和项目需使用有效的标签名称。");
  }
  if (!priorities.some(p=>p===value.priority)) throw new Error("优先级无效。");
  if (value.due && !validDate(value.due)) throw new Error("截止日期无效。");
  if (value.time && (!value.due || !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value.time)))
    throw new Error("请先选择截止日期，再设置有效时间（00:00–23:59）。");
  return value;
}
export function safePath(value: string): string {
  const parts = value.trim().replace(/\\/g,"/").replace(/\/+$/,"").split("/");
  if (parts.some(p=>!p || p==="." || p===".." || /[:*?"<>|\x00-\x1F]/.test(p) || p.startsWith(".") || /[. ]$/.test(p) ||
    /^(?:CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i.test(p)))
    throw new Error("请输入库内相对路径。");
  return parts.join("/");
}
function tagValue(field: "category"|"project", value: string, source?: Task): string {
  const pattern = field==="category" ? /^(分类|category|cat)$/i : /^(项目|project)$/i;
  const namespace = source && tagsIn(source.body).find(m=>pattern.test(m[2]))?.[2];
  return value ? "#"+(namespace || (field==="category" ? "分类" : "项目"))+"/"+value : "";
}
export function renderLine(draft: Draft, globalTag: string, old?: Task, id?: string): string {
  const d = validateDraft(draft);
  if (old && Object.keys(d).every(k=>d[k as keyof Draft]===old[k as keyof Draft])) return old.raw;
  if (old) {
    const tags=tagsIn(old.body);
    if (tags.filter(t=>/^(分类|category|cat)$/i.test(t[2])).length>1 ||
        tags.filter(t=>/^(项目|project)$/i.test(t[2])).length>1)
      throw new Error("此任务含多个分类或项目标签，请在原笔记编辑以保留全部标签。");
  }
  let title = d.title;
  if (!old && globalTag && !title.split(/\s+/).includes(globalTag)) title += " "+globalTag;
  let metadata = old?.metadata ?? "";
  metadata = metadata.replace(tag,"$1");
  const oldFlat = old?.category;
  if (oldFlat) metadata=metadata.replace(flatCategory,(full,space,name)=>name===oldFlat ? space : full);
  const legacy = d.category && Array.from((" #"+d.category).matchAll(flatCategory)).length && !title.split(/\s+/).includes("#"+d.category)
    ? "#"+d.category : "";
  if (d.due !== old?.due) metadata = metadata.replace(dateField," ");
  if (d.priority !== old?.priority) metadata = metadata.replace(
    new RegExp("(^|\\s)("+symbols+"(?=\\s|$)|\\[priority::\\s*\\w+\\s*\\])","gu"),"$1");
  if (d.time !== (old?.time??"")) metadata=metadata.replace(/\[taskhub-time::[^\]]*\]/g,"");
  const block = metadata.match(/(?:^|\s)(\^[\w-]+)\s*$/)?.[1] ?? "";
  if (block) metadata = metadata.trimEnd().slice(0,-block.length);
  return [old ? old.prefix+old.status+"]" : "- [ ]",
    title,tagValue("category",d.category,old),legacy,tagValue("project",d.project,old),
    d.priority!==old?.priority ? d.priority : "",
    d.due && d.due!==old?.due ? "📅 "+d.due : "",
    d.time && d.time!==(old?.time??"") ? "[taskhub-time:: "+d.time+"]" : "", metadata.trim(),
    id ? "^taskhub-"+id : block].filter(Boolean).join(" ");
}
export function appendLine(text: string, line: string): string {
  const eol = text.includes("\r\n") ? "\r\n" : "\n";
  return text + (text.endsWith(eol+eol) || !text ? "" : text.endsWith(eol) ? eol : eol+eol) + line + eol;
}
export function replaceLine(text: string, target: Task, replacement: string): string {
  const rows = text.split(/(\r?\n)/);
  const matches = parseNote(text,target.path).filter(t=>t.raw===target.raw);
  if (matches.length!==1) throw new Error("任务原文已变更或有相同记录，请刷新后在原笔记检查。");
  rows[matches[0].line*2]=replacement;
  return rows.join("");
}
export function deleteTaskLine(text:string,target:Task) {
  const matches=parseNote(text,target.path).filter(task=>task.raw===target.raw);
  if(matches.length!==1) throw new Error("任务原文已变更或有相同记录，请刷新后重试。");
  const rows=text.split(/(\r?\n)/);
  const index=matches[0].line*2;
  const indentation=(line:string)=>(line.match(/^[ \t]*/)?.[0]??"").replace(/\t/g,"    ").length;
  for(let next=index+2;next<rows.length;next+=2){
    if(!rows[next].trim()) continue;
    if(indentation(rows[next])>indentation(rows[index])) throw new Error("该任务下有子任务或缩进正文，请先在原笔记处理后再删除。");
    break;
  }
  rows.splice(index,2);
  return rows.join("");
}
export function finished(task: Task): boolean {
  return /[xX]/.test(task.status) || /(?:^|\s)(?:❌\s*\d{4}-\d{2}-\d{2}|\[cancelled::\s*\d{4}-\d{2}-\d{2}\s*\])/u.test(task.metadata);
}
export function completionStamp(task:Task): string {
  const day=task.metadata.match(/✅\s*(\d{4}-\d{2}-\d{2})|\[(?:completion|done)::\s*(\d{4}-\d{2}-\d{2})\s*\]/u);
  const date=day?.[1]??day?.[2];
  if(!date) return "";
  const time=taskField(task,"completed-time");
  return /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(time)?date+" "+time:date;
}
export function completionLine(task: Task, today: string, time=""): string {
  if (task.recurring || ![" ","x","X"].includes(task.status) || /❌|\[cancelled::/u.test(task.metadata))
    throw new Error("请在原笔记通过 Tasks 修改循环任务或自定义状态。");
  const body = task.body.replace(/(?:^|\s)(?:✅\s*\d{4}-\d{2}-\d{2}|\[(?:completion|done)::\s*\d{4}-\d{2}-\d{2}\s*\]|\[taskhub-completed-time::[^\]\r\n]*\])/gu,"");
  const suffix = task.raw.slice(task.prefix.length+2,task.raw.length-task.body.length);
  if (finished(task)) return task.prefix+" ]"+suffix+body;
  const tail = body.match(/\s+(?=<!-- taskhub-id:|\^[\w-]+\s*$)/)?.index ?? body.length;
  const stamp=time?" [taskhub-completed-time:: "+time+"]":"";
  return task.prefix+"x]"+suffix+body.slice(0,tail)+" ✅ "+today+stamp+body.slice(tail);
}
function key(text: string) { return clean(text.normalize("NFKC")).toLowerCase(); }
export function isDuplicate(tasks: Task[], draft: Draft, globalTag: string, exclude?: Task): boolean {
  const titleKey = (title: string) => key(title.split(/\s+/).filter(t=>!globalTag || t!==globalTag).join(" "));
  return tasks.some(t=>!finished(t) && !(exclude && t.path===exclude.path && t.line===exclude.line)
    && titleKey(t.title)===titleKey(draft.title) && key(t.category)===key(draft.category)
    && key(t.project)===key(draft.project) && t.due===draft.due && (t.time??"")===(draft.time??""));
}
export function filterTasks(tasks: Task[], query: Query, today: string, nowTime=""): Task[] {
  return tasks.filter(t=>{
    const scope=query.scope??"全部";
    if (scope==="已完成" ? !finished(t) : finished(t)) return false;
    if (scope==="今天" && t.due!==today) return false;
    if (scope==="逾期" && (!t.due || t.due>today || (t.due===today && (!t.time || t.time>=nowTime)))) return false;
    if (scope==="收集箱" && (t.project || (t.category && !/^(inbox|收集箱|收件箱|未分类)$/i.test(t.category)))) return false;
    if (scope==="项目" && !t.project) return false;
    return (!query.category || key(t.category)===key(query.category)) &&
      (!query.project || key(t.project)===key(query.project)) &&
      (!query.priority || (query.priority==="none" ? !t.priority : t.priority===query.priority)) &&
      (!query.search || key(t.body).includes(key(query.search)) || completionStamp(t).includes(key(query.search).trim()));
  }).sort((a,b)=>(query.scope==="已完成"?completionStamp(b).localeCompare(completionStamp(a)):0) || (a.due||"9999").localeCompare(b.due||"9999") ||
    (a.time||"23:59").localeCompare(b.time||"23:59") ||
    ["🔺","⏫","🔼","","🔽","⏬"].indexOf(a.priority)-["🔺","⏫","🔼","","🔽","⏬"].indexOf(b.priority));
}
export function parseQuery(source: string): Query {
  const q: Query = {};
  for (const row of source.split(/\r?\n/)) {
    if (!row.trim()) continue;
    const m = row.match(/^\s*(scope|category|project|priority|search)\s*:\s*(.*?)\s*$/);
    if (!m) throw new Error("不支持的查询条件："+row);
    if (m[1]==="scope" && !scopes.includes(m[2] as Scope)) throw new Error("未知任务视图："+m[2]);
    if (m[1]==="priority" && m[2]!=="none" && !priorities.some(p=>p===m[2])) throw new Error("未知优先级："+m[2]);
    Object.assign(q,{[m[1]]:m[2]});
  }
  return q;
}
export function parseCapture(text: string): Capture {
  if (text.length>16000) throw new Error("录入数据太长。");
  const raw = JSON.parse(text.replace(/^\uFEFF/,""));
  if (!raw || raw.version!==1 || typeof raw.id!=="string" || !/^[a-z0-9-]{8,80}$/.test(raw.id) ||
      typeof raw.source!=="string" || !raw.task || typeof raw.task.title!=="string")
    throw new Error("录入数据格式无效。");
  const fields = {title:raw.task.title,category:raw.task.category??"",project:raw.task.project??"",
    due:raw.task.due??"",priority:raw.task.priority??"",time:raw.task.time??""};
  if (Object.values(fields).some(v=>typeof v!=="string")) throw new Error("录入字段必须为文本。");
  return {version:1,id:raw.id,source:raw.source,task:validateDraft(fields)};
}

