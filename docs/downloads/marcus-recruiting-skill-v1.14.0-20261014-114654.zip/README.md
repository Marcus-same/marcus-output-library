# Marcus recruiting skill · 分享版首次使用

这是通用流程包，不是作者招聘工作区的备份。包含六个招聘 Skill、执行脚本、空白模板；没有作者的公司背景、岗位画像、候选人、台账记录、简历、截图、日报、账号、登录态或个人配置。

## 1. 解压并打开

将 ZIP 解压到自己选择的文件夹，例如 `D:\projects\my-recruiting-kit`。使用支持本地文件和命令执行的 AI 工具打开该目录，告诉它：

> 请阅读 AGENTS.md 和 skills/recruit-init/SKILL.md，帮我初始化一个全新的招聘工作区，放到我指定的目录。不导入作者历史数据，安装依赖或修改浏览器设置前先询问我。

普通网页版聊天仅上传 ZIP 不等于安装，必须提供实际本地文件与浏览器执行能力。

## 2. 创建自己的空白工作区

初始化需要 Node.js 22 或以上，安装 Node 属于使用者自行确认的系统变更。本包不自动安装全局依赖。
在解压目录运行（Windows PowerShell、macOS/Linux 终端均可）：

```text
node skills/recruit-init/scripts/init-workspace.mjs --workspace "D:\projects\my-recruiting-workspace"
```

macOS/Linux 将目标替换成自己选择的绝对路径。脚本创建空白标准手册、只有表头的台账、目录和六个 Skill，并尝试注册项目级链接；已有文件一律保留，不覆盖，也不删除。链接失败会报告，仍可让 AI 读取根目录 AGENTS.md。脚本不联网、不启动浏览器、不发消息。

之后在 AI 工具里打开**目标工作区**。先说“新开岗位”，填写自己的公司背景、岗位标准和 BOSS 发布岗位绑定，再说“处理今天的招聘”。没有岗位标准不能筛人，打招呼须另行授权。

## 3. 配置 BOSS 浏览器依赖（首次一次）

BOSS 主路径使用 [web-access 原项目](https://github.com/eze-is/web-access)。它是第三方依赖，不是第七个招聘业务模块。本包不附带作者安装目录、配置文件或浏览器历史。

已安装 web-access 的用户优先复用。未安装者经确认后在目标工作区执行：

```text
node skills/recruit-init/scripts/install-web-access.mjs --workspace "." --install
```

该脚本从原项目固定提交 `2c8bf0e1c7b9a60ae9689112002eb256c86bbfbe` 下载明确列出的公开源文件到 `skills/web-access`，没有全局安装；已有同名文件保留，不升级或覆盖。网络不通会报错，此时离线岗位梳理仍可使用，但 BOSS 操作未就绪。安装后再次运行初始化命令，将依赖注册到项目级发现目录。第三方依赖保留原作者与授权标记，使用前需阅读其 SKILL.md。

使用者自行登录 Chrome 或 Edge 的 BOSS 招聘者网页，并授权 AI 复用该标签页。启用浏览器远程调试是配置变更，需先确认；根据 web-access 探针与浏览器实际提示操作，不关闭已有标签页、不暴露调试端口到公网、不改变 VPN。

在运行下列检查前，先允许首次生成本机 `config.env`；单次浏览器选择用参数，不需写持久偏好：

```text
node skills/web-access/scripts/check-deps.mjs --browser chrome
```

如使用 Edge，将 chrome 换成 edge。此命令可能启动本地 CDP Proxy；默认仅监听本机 3456 端口。检查 `/health`、`/targets` 后，绑定使用者已登录的 BOSS 标签页，所有招聘步骤复用同一 targetId。没有登录或出现安全验证时停止，不能绕过验证或伪造完成。

浏览器自动化可能触发平台风控，无法保证零风险。只对文字复筛后的合适人选按需截图；发送必须确认身份、岗位与授权，结果未知不自动重发。

## 4. 可选能力与更新

- 猎聘 CLI 仅在使用者选择猎聘渠道后，经确认运行原安装脚本；BOSS 普通推荐路径不要求 Boss CLI。
- 不连接飞书，不要求 lark-cli。PDF/Word 简历的读取能力由所用 AI 工具提供；无法读取时先报告缺失，不假装已看过。
- 升级时先备份，更新流程文件但保留自己的 CONTEXT.md、JD、台账、候选人和 runtime 数据。初始化脚本只是补缺，不是升级工具；已有 Skill 不会被静默替换。
- 默认不向作者的网站、仓库或账号同步任何招聘数据。首次使用需联网下载第三方依赖，日常招聘需使用者自己的平台账号和浏览器权限；这不是免配置的独立桌面软件。
