import fs from 'node:fs';
import path from 'node:path';

const revision = '2c8bf0e1c7b9a60ae9689112002eb256c86bbfbe';
const files = ['SKILL.md', 'scripts/check-deps.mjs', 'scripts/cdp-proxy.mjs', 'scripts/browser-discovery.mjs', 'scripts/find-url.mjs', 'scripts/match-site.mjs', 'references/cdp-api.md', 'references/migration-2.5.3.md', 'templates/config.env.template'];

async function main() {
  const args = process.argv.slice(2);
  if (args.length !== 3 || args[0] !== '--workspace' || args[2] !== '--install') {
    throw new Error('After user approval: node install-web-access.mjs --workspace <directory> --install');
  }
  if (Number(process.versions.node.split('.')[0]) < 22) throw new Error('Node.js 22+ is required');
  const workspace = path.resolve(args[1]);
  if (!fs.existsSync(path.join(workspace, 'AGENTS.md')) || !fs.existsSync(path.join(workspace, 'CONTEXT.md'))) {
    throw new Error('Initialize the workspace first');
  }
  const root = path.join(workspace, 'skills/web-access');
  function assertParents(directory) {
    const parent = path.dirname(directory);
    if (parent !== directory) assertParents(parent);
    try {
      const info = fs.lstatSync(directory);
      if (info.isSymbolicLink() || !info.isDirectory()) throw new Error(`Unsafe directory: ${directory}`);
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  assertParents(root);
  const missing = files.filter(file => {
    try { fs.lstatSync(path.join(root, file)); return false; }
    catch (error) { if (error.code !== 'ENOENT') throw error; return true; }
  });
  // Fetch all missing files before writing; failures never create a half-downloaded SKILL.md.
  const downloaded = await Promise.all(missing.map(async file => {
    const response = await fetch(`https://raw.githubusercontent.com/eze-is/web-access/${revision}/${file}`, { signal: AbortSignal.timeout(20000) });
    if (!response.ok) throw new Error(`${file}: HTTP ${response.status}`);
    return { file, content: await response.text() };
  }));
  for (const item of downloaded) {
    const destination = path.join(root, item.file);
    assertParents(path.dirname(destination));
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    fs.writeFileSync(destination, item.content, { encoding: 'utf8', flag: 'wx' });
  }
  console.log(JSON.stringify({ revision, root, installed: missing, preserved: files.filter(file => !missing.includes(file)), next: 'Re-run init-workspace.mjs to register project skills. Browser configuration and config.env creation need separate approval.' }, null, 2));
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
