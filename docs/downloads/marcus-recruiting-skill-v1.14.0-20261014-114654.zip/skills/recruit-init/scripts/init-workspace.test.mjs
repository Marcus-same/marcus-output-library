import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import test from 'node:test';
import { initWorkspace } from './init-workspace.mjs';

test('creates blank workspace, then preserves existing recruitment data', () => {
  const base = process.env.RECRUIT_TEST_ROOT;
  assert.ok(base && path.isAbsolute(base), 'Set RECRUIT_TEST_ROOT to an isolated absolute test directory');
  fs.mkdirSync(base, { recursive: true });
  const target = fs.mkdtempSync(path.join(base, 'blank-'));
  const first = initWorkspace(target);
  const ledger = path.join(target, '02-sourcing/dedup-ledger.csv');
  assert.equal(fs.readFileSync(ledger, 'utf8').trim().split(/\r?\n/).length, 1);
  assert.match(fs.readFileSync(path.join(target, 'CONTEXT.md'), 'utf8'), /待填写/);
  assert.equal(fs.readdirSync(path.join(target, 'skills')).length, 6);
  assert.equal(fs.readdirSync(path.join(target, 'runtime/reports')).length, 0);
  assert.doesNotMatch(fs.readFileSync(path.join(target, 'AGENTS.md'), 'utf8'), /marcus-output-library/);
  assert.ok(first.created.length > 0);
  const marker = 'test-owned-content';
  fs.writeFileSync(ledger, marker);
  const second = initWorkspace(target);
  assert.equal(fs.readFileSync(ledger, 'utf8'), marker);
  assert.equal(second.created.length, 0);
  assert.equal(second.links.length, 0);
  console.log(`Test artifacts retained: ${target}`);
});
