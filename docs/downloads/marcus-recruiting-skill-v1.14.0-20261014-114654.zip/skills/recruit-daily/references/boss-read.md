# BOSS 卡片、文字与按需截图

执行前读 `boss-recommend-integration.md` 和 `boss-browser.md`。标准来自 CONTEXT 与对应岗位内部笔记，面板来自 `<role>.boss-profile.json`。

1. 在推荐 iframe 读取 `.candidate-card-wrap` 的可见文本和页面已有的稳定身份标识；序号只能用于当前页面诊断，不得当候选人身份。去重计数按不同候选人累计，不能只看 DOM 数量。
2. 按浅到深逐批筛选：方向 → 可见硬门槛 → 命脉信号 → 排除信号。薪资只记录。
3. 初筛入选者先执行 `../scripts/batch-read-resume.mjs <targetId> --names-file=<UTF-8名单> --json`；同名歧义先待确认。默认禁止切换入口找人。
4. truncated=true 时用 --chars=0 补读完整右侧文字。右侧文字不等于 canvas 项目全文，缺少项目证据不能直接认定候选人没有该能力。
5. 文字确认不合适者不截图；仍有潜力且缺完整项目证据者按集成流程截图，证据立即保存到本地台账。无每日截图数字上限，不进行全池截图或无目的重复截图。
6. 扩池使用 `../scripts/human-scroll.mjs`，分步滚动并记录新增身份。脚本累计 DOM 张数不能代替去重扫描数。
7. 普通推荐停止与进入精选的闸门见集成文档；岗位配置禁止的入口不能进入。截图失败、验证或登录异常时停止。

