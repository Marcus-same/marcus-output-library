# BOSS 推荐页授权发送

这是 recruit-daily 的发送阶段，不是另一套 skill。读取 `recovery-and-identity.md` 后按一人一事务执行。

1. 从台账冻结已初筛通过且未联系的候选人名单，核验 platform、candidateId、role、jobId；同名必须唯一，列表序号不能跨状态使用。
2. 核查本轮用户明确授权范围和人数。筛选目标、截图授权、合并 skill 的请求都不构成发送授权。
3. 每次点击前通过 `../scripts/action-log.mjs` 保存 greet_pending、稳定身份与 authorization；写入失败立即停止。
4. 在原 targetId 执行 `../scripts/greet-from-recommend.mjs <targetId> --names-file=<冻结名单UTF-8文件> --max=<授权剩余人数>`。执行脚本本身不会授予发送权限；只有上述条件全部满足才能调用。
5. 脚本按姓名绑定之前，执行者必须已用稳定 ID 核验该卡片对应冻结名单本人。页面重排、同名歧义或 ID 缺失时停止，不换人补量。
6. 真实发送使用浏览器可信鼠标事件。当前 proxy 不支持可信点击时停止，不以 DOM click 发招呼。--dry 只演练，不发送。
7. 卡片“继续沟通”等明确证据并核验本人后保存 greet_confirmed，才更新台账“已打招呼”。SUCCESS_UNCONFIRMED、超时或缺少证据均记 greet_unknown，不能计为确认成功或自动重试。
8. greet_pending/unknown 先查当前按钮或会话证据，不沿用旧授权自动重发。达到授权人数、平台额度或风控时停止。

搜索页发送由同一 daily 流程在同一 tab 执行，稳定身份核验、发送前落盘与未知结果处理完全相同；不可跨页面使用序号。
