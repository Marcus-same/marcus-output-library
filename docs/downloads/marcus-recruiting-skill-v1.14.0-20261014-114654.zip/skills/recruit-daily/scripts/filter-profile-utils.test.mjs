import assert from 'node:assert/strict';
import test from 'node:test';
import { expectedCheckedFilters, pickFilterCount, sameFilterValue, selectedTextDiff } from './filter-profile-utils.mjs';

test('筛选计数只接受筛选或筛选·N，不把筛选条件当计数', () => {
  assert.deepEqual(pickFilterCount(['筛选条件', '筛选·14']), { found: true, text: '筛选·14', count: 14 });
  assert.deepEqual(pickFilterCount(['筛选条件']), { found: false, why: 'no_button' });
});

test('不限也必须校验为零，不能跳过残留条件', () => {
  const checks = expectedCheckedFilters({
    activation: '不限',
    school: ['985', '211'],
    school_first_degree_only: true,
    recent_not_viewed: '不限',
    gender: '不限',
    exchange_resume_with_colleague: '不限',
    experience: ['1-3年', '3-5年', '5-10年', '10年以上'],
    degree: ['本科', '硕士', '博士'],
  });
  const expected = Object.fromEntries(checks.map((x) => [x.key, x.expected]));
  assert.equal(expected.activation, 0);
  assert.equal(expected.recentNotView, 0);
  assert.equal(expected.exchangeResumeWithColleague, 0);
  assert.deepEqual(expected.school, [1104, 1103]);
  assert.deepEqual(expected.experience, [104, 105, 106, 107]);
  assert.ok(!sameFilterValue(2504, expected.activation));
  assert.ok(sameFilterValue([1104, 1103], expected.school));
});

test('多选组同时移除残留项并补上缺项', () => {
  assert.deepEqual(
    selectedTextDiff(['1年以内', '1-3年', '3-5年', '5-10年'], ['1-3年', '3-5年', '5-10年', '10年以上']),
    { remove: ['1年以内'], add: ['10年以上'] },
  );
});
