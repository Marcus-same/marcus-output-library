const SINGLE_VALUE_MAP = {
  activation: {
    '不限': 0,
    '刚刚活跃': 2501,
    '今日活跃': 2502,
    '3日内活跃': 2503,
    '本周活跃': 2504,
    '本月活跃': 2505,
  },
  recentNotView: { '不限': 0, '近14天没有': 2301 },
  gender: { '不限': 0, '男': 1001, '女': 1002 },
  exchangeResumeWithColleague: { '不限': 0, '近一个月没有': 1301 },
};

const ARRAY_VALUE_MAP = {
  school: {
    '不限': 0,
    '双一流院校': 1102,
    '985': 1104,
    '211': 1103,
  },
  experience: {
    '不限': 0,
    '1年以内': 103,
    '1-3年': 104,
    '3-5年': 105,
    '5-10年': 106,
    '10年以上': 107,
  },
  degree: {
    '不限': 0,
    '本科': 203,
    '硕士': 204,
    '博士': 205,
  },
};

function asTexts(value) {
  if (Array.isArray(value)) return value.map(String);
  return [String(value ?? '不限')];
}

export function pickFilterCount(texts) {
  const candidates = (texts || []).map((x) => String(x || '').trim());
  const numbered = candidates.find((x) => /^筛选[·・]?\d+$/.test(x));
  if (numbered) return { found: true, text: numbered, count: Number(numbered.match(/\d+/)[0]) };
  const plain = candidates.find((x) => x === '筛选');
  if (plain) return { found: true, text: plain, count: 0 };
  return { found: false, why: 'no_button' };
}

function mapSingle(key, text) {
  const map = SINGLE_VALUE_MAP[key] || {};
  return Object.prototype.hasOwnProperty.call(map, text) ? map[text] : undefined;
}

function mapArray(key, value) {
  const map = ARRAY_VALUE_MAP[key] || {};
  const texts = asTexts(value);
  const values = texts.map((text) => map[text]);
  return values.some((x) => x === undefined) ? undefined : values;
}

export function expectedCheckedFilters(dimensions = {}) {
  return [
    { key: 'activation', expected: mapSingle('activation', String(dimensions.activation ?? '不限')) },
    { key: 'school', expected: mapArray('school', dimensions.school?.length ? dimensions.school : ['不限']) },
    { key: 'recentNotView', expected: mapSingle('recentNotView', String(dimensions.recent_not_viewed ?? '不限')) },
    { key: 'gender', expected: mapSingle('gender', String(dimensions.gender ?? '不限')) },
    { key: 'exchangeResumeWithColleague', expected: mapSingle('exchangeResumeWithColleague', String(dimensions.exchange_resume_with_colleague ?? '不限')) },
    { key: 'experience', expected: mapArray('experience', dimensions.experience?.length ? dimensions.experience : ['不限']) },
    { key: 'degree', expected: mapArray('degree', dimensions.degree?.length ? dimensions.degree : ['不限']) },
    { key: 'firstDegree', expected: dimensions.school_first_degree_only ? 999 : 0 },
  ];
}

function normalized(value) {
  if (Array.isArray(value)) return [...value].map(Number).sort((a, b) => a - b);
  return value === undefined || value === null ? value : Number(value);
}

export function sameFilterValue(actual, expected) {
  const a = normalized(actual);
  const e = normalized(expected);
  return JSON.stringify(a) === JSON.stringify(e);
}

export function selectedTextDiff(actualTexts, wantedTexts) {
  const actual = [...new Set((actualTexts || []).filter((x) => x && x !== '不限'))].sort();
  const wanted = [...new Set((wantedTexts || []).filter((x) => x && x !== '不限'))].sort();
  return {
    remove: actual.filter((x) => !wanted.includes(x)),
    add: wanted.filter((x) => !actual.includes(x)),
  };
}
